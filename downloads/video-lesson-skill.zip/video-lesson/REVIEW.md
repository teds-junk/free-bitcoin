# Review

Two passes you make yourself before the user sees anything, and how to act on the notes they send back. The lint catches what a pattern can catch. These passes catch the rest, and every item on them is here because a finished video was sent back for it.

Do each pass as its own step, with the list open. Go item by item across the whole video, not scene by scene across the list: you find more by asking one question of twenty scenes than twenty questions of one.

## Contents

- [Script pass](#script-pass) (before the approval checkpoint)
- [Look pass](#look-pass) (before rendering, and again on the finished stills)
- [Acting on review notes](#acting-on-review-notes)

## Script pass

When: after the lint passes and the cold read is done, before presenting the storyboard. Read `script.md` from top to bottom once for each item.

| # | Ask of every sentence | Wrong | Right |
|---|---|---|---|
| 1 | **Does it say how long anything in the video takes?** Never state a length. | "In the next fifteen minutes you'll…" | "In this lesson, you'll run an experiment on two models." |
| 2 | **Is it an order?** The viewer is watching, not following along, and nobody stops a video to obey it. Say what we do. | "Start with what a skill is." "Now do it yourself." "Pause here and guess." "Run the command again." | "Let's start with what a skill is." "If you tried it yourself, you'd see…" "What would you expect?" (then a beat) "You'd just run it again." |
| 3 | **Does the hook use only words the viewer already has?** A promise that leans on an idea the video has not taught yet means nothing at second ten. | "…and find the difference in the files that get saved." | "…and find the differences in their behavior." |
| 4 | **Does it explain something `viewer_starts` says they know?** Explaining the basics tells an expert the video is not for them. | "The backslash at the end of a line means the command continues." (to programmers) | Cut it. |
| 5 | **Would a listener get it the first time, without seeing the script?** A sentence that quotes a label off the screen in the middle of a clause is the usual offender. | "One of one evals passed counts eval files, and you ran one." | "There's a tick for each model." Or cut it. |
| 6 | **Is the claim the size of its evidence?** Words like never, always, and impossible must be literally true. | "…evidence that trying it by hand would never have given you." | "…that would be difficult to discover for every model by hand." |
| 7 | **Does the answer have the form the question asked for?** "What does it do?" is answered with verbs. | "What does Vally do in one run?" "A workspace. An agent. A patch." | "It makes a workspace. It runs an agent. It saves a patch." |
| 8 | **Does it call a permanent fact temporary?** If something is explained later, say so once and move on. | "For now, it's a tick or a cross." "In the next few minutes it takes three things." | "What's inside the check, we'll explain later." "We'll start by giving it three things." |
| 9 | **Would the result mislead without its context?** Say what kind of case it is. | "Both models got a green tick." | "In this rudimentary eval, both models got a green tick." |
| 10 | **Is a demo narrated as something we are doing?** | "List the results folder." "Change into it." | "Let's look in the results folder." "We change into it." |
| 11 | **Does a demo show the viewer something they have already seen?** Printing a file that a file panel walked through two minutes ago adds a path to read and nothing to learn. | `cat` of the changelog, after a panel on it | Cut the command. |

Then one check of the whole script: say the hook's promise aloud, then the last stage's `viewer_can`. They should be the same thing.

## Look pass

When: after the scenes exist, on `preview.js --all <dir>` (the whole video on one sheet) and on each scene's own stills; and again on the `verify.js --frames` stills of the finished video. Open the images. A scene you have not looked at is not checked.

| # | Look for | Fix |
|---|---|---|
| 1 | **A headline over six words, or one that wraps.** | Cut words; move the rest to a `.lead` or the voice. Never change the font. |
| 2 | **A scene that looks like it came from a different video.** Code that is not in a dark box; notes that are not on its right; a table where the others use code with notes. | Rebuild it from the same parts as the rest (`SLIDES.md` → *One visual language*). |
| 3 | **Text you have to lean in to read.** Pale gray on the paper, small labels. | Use the theme's classes; never write a color. `preview.js` reports contrast under 4:1. |
| 4 | **Arrows.** For each: does something pass from the first thing to the second? | If not, remove them. A list is highlighted in turn; steps are numbered. |
| 5 | **Two marks on one object**, or a placeholder where evidence belongs. | One mark. Show the real thing. |
| 6 | **Two things highlighted at once**, or a highlight still on after the voice has left. | One highlight at a time; callouts for notes; `until` on any second channel. |
| 7 | **A note that is not level with the line it explains.** | Make it a `.callout`. |
| 8 | **A path anyone has to read**: over a panel, in a typed command, in output. Long, or naming this machine. | Shortest label; made-up short demo folder; rewrite an absolute path the tool prints (`TERMINAL-DEMOS.md` → *Paths on screen*). |
| 9 | **A file panel that shows part of a file with nothing to say so.** A partial panel has a minimap; with no room for one, its "lines hidden" rows must all be in view, or it has a scrollbar. | Regenerate the panel with `file-panel.js`; never strip the minimap from a panel that scrolls. |
| 10 | **A scene that is mostly empty, or crowded into a corner.** | Use `.stage` and `.cols`; let blocks take the width; give short blocks a `min-height`. |
| 11 | **A terminal screen that goes away before it could be read.** Count the lines of output and the seconds it stays (`sync-report.js`). | Add `"read"` to the sentence about it, about one second per line the viewer must take in. |
| 12 | **Anything personal in a terminal**: a home folder, a user name, a machine name. | `TERMINAL-DEMOS.md` → *Credentials on screen*. |
| 13 | **On-screen text that gives an order.** A line on a slide follows the same rule as the voice. "Run it again, or leave the trial out." | Say what we do: "We run it again, or leave the trial out and say so." |

## Acting on review notes

The user watched the video and sent notes, usually with timestamps. How you apply them matters as much as that you do.

1. **Look first.** Pull the frame at every timestamp before changing anything: `node <SKILL_DIR>/scripts/verify.js <dir> --at 0:56,1:43,7:22`. The note is about what was on screen at that moment, and it is often not what you assume.
2. **Fix what the note says, at the size it says it.** A note has a scope, and the scope is in its words.
   - "This headline font is terrible for so many words" is about long headlines. The fix is shorter headlines. It is not "remove the font".
   - "Needs more contrast; this applies everywhere that color is used" has said everywhere. Fix it everywhere.
   - "Say 'Let's start with…'. Don't command people" is a rule. Apply it to every sentence.
   
   When you are unsure whether a note is about one scene or all of them, apply the narrow reading and ask.
3. **Never fix a note by removing the thing it is about.** If the user disliked how something was used, use it properly. Stripping out the fonts, the highlights, or the demo to make the complaint impossible is an overcorrection, and it reads as not having listened.
4. **Do not re-open what the note did not mention.** Scenes and sentences nobody complained about stay as they are, unless a general rule from step 2 applies to them.
5. **Write each general rule down where the next video will find it.** Add it, in the user's words, to `style_notes` in `<workspace>/videos/preferences.json` (`COURSE.md`). The lint prints those notes at the top of every run, so the next lesson, and the next session, starts from them.
6. **Make a table of the notes**: the timestamp, the note in the user's words, what you changed, and the path of the new still. Every note gets a row. A note you could not act on gets a row that says why.
7. **Check each fix on the new video.** Scene times move when narration changes, so find each note's scene in `build/timeline.json`, pull the new frame with `--at`, and look at it. Do not report a note as fixed from the source alone.
8. **Report with the table**, and say what you could not check (you cannot hear the audio or watch motion).

Changed narration, visuals, or tapes go through the normal recipe in `SKILL.md` (*Recipe: change an existing video*). A note that asks for a specific wording is its own approval; a change you chose yourself to satisfy a note is listed in the report.
