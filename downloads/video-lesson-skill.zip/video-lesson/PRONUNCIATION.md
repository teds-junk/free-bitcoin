# Pronunciation

A mispronounced word takes the viewer out of the video, and you cannot hear the audio. This file is how to catch a wrong word anyway: read what the voice is going to say before it says it, check what it did say afterwards, and give the user one page of the words only an ear can settle.

## Contents

- [The three checks](#the-three-checks)
- [1. Analyze before narrating](#1-analyze-before-narrating)
- [2. The review page](#2-the-review-page)
- [3. Transcribe after narrating](#3-transcribe-after-narrating)
- [Lexicons](#lexicons)
- [Heteronyms](#heteronyms)
- [Names](#names)
- [Fixing one word](#fixing-one-word)

## The three checks

| Check | Catches | Cannot catch |
|---|---|---|
| **Analyze** (`tts.py --analyze`, run by the lint) | Words outside the voice's dictionary, whose sound is a guess from spelling; which reading a heteronym got; every lexicon entry; proper nouns | Whether a dictionary word sounds the way the user wants |
| **Review page** (`pronunciation-review.js`) | Anything, because the user listens | Nothing, but it costs the user's time, so each word is asked once per course |
| **Transcribe** (`tts.py --transcribe`) | Words the voice dropped or garbled badly enough that a listener hears a different word | A heteronym in the wrong tense, or a valid pronunciation the user does not want: the transcript is spelled the same either way |

Use all three. The first is free and runs every time; the second is where the user's ear goes; the third is a net under both.

## 1. Analyze before narrating

`lint-storyboard.js` runs the analysis and prints two lists. Run it directly for the detail:

```bash
PY <SKILL_DIR>/scripts/tts.py --analyze <video-dir>            # readable; add --json for everything
PY <SKILL_DIR>/scripts/tts.py --analyze <video-dir> --include stimuli,rubric,lint
```

It loads no voice and writes nothing, and takes a few seconds. For every word it reports where the pronunciation came from (a lexicon entry, the voice's dictionary, or a fallback guess), the phonemes, and `sounds_like`, a plain respelling you can read (`eval → "ih-VAL"`).

**Heteronyms to judge by context.** For each use of a word with two readings, the cue says which reading the voice chose and when the other applies:

```
s16 sentence 2: "Two out of three shows up as flaky, so read the count, and not only the state."
  read → "red" (past: 'she read it yesterday'; tagged VBD). The other reading is "reed" when present or base form.
```

Read the cue against the sentence. That one is wrong: "so read the count" is an instruction, so it should be "reed". You can judge every one of these without hearing anything; see *Heteronyms* for the fix. Do this for all of them: in eight finished videos the voice chose wrong in 11 of 127 uses.

**Words for the user to hear.** Each has a tier that says why it is doubtful:

| Tier | Meaning | Usual action |
|---|---|---|
| `person` | A person's name | See *Names*. Do not narrate it unconfirmed |
| `fallback` | Not in the dictionary or any lexicon; the sound is a guess | Read `sounds_like`. If it is plainly wrong, add a lexicon entry now; either way it goes on the review page |
| `identifier` | A flag, path, file name, or code identifier | Rewrite the sentence in spoken form ("the dash dash output flag") and show the identifier on screen |
| `heteronym` | Two readings | Judge by context (above); the user hears each reading once |
| `lexicon` | Said through a lexicon entry | The user hears each entry once |
| `acronym`, `number` | Letter strings, versions, symbols | Check `sounds_like`; write versions in words |
| `proper-noun` | A capitalised name of a product, place, or method | Review page |

Dictionary membership cannot find a word that is in the dictionary but said in a way the user dislikes, or the course's own jargon. Add those with `--include`, taking them from the workspace glossary, so the user hears each once.

## 2. The review page

One static page of every doubtful word, each in its real sentence from the script, for the user to click through. Build it once the storyboard is approved and before narrating; for a course, build one page for all the videos so each word appears once.

```bash
node <SKILL_DIR>/scripts/pronunciation-review.js <video-dir> --open
node <SKILL_DIR>/scripts/pronunciation-review.js --course <workspace>/videos --open
node <SKILL_DIR>/scripts/pronunciation-review.js <video-dir> --alt "dir=dur|deer|/dˈɪɹ/" --include stimuli,rubric --open
```

- Each card shows the word, why it is doubtful, what the voice will say, what the transcript heard (if there is one), and a play button on the real sentence. A word is auditioned in its real sentence because an invented one can change how it is said.
- `--alt "word=first|second|/phonemes/"` puts alternatives side by side, so the user picks one instead of describing a sound. Offer alternatives for any word you already suspect.
- A heteronym gets a card per sentence, since the same reading can be right in one and wrong in the next.
- **The user listens on the page, in the browser.** Build the page even for one word and open it with `--open`. Do not hand the user a WAV in the system media player (`open file.wav`, `--play`): one user asked for the page instead after exactly that.
- The user marks each card "sounds right" or "sounds wrong", adds a note if they like, and copies or downloads the results. Ask them to give you the file or paste its contents.

Record the answers:

```bash
node <SKILL_DIR>/scripts/pronunciation-review.js --import <results.json> --course <workspace>/videos --apply
```

Approved words go into `<workspace>/videos/pronunciation-ledger.json`, and from then on the analysis leaves them out, so the user never reviews a word twice.

**Roll pronunciations forward; never ask about the same word twice.** A word the user has already heard is settled for every later video in the workspace, whether or not the ledger recorded it. That covers a word narrated in a video the user watched and approved (`approval.style_approved`, or any finished video they accepted), and every entry in the workspace lexicon that such a video used. Before building a page for a new video:

1. Run `tts.py --analyze <video-dir> --json` and take the doubtful list.
2. For each word on it, search the narration of the workspace's approved videos (`<workspace>/videos/*/storyboard.json`). If the word was spoken there with the same pronunciation (the same lexicon entry, or no entry in both), it is settled.
3. Record the settled words in the ledger yourself: write a results file with `"verdict": "right"` and a note naming the video it rolled forward from, and import it with `--import <file> --by agent`. Then build the page.

The page that reaches the user holds only words they have never heard, and words whose pronunciation changed since they heard them. If that leaves nothing, there is no page: say so in the checkpoint and go on. A word comes back only if its pronunciation changes. `--apply` writes the alternatives the user chose into the workspace lexicon. The command prints the words marked wrong, with the notes: fix each (below), then rebuild the page with only those words for a second pass.

Done when: the import reports nothing wrong and nothing unanswered.

## 3. Transcribe after narrating

After `tts.py <video-dir>` has made the clips:

```bash
PY <SKILL_DIR>/scripts/tts.py --transcribe <video-dir>
```

It needs the speech-to-text model (`node <SKILL_DIR>/scripts/setup.js --yes --stt`, about 150 MB, stored in `~/.video-lesson/models/`; ask the user before the first download). It writes `audio/transcript.json` and prints the sentences where what was heard differs from the script, after allowing for respellings and numbers, plus `by_word`: for each word, in how many of its sentences it was misheard.

Read `by_word` first. A word misheard nearly every time is mispronounced ("eval" heard as "a vowel" in 8 of 11 sentences); a word misheard once in twenty is usually the transcriber's own error. Fix the first kind and rebuild the review page with those words. Re-running is cheap: transcripts are cached per clip.

## Lexicons

A lexicon maps a word to how it should be said. It changes only the text sent to the voice; the narration and the captions keep the real spelling. So a pronunciation is never fixed by respelling the word in `storyboard.json`.

**Where they live (later wins):**
1. `<SKILL_DIR>/assets/pronunciations.json`: global (JSON, YAML, LLM, jq, …).
2. `<workspace>/videos/pronunciations.json`: this workspace or course. Create it when the first course-specific term comes up.
3. `<video-dir>/pronunciations.json`: one video only (rare).

```json
{
  "Vally": "Valley",
  "kubectl": "cube control",
  ".jsonl": "dot jay-son-ell",
  "output dir": "output dur",
  "they read": "they reed",
  "Kokoro": "/kˈOkəɹO/",
  "tomato": { "us": "/təmˈAɾO/", "gb": "/təmˈɑːtQ/" },
  "=IT": "I T"
}
```

- **Keys match whole words in any letter case.** `"yaml"` covers yaml, Yaml, and YAML. When two keys differ only by case, the one spelled like the text wins.
- **`=` in front of a key matches that exact case only**, for an acronym that is also an ordinary word (`=IT`, `=US`).
- **A key may be several words** (`"output dir"`, `"they read"`), and may start with punctuation: `".jsonl"` turns `results.jsonl` into "results dot jay-son-ell".
- **Respelling first:** easy to read, and right most of the time. Check the result with `--analyze --say "<sentence>"`: read `sounds_like` before asking anyone to listen.
- **Phonemes** (`/…/`) when respelling fails. They use the voice's own alphabet, not strict IPA. Shared: `ˈ ˌ` (stress), consonants `b d f h j k l m n p s t v w z ɡ ŋ ɹ ʃ ʒ ð θ ʤ ʧ`, vowels `ə i u ɑ ɔ ɛ ɜ ɪ ʊ ʌ`, diphthongs `A`=eɪ `I`=aɪ `W`=aʊ `Y`=ɔɪ. US only: `æ O`(=oʊ) `ᵻ ɾ`. GB only: `a Q`(=əʊ) `ɒ ː`. A wrong symbol is dropped silently; `tts.py` warns about symbols outside the set.
- A value of `null` in a later lexicon removes an earlier entry: "say it as written".
- Keys starting with `_` are comments.

## Heteronyms

Words with two readings: read, live, lead, record, use, close, present, separate, reject, and several hundred more. The voice picks a reading from the word's part of speech in the sentence, and gets it wrong often enough to check every one. A known weakness: plural present-tense "read" ("they read the file", "four read the outcome") is spoken as the past, "red".

When a cue shows the wrong reading:

1. **Rewrite the sentence** so the word is unambiguous or gone: "so check the count", "two tags note which side". This is the most reliable fix, and it is a wording change, so show it to the user unless the workspace preferences allow small rewordings.
2. Or add a **lexicon phrase** that pins the reading in that context: `"they read": "they reed"`, `"to record": "to ri-KORD"`. Keep phrases narrow; a bare `"read"` entry would break every other use.
3. Run the analysis again and confirm the cue.

Record your judgement of each remaining use so it is not raised again: `pronunciation-review.js --heteronyms <video-dir>` prints a results skeleton with every heteronym sentence; fill in right or wrong for each from the cue, and import it with `--import <file> --by agent`. Your judgement covers context only. The user still hears each reading once on the review page.

## Names

Do not let the voice speak a real person's name until the user has confirmed how it is said. A guessed name is the mispronunciation people notice most.

- **List every real person the narration names** in the storyboard: `"people": ["Ada Lovelace"]`. You are the only reliable detector; the analysis's own name recognition misses surnames used as terms ("the Wilson interval") and flags words that are not names.
- A listed name that the user has not approved on the review page is a lint error. A lexicon entry alone does not confirm it.
- **The default is to write around the name**: show it on screen and say who they are ("the paper's author", "the team that built it"). Narrate a name only when the video needs it, and then put it on the review page, with alternatives if you can guess them.
- Product, company, and method names (the `proper-noun` tier) are not errors, but the user should hear each once.

## Fixing one word

When the user reports a word, or the review page marks one wrong:

1. Hear it as it is, and read what the voice does with it:
   ```bash
   PY <SKILL_DIR>/scripts/tts.py --analyze --say "Run Vally on it." --video <video-dir>
   PY <SKILL_DIR>/scripts/tts.py --say "Run Vally on it." --video <video-dir> --play
   ```
   Pass `--video` so the video's own lexicons, voice, and speed apply. `--play` and the WAV path are for a quick check the user asked for; when the user is the one who must listen, put the sentence on the review page (above) and open that.
2. Add a respelling to the workspace lexicon, check `sounds_like` with `--analyze --say`, then audition again. If respelling cannot get there, use phonemes.
3. When the user approves, re-run `tts.py <video-dir>` for every video in the workspace that uses the word (only sentences containing it are re-synthesized), then `render-scenes.js <dir> --no-record` and `assemble.js <dir>`.

Two things the voice does that are worth knowing: it can swallow or blur a short sentence-opening word: "A", "The" and "We'll" go missing ("We'll run" was heard as the order "Run"), and "And error" comes out as "An error". The transcript check shows these as a missing or different first word; fix them by opening with a firmer word that keeps the meaning ("First, we'll run", "This grader", "Finally, error means"), re-narrate, and re-check, and it spells out an all-capitals word it does not know, which is right for CLI and API and wrong for JSON and YAML.
