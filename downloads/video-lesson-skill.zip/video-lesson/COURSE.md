# Course mode

Making videos for several lessons of one workspace. The user settles the style once, on the first video, and then approves the rest as one batch instead of sitting through the same checkpoints eight times. Preferences that hold for the whole workspace live in one file, so nothing has to be asked twice.

## Workspace files

Everything shared by a workspace's videos sits in the videos folder, next to the video folders:

| File | Holds |
|---|---|
| `preferences.json` | Voice, output folder, demo policy, spend budget, approval state, and the user's standing notes (`style_notes`) |
| `pronunciations.json` | The workspace lexicon (`PRONUNCIATION.md`) |
| `pronunciation-ledger.json` | Words the user has already heard and approved, so they are not reviewed again |
| `spend-log.json` | What each recording cost |
| `_demo/` | Saved start states and real results for the terminal demos, for what the course's own `practice-starter/` and `verified/` folders do not provide (`TERMINAL-DEMOS.md`) |
| `<lesson-stem>/<lesson-stem>.mp4`, `poster.png` | A finished lesson video and its poster. A teach-me lesson page shows them by itself once they exist here |
| `course/` | The combined course video (`COMPILATION.md`) |
| `auditions/` | Voice samples and the pronunciation review page |

## preferences.json

Create it the first time a workspace gets a video. Ask the user for the values in one batch, each with the recommended answer shown here, and write the file. Every script reads it; a field left out takes the default.

```json
{
  "voice": { "voice": "am_echo", "speed": 1.2 },
  "output_dir": "videos",
  "demos": { "record_real_runs": true, "credentials": "scan", "perform_checkpoint": true },
  "spend": { "budget": 60, "unit": "agent runs" },
  "bridging_sentences": "allowed",
  "approval": { "style_approved": null, "batch": true },
  "style_notes": [
    "Never say how long the video is. Prefer: In this lesson, you'll …",
    "Don't command the viewer. Say: Let's start with …",
    "Made-up short paths on screen (~/src/demo), never paths from my machine."
  ]
}
```

| Field | Meaning | Default |
|---|---|---|
| `voice.voice`, `voice.speed` | Narrator and speed for every video. Offer the voice sample page (`NARRATION.md`) before fixing it. A storyboard's own `voice` block overrides this for one video | `am_echo`, 1.2 |
| `output_dir` | Folder for video folders, relative to the workspace root | `videos` |
| `demos.record_real_runs` | Record the real commands, including ones that need a sign-in or cost something. `false` means show such commands on a slide instead | `true` |
| `demos.credentials` | `scan`: recordings are scanned for secrets and a hit blocks the build. `forbid`: do not record anything that needs credentials | `scan` |
| `demos.perform_checkpoint` | Perform the lesson's exercise on screen in the `practice` scene | `true` |
| `spend.budget`, `spend.unit` | The most that recording may cost across the workspace, in the unit the tapes declare. `null` means ask each time | `null` |
| `bridging_sentences` | `allowed`: you may add or reword short connective sentences after approval without asking again. `ask`: show every change first | `ask` |
| `approval.style_approved` | The slug of the video whose finished result the user approved as the style for the rest. Set by you when they approve it | `null` |
| `approval.batch` | Approve the remaining videos as one batch | `true` |
| `style_notes` | The user's standing rules for every video in the workspace, in their words: one string per rule. Add to it whenever the user gives feedback that is a rule and not a one-off (`REVIEW.md` → *Acting on review notes*). The lint prints the list at the top of every run; check every scene and sentence against it before each checkpoint. Never delete a note; if the user changes their mind, replace it | `[]` |

`bridging_sentences: "allowed"` covers signposts at a change of mode, a clause of reason, and smoothing a join. It does not cover a new claim, a changed meaning, or a new command: those go back to the user. List every sentence you added or changed under this permission in the final report.

## Flow

### 1. The first video sets the style
Make it with the full workflow in `SKILL.md`, every checkpoint included. When the user has watched the finished video and approves it, write its slug to `approval.style_approved`. That approval covers voice and speed, pacing, the look, how files and terminals are shown, and how the practice scene is handled. It does not cover the content of later videos.

If the user asks for changes to the style, make them on this video until they approve (`SKILL.md` → *Recipe: apply review notes*), and write each rule they give into `style_notes` as you go, so the rest of the course starts from it. Do not start the batch against a style they have not seen finished.

### 2. Plan the rest as a batch
For each remaining video, in lesson order: plan the narrative, write the storyboard, run the lint, and run the cold read (`NARRATIVE.md`). Do not narrate or render yet.

Plan across the set, not only per video:
- Read `style_notes` first. They apply to every video in the batch.
- `viewer_starts` of each video is what the earlier videos' arcs end with. A term or command introduced in an earlier lesson still gets one reminding clause the first time a later video uses it.
- Keep one running example through the course where the lessons allow it.
- If a combined video is planned, write the bridge for each lesson boundary now, while both lessons are in view (`COMPILATION.md`).

For a teach-me course, `COURSE-PLAN.md` has done this planning: the lesson order, each lesson's Question and Win, the running example, the concept order, and each Hand-off, which is what the bridge after that lesson says. Take them from the plan. Total the plan's Time lines for the spend the batch will need, and show it against the budget at the checkpoint.

### 3. One checkpoint for the batch
Present everything the user needs to say yes once:
- Per video: the question, the arc, the estimated length, the path to its `script.md`, and what its cold read found and what you changed.
- The commands every terminal demo will type, across all videos, with what recording them will spend in total against the budget.
- One pronunciation review page for the whole course (`PRONUNCIATION.md`), each doubtful word once.
- Two or three questions that are the user's to answer.

Wait for the answer. Apply changes, re-lint, and show only what changed until they approve.

**When the user waives the storyboard checkpoint.** After a few videos a user may say the storyboards need no review as long as they follow the lesson. Record that in `approval._note` in `preferences.json`, in their words, and from then on stop only for what they kept or what the waiver cannot cover:
- a new word for the pronunciation review page (one page for the whole batch);
- a storyboard that departs from its lesson: a different order, a section left out, a claim the page does not make, a command the page does not print;
- spend that would pass the budget, or a kind of command they have not approved before.

Everything else proceeds. The lint, the cold read, the script pass, both look passes and the full review of every still are yours and are never waived. Report per video where it differs from its page and what a non-deterministic run produced.

**Authoring in parallel.** Storyboards, slides and tapes for several lessons can be written at the same time. Recordings cannot: they run one at a time, and when each lesson's demo starts from the state the previous lesson's demo left (one practice folder for the course), they run in lesson order. So plan and author ahead in parallel, and let recording and the scenes that quote a run follow in order behind.

### 4. Produce
Narrate, record, render, assemble, and verify each video. When your agent can launch subagents, share the work out as `DELEGATION.md` describes: narration in the background while you author, one production subagent per video on a cheaper model, and the full review of every finished video's stills done by you. Videos can be narrated and their slides rendered side by side, but terminal demos record one at a time: the renderer holds a machine-wide lock, so a second render waits its turn. Do not work around it; two recordings at once drop frames and can collide on the same sign-in.

Recording a tape that declares a cost needs `--allow-spend`. Pass it only for what the user approved at the checkpoint. If the running total would pass the budget, stop and ask.

### 5. One report
A table of the videos with length, path, and any verify warnings; what was spent against the budget; the sentences added under `bridging_sentences`; and what you could not check (you cannot hear the audio or watch motion). Write each video's `publish.md` as usual.

## Gotchas

- **A missing preferences file is not a reason to guess.** Ask once and write it; do not scatter defaults across storyboards.
- **A rule the user gave once is a rule for every video.** Notes on the first video that were not written into `style_notes` get broken again in the second.
- **The course look is the skill's theme.** Do not add a stylesheet for the course; every video's scenes use `_theme/theme.css` and the layouts.
- **Style approval is for a finished video, not a storyboard.** The user cannot judge voice and pacing from a table.
- **A batch is approved as a whole, and can be rejected in part.** If the user rejects one video's plan, hold only that one and carry on with the rest.
- **Changing the workspace voice later** means re-narrating every video that has no `voice` block of its own: run the narration, render, and assemble steps for each.
