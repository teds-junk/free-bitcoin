---
name: video-lesson
description: >-
  Makes YouTube-quality narrated tutorial videos locally on an Apple Silicon Mac:
  slides, real files, recorded terminal demos, a natural voiceover, captions, and
  chapters. Works from a teach-me lesson, a whole course, a document, or a topic.
  Joins finished lessons into one course video and re-narrates its own videos.
  Use when: "make a video of lesson 3", "turn this teach-me lesson into a video",
  "make videos for the whole course", "make an explainer/tutorial video on X",
  "narrate this doc as a video", "add a voiceover to lesson 2", "combine the lesson
  videos into one long video", or fixing a video this skill made: a mispronounced
  word, re-voicing, re-wording, or a video that is hard to follow.
  Do NOT use for authoring or teaching text lessons (use `teach-me`), browser GIFs
  or screen recordings (use `claude-in-chrome`), slide decks without video (use
  `pptx`), editing or captioning footage the user recorded, writing only a script
  or thumbnail for some other video, or music and non-instructional video.
---

# Video Lesson

Turn a lesson, document, or topic into a narrated 1080p tutorial video in the **Solarized Technical Essay** style. A good video takes the viewer on a journey: they always know whether they are being shown how a thing works, how to think about it, or how to use it; nothing runs before it has been explained; and what they see is the real file and the real command. The story is planned first, the audio is made before the pictures, and nothing renders until the user approves.

**Requires macOS on Apple Silicon** (narration runs on MLX). `prereqs.js` checks this.

Paths in this skill are relative to the directory that contains this SKILL.md, written `<SKILL_DIR>` in commands. `PY` stands for `~/.video-lesson/venv/bin/python`; substitute it before running. `<workspace>` is the course root (for teach-me, the folder with `COURSE-PLAN.md` and `lessons/`), or the current directory for other sources. Files shared by a workspace's videos (`preferences.json`, `pronunciations.json`, `_demo/`) sit in `<workspace>/videos/`, next to the video folders.

## Ground rules

- **Nothing renders before approval.** Step 6 (story, script, and storyboard) and step 7's command review are stops, because rendering and recording cost time and sometimes money.
- **Edit `storyboard.json` only.** `script.md` is generated from it by the lint, so what the user approves is exactly what gets spoken.
- **Run the scripts.** Do not hand-write ffmpeg pipelines, captions, chapter lists, file panels, or timing; each has a script that gets it right every time.
- **Say the goal of each command, or burst of commands, in one line before running it.**
- **Leave version control alone.** Do not commit; tell the user what is ready.
- **The user's request and the workspace preferences outrank the defaults here.** The lint prints the user's standing notes for the workspace (`style_notes`) at the top of every run: read them every time.
- **The viewer is watching, not following along.** Never tell them to pause, type, or try something, and never say how long the video is. Say what we do: "Let's start with…", "First, we check…", "If you tried it yourself, you'd see…".
- **The look is built; do not redesign it.** Start every scene from a layout, use the theme's classes, and add no stylesheet, font, or color of your own. A headline is six words or fewer. If something looks wrong, there are too many words in it.
- **Show the real thing, and leave it up long enough to read.**
- **Look at what you made.** Open the stills at every step that produces them. A scene you have not looked at is not checked.

## Workflow

### 1. Check prerequisites
Run `node <SKILL_DIR>/scripts/prereqs.js`. If a required tool is missing, show its install line and stop. If the narration environment is not set up, ask the user (it downloads several GB), and only after they agree run `node <SKILL_DIR>/scripts/setup.js --yes` (add `--manim` if manim scenes are planned, `--stt` for the pronunciation transcript check). `setup.js` refuses to run without `--yes`.

Done when: `prereqs.js` reports `"ok": true` and `"venv": true`.

### 2. Pick the mode
| The user wants | Go to |
|---|---|
| One new video | Step 3 |
| Videos for several lessons of a course | `COURSE.md`, which runs steps 3–11 for the first video and then batches the rest |
| A change to an existing video | *Recipe: change an existing video* |
| The user watched a video and sent notes on it | *Recipe: apply review notes* |
| A pronunciation fix | *Recipe: fix a pronunciation* |
| A different voice | *Recipe: change the voice* |
| One combined video from finished lessons | `COMPILATION.md` |

### 3. Settle preferences and the output folder
Read `<workspace>/videos/preferences.json` if it exists. If it does not and this workspace will have more than one video, create it now (`COURSE.md` → *preferences.json*). Resolve the output folder to an absolute path: for a teach-me lesson `<workspace>/videos/<lesson-file-stem>/` (the lesson page shows `<lesson-file-stem>.mp4` and `poster.png` from that folder by itself, so keep the name); otherwise `./videos/<slug>/`. Ask "Save the video to `<absolute path>`, or somewhere else?" and wait for the answer, unless the preferences already fix it. Then scaffold:
```bash
node <SKILL_DIR>/scripts/new-video.js --out <dir> --title "<title>" [--source <lesson.html>] [--lesson <n>]
```

### 4. Plan the story
Read `NARRATIVE.md`. Read the source (for teach-me: the lesson's entry in `COURSE-PLAN.md`, the lesson page, `MISSION.md`, `NOTES.md`; `STORYBOARD.md` → *Reading the source* lists what each holds). Fill in `narrative` in `storyboard.json`: the question the video answers, where the viewer starts, and an arc of two to five stages with what the viewer can do after each. A teach-me plan already states the lesson's question, its sections with their modes, and its win: use them.

Done when: you can say the arc in one breath as "first you'll be able to…, which lets you…, so that finally you can…".

### 5. Write the storyboard
Read `STORYBOARD.md`. Write the scenes: a hook, then for each stage scenes that each have one `mode` (think, works, or use), a `role`, a renderer and layout, an `on_screen` description, what the scene `introduces`, and narration (one sentence per item). Explain every command and file before it appears, and set demos up correctly the first time. Narrate demos as something we are doing, never as instructions to the viewer. Do not write `script.md` by hand.

### 6. Checkpoint: get approval
1. Run `node <SKILL_DIR>/scripts/lint-storyboard.js <dir>` (it regenerates `script.md`). Fix every error. Read the mode sequence and the *Explained before shown* list it prints as a viewer would.
2. Do the cold read (`NARRATIVE.md` → *Cold read*) and fix what it finds.
3. Do the script pass (`REVIEW.md` → *Script pass*): eleven questions asked of every sentence. Fix what it finds and re-run the lint.
4. Judge every heteronym the lint lists against its cue, and reword any sentence where the voice would pick the wrong reading (`PRONUNCIATION.md` → *Heteronyms*). Do it now, because a rewording is something the user approves.
5. Present, in plain language:
   - The question and the arc.
   - The scene table, with a one-line key: *mode* = works, think, or use; *renderer* = how a scene is drawn (`slide` still, `html` animated, `terminal` recorded terminal, `manim` animation); *~Len* = seconds.
   - The estimated length and the path to `script.md`.
   - What the cold read found and what you changed.
   - The pronunciation review list, framed as "words I'll check with you before recording".
   - The voice (from the preferences, or `am_echo` at 1.2×). Offer the sample page if they want to hear alternatives.
   - Two or three questions that are theirs to answer: is the order right, the wording, the length?

Wait for approval. Apply changes and re-lint until the user approves. Nothing renders before this.

**Steps 7–11 can be shared out.** If your agent can launch subagents and run background commands, read `DELEGATION.md` now: you author the scenes and do both look passes, narration runs in the background while you author, and one production subagent on a cheaper model runs steps 9–10. Reviewing every still of the finished video stays with you.

### 7. Author the visuals
Read only the topic files for what the storyboard uses:
| The scene shows | Topic file |
|---|---|
| Slides, code, diagrams (`html`, `slide`) | `SLIDES.md` (look and layouts) and `MOTION-GRAPHICS.md` (cues) |
| A real file | `FILES-ON-SCREEN.md` |
| A recorded terminal (`terminal`) | `TERMINAL-DEMOS.md` |
| Geometry or a clip made elsewhere (`manim`, `video`) | `MOTION-GRAPHICS.md` |

Start each scene from `assets/layouts/` and keep its frame: an optional eyebrow, a headline of six words or fewer, then `.stage`. Code, commands, paths, and output always go in a dark box on the left with their notes on the right (`code.html`); do not invent another style for one scene. For each terminal scene, once its tape is written, tie the scene's sentences to the tape's commands with `before` and `wait_for` in `storyboard.json`, and give every sentence that asks the viewer to take in a screen of output a `read` (adding an anchor or a `read` changes timing, not wording, so it needs no new approval).

Check stills of each animated scene with `node <SKILL_DIR>/scripts/preview.js <dir>/scenes/<id>.html --sheet --video <dir> --scene <id>` and look at them. When every scene exists, run `node <SKILL_DIR>/scripts/preview.js --all <dir>`, open `build/preview/_all/sheet.png`, and do the look pass (`REVIEW.md` → *Look pass*). Then run `lint-storyboard.js <dir> --strict` and fix every error. It lists the commands the terminal demos will type and what recording them spends: show the user that list, any warning about a command that is not plain, and the manim file paths, and get an OK. They run for real.

### 8. Narrate
Read `PRONUNCIATION.md`. Resolve every word on the review list (lexicon entry, rewrite, or the user's confirmation on the review page), then run `PY <SKILL_DIR>/scripts/tts.py <dir>`. `NARRATION.md` covers voices, speed, and failures.

### 9. Render scenes
Read `ASSEMBLY.md`. Run `node <SKILL_DIR>/scripts/render-scenes.js <dir>` (add `--allow-spend` only for recordings the user approved). It re-renders only what changed. Fix what it reports: `warnings` (overflow, script errors, remote loads), and any credential hit or partly scanned recording, either of which stops the run until it is resolved (`TERMINAL-DEMOS.md` → *Credentials on screen*). For terminal scenes, run `node <SKILL_DIR>/scripts/sync-report.js <dir>` and fix what it finds with anchors and `read`, not with sleeps or extra sentences. Check every `outcome` sentence against its recording, and check that every screen of output stays up long enough to read.

### 10. Assemble and verify
Run `node <SKILL_DIR>/scripts/assemble.js <dir>`. It builds `<slug>.mp4` and `poster.png`, and runs `verify.js`. Then run `node <SKILL_DIR>/scripts/verify.js <dir> --frames` and look at every still in `build/review/`, doing the look pass again (`REVIEW.md` → *Look pass*): clipped text, empty frames, content in the bottom caption band, a scene that does not match the others, a terminal that shows a long or personal path. If you cannot view images, list the still paths for the user and say the visual check was not done.

### 11. Report and publish kit
Write `<dir>/publish.md` with three title options, a two-to-three sentence description, the source link, and the contents of `chapters.txt`. Tell the user:
- The MP4 path and length, and the `publish.md` path. For a teach-me lesson, say that its lesson page now shows the video.
- **Upload `<slug>.srt` in YouTube Studio → Subtitles.** YouTube ignores the embedded caption track.
- What recording spent, any credential hits and how each was resolved, and any verify warnings.
- What you could not check: you cannot hear the audio or watch motion, so ask them to watch it once.

## Recipe: change an existing video
1. Edit `storyboard.json` (and the visuals if they change). Re-run `lint-storyboard.js <dir>` (`--strict` if visuals changed).
2. Show the user the changed scenes and get approval. A pure pronunciation fix needs only the audition.
3. If narration, voice, or speed changed: `PY <SKILL_DIR>/scripts/tts.py <dir>`. Only changed sentences re-synthesize.
4. Run `render-scenes.js <dir> --no-record` when no tape changed, so nothing is recorded again by accident. If a tape changed, get the commands approved again first.
5. Steps 10–11.

For "this video is hard to follow", start at step 4 of the workflow: re-plan the story, then change the scenes. Reordering and rewording is cheap; recordings are reused as long as their tapes do not change.

## Recipe: apply review notes
The user watched a finished video and sent notes. Read `REVIEW.md` → *Acting on review notes* first; in short:
1. Pull the frame at every timestamp before changing anything: `node <SKILL_DIR>/scripts/verify.js <dir> --at 0:56,1:43`.
2. Fix each note at the size it was given. Do not fix a note by removing the thing it is about (a complaint about long headlines in the serif is fixed with shorter headlines, not by dropping the serif), and do not re-open what the notes did not mention.
3. Add every note that is a general rule to `style_notes` in `<workspace>/videos/preferences.json`, in the user's words.
4. Apply the changes with *Recipe: change an existing video*. A wording the user dictated is already approved.
5. Pull the new frame for every note (scene times will have moved), look at each, and report with a table: the note, what changed, the still.

## Recipe: change the voice
1. Build and open the sample page: `PY <SKILL_DIR>/scripts/tts.py --samples --video <video-dir> --open` (`--british` adds British voices; offer them only if asked).
2. When the user picks one, set `voice` in `<workspace>/videos/preferences.json` for every video in the workspace, or in one video's `storyboard.json` for that video only.
3. For each affected video: `tts.py <dir>`, `render-scenes.js <dir> --no-record`, `assemble.js <dir>`, then step 11.

## Recipe: fix a pronunciation
1. Add `"word": "respelling"` to the workspace lexicon `<workspace>/videos/pronunciations.json` (create it if missing). Keys match in any letter case.
2. Audition a real sentence with the video's own voice and lexicons: `PY <SKILL_DIR>/scripts/tts.py --say "<sentence>" --video <video-dir> --play`. Give the user the WAV path and ask them to listen; you cannot hear it.
3. If it is still wrong, try phonemes (`PRONUNCIATION.md`) and audition again.
4. Once the user approves: `tts.py <dir>`, `render-scenes.js <dir> --no-record`, `assemble.js <dir>` for every video in the workspace that uses the word.

## Gotchas

Each of these was a real failure in finished videos.

- **A sentence set in the headline font.** Headlines stated the scene's whole point in the condensed display serif and were called atrocious. Six words or fewer; the sentence goes to the voice.
- **Overcorrecting a note.** Told the serif was wrong for long text, every headline was switched to the sans, and the video lost its look. Fix the misuse, keep the thing (`REVIEW.md` → *Acting on review notes*).
- **A stylesheet of its own.** A per-course CSS file restyled the theme's headlines, blocks, and notes. The look is the theme's; scenes use its classes.
- **Pale gray on the paper.** Model names and notes in `base1` could not be read. Text on the paper is `--ink`, `--ink-soft`, or `--ink-muted`.
- **One scene in a different style.** A path was explained in a table when every other scene put code in a dark box with notes on the right. One visual language (`SLIDES.md`).
- **Arrows between things that do not flow, and two marks on one box.** Skill → agent → model; a tick and a question mark together. An arrow means "flows into"; an object carries one mark.
- **A placeholder where the evidence belonged.** Two cards with "?" on them instead of what each model wrote. Show the real results.
- **Stating the video's length, and ordering the viewer about.** "In the next fifteen minutes", "Start with…", "Now do it yourself", "Pause here". The viewer is watching; say what we do and never how long it takes.
- **A screen of output cleared before it could be read.** A hidden `clear` ran three seconds after twelve lines appeared. The renderer now holds output while it is being talked about; add `read` for anything the viewer must take in.
- **A long path on screen.** A deep fixture path over a panel and in a typed `cat`; the tool's absolute path in its output. Short labels, a made-up demo folder, and no command that only re-shows a file (`TERMINAL-DEMOS.md` → *Paths on screen*).
- **Part of a file shown as if it were the whole.** The minimap was switched off to make room for notes, so nothing told the viewer the panel held nine rows of a longer file. A partial panel always says so: the minimap; or, with no room for one, its "lines hidden" rows when all are in view, else a scrollbar (`FILES-ON-SCREEN.md` rule 3).
- **A highlight that outstayed the voice.** A note stayed lit while the next line was highlighted. One highlight at a time; notes beside code are callouts.
- **Running before explaining.** A terminal scene opened a stage and the viewer was lost. Concepts first; the lint's *Explained before shown* list must have no gaps.
- **Showing a mistake, then the fix.** A demo ran the wrong way first and the narration confessed. Set it up correctly and give the reason in a clause; production discoveries go in the `script.md` notes.
- **Querying a file the viewer has never seen.** `jq`, `sed`, and `grep` over an output file. Show the file in a file panel and move through it.
- **Shell tricks to make a command fit.** Variables, `$(…)`, and continuations appeared because paths were long. Change the setup so the plain command fits.
- **Describing instead of doing.** Commands on slides and an exercise left to the lesson page. Record the real run and perform the checkpoint.
- **Tuning sleeps and adding filler sentences.** Hours went to aligning recordings by hand. Use `before` and `wait_for`, and read `sync-report.js`.
- **Hard jumps between parts of a file.** Each region was its own scene. One panel, real line numbers, a visible row for every hidden stretch, and a scroll between regions.
- **Asking about a word the user had already approved.** The second video's review page repeated the course's own name and two file extensions from the first. Roll settled words forward into the ledger before building a page (`PRONUNCIATION.md` → *The review page*).
- **Mispronunciations nobody caught.** Lowercase forms missed the lexicon, a heteronym took the wrong tense, and a person's name was guessed. Resolve the analysis list and the review page before narrating.
- **Italic on every headline.** The templates all had one, so every scene did. Headlines are plain unless one word carries the point.
- **Deck habits.** Headlines that named a topic instead of making a point, and a course label on every scene. The headline states what the scene proves, the screen shows evidence instead of bullets, and comparisons sit side by side (`SLIDES.md` → *Evidence, not bullets*).
- **A stapled course video.** Every lesson's title, recap, and "next lesson" repeated. Tag scene roles so the compilation can drop them, and keep lesson talk out of body scenes.
- **Narration written before a non-deterministic demo ran.** Probe first; mark sentences that depend on the result and check them against the recording.
- **The hidden setup command flashing on screen.** Recordings started before the setup had finished, so its command line showed for a fraction of a second. Wait for the prompt before `Show`; the renderer also covers any such frames.
- **A credential on screen.** Scan hits block the build; re-record masked, blur, or accept with a reason, and tell the user.
- **Trusting a delegated review.** A subagent that ran the production steps said the stills looked fine. Its report says where to look first; you still open every still.

## Verification

A video is done only when all of these hold:
- The user approved the story, script, and storyboard, and any terminal commands, before rendering.
- `lint-storyboard.js <dir> --strict` exits 0, and each warning was fixed or explained to the user.
- The script pass and the look pass (`REVIEW.md`) were done, the second on the stills of the finished video.
- `verify.js` reports `"ok": true`.
- No credential hit is open, every `outcome` sentence matches its recording, and `sync-report.js` findings are fixed or reported.
- `<slug>.srt`, `chapters.txt`, and `publish.md` exist.
- You looked at every `--frames` still yourself, or told the user you could not. A subagent's look does not count (`DELEGATION.md`).

## Reference files

| File | Read when |
|---|---|
| `NARRATIVE.md` | Step 4, the cold read in step 6, or a video that is hard to follow |
| `STORYBOARD.md` | Step 5, or any change to scenes, wording, or the schema |
| `REVIEW.md` | Step 6 (script pass), steps 7 and 10 (look pass), and whenever the user sends notes on a finished video |
| `COURSE.md` | Several videos for one workspace; creating or reading `preferences.json` |
| `SLIDES.md` | A scene uses `html` or `slide`: the frame, the three faces, the one visual language, layouts, evidence instead of bullets, code with notes, blocks, tables |
| `FILES-ON-SCREEN.md` | A scene shows a real file |
| `MOTION-GRAPHICS.md` | A scene uses cues, `manim`, or `video` |
| `TERMINAL-DEMOS.md` | A scene uses `terminal`: what to record, plain commands, paths on screen, start states, timing anchors, time to read, cost, credentials |
| `PRONUNCIATION.md` | Step 8, a pronunciation fix, or a name the narrator will say |
| `NARRATION.md` | Setup, choosing a voice or speed, or a narration failure |
| `DELEGATION.md` | Before step 7, when your agent can launch subagents: who does which step, the production subagent's brief, limits, and report, and why the full review stays with you |
| `ASSEMBLY.md` | Steps 9–10, re-rendering after a change, or a verify failure |
| `COMPILATION.md` | The user wants one combined video |
| `references/SOLARIZED-TECHNICAL-ESSAY.md` | A style question `SLIDES.md` and `MOTION-GRAPHICS.md` do not answer (it has a table of contents; read the section you need) |

## Scripts

Run these; `--help` on each lists its options.

| Script | Does |
|---|---|
| `scripts/prereqs.js` | Tool and platform check |
| `scripts/setup.js` | One-time setup in `~/.video-lesson/` (narration venv, optional manim and speech-to-text); needs `--yes` |
| `scripts/new-video.js` | Scaffolds a video folder with the storyboard template, theme, runtime, and fonts |
| `scripts/lint-storyboard.js` | Generates `script.md`; prints the user's standing notes; checks structure, the story (narrative, modes, roles, explained-before-shown), the wording (stated lengths, orders, absolutes), timing, pronunciation; `--strict` adds visuals, the look (headline length, a second stylesheet, pale text, long paths, arrows, lingering highlights), cues, tapes, and the command list |
| `scripts/code.js` | Syntax-highlighted code fragment with concept markers |
| `scripts/file-panel.js` | A real file as a scrolling panel with real line numbers, hidden-row markers, and a minimap; a partial view always says it is partial (`FILES-ON-SCREEN.md` rule 3) |
| `scripts/preview.js` | Stills of one scene, plus font, cue, overflow, and contrast problems; `--all <dir>` puts one still of every scene on one sheet |
| `scripts/tts.py` | Narration (run with `PY`): per-sentence clips, lexicons, `--say` audition, `--samples` voice page, `--analyze` and `--transcribe` pronunciation checks |
| `scripts/pronunciation-review.js` | One page of every doubtful word to click through, and the import of the user's verdicts |
| `scripts/render-scenes.js` | Records and renders clips at exact length, applies narration anchors, holds output on screen until it has been read, writes the timeline, captions, chapters |
| `scripts/sync-report.js` | When each command's output appears against when each sentence is spoken |
| `scripts/secret-scan.js`, `scripts/redact.js` | Find credentials in a recording; blur one |
| `scripts/assemble.js` | Narration master, loudness, concat, mux, verify |
| `scripts/verify.js` | Definition-of-done checks; `--frames` writes review stills; `--at 0:56,1:43` writes stills at those times of the finished video |
| `scripts/compile.js` | One combined video from finished lessons, woven by scene role |

`scripts/lib.js`, `scripts/browser.js`, `scripts/story-checks.js`, `scripts/craft-checks.js`, `scripts/tape-check.js`, and `scripts/recording.js` are libraries the scripts above use; do not run them directly. `scripts/tape-events.js` is the library that finds screen events in a recording; run it directly only to see what it found (`TERMINAL-DEMOS.md` → *Timing to narration*). `assets/` holds the theme, the motion runtime, the layouts, fonts, and the templates the scripts copy.

## Out of scope

- Writing or teaching the lesson itself → a lesson-authoring skill such as `teach-me`.
- A GIF or recording of a website → a browser-automation skill.
- A slide deck with no video → a slide-deck skill.
- Editing, captioning, or color-grading footage the user recorded; a script, captions, or thumbnail for a video made elsewhere; music videos, ads, and other non-instructional video → not this skill.
