# Terminal demos

Scripted terminal recordings with charmbracelet `vhs`. A `.tape` file types commands into a real shell and records 1080p video. The commands run for real, and real runs are the default: a viewer learns from watching the actual command produce its actual output, including commands that need a sign-in or cost something.

## Contents

- [What to record](#what-to-record)
- [Safety](#safety)
- [Plain commands](#plain-commands)
- [Paths on screen](#paths-on-screen)
- [Start states](#start-states)
- [Writing a tape](#writing-a-tape)
- [Timing to narration](#timing-to-narration)
- [Time to read](#time-to-read)
- [Slow commands: the jump cut](#slow-commands-the-jump-cut)
- [Non-deterministic demos](#non-deterministic-demos)
- [Cost and the recording lock](#cost-and-the-recording-lock)
- [Credentials on screen](#credentials-on-screen)
- [Pitfalls](#pitfalls)

## What to record

- **Record what the viewer will run.** If the lesson has the reader run a command, the video runs it, with the real tool and the real output. Do not describe a command on a slide and move on.
- **Perform the checkpoint.** The `practice` scenes ask the question the exercise answers, leave a beat, then do it on screen, narrated as what we are doing: "First, we check the tools." "Let's look in the results folder." The viewer is watching a demonstration, not typing along; never tell them to run, pause, or try.
- **Explain first.** A command appears only after the viewer has been told what it is and why it matters (`NARRATIVE.md` → *Explain before doing*). A terminal scene is never the first scene of a stage.
- **Do not show the viewer what they have already seen.** A step that only prints a file the video walked through in a file panel adds a path to read and nothing to learn. Leave it out, even when the lesson page has it.
- **Do not read files with commands.** `cat` on a short file the viewer has not seen is fine. Anything that queries a file (`jq`, `sed -n`, `grep`, `head`) assumes the viewer already understands a file they have never seen. Show the file in a file panel and move through it (`FILES-ON-SCREEN.md`).
- The workspace preferences can narrow this (`COURSE.md`): `demos.record_real_runs: false` puts commands that need a sign-in or cost something on a slide; `demos.credentials: "forbid"` records nothing that needs credentials.

## Safety

- **The user approves the commands.** `lint-storyboard.js --strict` lists every command the tapes will type, hidden setup included, and what recording will spend. Show that list to the user and get an OK before the first recording, and again whenever a tape changes.
- **Run in a scratch copy**, set up in the hidden block (`/tmp/vl-demo` or a per-run folder such as `/tmp/vd/$$`). Do not point a tape at a repository or folder the user cares about.
- **No destructive or outward-writing commands**, even in scratch: `rm -rf` outside `/tmp`, `git push`, `git commit`, deploys, publishing, network writes. The lint and the renderer refuse them (`scripts/tape-check.js`). If the lesson needs one, show it on a slide.
- **Secrets never reach the video.** See *Credentials on screen*.

## Plain commands

Type what a guide would print: one plain command on one line, with literal paths.

| Not this | Do this instead |
|---|---|
| `R=../results/lesson-3` then `$R/…` | Type the literal path. If it is long, change the setup so it is short |
| `RUN=$(ls -d results/*/ \| tail -n 1)` | Give the folder a fixed name in the hidden setup |
| One long line with several flags | Split it over lines with a trailing `\`, one flag per line, the way a guide prints it (set `PS2=''` in the hidden setup so the continuation lines have no `>`). Do not explain the backslash |
| `… \| grep -E 'x\|y' \| cut -c1-96` | Show the whole output, or the file in a file panel |
| `jq 'select(…)' results.jsonl` | A file panel on `results.jsonl` |
| `cmd1 && cmd2` | Two commands, each with its own sentence |

**When a command does not fit on screen, change the setup, not the command.** The hidden block can `cd` into the folder the commands run from, copy the start state under a short name, or set a config file so a flag is not needed. A visible line stays under about 60 characters at FontSize 44 (about 80 at 34). The lint warns about each of the patterns above; fix them or explain to the user at the command review why one must stay.

## Paths on screen

A path is something the viewer reads instead of the thing you are showing. Every path on screen is short, and none names this machine.

- **The demo folder has a short made-up name**, and the prompt shows only the current folder: `export PS1='\W $ '` gives `practice $`. Never show the real scratch path, a home folder, or a user name.
- **Type short paths.** `cd` into the folder first (in the hidden setup when the `cd` teaches nothing), so commands name files, not routes to them. The lint warns about a typed path more than three folders deep.
- **Label a panel with the shortest name that identifies the file**: `service.yaml`, `notes-cli/CHANGELOG.md`. Not the path from the repository root, and above all not before the video has introduced that layout.
- **When a tool prints an absolute path, show it as the made-up one.** Many tools print where they saved something as a full path. Wrap the tool in the hidden setup so its output passes through a rewrite. `script` keeps the tool on a terminal, so its colors and layout are exactly what it would print:
  ```
  Hide
  Type `export PS1='\W $ ' PS2='' && mkdir -p /tmp/vl-demo && cp -R /abs/path/start /tmp/vl-demo/practice && cd /tmp/vl-demo && clear`
  Enter
  Wait /\$\s*$/
  Type `T=$(type -P mytool); mytool(){ script -q /dev/null "$T" "$@" | sed -l 's|/private/tmp/vl-demo|~/src/demo|g; s|/tmp/vl-demo|~/src/demo|g'; }`
  Enter
  Wait /\$\s*$/
  Type "clear"
  Enter
  Wait /\$\s*$/
  Show
  ```
  Use one made-up folder for the whole course (`~/src/demo` unless the user names another) and say in the tape's comment that the path is rewritten. Change nothing else about the output. Check the first recording's stills: the path the viewer sees should be the made-up one everywhere.
- The credential scan flags a home folder or user name that reaches the screen; treat that as a path to fix, not a note to accept.

## Start states

A demo needs the world to be in a known state when the recording starts, and re-recording must start from the same state.

- **A teach-me course ships its start states.** Lesson 1 starts from `<workspace>/practice-starter/`; lesson N starts from `<workspace>/verified/lesson-<N-1>/`, the practice folder as the author's verified run left it. The same folders hold the console output of that run: read it before writing narration, since it is a free probe of what the demo prints. Copy the state into scratch as a folder named `practice` and `cd` into it, because every path on the lesson page is relative to `./practice/`, and the visible commands should be the page's commands, character for character.
- **Otherwise, save each start state in the workspace**: `<workspace>/videos/_demo/` holds a copy of the files as they are at the start of each demo, the real results of runs that later demos read, and a short `README.md` saying what each state is and how it was made. Use it too for anything a course's `verified/` folder lacks.
- **A name known only at run time** (a results folder stamped with the time) cannot be typed literally in a tape written beforehand. The lesson page handles this by listing the folder and giving the next command with a stand-in name. Do the same on screen, and make it true: after the command that creates the folder, a hidden block renames it to the stand-in the page prints, so the next visible command is the literal one from the page.
- **The hidden setup copies a state into scratch and works there**, so neither `_demo/` nor the user's real files are changed by a recording:
  ```
  Hide
  Type "export PS1='$ ' && mkdir -p /tmp/vd/$$ && cp -R /abs/path/videos/_demo/repo/l3 /tmp/vd/$$/skills && cd /tmp/vd/$$/skills && clear"
  Enter
  Wait /\$\s*$/
  Show
  ```
- **Wait for the prompt before `Show`.** Without it the recording starts while the setup is still running, and the viewer sees the setup command flash by (the lint warns).
- **The viewer never sees hidden setup, even when a tape gets this wrong.** If the frames after a `Show` still show what a hidden block typed, the renderer covers them with the first clean frame that follows, at every `Show` in the tape. Nothing moves: the scene's length, the audio, and every timing stay the same, and it applies to recordings that already exist without recording again. `sync-report.js` lists what was covered. The renderer leaves the frames alone, and warns with the tape line and time, when it cannot be sure: the screen is not wiped within 1.5 s of the `Show`, or a hidden command printed something that was never cleared. End every hidden block with `clear` and a `Wait` so there is always a clean frame to use.
- A change the demo needs but the viewer should not watch (a deliberately broken file, a fixture swap) also goes in a hidden block, and the narration says plainly what state the viewer is looking at.

## Writing a tape

Copy `assets/terminal.tape` to `<video-dir>/tapes/<id>.tape`.

- **No `Output` line**: `render-scenes.js` adds it. Settings (`Set …`) come before the first command; only `TypingSpeed` may change later.
- **Wait, don't guess:** after `Enter`, use `Wait /\$\s*$/` (the prompt) rather than a long `Sleep`. Write `\s*`, not a literal trailing space: the terminal trims it, so `/\$ $/` never matches. The default timeout is 15 s; use `Wait@60s /…/` for slower commands.
- **Keep sleeps short and fixed.** 500 ms after `Show`, about 400 ms between `Type` and `Enter`, about 1 s after each `Wait`, and 4–5 s on the final output. These give each screen event its own moment, which is what lets the renderer find them. Do not size a `Sleep` to the narration or to reading time; anchors and `read` do that (the lint warns on a long one).
- **Clear between screens with a hidden block** (`Hide`, `Type "clear"`, `Enter`, `Wait /\$\s*$/`, `Show`, `Sleep 500ms`) when the next command's output would scroll the screen. The renderer keeps the old output up until it has been talked about and read (*Time to read*), however short the Sleep before the `Hide`.
- **Keep `Set CursorBlink false`.** A held frame is invisible only when the cursor is not blinking.
- **Determinism:** pin tool versions, fix the prompt, avoid timestamps and random ids in output where the tool allows, and seed fixtures.
- Font size 44 (the template default); 34 only when output is wide. Keep the template's theme: a Solarized dark panel with a 120 px margin. It asks for JetBrains Mono and falls back to Menlo, because vhs only sees installed fonts. For the exact font, ask the user, then run `node <SKILL_DIR>/scripts/setup.js --yes --install-fonts`.
- A demo of only one to three short lines leaves the frame mostly empty. Put more of the story in the tape (the output, the follow-up command), or show it on an `html` code panel.

## Timing to narration

Narration waits for the screen, and the screen waits for narration. Tie sentences to what the recording shows; do not tune sleeps or add filler sentences.

The renderer finds four moments for each visible command in the recording, numbered from 1 in the order they are typed:

| Event | The moment |
|---|---|
| `typed:N` | Command N starts being typed |
| `enter:N` | It is submitted |
| `output:N` | Its output first appears (for a command with no output, the same moment as `enter:N`) |
| `done:N` | The output has finished and the prompt is back |

One command is everything typed up to the Enter that submits it, so a command typed over several lines counts once. Hidden commands are not counted. To see the commands and events the renderer finds: `node <SKILL_DIR>/scripts/tape-events.js --commands <tape>` and `node <SKILL_DIR>/scripts/tape-events.js <tape> <video-dir>/build/raw/<id>.mp4`.

Put anchors on narration items in `storyboard.json`:

```json
"narration": [
  { "text": "Lint checks the spec without running an agent, so it costs nothing.", "before": "typed:1" },
  { "text": "The last line is the one we're after.", "before": "enter:1" },
  { "text": "It says the file is valid.", "wait_for": "output:1", "read": 2 },
  { "text": "Now the real run.", "before": "typed:2" }
]
```

- **`before`**: the event does not happen until the sentence has finished, plus a 0.3 s margin (`"before": "typed:2+1"` adds a second more; `pacing.before_margin` changes the default). The recording holds on a still frame for as long as that takes, and everything after it moves later. Use it for every explanation that must land before a command is typed or run.
- **`wait_for`**: the sentence does not start until the event is on screen (`"wait_for": "output:1+1.5"` starts 1.5 s after it). Use it for every sentence that talks about output.
- **`read`**: quiet seconds after a sentence for the viewer to read the screen. The next sentence starts after them, and the output is not cleared before they are up (*Time to read*).
- **`pause`**: extra silence before a sentence, on top of the normal gap. With `wait_for`, the sentence starts at whichever is later.
- **Order:** anchors go in sentence order and never point backwards. A sentence may carry both, with `before` naming a later event than `wait_for`. Several sentences may share one `before` (they all finish first). A sentence without an anchor follows the previous one after the normal gap.
- A typical command takes three sentences: what it is and why (`before: typed:N`), what to look for (`before: enter:N`), and what it showed (`wait_for: output:N`, with `read` when there is more than a line or two to take in).
- A scene with anchors stops the render if an anchor names an event the recording does not have, or the tape no longer matches its recording. Fix the anchor, or record again if the tape changed.

Once a scene is recorded, read the report. It needs only the recording and the storyboard, writes nothing, and shows what the next render would do, so anchors can be tried before rendering:

```bash
node <SKILL_DIR>/scripts/sync-report.js <video-dir> [--scene s07] [--json]
```

```
s11  tapes/s11.tape | recording 31.16s | scene 31.17s | 3 commands
    time  screen                              narration
   20.93                                      3  20.93-25.70  "Second, lint in strict mode, which catches ty…"
   23.40  typed:3  vally lint -e …
   26.20                                      4  26.20-28.00  "The spec is valid."
   27.28  output:3
  Findings
   1. [starts-before-output] sentence 4 ("The spec is valid.") starts at 26.20, 1.08s before the output of command 3 appears (27.28) … add "wait_for": "output:3".
```

| Finding | Meaning | Fix |
|---|---|---|
| `starts-before-output` | A sentence is speaking when an output it probably describes has not appeared yet | `wait_for` on that output |
| `untied` | Sentences with no anchor in a scene with several commands | Anchor each one; the report suggests the nearest event, which is a guess to check against what the sentence says |
| `output-unspoken` | Output appears and is replaced before any sentence starts | A sentence with `wait_for`, or `before` on the next command |
| `dead-air` | The screen is still and nobody speaks for 3 s or more (`--still` changes it) | Shorten a Sleep, or move a sentence there. Silence you asked for with `read` is not dead air |
| `detector` | An event was placed with less than full confidence | Give the tape the short pauses the lint asks for; check a still at that time |

Fix what it reports by adding or moving anchors, then run `render-scenes.js <dir> --no-record`: only the affected clip is re-fitted, and the recording is not redone.

## Time to read

A viewer cannot scroll back. Output that is cleared, scrolled away, or cut to the next scene before it could be read might as well not have been shown, and "read the lines that begin with a plus" followed by a cleared screen is worse than saying nothing.

- **The renderer never clears output that is being talked about.** A sentence with `wait_for` is about the screen that event produced, and so is every sentence after it until one names a later event with `before`. If a hidden block clears that screen, the recording is frozen on the last frame before the clear until those sentences have ended, plus `pacing.read_hold` (2.5 s unless the storyboard changes it). The scene's last screen gets the same time before the scene ends.
- **Ask for more with `read`** on the sentence that points at the output: about one second for each line the viewer must take in, on top of the sentence itself. Twelve lines of results with two ticks to find: `"read": 3`. A patch the viewer is asked to read: `"read": 4`.
- **This only works when the sentence is tied to the output.** A sentence about output with no `wait_for` is not known to be about it. `sync-report.js` lists such sentences as `untied`.
- After rendering, read `sync-report.js`: for each screen of output, the time between its `output` event and the next cut is how long the viewer has. If that is less than a second per line, add `read`.

## Slow commands: the jump cut

A command that takes more than about ten seconds is dead air. Show it start, cut the wait, and come back when the prompt returns:

```
Type "vally eval -e evals/hello/eval.yaml"
Sleep 400ms
Enter
Sleep 2s
Hide
Wait@300s /\$\s*$/
Show
Sleep 5s
```

The viewer sees the command begin, then its finished output. Say how long it really takes in a clause ("about a minute later") so the cut is honest. For a jump-cut command, `output:N` is the first frame after the `Show` and `done:N` the same moment or a frame later.

## Non-deterministic demos

Some demos do not produce the same result twice: an agent run, a model call, anything timed. Narration written before the recording can then describe something that did not happen.

1. **Probe first.** Before writing the narration, learn what varies. A teach-me course's `verified/lesson-NN/` already holds the output of one real run, and the plan's Time line says what the checkpoint spends; start there. Where that is not enough, run the demo in a scratch copy of its start state (three runs is usually enough; count the cost against the budget). Record what you saw in the `script.md` notes block and save a representative result under `_demo/`.
2. **Prefer sentences that are true whatever happens**: "The last line is the verdict", not "It passed".
3. **Mark the rest.** A sentence that depends on the result carries `"outcome": true`. The lint lists every such sentence.
4. **After recording, check each marked sentence against the recording** (the review stills, and the text snapshot in `build/raw/<id>.txt`). If the recording disagrees, change the sentence, not the story about what happened: re-narrate that sentence and render again. Do not re-record until you get the outcome the script wanted unless the user agrees to the cost.
5. If a later scene depends on a specific outcome (it reads the results), feed it from the saved result in `_demo/`, not from whatever the last recording produced.
6. **When scenes quote the result of a paid run (a tally, a table of what each trial wrote), record that tape first and alone,** as soon as the commands are approved and narration exists, before authoring the scenes that quote it: `render-scenes.js <dir> --only <id> --allow-spend`. It records, logs the spend, and then exits 1 with "scenes outside --only are out of date"; that exit is expected. Copy what the video quotes into its `src/` (paths rewritten), have the scene generator read the numbers from those files and assert the counts the narration states, reword the `outcome` sentences to what happened, and re-narrate. The scenes then cannot disagree with the recording, and a retake that changes the result fails the generator instead of shipping a wrong number.

## Cost and the recording lock

- **Declare what a recording costs** in the tape, as a comment: `# Spend: 1 agent run`. For a tape that is already recorded, put `"spend": "1 agent run"` on its scene in `storyboard.json` instead: changing the tape, even by a comment, would force it to record again. The lint totals the declared cost for the video and compares it with `spend.budget` in the workspace preferences and with what has already been spent.
- **The renderer will not record a tape that declares a cost unless you pass `--allow-spend`**, and it logs each recording to `<workspace>/videos/spend-log.json` (failed recordings too, since the command may still have run). Pass the flag only for what the user approved. A recording that would pass the budget stops before it starts, with the numbers.
- **`--no-record` makes the renderer fail instead of recording anything.** Use it when you only mean to re-fit or re-render: after changing narration, anchors, or slides.
- A recording is reused until its tape changes. Editing a tape that declares a cost means paying again, so settle the commands at the review before the first recording.
- **One tape records at a time, across every video on the machine.** The renderer takes a lock in `~/.video-lesson/`; a second run waits its turn (up to an hour) and says for whom. Leave it alone: two recordings at once drop frames and can collide on the same sign-in. A lock left by a process that died is taken over automatically.

## Credentials on screen

Recording a command that needs a sign-in is allowed. Showing a secret is not.

- **Prevent first.** Sign in before recording, outside the tape. Do not `echo` or `export` a token in a visible command. Prefer the tool's quiet or masked mode. To show that a variable is set without showing it, say so in narration instead of printing it.
- **A credential written in a tape stops the lint and the recording** before anything runs.
- **Every recording is scanned.** The renderer saves a text snapshot of the screen with each recording (`build/raw/<id>.txt`) and scans it for token shapes, the values of secret-looking environment variables, and identity details (email addresses, the home folder, the user and machine names). Results go to `build/raw/<id>.scan.json`; values are never printed, only their kind, a masked form, and where they are. Identity details are notes to weigh with the user. A secret stops `render-scenes.js` until it is resolved.
- **The scan sees one screenful.** Once output scrolls, the snapshot no longer matches the screen, so the rest of the recording is unscanned and the renderer stops until someone has looked. Keep a demo that touches credentials within one screen (14 rows at FontSize 44, 18 at 34) or run `clear` between commands. When a recording is only partly scanned:
  ```bash
  node <SKILL_DIR>/scripts/redact.js <video-dir> --scene <id> --stills        # stills across the whole recording; look at every one
  node <SKILL_DIR>/scripts/secret-scan.js <video-dir> --scene <id> --reviewed --reason "looked at 12 stills: only paths and counts"
  ```
- **Resolve a secret** in this order:
  1. Re-record with the value masked at the source. This is the only fix that leaves nothing to chance; it costs a recording.
  2. Blur it: `node <SKILL_DIR>/scripts/redact.js <video-dir> --scene <id> --hit <hit-id>` (`--style box` paints a solid bar). It covers the value's cells for as long as they show it, then prints a still to check: look at it, and at one from before the value appeared. If it cannot place the region with confidence (the screen scrolled), it says so; give it the rows or a box yourself: `--rows 10 --from 1.9 --to 6.3`, or `--box x,y,w,h` (seconds are in the raw recording).
  3. If it is not a secret, accept it with a reason: `node <SKILL_DIR>/scripts/secret-scan.js <video-dir> --accept <hit-id> --reason "…"`.
- After a redaction, run `render-scenes.js <dir> --no-record` and `assemble.js <dir>` again; the finished MP4 is not updated by itself.
- The unredacted recording is kept outside the video folder, in `~/.video-lesson/unredacted/`, so a misplaced blur can be redone (`redact.js --undo`) without paying for a new recording. Delete the kept copies once the video is approved: `node <SKILL_DIR>/scripts/redact.js <video-dir> --purge`.
- **Tell the user about every hit**, including accepted and reviewed ones, in the final report. You cannot see every frame, so also ask them to watch the terminal scenes once for anything personal.
- A recording made before scanning existed has no snapshot and is reported as not scanned; re-recording it adds the scan.
- Leave `Margin`, `WindowBar`, and `BorderRadius` out of tapes: they move the terminal within the picture and rule out automatic placement of a blur.

## Pitfalls

- `vhs` needs `ttyd` and `ffmpeg` on PATH (`prereqs.js` checks both).
- A heavily loaded machine can drop frames. Re-record one scene alone with `render-scenes.js <dir> --only <id> --force` (add `--allow-spend` if the tape declares a cost, with the user's agreement).
- The tape runs with the video directory as its working directory; use absolute or `/tmp` paths in the hidden setup.
- A `Wait` that never matches fails the render after its timeout. Check the regex against the `PS1` you set.
- vhs starts the shell without rc files and with its own `> ` prompt. Keep `export PS1='$ '` in the hidden setup so `Wait /\$\s*$/` matches.
- Raw recordings are cached in `build/raw/<id>.mp4` by a hash of the tape. Changing narration or anchors re-fits the clip without recording again.
