# Motion

How scenes move. The design system's primary animation language is **concept morphing**: motion explains how one idea becomes another or how things relate, then holds still so the viewer can read. **Text provides context. Highlighting directs attention. Morphing explains relationships.** Canonical rules: `references/SOLARIZED-TECHNICAL-ESSAY.md` §8–§14, §19–§20.

## The Cue Types
Declare them as cues in the scene's `<script type="application/json" id="cues">` array. The runtime (`_theme/vl-runtime.js`) evaluates every frame purely from its timestamp, so frames come out identical in any order.

| Type | Does | Default | Fields |
|---|---|---|---|
| `focus` | Animates a highlight backing behind text that is already visible; slides between targets in the same block, crossfades across blocks. A block, quote, or card targeted as a whole is filled with the color. Any `.callout` anchored to the target lights up with it | 350 ms | `target` (concept id, or `"none"` to clear), `color`, `channel`, `until` |
| `morph` | Carries a concept from one representation to another (e.g. a code expression into a semantic block); the destination appears only when the morph arrives | 700 ms | `from`, `to` (e.g. `"filter-op@code"` → `"filter-op@block"`) |
| `connect` | Draws an arrow from one element to another. **Only for a real flow**: something passes from the first into the second, or the first becomes the second. Not for items in a list, and not for steps in order (number those) | 500 ms | `from`, `to`, `color` (structure/transform/attention/success), `curve` (0–0.3), `arrow: false` |
| `expand` | An abstraction opens to reveal its `.part` children; the title stays put | 650 ms | `target` (`#id` of a `.semantic-block`) |
| `collapse` | The reverse of expand | 650 ms | `target` |
| `scroll` | Moves a file panel's window to a line or range, eased, resting on whole rows (`FILES-ON-SCREEN.md`) | 600–1800 ms by distance | `target` (`#panel-id`), `to` (`"44"`, `"127-138"`, `"top"`, `"end"`), `align: "top"` |

Every cue needs `"at"`: `"2"` = when narration sentence 2 (0-based) starts, `"2~flag"` = the moment the word or short phrase "flag" is spoken in sentence 2, `"2+0.4"` = 0.4 s after the sentence starts, `"t=3.5"` = absolute. Prefer `"N~word"` to a counted offset whenever a cue should land on a word: it follows the narration when the wording or the voice changes, and the lint reports an error if the sentence does not say the word. (The time is estimated from the word's position in the sentence; preview with `--video <dir> --scene <id>` so real sentence timing is used.) Optional `"duration"` in ms (`0` = already complete at its start, e.g. connectors present from the first frame).

**Targets:** `"filter-op"` means every element with `data-concept="filter-op"`, so focus highlights the code and the diagram node together. `"filter-op@block"` means the one with `data-rep="block"`; `"#trial"` is an element id.

```json
[
  { "type": "connect", "from": "users@diagram", "to": "filter-op@diagram", "at": "t=0", "duration": 0 },
  { "type": "focus",   "target": "users", "at": "0", "color": "blue" },
  { "type": "focus",   "target": "filter-op", "at": "1" },
  { "type": "morph",   "from": "filter-op@code", "to": "filter-op@block", "at": "1+1.2" },
  { "type": "focus",   "target": "none", "at": "3" }
]
```
`assets/layouts/code-diagram.html` is the design system's worked example ("A pipeline of intent"), built exactly this way.

## One highlight at a time
A highlight says "the voice is here". On the default channel a new `focus` replaces the last one, which is what you want: the eye moves with the voice.

- **Do not light two things at once** unless the point is that they are the same thing (one concept id on the code and on its block).
- **A note beside code is a callout, not a second highlight.** `<p class="callout" data-anchor="filter-op">` is lined up with its anchor by the runtime and is lit exactly while the anchor is highlighted. No cue, no channel, nothing to forget to switch off.
- **If you do use a second `channel`**, give every cue on it an `until` (the sentence where the voice leaves it): `{ "type": "focus", "target": "pr41", "channel": "prev", "at": "5~forty-one", "until": "6" }`. Without it the highlight stays for the rest of the scene. The lint warns.
- End the scene on a calm state: clear the focus (`"target": "none"`) on the last sentence, or hold the one highlight the scene ends on.

## Planning Motion for a Scene
1. Name the concepts the narration talks about and give each a stable id (kebab-case), the same in code and diagram.
2. Mark them in the code with `code.js` markers; give diagram nodes and blocks the same `data-concept` with a different `data-rep`.
3. One cue per idea the narrator reaches: start emphasis **at or just before** the sentence that names it (`"at": "N"`, or `"N~word"` to land on a word mid-sentence).
4. After a morph or expand, leave a hold of about 1 s or more before the next cue. Prefer fewer, clearer transitions.
5. End scenes on a calm state: clear the focus (`"target": "none"`) or hold the final highlight.
6. Before adding a `connect`, say in words what passes along the arrow. If you cannot, the things are a list: highlight each in turn instead.

## Rules
- **No progressive text reveals.** Readable text is on screen from frame 0. Concepts may appear progressively only by morphing from where they already are, by expanding, or by being connected.
- **No reflow:** highlights are backings in their own layer, and morphs move a copy in a transition layer, so the code never shifts.
- **Easing:** focus, connect, and expand use the system's standard curve (cubic-bezier(.22, 1, .36, 1)); morphs use a symmetric in-out curve. No overshoot or spring.
- **Deterministic:** never use `setTimeout`, `setInterval`, `requestAnimationFrame`, CSS transitions, or free-running `@keyframes`. If a scene truly needs custom motion, write `window.onSeek = (t, vl) => { … }` as a pure function of `t`. The renderer re-renders a sample of frames out of order and warns if any differ.
- **Scene changes are hard cuts** between compositions. Continuity comes from repeating a concept's id, color, and position across adjacent scenes (e.g. the next scene opens with the block the previous one morphed into).

## manim (renderer `manim`)
For motion HTML can't express well: geometric transforms, plotted functions, objects moving along curves. Needs `setup.js --yes --manim` (ask the user first).
- Copy `assets/manim_scene.py` to `<video-dir>/manim/scenes.py`. Storyboard visual: `"manim/scenes.py#ClassName"`.
- The template is already in the design system: Solarized paper and ink, semantic accents, and the bundled fonts registered from `_theme/fonts/ttf` (Instrument Serif, Inter, JetBrains Mono). Keep it that way: no LaTeX, no camera moves, no bounce, and text visible from the start (`self.add` it, don't `Write` it in).
- Time to the voice with `self.play_at(at(i, fallback), …)` and `self.finish()`; they read manim's own clock, so plain `self.play()`/`self.wait()` calls stay in sync.
- Raw output is cached by a hash of the file, the class, and the narration timing. Prefer one class per file for long animations. Preview quickly with `PY -m manim render -ql <file> <Class>`.
- Pitfalls: "pangocairo not found" means `brew install pango pkg-config` is missing; keep `font_size` ≥ 28.

## Pre-rendered video (renderer `video`)
For a clip made elsewhere, such as [HyperFrames](https://github.com/heygen-com/hyperframes) (not installed by default; ask the user before installing, and check its `--help` for flags). The clip must follow this design system too. `render-scenes.js` letterboxes it on paper and fits it to the narration.

## Decision Guide
1. Pointing at part of visible text? → `focus`.
2. Showing that an expression **is** a stage, value, or component? → `morph` it there.
3. Showing that one thing flows into or becomes another? → `connect`. Listing things, or steps in order? → no arrows: blocks highlighted in turn, numbered if the order matters.
4. Opening up what's inside an abstraction? → `expand` (and `collapse` to sum up).
5. Moving to another part of a real file? → `scroll`, then `focus`.
6. Saying something about a line of code or a file? → a `.callout` anchored to it (`SLIDES.md` → *Code, commands, and output*).
7. Needs real geometry or plotting? → `manim`. Otherwise, stay in HTML.
