# Course plan: Ask your orders a question

Status: verified
<!-- draft → agreed → authored → built → verified -->

## Story
Starting problem: You export the shop's orders as a CSV file every week and can only scroll through it, so "what sells most?" is answered by guessing.
Destination: Given any week's export, you can ask it a question in one line and trust the answer.
Running example: `orders.csv`, a week of coffee orders from a small shop. The course ships it in `./practice-starter/`. Lesson 1 copies that folder to `./practice/`, and every later lesson asks the same file a harder question.

## Practice
- `./practice-starter/` (shipped): `orders.csv`.
- `./practice/` (created by the reader in lesson 1): all hands-on work. Every path in a lesson is relative to it.
- `./verified/lesson-NN/` (shipped): the state of the practice folder at the end of each lesson and the console output from the author's run.

## Lessons

### 1. Your first query
File: 0001-first-query.html
Question: Which drink sells the most, and how do I ask the file instead of counting by hand?
Win: Load the week's orders into a database and get a count of orders per drink with one query.
Hand-off: You counted every order. Most questions are about some of them: only the large drinks, only one day. How do you ask about part of a table?
Time: 10 minutes, no paid runs
Sections:
1. A table is a question waiting to happen | think | A spreadsheet shows a grid; a database answers a question about it and returns only the rows that answer.
2. What is in the orders file | works | `orders.csv` is plain text: one order per line, and the first line names the columns.
3. What SQLite does with it | works | SQLite keeps a whole database in one file; `sqlite3` opens it, `.mode csv` then `.import` load the CSV into a table.
4. What a query is made of | works | `SELECT` names columns, `FROM` names the table, `GROUP BY` collects rows that share a value, `COUNT` counts each group.
5. Ask the question | use | Copy the starter, open the database, import the orders, run the query, read the counts.
Recalls: none
Primary source: SQLite documentation, Command Line Shell For SQLite

### 2. Filtering rows
File: 0002-filtering-rows.html
Question: How do I ask about only some of the orders?
Win: Count the orders of one size, and of one drink in one size, with `WHERE`.
Hand-off: You can count. The shop also wants to know how much money each drink brought in.
Time: 10 minutes, no paid runs
Sections:
1. Most questions are about part of the table | think | A condition narrows a question to the rows it is about.
2. What WHERE does | works | `WHERE` keeps the rows for which a condition is true, before any grouping.
3. Narrow the count | use | Count the large orders, then the large lattes.
Recalls: what `GROUP BY` does; what the first line of the CSV is for
Primary source: SQLite documentation, SELECT

## Concept order
| Term, tool or file | Origin | Introduced | First used |
|---|---|---|---|
| table | SQLite documentation | L1 §1 | L1 §5 |
| row | SQLite documentation | L1 §1 | L1 §5 |
| column | SQLite documentation | L1 §1 | L1 §5 |
| `orders.csv` | course | L1 §2 | L1 §5 |
| SQLite | SQLite documentation | L1 §3 | L1 §5 |
| `sqlite3` | SQLite documentation, Command Line Shell | L1 §3 | L1 §5 |
| `shop.db` | course | L1 §3 | L1 §5 |
| `.mode csv` | SQLite documentation, Command Line Shell | L1 §3 | L1 §5 |
| `.import` | SQLite documentation, Command Line Shell | L1 §3 | L1 §5 |
| query | SQLite documentation | L1 §4 | L1 §5 |
| `SELECT` | SQLite documentation, SELECT | L1 §4 | L1 §5 |
| `GROUP BY` | SQLite documentation, SELECT | L1 §4 | L1 §5 |
| `COUNT` | SQLite documentation, Aggregate Functions | L1 §4 | L1 §5 |
| `WHERE` | SQLite documentation, SELECT | L2 §2 | L2 §3 |

No coined terms.
