/* The one place lesson titles, files and wins are listed. */
window.COURSE = {
  title: 'Ask your orders a question',
  video: '',
  lessons: [
    { n: 1, file: '0001-first-query.html', title: 'Your first query', win: 'Load the week\'s orders into a database and get a count of orders per drink with one query.', part: '' },
    { n: 2, file: '0002-filtering-rows.html', title: 'Filtering rows', win: 'Count the orders of one size, and of one drink in one size, with WHERE.', part: '' }
  ],
  references: []
};
