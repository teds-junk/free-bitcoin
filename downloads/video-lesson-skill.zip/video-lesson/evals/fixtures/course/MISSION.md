# Mission

## Why
I run a small coffee shop and export my orders as CSV files. I want to answer my own questions about what sells, without waiting for someone to build me a report.

## Success looks like
Given a week's export, I can find out what sold most, in which size, and for how much, in a few minutes.

## Audience
Shareable: the shop's staff will take this course too. It uses a small example file the course ships, not my real exports.
