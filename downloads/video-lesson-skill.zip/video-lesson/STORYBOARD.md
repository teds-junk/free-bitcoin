# Storyboard

How to turn a planned story into `storyboard.json` (and the `script.md` generated from it): the plan the user approves before anything renders. Plan the narrative first (`NARRATIVE.md`); this file covers reading the source, the scene list, the wording, and the schema.

## Contents

- [Reading the source](#reading-the-source)
- [Shape of a good video](#shape-of-a-good-video)
- [Writing narration](#writing-narration)
- [storyboard.json](#storyboardjson)
- [script.md](#scriptmd)
- [Choosing a renderer and layout](#choosing-a-renderer-and-layout)
- [Anti-patterns](#anti-patterns)

## Reading the source

**teach-me lesson** (the optimized path). A teach-me course has already planned what each lesson is for, in `COURSE-PLAN.md`. Read that plan and build the video from it; do not plan the lesson a second time. Read:

- **`<workspace>/COURSE-PLAN.md`**:
  - *Story*: the starting problem, the destination, and the running example every lesson works on.
  - The lesson's entry: its **Question**, its **Win**, its **Hand-off** to the next lesson, its **Time** (including how many paid runs its checkpoint spends), its **Sections** (each with a mode, think, works, or use, and its one new idea), and its **Recalls**.
  - The **concept order** table: the course's vocabulary, with where each term, tool, and file is introduced and first used. Use these words and no synonyms.
  - `Status:`. Make videos from a course whose plan says `verified`. Earlier than that the lessons can still change and their commands may not have been run; tell the user and ask before going on.
- **The lesson page**, `<workspace>/lessons/<stem>.html`: the wording and the evidence. Each `<h2>` carries its mode in `data-mode`. A checkpoint sits inside a "use" section: each step has a goal line, a command block (`data-where` names the program it is typed into when there is more than the terminal), and what a successful run prints (`.expect` or `<pre class="output">`). Files are shown as annotated `.file-excerpt` blocks with a marker wherever lines are left out.
- **`<workspace>/verified/lesson-NN/`**, when the course ships it: the practice folder as it stands at the end of each lesson, and the console output from the author's own run. This is where demo start states and real files for file panels come from (`TERMINAL-DEMOS.md` → *Start states*).
- **`<workspace>/MISSION.md`**: why the learner is here and who the course is for. One sentence of it belongs in the hook.
- **`<workspace>/NOTES.md`**: the user's preferences and the verification log (what was run, and what was not).
- **`<workspace>/assets/course.js`**: the course title and the lesson list.
- **`<workspace>/videos/preferences.json`** if it exists (`COURSE.md`).

`GLOSSARY.md` records the terms the learner has shown they understand. It is not the course vocabulary; that is the plan's concept order table.

Map the plan and the page to the video:

| In the course | In the video |
|---|---|
| The lesson's Question | `narrative.question`, in the same words |
| "So far" on the page: the earlier lessons' Wins, and every concept-order row introduced before this lesson | `narrative.viewer_starts`. These are known; anything else must be taught before it is used |
| Sections, in the plan's order | The arc's stages. A section becomes one to four scenes, all in the section's mode |
| The Win | The last stage's `viewer_can` |
| The opening paragraph (the problem) | The `hook` (about 20 s at most). Put the title in the hook's headline when it states the problem ("It works for *me*."); add a separate `title` card of 3 s at most only when it does not |
| A `.file-excerpt` | A file panel on the real file (`FILES-ON-SCREEN.md`), opened at the lines the excerpt annotates |
| The checkpoint | `practice` scenes: ask the question the checkpoint answers, leave a beat, then perform it for real, narrated as what we are doing ("If you tried it yourself, here's what you'd see"). The viewer is watching, not typing along; the lesson page is where they do it. Type the commands exactly as the page prints them: they are already plain and verified. Leave out a step that only prints a file the video has already walked through in a panel. Skip the performance only when the workspace preferences set `demos.perform_checkpoint` to false |
| `.expect` lines and output blocks | What each demo should show. A sentence that depends on it is an `outcome` sentence |
| Warm-up questions and exercises | Leave to the page. They are the learner's own recall |
| The Hand-off | The `next` scene, and the bridge after this lesson in a combined video (`COMPILATION.md`) |
| The primary source | A `.note` on the `next` scene |

If the video seems to need a different order from the plan (a concept the page uses before explaining it, a section in two modes), that is a finding about the course. Tell the user; do not quietly reorder, or the video and the page will teach different things.

**A course without `COURSE-PLAN.md`** (made by an earlier teach-me): read the lesson page, `GLOSSARY.md`, and `MISSION.md`, treat each `h2` as a stage, and plan the narrative yourself (`NARRATIVE.md`).

**Document or URL:** extract the three to six ideas that matter, then plan the narrative yourself. **Topic only:** research from trustworthy sources first, note them in the `script.md` notes block, and do not rely on memory for facts.

## Shape of a good video

- **Length:** follow the content, about 5–12 minutes for a lesson (narration runs about 180 words per minute at speed 1.2). The lint prints the estimate; if it exceeds about 12 minutes, ask the user whether to cut or split.
- **Hook first:** the first 10–20 s decide whether viewers stay. Open on the problem or the payoff, in the viewer's own situation, and show it: "Imagine you wrote a skill, tried it once, and the agent did what you wanted. Then a teammate runs it on another model and gets something different." with the request and the two different results on screen. Then promise what the viewer will be able to do: "In this lesson, you'll run an experiment on two models and find the differences in their behavior."
  - **Never promise a length** ("in five minutes", "in the next few minutes"). It is wrong the moment the video is edited, and nobody chose the video for its length.
  - **The promise uses only ideas the viewer already has.** "Find the difference in the files that get saved" means nothing before the viewer knows anything is saved.
  - Do not open with "Welcome to…" or "In this video…" (the lint warns).
- **One idea and one mode per scene,** 5–30 s each. A new visual every 10–20 s keeps attention.
- **Chapters** at stage boundaries: the first scene starts a chapter, and each chapter lasts at least 10 s (a YouTube rule). Name chapters after the outcome ("Read the pass rate"), not "Intro".
- **Close** with the `practice` scene, a `recap` (one statement and the picture the video already explained, asked before answered; not a bullet list), and a separate `next` scene. Keep everything that refers to "this lesson", "the next lesson", or "the lesson page", spoken or on screen (a "Lesson 3" label included), inside `title`, `recap`, and `next` scenes: a compilation drops those roles and keeps the rest, so anything lesson-specific in a `hook`, `body`, or `practice` scene survives into the course video (the lint warns). A scene that only tells the viewer to go and do an exercise on the lesson page is a `next` scene, not a `practice` scene. The hook's promise ("In this lesson, you'll …") is the one lesson reference a kept scene may make.

## Writing narration

Narration is written for the ear, not copied from the lesson.

- Short sentences, 8–20 words. One sentence per array item; the lint rejects sentences over 45 words.
- Vary the rhythm. A synthetic voice is flat, so mix short sentences with longer ones and use an occasional question before a reveal.
- The voice carries the reasoning (because, so, unless, compared with); the screen carries the evidence it is about. Do not read on-screen text aloud word for word, and do not put the reasoning on screen as bullets (`SLIDES.md` → *Evidence, not bullets*).
- Say numbers with their unit and a comparison ("three of ten, against none at two workers"), and plan for the screen to show them.
- Speak code the way a person would: "the dash dash output flag", "the eval dot yaml file". Do not read raw paths or long identifiers; show them on screen.
- Write versions in words when they matter: "version zero point twenty-one".
- Define a term the first time, in the course's own words (for teach-me, the plan's concept order table and the lesson's definition), and use no synonyms afterwards.
- Use contractions, "you" for what the viewer will be able to do, and "we" and "let's" for what the video is doing.
- **Do not give the viewer orders.** They are watching a video, not following a manual, and nobody stops to obey it. Not "Start with what a skill is" but "Let's start with what a skill is". Not "Now do it yourself" but "If you tried it yourself, you'd see…". Not "List the results folder" but "Let's look in the results folder". Not "Pause here and guess" but the question, then a beat of silence (`read`). The lint lists sentences that open with a bare verb.
- **Never say how long the video, or a part of it, takes.**
- **Explain what is new to this viewer, and nothing they already know.** `viewer_starts` says who they are. A programmer does not need `cd`, a backslash, or a pull request explained; explaining them says the video is for someone else.
- **Size every claim to its evidence.** "Would never have shown you" is only right if never is true; "would be difficult to discover for every model by hand" is what the evidence supports. Say what kind of case a result comes from: "in this rudimentary eval, both models got a tick".
- **Answer in the form the question asks.** "What does it do in one run?" is answered with verbs: "It makes a workspace. It runs an agent."
- **Say a thing once, plainly.** Not "for now, it's a tick or a cross" but "we'll explain the check later". Not "in the next few minutes it takes three things" but "we'll start by giving it three things".
- **Say what a label means, not the label.** Reading a line of output aloud inside a sentence ("one of one evals passed counts eval files") cannot be followed by ear.
- Write sentences that are true whatever a demo produces, or mark them `"outcome": true` when they depend on the result (`TERMINAL-DEMOS.md` → *Non-deterministic demos*).
- Do not add a sentence to fill time while a command runs. Tie sentences to the screen instead (`wait_for`, `before`, `pause` below), and cut slow waits with a jump cut.
- Do not speak a real person's name until the user has confirmed how it is said (`PRONUNCIATION.md`). Show the name on screen and say "the paper's author".
- If the user has a writing-voice skill, apply it to the narration only when the user asks.

## storyboard.json

`new-video.js` creates it from the template. A narration item is a sentence string, or an object when the sentence needs timing or a flag.

```json
{
  "schema": 2,                         // 2 = narrative, role, mode, introduces are required
  "title": "Anatomy of an eval",
  "slug": "0002-anatomy-of-an-eval",   // output file name
  "kind": "lesson",                    // lesson | intro | outro | bridges
  "lesson_number": 2,                  // optional
  "people": ["Ada Lovelace"],          // every real person the narration names (PRONUNCIATION.md → Names)
  "poster": "s02",                     // optional: the scene poster.png is taken from (default: the title scene)
  "source": "/abs/path/lesson.html",
  "voice": { "voice": "af_heart" },    // optional: only to differ from the workspace preferences
  "pacing": { "lead_in": 0.4, "gap": 0.5, "tail": 0.8 },
  "narrative": { "question": "…", "viewer_starts": "…", "arc": [ { "stage": "read-a-spec", "viewer_can": "…" } ] },
  "scenes": [
    {
      "id": "s07",                     // unique; insert s07b instead of renumbering
      "role": "body",                  // hook | title | body | practice | recap | next | bridge
      "mode": "use",                   // works | think | use (hook, body, practice scenes)
      "stage": "read-a-spec",          // a narrative.arc stage
      "chapter": "Check the spec",     // starts a chapter at this scene (omit to continue one)
      "renderer": "terminal",          // html (cues) | slide (static) | terminal | manim | video
      "visual": "tapes/s07.tape",      // manim: "manim/scenes.py#ClassName"
      "on_screen": "Terminal: vally lint on the spec; the valid line appears",
      "introduces": ["vally lint"],    // commands and files this scene explains
      "shows": ["vally lint", "eval.yaml"], // optional: what appears in this scene, until its tape or panel exists
      "narration": [
        { "text": "Lint checks the spec without running an agent, so it costs nothing.", "before": "typed:1" },
        { "text": "It says the file is valid.", "wait_for": "output:1", "outcome": true, "read": 3 },
        { "text": "So what did it actually check?", "pause": 1.5 }
      ],
      "spend": "1 agent run",          // optional: what one recording of this scene's tape costs
      "speed": 1.1,                    // optional per-scene voice speed
      "hold_after": 1.5,               // optional extra seconds after the last sentence
      "min_duration": 4                // optional floor, e.g. for a silent scene
    }
  ]
}
```

| Narration field | Meaning |
|---|---|
| `text` | The sentence |
| `pause` | Extra silent seconds before the sentence (any renderer) |
| `read` | Quiet seconds after the sentence, for the viewer to read what is on screen (any renderer). In a terminal scene the output being talked about is never cleared before this time is up. Use it after any sentence that points at a screen of output, a file, or a question the viewer should think about: about one second per line they must take in |
| `wait_for` | Terminal scenes: do not start the sentence until this event is on screen |
| `before` | Terminal scenes: the event does not happen until the sentence has finished; the recording holds on a still frame |
| `outcome` | `true` when the sentence depends on what a demo produced; the lint lists these for checking against the recording |

Events are `typed:N`, `enter:N`, `output:N`, and `done:N`, where N counts the visible commands in the tape from 1. Details and examples are in `TERMINAL-DEMOS.md` → *Timing to narration*.

`on_screen` is for the human reviewer: name the layout and what moves, concretely enough that someone could draw the frame. A storyboard without `"schema": 2` (one made by an earlier version of this skill) still lints and renders; the narrative, role, mode, and introduction findings are warnings there.

## script.md

The human-readable copy the user approves, and what the cold read reads. It is generated from `storyboard.json` every time `lint-storyboard.js` runs, so the two cannot drift; do not edit it by hand. It opens with the story (question, where the viewer starts, the arc), then each scene with its role, mode, stage, and what it introduces.

Free-form notes go between `<!-- notes -->` and `<!-- /notes -->`, which the generator keeps: research sources, open questions, and everything learned while making the video that the viewer should not hear (`NARRATIVE.md` → *Do it right the first time*).

## Choosing a renderer and layout

Every scene follows the Solarized Technical Essay style (`SLIDES.md`); choose a layout for each scene and vary them across the video.

1. A real file the viewer needs to read → `html` with a file panel (`FILES-ON-SCREEN.md`).
2. Code, diagrams, or ideas with motion tied to the narration → `html` with cues (the default).
3. A static composition with no cues, such as a recap → `slide` (renders much faster).
4. The viewer will run this command themselves, or its real output is the point → `terminal`. Real runs are the default, including ones that need credentials or cost something, within the workspace's demo policy and budget (`TERMINAL-DEMOS.md`).
5. Real geometry, plotting, or motion along curves → `manim`.
6. A clip made elsewhere in the same style → `video`.

## Anti-patterns

- **Greeting openers.** "Welcome to lesson one…" spends the most valuable seconds on nothing.
- **A promised length.** "In the next fifteen minutes…", in a nine-minute video.
- **Orders.** "Start with…", "Now do it yourself", "Pause here", "Run the command again". Say what we do.
- **Explaining the basics to an expert.** What a backslash does, to programmers.
- **An overclaim.** "Would never have…", "always", "impossible", where "usually" is the truth.
- **Nouns for an answer that should be verbs.** "What does it do?" "A workspace. An agent."
- **Re-showing.** A `cat` of a file a panel walked through two minutes earlier.
- **Narrating the slide.** The screen shows the anchor; the voice explains.
- **Wall-of-text slides.** More than about 40 words of prose on screen. Split the scene.
- **A deck with a voiceover.** Bullets on screen while the voice reads around them. Show evidence; say the reasoning.
- **Long scenes.** One visual held for over 45 s. Add a cue, a scroll, or a cut.
- **Paragraph sentences.** Multi-sentence array items break caption timing and per-sentence pacing.
- **Inventing vocabulary.** Words the lesson does not use confuse the learner. Do not coin a name the course plan does not list.
- **Describing a command on a slide instead of running it.** If the viewer will run it, record it.
- **Bridging sentences.** A sentence that exists to cover a wait. Use an anchor or a jump cut.
- **Lesson talk in body scenes.** "As we saw in lesson two…" cannot be cut from a compilation.
