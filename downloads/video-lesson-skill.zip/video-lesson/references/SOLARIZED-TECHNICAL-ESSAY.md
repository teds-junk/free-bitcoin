# Solarized Technical Essay — Video Design System

Version: 1.0. The canonical visual and animation system for every video this skill makes. The
user supplied it on 2026-11-09; keep it verbatim. Operational rules distilled from it live in
`SLIDES.md` (look) and `MOTION-GRAPHICS.md` (motion). When they disagree, this file wins.

**How this skill implements it**
| Spec concept | In this skill |
|---|---|
| Tokens, typography, layouts A–G (§3–5, §11) | `assets/theme.css`; layout starters in `assets/layouts/*.html` |
| Fonts bundled, never from the network (§5, §13) | `assets/fonts/*.woff2` (browser) and `assets/fonts/ttf/` (manim, vhs); OFL licenses alongside |
| Shiki + Solarized, concept spans (§6, §10) | `scripts/code.js` (`⟦concept-id:expr⟧` markers → `data-concept` spans) |
| focus / morph / connect / expand / collapse, `renderAt(t)` (§8, §9, §13, §14) | `assets/vl-runtime.js`; cues as JSON in each scene; `window.__seek(t)`, `window.__vlReady` |
| Scene specification (§12) | `storyboard.json` (scene, narration, timing) + scene HTML (concepts, representations, cues) |
| Deterministic rendering, ready signal, shuffled-seek test (§13, §21) | `scripts/render-scenes.js` (frame-stepping, determinism check), `scripts/browser.js` |
| Representative frames, overflow, fonts, cue validation (§21, §22) | `scripts/preview.js`, `scripts/lint-storyboard.js --strict`, `scripts/verify.js --frames` |
| Toolchain (§16) | Plain JavaScript (no TypeScript build) and puppeteer-core driving Chromium instead of Playwright; same model. 30 fps throughout |

## Amendments from finished videos

Three points where practice tightened this document. They override the sections named, and `SLIDES.md` and `assets/theme.css` already follow them.

1. **Headlines are short (§5, §17 EditorialHeadline).** Instrument Serif is a condensed display face. A headline is six words or fewer, on one line, at 96 px (136 px for a chapter or title). A full sentence in it is hard to read; the sentence goes in the supporting text or the narration. Fix a headline that looks wrong by shortening it, never by changing the face.
2. **Muted text on the paper is darker than base00 (§4 Foundation, §11 tokens).** Video is watched small and compressed. Text on the paper uses `--ink` (#073642, 12:1), `--ink-soft` (#2f4a53, 8.7:1), or `--ink-muted` (#4a6068, 6.1:1). base00, base0, and base1 are for rules and marks on the paper, not text. On the dark panel, plain text is #b3c0bf and the accents are lightened so each is at least 4.2:1; `code.js` applies this.
3. **Blocks are quiet at rest and filled when in focus (§7 Semantic Blocks, §9).** A semantic block has a faint tint of its role color; a focus cue on the block fills it with the stronger backing color. Notes beside code are callouts that the runtime lines up with their anchor and lights with it. An arrow is used only for a real flow.

## Contents
1. [Design Philosophy](#1-design-philosophy)
2. [Visual Identity](#2-visual-identity)
3. [Canvas and Layout](#3-canvas-and-layout)
4. [Color System](#4-color-system)
5. [Typography](#5-typography)
6. [Code Presentation](#6-code-presentation)
7. [Diagram Style](#7-diagram-style)
8. [Animation Philosophy](#8-animation-philosophy)
9. [Highlighting Behavior](#9-highlighting-behavior)
10. [Stable Semantic Identity](#10-stable-semantic-identity)
11. [CSS Design Tokens](#11-css-design-tokens)
12. [Scene Specification](#12-scene-specification)
13. [Deterministic Rendering](#13-deterministic-rendering)
14. [Morphing Implementation](#14-morphing-implementation)
15. [HTML, CSS, and SVG Responsibilities](#15-html-css-and-svg-responsibilities)
16. [Rendering Toolchain](#16-rendering-toolchain)
17. [Reusable Scene Components](#17-reusable-scene-components)
18. [Example Teaching Scene](#18-example-teaching-scene)
19. [Video Scene Transitions](#19-video-scene-transitions)
20. [Audio and Narration Synchronization](#20-audio-and-narration-synchronization)
21. [Quality Assurance](#21-quality-assurance)
22. [Skill Authoring Instructions](#22-skill-authoring-instructions)
23. [Final Creative Direction](#23-final-creative-direction)

Purpose: A reusable visual and animation system for educational videos about programming, software architecture, developer tools, and computer science.
Target: HTML/CSS/SVG-based video generation, rendered deterministically to frames and encoded to video.

## 1. Design Philosophy

Create technical videos that combine the conceptual clarity of 3Blue1Brown-style explanations with the warmth of Solarized, expressive editorial typography, and the precision of modern code editors.

The aesthetic should resemble a beautifully typeset technical essay brought to life, not a screen recording, slide deck, terminal session, or mathematical blackboard.

Core principle:

**Text provides context. Highlighting directs attention. Morphing explains relationships.**

The viewer should be able to understand the complete visual context immediately. Animation must communicate causality, transformations, relationships, or emphasis—not merely make the screen feel active.

### Nonnegotiable rules

1. Show complete readable text immediately when a scene begins. Never use typewriter effects, word-by-word reveals, or line-by-line reveals of code or prose.
2. Use animated highlight backgrounds to focus attention on text already visible.
3. Preserve surrounding code and explanatory context while moving attention between expressions.
4. Morph related visual concepts between representations rather than treating them as unrelated appearances.
5. Prefer text, typography, and spatial relationships to decorative boxes and icons.
6. Use soft semantic blocks only when grouping, transformations, or boundaries benefit from being visually explicit.
7. Keep movement deliberate and purposeful. Avoid excessive camera movement, bounce, decorative particles, and flashy transitions.
8. Maintain consistent visual semantics across scenes.
9. Prioritize readability in a compressed 1080p video, including playback on smaller screens.
10. Every animation must be deterministic and seekable, producing the same visual output at the same timestamp regardless of playback history.

## 2. Visual Identity

Name: Solarized Technical Essay

Personality:
- Editorial
- Thoughtful
- Precise
- Warm
- Minimal
- Explanatory
- Technically sophisticated
- Calm but not static

Avoid:
- Generic corporate slide aesthetics
- Heavy IDE/browser chrome
- Terminal windows used solely as decoration
- Excessive card-based layouts
- Neon gradients and glows
- 3D elements without explanatory value
- Decorative grids and dotted backgrounds
- Arbitrary drop shadows
- Heavy outlines
- Gratuitous icons
- Excessive punctuation or uppercase labels
- Comic or playful animation easing

Reference principles:
- 3Blue1Brown: continuity between concepts, spatial reasoning, and animated transformations.
- Solarized: carefully balanced warm neutrals and restrained semantic colors.
- Editorial design: expressive headlines, thoughtful typography, deliberate whitespace.
- Technical illustration: clarity, consistency, and precise relationships.

Do not attempt to reproduce any third-party channel's exact branding or artwork.

## 3. Canvas and Layout

Default video resolution: 1920 × 1080.
Aspect ratio: 16:9.
Default frame rate: 30 fps. Use 60 fps for scenes with fast or detailed motion when warranted.
Default canvas: Solarized Base3 (#FDF6E3).

Keep content inside a 120 px safe margin on all four sides. Provide more space when needed for subtitles or platform overlays.

Use CSS Grid or Flexbox for major compositions. Reserve absolute positioning for animation layers, connectors, and purposeful overlays.

Prefer compositions with:
- A large editorial headline
- A short supporting sentence when needed
- One primary teaching visual
- Ample negative space
- Consistent alignment
- A clear reading hierarchy

Typical scene layouts:

### A. Concept Introduction

Large editorial headline, short explanatory sentence, one simple visual relationship.

### B. Code + Diagram

Code on the left, conceptual representation on the right.

Both remain visible simultaneously. Highlight corresponding portions during narration.

### C. Full-Width Code

A complete code sample centered or left aligned, with animated highlight backgrounds and small surrounding annotations.

### D. Before / After

Two complete code or concept representations shown side by side, with animated correspondence between changed elements.

### E. System Overview

A spatial architecture diagram using typographic nodes and soft semantic blocks.

### F. Concept Expansion

A simple concept expands to reveal constituent operations, dependencies, or internal structure.

### G. Summary

A concise statement accompanied by an already-explained diagram or visual abstraction.

Avoid using the same composition in every scene. Maintain consistency through typography, colors, spacing, and animation behavior, while varying composition to suit the explanation.

## 4. Color System

Use Solarized as the canonical palette.

### Foundation

| Token | Hex | Role |
|---|---|---|
| base03 | #002B36 | Darkest background |
| base02 | #073642 | Dark code surface and primary ink |
| base01 | #586E75 | Secondary dark neutral |
| base00 | #657B83 | Muted text on light backgrounds |
| base0 | #839496 | Muted text on dark backgrounds |
| base1 | #93A1A1 | Secondary text on dark surfaces |
| base2 | #EEE8D5 | Secondary light surface |
| base3 | #FDF6E3 | Primary canvas |

### Accent Colors

| Token | Hex | Semantic role |
|---|---|---|
| blue | #268BD2 | Structure, types, interfaces, stable relationships |
| cyan | #2AA198 | Transformations, processing, current focus |
| yellow | #B58900 | Attention, distinctions, caution |
| green | #859900 | Success, validation, completed outcomes |
| orange | #CB4B16 | Change, exceptional operations |
| red | #DC322F | Errors, failures, destructive operations |
| violet | #6C71C4 | Optional distinct categories |
| magenta | #D33682 | Optional distinct categories |

Use blue, cyan, and yellow most frequently. Green, orange, and red should have meaningful semantic roles.

### Derived Highlight Backgrounds

| Token | Hex |
|---|---|
| focus-cyan | #D7EBE3 |
| focus-blue | #DCEBF3 |
| focus-yellow | #F1E5BC |

These derived colors are not canonical Solarized palette colors. They are deliberately softer backgrounds for highlighting text on the light canvas.

Avoid saturated, opaque highlight blocks behind large text regions.

### Color Rules

- Primary canvas is Solarized Light.
- Floating code inherits the light canvas.
- Dark panels use #073642 and appear when displaying substantial code files, debugging, terminals, or code-heavy comparisons.
- Use dark full-screen scenes only for meaningful changes of emphasis, not randomly.
- Keep normal body text dark enough to read comfortably.
- Use muted gray only for secondary information.
- Important text must remain legible outside the active focus state.
- Never encode meaning using color alone; also use labels, position, shape, or context.
- Verify contrast for smaller labels and low-saturation accents.
- Do not assume a canonical accent is readable as small text on Solarized paper. Use a darker accessible foreground variant when needed.

## 5. Typography

Use three typefaces:

### Headlines: Instrument Serif

Use for:
- Scene headlines
- Chapter titles
- Conceptual statements
- Selected expressive phrases

Style:
- Regular weight
- Occasional italic emphasis
- Large scale
- Tight but readable letter spacing
- Restrained line spacing
- Sentence case preferred

Avoid long paragraphs in the headline font.

### Body: Inter

Use for:
- Narration-supporting text
- Descriptions
- Labels
- Captions
- Diagram explanations
- Section identifiers

Prefer regular and medium weights. Bold should be reserved for meaningful emphasis.

### Code: JetBrains Mono

Use for:
- Source code
- Function names
- Type names
- Symbols
- Inline expressions
- Code-like diagram labels

Use a monospaced font with stable metrics for code transformations and alignment.

Code typography must remain readable at typical video playback sizes.

### Recommended Sizes at 1920 × 1080

| Element | Size |
|---|---|
| Chapter title | 100–120 px |
| Scene headline | 68–88 px |
| Body explanation | 32–38 px |
| Primary code | 38–46 px |
| Diagram label | 28–34 px |
| Eyebrow or section identifier | 20–24 px |

These are starting values. Adjust for actual composition, not to fit unreasonable amounts of text.

Target approximately 42 px for primary code, with line height around 1.6–1.9.

Use short line lengths. Avoid shrinking code to display large files. Split larger examples into meaningful scenes while preserving complete visible context within each scene.

Fonts must be loaded and stabilized before measuring layout or capturing frames. Bundle or locally install appropriately licensed fonts rather than depending on a live network font service.

## 6. Code Presentation

The default code presentation is **Code as Typography**.

Code should live directly on the Solarized paper background, without a simulated editor window.

Features:
- Syntax-aware coloring
- No unnecessary borders
- No default line numbers
- No fake traffic-light window buttons
- No fake filename tabs
- Stable line wrapping and indentation
- Generous spacing around code
- Ability to highlight individual tokens, expressions, ranges, or complete lines

Use dark code panels only when appropriate for:
- Large code excerpts
- File-based walkthroughs
- Debugging examples
- Terminal output
- Multi-file comparisons
- Diffs

In those situations, minimal file labels or line numbers are acceptable when they contribute useful information.

### Syntax Highlighting

Use Shiki with a custom Solarized-compatible theme, or equivalent syntax-aware tokenization.

Preserve semantic token spans for animation.

Syntax coloring and animation focus coloring are different systems. A focus highlight should not erase the code's syntax colors.

### Full-Text Visibility Rule

For any given scene, every code block and explanatory text block should be completely visible at its first readable frame.

Do not animate code by typing it character by character or inserting its lines sequentially.

Instead:
1. Show the complete code block.
2. Introduce an animated highlight background around the relevant expression.
3. Shift the highlight to the next relevant expression.
4. Optionally morph the highlighted expression into a conceptual diagram element.
5. Preserve the surrounding text and code context.

If the content genuinely changes during the explanation, such as a refactor, the code may transform from one complete valid state into another. This is different from hiding text to reveal it gradually.

## 7. Diagram Style

Combine **Typographic Diagrams** and **Semantic Blocks**.

### Typographic Diagrams

Prefer:
- Functions and expressions
- Identifiers
- Type names
- Arrows
- Operators
- Labels
- Lines representing relationships

Example:

users → filter() → map() → result

Typography itself should communicate structure.

### Semantic Blocks

Use softly filled, low-saturation rectangles when emphasizing:
- Groups
- Boundaries
- Processing stages
- Type categories
- Abstractions
- Ownership
- Transformations

Use small corner radii, generally 4–8 px at full resolution.

Avoid excessive borders, shadows, and decorative cards.

### Diagram Rules

- One clear primary relationship per scene.
- Consistent spacing and alignment.
- Prefer left-to-right flow for sequential transformations.
- Use arrows when direction carries meaning.
- Avoid arrows for relationships that are not directional.
- Minimize crossed connector lines.
- Keep labels close to their associated concepts.
- Avoid redundant legends.
- Let diagram color match corresponding code expressions.
- Preserve object identities between code and diagram representations.

Diagrams should be constructed with HTML for typography and semantic blocks, and inline SVG for paths, connectors, curves, and precise shapes.

Use a single coordinate system or explicit coordinate transformations when connecting SVG geometry to HTML elements.

## 8. Animation Philosophy

Primary animation language: **Concept Morphing**.

The purpose of motion is to explain how one idea becomes another or how objects are related.

Core principle:

**Reveal concepts progressively, but reveal readable text completely.**

When concepts change representations, preserve visual continuity.

For example, an expression highlighted in a code block may move into a diagram, grow into a soft semantic block, and connect to another transformation.

The viewer should experience it as the same concept in a different representation.

### Animation Primitives

Implement the following primitives:

#### focus

Animate a highlight background behind a previously visible text range or visual element.

Typical duration: 350 ms.

Requirements:
- Preserve text layout.
- Do not replace or retype text.
- Avoid moving surrounding content.
- Support moving or crossfading emphasis between targets.
- Keep all non-focused context legible.

#### morph

Transform one representation of a concept into another.

Typical duration: 700 ms.

Requirements:
- Preserve the concept's identity.
- Interpolate position, size, and where practical shape.
- Preserve semantic color.
- Maintain visible continuity during the change.
- Do not simply fade one unrelated object out and another in when spatial morphing is feasible.

#### connect

Animate the appearance of a relationship.

Typical duration: 500 ms.

Examples:
- Data flows between functions.
- Dependency connects components.
- A transformed value moves from one stage to another.

Use SVG paths and, when useful, progressive stroke drawing.

#### expand

Reveal the internal structure of an abstraction.

Typical duration: 650 ms.

Examples:
- Function becomes constituent operations.
- Service becomes several internal components.
- Data structure reveals its properties.

The concept should remain recognizable throughout.

#### collapse

The reverse of expand.

Use to consolidate multiple internal concepts into a higher-level abstraction.

### Motion Rules

- No typewriter animations.
- No word-by-word text reveals.
- No line-by-line code reveals.
- No unnecessary sequential bullet reveals.
- No arbitrary bouncing.
- No decorative particles.
- No perpetual ambient motion.
- No exaggerated camera movements.
- No animations that obscure readable content.
- No constant movement during narration.

Prefer a calm rhythm: motion, followed by a readable hold.

Recommended easing for focus and standard transitions:

cubic-bezier(0.22, 1, 0.36, 1)

For spatial morphs, use easing appropriate to continuity and precise geometry.

Avoid elastic or spring-like overshoot as the default.

## 9. Highlighting Behavior

Highlighting is the primary focus mechanism for text-heavy scenes.

A highlight should behave like a transparent, colored backing layer that moves behind text.

Requirements:
- Text is rendered fully before highlighting begins.
- Highlights must not change text dimensions or cause reflow.
- Highlights should occupy the text's bounding box plus small padding.
- For multiline ranges, support separate highlight rectangles per line or a suitable union geometry.
- Round corners subtly.
- Animate the backing shape, not the text itself.
- Allow focus to move between expressions.
- Preserve syntax coloring.
- Avoid dimming surrounding text so much that it becomes unreadable.
- Allow distinct highlight colors for different semantic roles.
- Highlight a small, meaningful unit where possible instead of a huge region.

For code-to-diagram morphs, the focused code expression and destination diagram node should share a semantic concept identifier.

## 10. Stable Semantic Identity

Every animated concept should have a stable identifier independent of its visual representation.

Example HTML:

```html
<pre class="code-block">
  <code>
    <span data-concept="input-users">users</span>
    <span data-concept="filter-operation">
      .filter(u => u.active)
    </span>
    <span data-concept="map-operation">
      .map(u => u.name)
    </span>
  </code>
</pre>

<div
  class="diagram-node"
  data-concept="filter-operation"
  data-role="transformation">
  filter
</div>
```

The engine should understand that both elements with data-concept="filter-operation" represent the same underlying idea.

When morphing, create a transition representation that interpolates between the measured source and destination.

During morphing, prevent unintended duplicate visual representations. The source and destination may remain in the DOM for measurement while their visibility is coordinated with the animation overlay.

Do not mutate the semantic identity of an object simply because its visual representation changes.

## 11. CSS Design Tokens

Use the following CSS variables as a baseline:

```css
:root {
  /* Solarized */
  --base03: #002b36;
  --base02: #073642;
  --base01: #586e75;
  --base00: #657b83;
  --base0: #839496;
  --base1: #93a1a1;
  --base2: #eee8d5;
  --base3: #fdf6e3;

  /* Semantic accents */
  --blue: #268bd2;
  --cyan: #2aa198;
  --yellow: #b58900;
  --green: #859900;
  --orange: #cb4b16;
  --red: #dc322f;
  --violet: #6c71c4;
  --magenta: #d33682;

  /* Semantic surfaces */
  --paper: var(--base3);
  --paper-muted: var(--base2);
  --ink: var(--base02);
  --ink-muted: var(--base00);
  --code-dark: var(--base02);

  --structure: var(--blue);
  --transform: var(--cyan);
  --attention: var(--yellow);
  --success: var(--green);

  /* Soft highlights */
  --focus-cyan: #d7ebe3;
  --focus-blue: #dcebf3;
  --focus-yellow: #f1e5bc;

  /* Typography */
  --font-display: "Instrument Serif", Georgia, serif;
  --font-body: "Inter", sans-serif;
  --font-code: "JetBrains Mono", monospace;

  /* Canvas */
  --scene-width: 1920px;
  --scene-height: 1080px;
  --safe-margin: 120px;
  --radius: 8px;

  /* Animation */
  --motion-focus: 350ms;
  --motion-morph: 700ms;
  --motion-connect: 500ms;
  --motion-expand: 650ms;
  --ease-standard: cubic-bezier(.22, 1, .36, 1);
}

.scene {
  position: relative;
  width: var(--scene-width);
  height: var(--scene-height);
  overflow: hidden;
  background: var(--paper);
  color: var(--ink);
  font-family: var(--font-body);
}

.scene-title {
  font-family: var(--font-display);
  font-weight: 400;
  font-size: 80px;
  line-height: 1.08;
  letter-spacing: -0.025em;
}

.scene-title em {
  color: var(--blue);
  font-style: italic;
}

.code {
  font-family: var(--font-code);
  font-size: 42px;
  line-height: 1.75;
  white-space: pre;
}

.diagram-label {
  font-family: var(--font-body);
  font-size: 32px;
}

.semantic-block {
  border-radius: var(--radius);
  background: var(--paper-muted);
}

.highlight {
  position: absolute;
  pointer-events: none;
  border-radius: 4px;
  background: var(--focus-cyan);
}
```

The design should use absolute pixel dimensions for its canonical 1920 × 1080 rendering target. Scale the completed scene uniformly for interactive browser previews rather than allowing responsive layout to reflow the video composition.

## 12. Scene Specification

Represent each scene declaratively.

A scene should describe:
- Duration
- Content
- Layout
- Semantic concepts
- Visual representations
- Animation cues
- Timing
- Optional narration synchronization

A possible TypeScript contract:

```typescript
type AnimationType =
  | "focus"
  | "morph"
  | "connect"
  | "expand"
  | "collapse";

interface AnimationCue {
  id: string;
  type: AnimationType;
  target: string;
  startMs: number;
  durationMs: number;
  from?: string;
  to?: string;
  colorRole?: string;
}

interface SceneDefinition {
  id: string;
  durationMs: number;
  layout: string;
  title?: string;
  description?: string;
  concepts: ConceptDefinition[];
  cues: AnimationCue[];
}

interface ConceptDefinition {
  id: string;
  role: string;
  content: string;
  colorRole?: string;
}
```

This is an illustrative API. The actual implementation may use richer structures for code ASTs, elements, SVG geometry, layout coordinates, and narration markers.

The important requirement is to separate **semantic content** from **visual representations** and **animation timing**.

## 13. Deterministic Rendering

The renderer must support direct timestamp-based evaluation.

Required conceptual API:

```typescript
interface VideoScene {
  durationMs: number;

  renderAt(timeMs: number): void;
}
```

Rendering at a given timestamp must be independent of the previously rendered timestamp.

For any timestamp T:

renderAt(T)

must produce the same visual state whether called after rendering T - 33 ms, T + 5000 ms, or no previous frame.

Implementation requirements:
- Evaluate animation progress mathematically from timestamps.
- Do not rely on wall-clock timers as the source of truth.
- Do not rely on incremental state changes across frames.
- Avoid random values unless seeded and deterministic.
- Wait for web fonts and relevant assets to load.
- Stabilize layout before measurements.
- Cache source and destination geometry where appropriate.
- Update positions, transforms, clipping, path progress, and highlights from the animation state.
- Seekability must work in both forward and reverse directions.
- Provide an explicit ready signal before frame capture.
- Disable nondeterministic CSS animations during offline rendering unless controlled by a deterministic animation timeline.
- Avoid depending on network resources during rendering.

Animations must be reproducible for testing and screenshot comparison.

## 14. Morphing Implementation

Use FLIP-like techniques or equivalent geometry interpolation.

Suggested process:

1. Measure the source element's bounding rectangle.
2. Measure the destination representation's bounding rectangle.
3. Establish a transition layer above the normal scene.
4. Create or reuse a visual representation of the concept in that layer.
5. Interpolate position and scale using timestamp-based progress.
6. Interpolate appropriate shape and style properties if supported.
7. Coordinate the visibility of source and destination representations.
8. End with the destination representation exactly aligned.
9. Remove or hide the transition layer when the morph is complete.

Do not apply transforms that cause code reflow.

For complex transformations, prioritize clarity and consistent correspondence over elaborate geometric interpolation.

A concept may transform from inline code to a labeled semantic block, but should retain its identifying name and color throughout the transition.

## 15. HTML, CSS, and SVG Responsibilities

### HTML

Use for:
- Typography
- Code
- Labels
- Semantic blocks
- Main layout
- Captions
- Accessible content structure

### CSS

Use for:
- Design tokens
- Font styling
- Spacing
- Surface appearance
- Highlights
- Static layout
- Transform and opacity properties driven by the timeline

### SVG

Use for:
- Connectors
- Curves
- Directed arrows
- Flow paths
- Braces and precise annotations
- Geometric shapes that require exact control

Prefer HTML text over SVG text when rendering longer explanations or syntax-highlighted code.

Avoid canvas-based text rendering unless a specific scene requires it. HTML text offers better typography, layout, tokenization, and reusable semantic structure.

## 16. Rendering Toolchain

Recommended baseline:

- TypeScript for scene definitions, timeline logic, and reusable components
- HTML and CSS for composition and typography
- Inline SVG for diagrams and connectors
- Shiki for syntax highlighting
- Playwright and Chromium for frame rendering
- FFmpeg for video encoding

Suggested project organization:

```text
video-skill/
  design/
    tokens.css
    typography.css
    layouts.css
    motion.ts
  components/
    Scene.ts
    EditorialHeadline.ts
    CodeBlock.ts
    FocusHighlight.ts
    SemanticBlock.ts
    DiagramConnector.ts
    ConceptMorph.ts
  timeline/
    types.ts
    interpolate.ts
    easing.ts
    evaluate.ts
  scenes/
    ConceptIntro.ts
    CodeDiagram.ts
    CodeFocus.ts
    BeforeAfter.ts
    Architecture.ts
    ConceptExpansion.ts
    Summary.ts
  render/
    browser.ts
    frames.ts
    encode.ts
  tests/
    visual-regression/
    deterministic-render/
    layout-overflow/
```

The exact directory organization may change, but keep presentation components separate from animation timing and rendering infrastructure.

## 17. Reusable Scene Components

Implement these first.

### EditorialHeadline

A large serif headline supporting selected italic and colored spans.

Should allow expressions such as:

"A pipeline of *intent.*"

Italic emphasis should be selective rather than applied to every headline.

### CodeBlock

Displays fully visible syntax-highlighted source code.

Should expose:
- Token identifiers
- Expression identifiers
- Line and range geometry
- Optional dark mode
- Highlight overlays
- Optional filename and line numbers

### FocusHighlight

Places an animated highlight behind an existing HTML range or DOM element.

Should:
- Avoid reflow
- Support multiline rectangles
- Support semantic colors
- Interpolate between positions
- Be controlled by the deterministic timeline

### SemanticBlock

A softly filled shape for explaining transformations, stages, groups, and boundaries.

Should support:
- Labels
- Semantic role
- Accent color
- Highlight state
- Morph identities

### DiagramConnector

Renders a relationship between concepts.

Should support:
- Straight paths
- Curved paths
- Directional arrows
- Optional animated stroke progress
- Endpoints attached to changing node geometry

### ConceptMorph

Animates continuity between multiple visual representations of one semantic concept.

### SceneLayout

Provides canonical positions and safe margins for common scene compositions.

## 18. Example Teaching Scene

Topic: array transformations in TypeScript.

Headline:

"A pipeline of intent."

Supporting text:

"Each operation does one thing, and passes its result along."

Code, visible in full immediately:

```typescript
const result = users
  .filter(u => u.active)
  .map(u => u.name);
```

Diagram:

users → filter → map

Semantic stages:
- users: collection
- filter: select active users
- map: extract name

Animation timeline:

0 ms:
- Full headline, supporting text, code, and diagram already visible.
- No active focus highlight.

1000 ms:
- Begin highlighting the input collection in the code and corresponding diagram node.

2500 ms:
- Move focus to the filter expression and filter diagram node.
- Complete all background highlight transitions smoothly.

4300 ms:
- Morph the filter expression into a larger semantic block labeled "select".
- Preserve the expression's conceptual identity and cyan accent.

6500 ms:
- Move focus to map.
- Highlight the corresponding code and diagram node.

8500 ms:
- Morph the map operation into a transformation block labeled "extract".

10500 ms:
- Return to an overview with the full pipeline visible.
- Preserve all code and supporting text.

12000 ms:
- End scene.

The timing should ultimately follow narration rather than be fixed to these values.

## 19. Video Scene Transitions

Prefer transitions that preserve visual continuity.

Acceptable:
- Matching elements morphing across scenes
- A diagram reorganizing into the next composition
- A subtle fade between unrelated chapters
- A restrained lateral transition for a meaningful conceptual progression
- A soft crossfade of full compositions when no semantic connection exists

Avoid:
- Spinning objects
- Zoom explosions
- Wipes used only as decoration
- Glitch transitions
- Rapid strobing
- Excessive parallax
- Randomized movement

Scene transitions should be less visually dominant than the conceptual animations within scenes.

## 20. Audio and Narration Synchronization

When narration is available:
- Align focus changes with the concepts being discussed.
- Begin emphasis at or just before the relevant spoken phrase.
- Hold visual focus long enough for the viewer to understand it.
- Avoid unnecessary animation during dense narration.
- Prefer fewer, clearer transitions to constant movement.
- Allow meaningful pauses after conceptual morphs.

When narration timing is unavailable, use explicit cue timestamps and sensible default holds.

Subtitles, when requested, must not obstruct code or diagram content. Reserve space or reposition the main composition.

## 21. Quality Assurance

Before exporting a video, verify the following:

### Visual consistency
- Correct Solarized palette
- Correct typography
- Consistent spacing
- Consistent accent semantics
- No unnecessary editor or terminal chrome
- No unrequested decorative elements

### Text readability
- All readable text blocks are completely present at scene entry.
- No typewriter or line-reveal effects.
- Primary code remains legible.
- Supporting text has adequate contrast.
- No clipped labels or offscreen code.
- No excessive shrinking of text.
- Highlight backgrounds do not reduce text readability.

### Animation
- Highlights do not cause reflow.
- Morphs preserve concept identity.
- Animation is purposeful.
- Existing context remains visible.
- No distracting repeated motion.
- Scene boundaries are smooth.
- Seek operations work correctly.

### Rendering
- Frames are deterministic.
- Fonts finish loading before rendering.
- SVG and HTML geometry aligns.
- No unexpected clipping.
- No flickering.
- No nondeterministic random behavior.
- No dependency on an external network during final rendering.
- Audio/video sync is correct.
- Output resolution and frame rate match requirements.

### Automated tests
- Capture representative frames for visual regression.
- Render timestamps in shuffled order and compare resulting images to sequential renders.
- Test long identifiers, multiline code expressions, and overflowing text.
- Test highlight geometry on multiline ranges.
- Test morphs with different source and destination sizes.
- Test both floating code and dark code panels.
- Validate that every referenced semantic concept exists.
- Detect conflicts between overlapping cues.
- Test font loading and fallback behavior.

## 22. Skill Authoring Instructions

When generating a new video:

1. Analyze the technical explanation and identify its teaching objectives.
2. Break the explanation into coherent scenes, each containing one primary teaching point.
3. Select the most appropriate reusable scene layout for each point.
4. Write complete code and explanatory text for each scene.
5. Identify key concepts and assign stable semantic IDs.
6. Choose corresponding diagram representations.
7. Assign semantic colors consistently.
8. Build an animation plan using focus, morph, connect, expand, and collapse primitives.
9. Keep complete blocks of readable text visible from the beginning of each scene.
10. Align animations with narration or explicit timestamps.
11. Render representative frames and check readability and layout.
12. Render the complete sequence deterministically.
13. Encode video and verify frame timing, audio sync, and visual quality.

Favor clarity over visual novelty.

Do not invent additional design patterns without a compelling instructional reason.

Do not use additional fonts, bright colors, elaborate transitions, or decorative elements merely to make a scene feel more visually interesting.

If a scene feels too dense, simplify its teaching objective or split it into multiple complete scenes rather than progressively revealing an overcrowded code block.

When choosing between two animations, select the one that communicates a clearer causal or conceptual relationship.

## 23. Final Creative Direction

The finished videos should look like an elegant technical essay that has become animated.

The page is warm Solarized paper.

The headings have the expressive personality of a well-typeset book.

Code floats directly on the canvas, rendered in precise monospace typography.

The complete code remains visible while gentle backgrounds move underneath the important expressions.

Those expressions can detach from the code and transform into labeled semantic blocks or typographic diagrams.

Relationships emerge through controlled spatial motion.

Everything moves for a reason.

The visual identity must support both practical coding walkthroughs and high-level architecture explanations without requiring separate visual styles.

**Text provides context. Highlighting directs attention. Morphing explains relationships.**
