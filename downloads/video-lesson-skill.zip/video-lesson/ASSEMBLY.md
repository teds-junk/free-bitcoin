# Assembly

Rendering scenes, mixing narration, captions, chapters, final encode, and verification. All of it is scripted; your job is to run the scripts, read their output, and look at the review stills.

## Timeline Model
Audio comes first:
1. `tts.py` measured every sentence clip.
2. Narration length for a scene = `lead_in` + clips + `gap` between sentences + any `pause` and `read` + `tail` + `hold_after` (defaults 0.4 / 0.5 / 0.8 s; change them under `pacing`).
3. In a terminal scene, sentences and the recording are laid out together. The renderer finds when each command is typed, submitted, and answered in the recording (cached in `build/raw/<id>.events.json`). A sentence with `wait_for` starts no earlier than its event; an event named by a `before` is held back, by freezing the recording on the frame before it, until that sentence has finished. Output that a hidden `clear` would wipe is held the same way until the sentences about it have ended and it has been read (`pacing.read_hold`, 2.5 s, or the sentence's `read`). Holds lengthen the recording and move every later event (`TERMINAL-DEMOS.md` → *Timing to narration*, *Time to read*).
4. Scene length = max(narration length, length of the `terminal` recording with its holds or of a `manim` or `video` clip, `min_duration`), **rounded up to a whole frame**. Every clip is encoded to an exact frame count, so audio and video can't drift.
5. Each sentence's absolute start becomes its caption cue, and its scene-relative start is what a cue's `"at": "N"` resolves to.

## Commands
```bash
node <SKILL_DIR>/scripts/render-scenes.js <video-dir>                   # renders only what changed
node <SKILL_DIR>/scripts/render-scenes.js <video-dir> --force           # re-render everything
node <SKILL_DIR>/scripts/render-scenes.js <video-dir> --no-record       # same, but fail instead of recording any tape
node <SKILL_DIR>/scripts/render-scenes.js <video-dir> --only s04 --force  # re-record one scene (e.g. a flaky tape)
node <SKILL_DIR>/scripts/render-scenes.js <video-dir> --allow-spend     # allow recording tapes that declare a cost
node <SKILL_DIR>/scripts/sync-report.js <video-dir>                     # terminal scenes: screen events against sentences
node <SKILL_DIR>/scripts/assemble.js <video-dir>                        # mix, concat, mux, verify
node <SKILL_DIR>/scripts/verify.js <video-dir> --frames                 # review stills in build/review/
node <SKILL_DIR>/scripts/verify.js <video-dir> --at 0:56,7:22           # stills at those times, in build/review/at/
```
**Caching:** every clip and raw recording carries a content-hash key covering its visual file, the `_theme/` files, the scene's narration timing, and the encode settings (and, for manim, the timing passed to the scene). A plain run re-renders exactly the scenes whose inputs changed, so after any edit (narration, lexicon, pacing, visuals) just run it again with no flags. `--only` limits a `--force` re-render to some scenes; if a scene outside `--only` is stale, the script stops rather than leave a clip at the wrong length. Images or other files that an HTML slide loads are not in the key, so use `--force` after changing only those.

`render-scenes.js` refuses to run if narration changed since `tts.py` ran; re-run `tts.py <dir>` first. Its JSON output lists `warnings`: script errors, failed or remote loads, and elements overflowing the 1920×1080 canvas. Fix those before assembling.

## What Gets Built
| Path | What |
|---|---|
| `build/clips/<id>.mp4` (+ `.key`) | Per-scene video only, 1920×1080, 30 fps, yuv420p, H.264 CRF 18, exact frame count |
| `build/raw/<id>.mp4` (+ `.key`) | Cached terminal, manim, or video source at its natural length |
| `build/raw/<id>.txt`, `.scan.json`, `.events.json` | Terminal scenes: the screen's text, the credential scan, and the detected screen events |
| `build/timeline.json` | Every scene and sentence with absolute times; terminal scenes also list their commands, events, and holds |
| `build/narration.wav` | One PCM track: each sentence placed at its exact sample offset, loudness-normalized (two-pass, −14 LUFS, −1 dBTP; a silent track is passed through) |
| `build/video.mp4` | Stream-copied concat of the clips |
| `<slug>.mp4` | Final: H.264 + AAC 192k + soft English subtitles + chapters, faststart |
| `<slug>.srt` | Captions: each sentence split into cues of at most 2 lines × 42 characters, timed by character share |
| `chapters.txt` | YouTube description chapter list |

Why this design: AAC per scene drifts when concatenated, so audio stays PCM until a single encode. The clips share one encoding spec, so the concat is a lossless stream copy.

The embedded subtitle track is for local players only; **YouTube ignores it**. The user uploads `<slug>.srt` in YouTube Studio → Subtitles (SKILL.md step 11).

## Reviewing
You cannot watch the video, so:
1. Read `verify.js` JSON. Every check must be `ok`: frame count equal to the timeline, video stream within 2 frames of the timeline, audio and video streams the same length, plus format and caption checks. Fix or report each warning (long or fast captions, chapter rules).
2. Run `--frames` and **open every still** in `build/review/`. Do the look pass on them (`REVIEW.md` → *Look pass*), and look for text clipped at the edges, content in the bottom 160px caption band, unreadable code, blank or black frames, a terminal stuck on its setup screen, and wrong theme colors. For a terminal scene one still is not enough: use `--at` with times just after each command's output (from `sync-report.js`) to see what the viewer is given to read. If you can't view images, give the user the still paths and say the check wasn't done.
3. Ask the user to watch it. Name the things only a human can judge: pronunciation, pacing, and whether reveals land on the right words.

## Troubleshooting
| Symptom | Cause / fix |
|---|---|
| "narration changed since tts.py ran" | Run `tts.py <dir>` |
| The run stops on a credential hit, or "only part of this recording could be scanned" | `TERMINAL-DEMOS.md` → *Credentials on screen* |
| The run stops on an anchor (unknown event, or the tape does not match its recording) | Fix the anchor in `storyboard.json`; if the tape changed, it must record again |
| `--no-record` stops with "tape changed" | The tape was edited after its recording. Get the commands approved and run without `--no-record` (with `--allow-spend` if it declares a cost) |
| "scenes outside --only are out of date" | Run `render-scenes.js <dir>` without `--only` |
| Frame-count or stream-length check fails | A clip was replaced by hand or the build is half-updated; run `render-scenes.js <dir>` then `assemble.js <dir>` |
| Concat fails or the video stutters at a cut | A clip not made by `render-scenes.js` crept in; `render-scenes.js <dir> --force` |
| Warning: script error / failed load / remote request | Fix the slide's HTML (typo in a path, a remote font or image); renders must work offline |
| Warning: overflow | Content runs off the canvas; split the scene or cut text |
| Warning: low contrast | Text is too pale against what is behind it. Remove the color you wrote and use the theme's classes; on the paper, text is `--ink`, `--ink-soft`, or `--ink-muted` |
| Output is cleared before it can be read | Tie the sentence about it to the output with `wait_for`, and add `read` (`TERMINAL-DEMOS.md` → *Time to read*) |
| Warning: hidden content after a `Show` was left as recorded | The renderer could not find a clean frame to cover it with. End that hidden block with `clear` and `Wait /\$\s*$/` before `Show`, and record again (`TERMINAL-DEMOS.md` → *Start states*) |
| An HTML animation is frozen | It uses timers or transitions; see `MOTION-GRAPHICS.md` (the strict lint warns about these) |
| Chapter warnings | Merge short chapters (`chapter` only on the first scene of a section) or accept and report |
| Very slow render | Frame-stepped `html` scenes cost about 1 min per 20 s; use `slide` for anything static |

## Decision Guide
1. Edited anything (narration, lexicon, voice, pacing, visuals)? → `tts.py <dir>` if narration, lexicon, or voice changed → `render-scenes.js <dir>` → `assemble.js <dir>`.
2. A flaky tape or manim render? → `render-scenes.js <dir> --only <id> --force` → `assemble.js <dir>`.
3. A terminal scene where voice and screen disagree? → `sync-report.js <dir>`, fix anchors, `render-scenes.js <dir> --no-record`.
4. Verify ok and stills look right? → Report (SKILL.md step 11).
