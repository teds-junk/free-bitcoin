# Narration

Local text-to-speech with Kokoro-82M through `mlx-audio` on Apple Silicon: setup, voices, speed, running the narration, and failures. How words are pronounced, and how to catch a wrong one without hearing it, is in `PRONUNCIATION.md`.

## Setup
Machine-local state lives outside the skill, in `~/.video-lesson/` (override with the `VIDEO_LESSON_HOME` environment variable): `venv/` (Python), `tts-cache/` (synthesized clips), `models/` (speech-to-text weights), and the recording lock. `PY` in commands stands for `~/.video-lesson/venv/bin/python`. Only `scripts/node_modules` (puppeteer-core, shiki) is installed inside the skill. A venv left in `scripts/` by an older version is moved, not rebuilt, the next time `setup.js --yes` runs.
1. Check: `node <SKILL_DIR>/scripts/setup.js --check`.
2. If it is not set up, **ask the user first**: setup downloads several GB (torch, spaCy, Kokoro weights). Only after they agree, run `node <SKILL_DIR>/scripts/setup.js --yes` (add `--manim` when manim scenes are needed). It refuses to run without `--yes`, and exits before downloading anything on a machine that isn't an Apple Silicon Mac.
3. Setup needs Python **3.12** (misaki 0.9.4, Kokoro's text-to-phoneme library, requires < 3.13 on PyPI) and `espeak-ng` (without it, Kokoro **silently skips** words it doesn't know). Install lines are in the `prereqs.js` output.
4. Setup ends with a self-test and writes `~/.video-lesson/venv/setup-report.json`.

Pinned versions: mlx-audio 0.6.3, misaki[en] 0.9.4, manim 0.22.1. If a command fails after an upgrade, run `PY -m mlx_audio.tts.generate --help` and the current README before changing anything.

## Voices
The voice comes from the workspace preferences (`<workspace>/videos/preferences.json`, see `COURSE.md`); a `voice` block in one video's `storyboard.json` overrides it for that video; with neither, the default is `am_echo` (American male) at 1.2×. The prefix sets the accent and gender: `am…`/`af…` American male/female, `bm…`/`bf…` British. `tts.py` derives Kokoro's `lang_code` from it (Kokoro's own default is wrong). Offer American voices by default and British ones only if the user asks.
| Voice | Character |
|---|---|
| `am_echo`, `am_michael`, `am_fenrir`, `am_puck`, `am_adam`, `am_eric`, `am_liam`, `am_onyx`, `am_santa` | American male |
| `af_heart`, `af_bella`, `af_nicole`, `af_aoede`, `af_kore`, `af_sarah`, `af_nova`, `af_alloy`, `af_sky`, `af_jessica`, `af_river` | American female |
| `bm_george`, `bm_daniel`, `bm_fable`, `bm_lewis`, `bf_emma`, `bf_alice`, `bf_isabella`, `bf_lily` | British |
**Choosing a different voice** (for one video, or for a whole course): build the sample page and open it for the user:
```bash
PY <SKILL_DIR>/scripts/tts.py --samples --video <video-dir> --open        # add --british only if the user asks
```
It renders every American voice saying a real sentence from that video (a question if there is one, for intonation), at that video's speed and with its lexicons, into `<video-dir>/auditions/voices/index.html`, with the current voice highlighted. Without `--video` it uses a stock sentence and the defaults. When the user picks one:
1. For a whole workspace, set `voice.voice` in `<workspace>/videos/preferences.json`; every video without its own `voice` block follows it. For one video only, set `voice.voice` in its `storyboard.json`.
2. Re-run `tts.py <video-dir>`, `render-scenes.js <video-dir>`, and `assemble.js <video-dir>`. Scene lengths shift with the new voice; the render cache handles that.

To compare just a few voices on one specific line, `tts.py --say "<sentence>" --video <video-dir> --voices am_echo,am_michael --play` is quicker.

**Speed:** the default is 1.2 (about 180 wpm; 1.0 is about 150). Set `voice.speed` to change a whole video, or `"speed"` on a scene; 1.05–1.1 suits code-heavy explanations.

## Running Narration
```bash
PY <SKILL_DIR>/scripts/tts.py <video-dir>                # all scenes
PY <SKILL_DIR>/scripts/tts.py <video-dir> --only s03,s07 # after editing those scenes
```
It writes `audio/<id>_<nn>.wav`, one per sentence, plus `audio/timings.json`. Clips are cached by (model, voice, speed, text), so unchanged sentences are free. Silent or NaN output fails loudly.

You cannot listen to audio. Tell the user which clips to spot-check (new lexicon entries, odd terms) and give them the WAV paths. `--play` plays through `afplay`; each result has `"played": true/false`, so never claim it played when it didn't.

## Pronunciation

How words are said (lexicons, heteronyms, names), the analysis that reads what the voice will say, the review page, and the transcript check are in `PRONUNCIATION.md`. Resolve its lists before running the narration: a word fixed afterwards means re-synthesizing and re-rendering every sentence that contains it.

## Failures
| Symptom | Fix |
|---|---|
| `setup.js` fails building spaCy, thinc, or blis | Use Python 3.12: `brew install python@3.12`, delete `~/.video-lesson/venv`, re-run |
| "silent or invalid audio" | Re-run that scene with `--force`; try the `-8bit` model variant in `voice.model` |
| A word is skipped | `espeak-ng` is missing, or a phoneme override has bad symbols |
| End of a sentence cut off or odd | Check for missing final punctuation, or a lexicon or phoneme entry that swallowed a word (compare `tts_text` in `audio/timings.json`). Length is rarely the cause: mlx-audio splits long English text on punctuation at 510 phonemes and only truncates a single unpunctuated run that long |
| First run is slow | Kokoro weights download to `~/.cache/huggingface` once |
| Want a different model (e.g. Qwen3-TTS) | Set `voice.model`. Untested: audition first and check the voice names it supports |

## Decision Guide
1. Is the venv missing? → Ask, then `setup.js --yes`.
2. Is the voice not chosen for this workspace? → Audition 2–3 voices with a real sentence.
3. Does the lint list heteronyms or pronunciation terms? → `PRONUNCIATION.md`: judge the heteronyms, build the review page, import the user's answers.
4. Narration done? → `ASSEMBLY.md`.
