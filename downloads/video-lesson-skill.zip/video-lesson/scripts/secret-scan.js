#!/usr/bin/env node
/**
 * Look for credentials and identity details in terminal demos before they reach a video.
 *
 * Usage:
 *   node secret-scan.js <video-dir> [--scene s14]
 *   node secret-scan.js <video-dir> --accept <hit-id> --reason "made-up value used by the lesson"
 *   node secret-scan.js <video-dir> --reopen <hit-id>
 *   node secret-scan.js <video-dir> --scene s14 --reviewed --reason "watched build/raw/s14.mp4"
 *   node secret-scan.js --text <file>
 *
 * What it reads, per terminal scene:
 *   the tape (everything it types, hidden or visible, and its other lines), and
 *   build/raw/<id>.txt, the text of the terminal screen that vhs saves after each tape step.
 *
 * Secrets block the render: well-known token shapes, long opaque values after token= / key= /
 * secret= / password=, and the value of any environment variable whose name looks secret, when
 * that value is on screen. Identity details (emails, the home directory, the user name, the
 * host name) are reported and do not block.
 *
 * A secret's value is never printed or stored: a hit carries its kind, the variable name if
 * there is one, a masked form, and where it is.
 *
 * Writes build/raw/<id>.scan.json. Prints JSON on stdout and notes on stderr.
 * Exit code: 0 nothing open, 1 a secret is open, 2 usage error.
 *
 * Limit worth knowing: vhs saves the screen text once per tape step, and after the screen has
 * filled it keeps saving the first screenful, not what is on screen. From that point the scan
 * is blind until a `clear`. The result says so under "coverage".
 */
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const L = require('./lib');

const VERSION = 1;
const SEPARATOR = /^─{20,}$/;

// ---- detectors -------------------------------------------------------------

// [kind, pattern, public prefix that is safe to show]
const TOKEN_PATTERNS = [
  ['github-token', /\b(?:gh[pousr]_[A-Za-z0-9]{16,}|github_pat_[A-Za-z0-9_]{20,})/g, /^(?:github_pat_|gh[pousr]_)/],
  ['sk-api-key', /\bsk-[A-Za-z0-9_-]{20,}/g, /^sk-(?:ant-|proj-)?/],
  ['aws-access-key-id', /\b(?:AKIA|ASIA)[0-9A-Z]{16}\b/g, /^.{4}/],
  ['slack-token', /\bxox[abeoprs]-[A-Za-z0-9-]{10,}/g, /^xox.-/],
  ['jwt', /\beyJ[A-Za-z0-9_-]{8,}\.eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]*/g, /^eyJ/],
  ['google-api-key', /\bAIza[0-9A-Za-z_-]{35}/g, /^AIza/],
  ['npm-token', /\bnpm_[A-Za-z0-9]{36}/g, /^npm_/],
  ['gitlab-token', /\bglpat-[A-Za-z0-9_-]{20,}/g, /^glpat-/],
  ['huggingface-token', /\bhf_[A-Za-z0-9]{30,}/g, /^hf_/],
  ['private-key-block', /-----BEGIN [A-Z ]*PRIVATE KEY-----/g, null],
];
const BEARER = /\bBearer\s+([A-Za-z0-9._~+/=-]{16,})/g;
const URL_CREDENTIALS = /\b[a-z][a-z0-9+.-]*:\/\/[^\s:@/]+:([^\s@/]{6,})@/gi;
// name = value, name: value, "name": "value", --name=value; the name must END in a secret word.
const ASSIGNMENT = /(?<![A-Za-z0-9])([A-Za-z0-9_.-]*?(token|secret|password|passwd|credential|api[_-]?key|key)s?)["']?\s*[=:]\s*["']?([^\s"'`,;&|<>(){}[\]]+)/gi;
const PLACEHOLDER = /^(?:password|passwd|changeme|example|secret|redacted|hidden|masked|none|null|true|false|required|optional|string|value|your[-_a-z]*)$/i;
const EMAIL = /[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}/g;
// Environment variable names whose VALUE is treated as a secret when it shows up.
const SECRET_ENV_NAME = /TOKEN|SECRET|PASSWORD|PASSWD|CREDENTIAL|APIKEY|(?:^|_)(?:API_?)?KEYS?(?:_|$)/i;

function entropy(s) {
  const n = {};
  for (const ch of s) n[ch] = (n[ch] || 0) + 1;
  return Object.values(n).reduce((e, c) => e - (c / s.length) * Math.log2(c / s.length), 0);
}

// Is `value` long and opaque enough to be a credential rather than an ordinary setting?
function opaque(word, value) {
  if (/^[$%<{[]/.test(value) || /^(?:\/|\.\/|~|https?:)/i.test(value)) return false; // variable, placeholder, path, URL
  if (/^(.)\1*$/.test(value) || /^[x*•.#-]+$/i.test(value)) return false; // already a mask
  if (/passw/i.test(word)) return value.length >= 6 && !PLACEHOLDER.test(value);
  const mixed = /[0-9]/.test(value) && /[A-Za-z]/.test(value);
  if (/^key$/i.test(word)) return value.length >= 16 && mixed && entropy(value) >= 3;
  return value.length >= 12 && mixed && entropy(value) >= 2.5;
}

// What to look for on this machine: secret environment values and identity strings.
function context(env = process.env) {
  const secrets = [];
  for (const [name, value] of Object.entries(env)) {
    if (!SECRET_ENV_NAME.test(name) || typeof value !== 'string') continue;
    const v = value.trim();
    if (v.length < 8 || /^\d+$/.test(v) || /^(?:\/|~|\.\/)/.test(v) || /\s/.test(v)) continue; // too short, a number, a path, prose
    secrets.push([name, v]);
  }
  secrets.sort((a, b) => b[1].length - a[1].length);
  const safe = fn => { try { return fn(); } catch { return ''; } };
  const home = safe(() => os.homedir());
  const user = safe(() => os.userInfo().username);
  const host = safe(() => os.hostname());
  const hosts = [...new Set([host, host.split('.')[0]])].filter(h => h.length >= 4 && h !== 'localhost');
  return { secrets, home: home.length >= 6 ? home : '', user: user.length >= 3 ? user : '', hosts };
}

const escapeRe = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// All findings in one string. Internal: findings carry the matched value, so they never leave this file.
function detect(text, ctx) {
  const found = [];
  const add = (pri, severity, kind, start, value, extra) => {
    if (value) found.push({ pri, severity, kind, start, end: start + value.length, value, ...extra });
  };
  for (const [name, value] of ctx.secrets) {
    for (let i = text.indexOf(value); i >= 0; i = text.indexOf(value, i + value.length)) add(0, 'secret', 'env-value', i, value, { env: name });
  }
  for (const [kind, re, prefix] of TOKEN_PATTERNS) {
    for (const m of text.matchAll(re)) add(1, 'secret', kind, m.index, m[0], { prefix: prefix ? (m[0].match(prefix) || [''])[0] : '' });
  }
  for (const m of text.matchAll(URL_CREDENTIALS)) add(2, 'secret', 'url-password', m.index + m[0].length - 1 - m[1].length, m[1]);
  for (const m of text.matchAll(BEARER)) add(3, 'secret', 'bearer-token', m.index + m[0].length - m[1].length, m[1]);
  for (const m of text.matchAll(ASSIGNMENT)) {
    const value = m[3].replace(/[.)]+$/, '');
    if (opaque(m[2], value)) add(4, 'secret', 'credential-assignment', m.index + m[0].length - m[3].length, value, { name: m[1] });
  }
  if (ctx.home) {
    for (let i = text.indexOf(ctx.home); i >= 0; i = text.indexOf(ctx.home, i + ctx.home.length)) add(5, 'identity', 'home-path', i, ctx.home);
  }
  for (const m of text.matchAll(EMAIL)) {
    if (/^git$/.test(m[0].split('@')[0]) && text[m.index + m[0].length] === ':') continue; // git@host:repo is a URL, not a person
    add(6, 'identity', 'email', m.index, m[0]);
  }
  const word = s => new RegExp(`(?<![A-Za-z0-9_])${escapeRe(s)}(?![A-Za-z0-9_])`, 'g');
  if (ctx.user) for (const m of text.matchAll(word(ctx.user))) add(7, 'identity', 'user-name', m.index, m[0]);
  for (const h of ctx.hosts) for (const m of text.matchAll(word(h))) add(8, 'identity', 'host-name', m.index, m[0]);

  // Overlaps: the earlier (more specific) detector wins; an env value that is also a known token shape keeps both facts.
  found.sort((a, b) => a.pri - b.pri || a.start - b.start);
  const kept = [];
  for (const f of found) {
    const clash = kept.find(k => f.start < k.end && k.start < f.end);
    if (!clash) { kept.push(f); continue; }
    if (clash.start === f.start && clash.end === f.end && clash.kind === 'env-value' && f.pri === 1) {
      clash.kind = f.kind;
      clash.prefix = f.prefix;
    }
  }
  return kept.sort((a, b) => a.start - b.start);
}

function mask(f) {
  const v = f.value;
  if (f.severity === 'secret') return `${f.prefix || ''}…(${v.length} chars)`;
  if (f.kind === 'email') return `${v[0]}…@…${v.slice(v.lastIndexOf('.'))}`;
  if (f.kind === 'home-path') return `${path.dirname(v)}${path.sep}…`;
  return `${v[0]}…(${v.length} chars)`;
}

// Ids are stable for the same value in the same scene, and say nothing about the value:
// they are salted with a random number kept outside the video folder.
let saltCache = null;
function salt() {
  if (saltCache) return saltCache;
  const file = path.join(L.STATE_DIR, 'scan-salt');
  try {
    if (!fs.existsSync(file)) {
      fs.mkdirSync(L.STATE_DIR, { recursive: true });
      fs.writeFileSync(file, crypto.randomBytes(24).toString('hex') + '\n', { mode: 0o600, flag: 'wx' });
    }
    saltCache = fs.readFileSync(file, 'utf8').trim();
  } catch { saltCache = `${os.hostname()}:${os.userInfo().username}`; }
  return saltCache;
}
const hitId = (f, scope, source) => `${f.severity === 'secret' ? 'sec' : 'idn'}-${L.sha1(salt(), scope, source, f.severity, f.value).slice(0, 8)}`;

// ---- text and tapes --------------------------------------------------------

// Run the detectors over lines. With `cols`, a line that fills the terminal width is treated as
// wrapped onto the next one, so a long token split across two rows is still seen whole.
// Returns findings with segments: [{ row, col, len }] (0-based).
function findInLines(lines, ctx, cols) {
  let text = '';
  const at = []; // index in `text` -> [row, col]
  lines.forEach((line, row) => {
    for (let c = 0; c < line.length; c++) at.push([row, c]);
    text += line;
    if (!(cols && line.length >= cols)) { text += '\n'; at.push([row, line.length]); }
  });
  return detect(text, ctx).map(f => {
    const segments = [];
    for (let i = f.start; i < f.end; i++) {
      const [row, col] = at[i];
      const last = segments[segments.length - 1];
      if (last && last.row === row && last.col + last.len === col) last.len += 1; else segments.push({ row, col, len: 1 });
    }
    return { ...f, segments };
  });
}

// Group findings into hits (one per distinct value), keeping the value out of the result.
function toHits(findings, scope, source, placeOf) {
  const byValue = new Map();
  for (const f of findings) {
    const key = `${f.severity}\0${f.value}`;
    if (!byValue.has(key)) byValue.set(key, { f, places: [] });
    byValue.get(key).places.push(...placeOf(f));
    const g = byValue.get(key);
    if (f.env && !g.f.env) g.f.env = f.env;
  }
  // A value seen while it was still being typed (missing its last characters) is the same hit.
  const groups = [...byValue.values()];
  for (const g of groups) {
    if (g.f.severity !== 'secret' || g.merged) continue;
    const whole = groups.find(o => o !== g && !o.merged && o.f.severity === 'secret' && o.f.value.length > g.f.value.length && o.f.value.startsWith(g.f.value));
    if (whole) { whole.places.push(...g.places); g.merged = true; }
  }
  return groups.filter(g => !g.merged).map(g => ({
    id: hitId(g.f, scope, source),
    severity: g.f.severity,
    kind: g.f.kind,
    env: g.f.env || null,
    masked: mask(g.f),
    length: g.f.value.length,
    source,
    where: g.places,
  }));
}

// Any text: hits with 1-based line numbers.
function scanText(text, opts = {}) {
  const ctx = opts.context || context(opts.env);
  const findings = findInLines(String(text).split('\n'), ctx, 0);
  return toHits(findings, opts.scope || 'text', opts.source || 'text', f => f.segments.map(s => ({ line: s.row + 1, col: s.col, len: s.len })));
}

// A tape: every line is read for secrets (a token in a comment still ends up in a repository);
// identity details are only reported where they will be typed on screen.
function scanTape(text, opts = {}) {
  const ctx = opts.context || context(opts.env);
  const lines = String(text).split('\n');
  const typed = [];
  let hidden = false;
  lines.forEach((raw, i) => {
    const line = raw.trim();
    const cmd = line.split(/\s+/)[0] || '';
    if (cmd === 'Hide') hidden = true;
    else if (cmd === 'Show') hidden = false;
    typed[i] = /^Type(?:@\S+)?$/.test(cmd) ? (hidden ? 'hidden' : 'visible') : null;
  });
  const findings = findInLines(lines, ctx, 0).filter(f => f.severity === 'secret' || typed[f.segments[0].row] === 'visible');
  return toHits(findings, opts.scope || 'tape', 'tape', f => f.segments.map(s => ({ line: s.row + 1, col: s.col, len: s.len, typed: typed[s.row] })));
}

// ---- screen snapshots ------------------------------------------------------

// vhs writes the screen as text after each step, each snapshot followed by a line of ─.
function parseSnapshots(text) {
  const snaps = [];
  let cur = [];
  let sep = null;
  for (const line of String(text).split('\n')) {
    if (SEPARATOR.test(line)) { snaps.push(cur); cur = []; sep = sep || line; } else cur.push(line);
  }
  return { snaps, sep: sep || '─'.repeat(80), tail: cur };
}

function serializeSnapshots({ snaps, sep, tail }) {
  return snaps.map(s => [...s, sep].join('\n')).join('\n') + (snaps.length ? '\n' : '') + tail.join('\n');
}

// Which tape step each snapshot follows (vhs 0.11): one per setting line once the text output is
// declared (not `Set Shell`), then one per step while the recording is shown, starting at `Show`.
// Returns null when the tape uses something this does not model; callers then scan every snapshot.
function snapshotSteps(tapeText) {
  const cmds = [];
  String(tapeText).split('\n').forEach((raw, i) => {
    const line = raw.trim();
    if (!line || line.startsWith('#')) return;
    const cmd = line.split(/\s+/)[0].replace(/@.*$/, '');
    if (cmd !== 'Output') cmds.push({ line: i + 1, cmd, raw: line });
  });
  if (cmds.some(c => ['Require', 'Source', 'Env'].includes(c.cmd))) return null;
  const steps = [{ line: 0, cmd: 'Output', setup: true }];
  let i = 0;
  for (; i < cmds.length && cmds[i].cmd === 'Set'; i++) {
    if (!/^Set\s+Shell\b/.test(cmds[i].raw)) steps.push({ line: cmds[i].line, cmd: 'Set', setup: true });
  }
  const leadingHide = cmds[i] && cmds[i].cmd === 'Hide';
  let shown = true;
  let seenShow = false;
  for (; i < cmds.length; i++) {
    const c = cmds[i];
    if (c.cmd === 'Hide') { shown = false; continue; }
    if (c.cmd === 'Show') {
      shown = true;
      // The first Show after a leading hidden block still holds the hidden command line, which is
      // gone before the first video frame; whatever stays on screen is in the next snapshot.
      steps.push({ line: c.line, cmd: 'Show', residue: leadingHide && !seenShow });
      seenShow = true;
      continue;
    }
    if (c.cmd === 'Set' && !/^Set\s+TypingSpeed\b/.test(c.raw)) continue;
    if (shown) steps.push({ line: c.line, cmd: c.cmd });
  }
  return steps;
}

// The settings of a tape that decide where things land in the frame (vhs defaults where unset).
function tapeSettings(text) {
  const s = { Width: 1200, Height: 600, Padding: 60, FontSize: 22, LetterSpacing: 1, LineHeight: 1, Margin: 0, WindowBar: '', BorderRadius: 0 };
  for (const line of String(text).split('\n')) {
    const m = line.trim().match(/^Set\s+(\w+)\s+(.+)$/);
    if (!m || !(m[1] in s)) continue;
    const v = m[2].trim().replace(/^["']|["']$/g, '');
    s[m[1]] = typeof s[m[1]] === 'number' ? Number(v) : v;
  }
  return s;
}

// Terminal width in characters: a cell is 0.6 x FontSize + LetterSpacing wide before vhs scales
// the canvas to the padded area (measured on recordings with JetBrains Mono and Menlo).
const terminalCols = set => Math.floor((set.Width - 2 * set.Padding) / (0.6 * set.FontSize + set.LetterSpacing));

// Snapshot layout shared with redact.js: which snapshots show the demo, and where the screen filled.
function screenLayout(snapshotText, tapeText) {
  const parsed = parseSnapshots(snapshotText);
  const { snaps } = parsed;
  let steps = tapeText ? snapshotSteps(tapeText) : null;
  if (steps && steps.length !== snaps.length) steps = null;
  const scanned = snaps.map((s, k) => (steps ? !steps[k].setup && !steps[k].residue : true));
  const last = [...snaps.keys()].reverse().find(k => scanned[k]);
  const rows = last === undefined ? 0 : snaps[last].length;
  // A row that is exactly as wide as the terminal continues on the next row (a wrapped line).
  // Without a tape to read the width from, rows are never joined.
  const widest = Math.max(0, ...snaps.flatMap((s, k) => (scanned[k] ? s.map(l => l.length) : [])));
  const cols = tapeText ? Math.max(terminalCols(tapeSettings(tapeText)), widest) : 0;
  // Bottom row in use: the screen is full and may have scrolled; vhs then keeps saving the first screenful.
  const filled = snaps.map((s, k) => scanned[k] && s.length > 0 && s.length >= rows && s[s.length - 1].trim() !== '');
  return { parsed, snaps, steps, scanned, rows, cols, filled };
}

function scanScreen(snapshotText, tapeText, opts = {}) {
  const ctx = opts.context || context(opts.env);
  const lay = screenLayout(snapshotText, tapeText);
  const findings = [];
  const cache = new Map();
  lay.snaps.forEach((rows, k) => {
    if (!lay.scanned[k]) return;
    const key = rows.join('\n');
    if (!cache.has(key)) cache.set(key, findInLines(rows, ctx, lay.cols));
    for (const f of cache.get(key)) findings.push({ ...f, snapshot: k });
  });
  const hits = toHits(findings, opts.scope || 'screen', 'screen', f => f.segments.map(s => ({ ...s, snapshot: f.snapshot })));
  // Fold the per-snapshot places into one entry per screen position.
  for (const h of hits) {
    const places = new Map();
    for (const p of h.where) {
      const key = `${p.row}:${p.col}`;
      if (!places.has(key)) places.set(key, { row: p.row, col: p.col, len: p.len, snapshots: [] });
      const e = places.get(key);
      e.len = Math.max(e.len, p.len);
      if (!e.snapshots.includes(p.snapshot)) e.snapshots.push(p.snapshot);
    }
    h.where = [...places.values()].map(e => {
      e.snapshots.sort((a, b) => a - b);
      const step = lay.steps && lay.steps[e.snapshots[0]];
      return step ? { ...e, first_after: { step: step.cmd, tape_line: step.line } } : e;
    });
  }
  const filledFrom = lay.filled.indexOf(true);
  const count = lay.scanned.filter(Boolean).length;
  const coverage = {
    screen: count === 0 ? 'none' : filledFrom >= 0 ? 'partial' : 'full',
    snapshots: lay.snaps.length,
    scanned_snapshots: count,
    rows: lay.rows,
    filled_from: filledFrom >= 0 ? filledFrom : null,
    note: filledFrom >= 0
      ? `the screen was full from snapshot ${filledFrom}${lay.steps ? ` (after ${lay.steps[filledFrom].cmd}, tape line ${lay.steps[filledFrom].line})` : ''}; ` +
        'while it is full vhs saves the first screenful instead of what is on screen, so output after that point was not scanned'
      : null,
  };
  return { hits, coverage };
}

// ---- per-scene results (build/raw/<id>.scan.json) ---------------------------

const snapshotPath = raw => raw.replace(/\.mp4$/, '') + '.txt';
const scanPath = raw => raw.replace(/\.mp4$/, '') + '.scan.json';

function readScan(file) {
  if (!fs.existsSync(file)) return null;
  try { return L.readJSON(file); } catch { return null; }
}

function writeScan(file, data) {
  const next = JSON.stringify(data, null, 2) + '\n';
  if (fs.existsSync(file) && fs.readFileSync(file, 'utf8') === next) return;
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, next);
}

// Scan one terminal scene and merge with what was decided before (accepted, redacted).
function checkScene(scene, dir, raw, opts = {}) {
  const file = scanPath(raw);
  const txt = snapshotPath(raw);
  const tapeFile = path.resolve(dir, scene.visual);
  const tapeText = fs.existsSync(tapeFile) ? fs.readFileSync(tapeFile, 'utf8') : '';
  const ctx = opts.context || context(opts.env);
  const prev = readScan(file) || {};
  const recorded = fs.existsSync(raw);
  const hasText = fs.existsSync(txt);

  const found = scanTape(tapeText, { context: ctx, scope: scene.id });
  let coverage = { screen: 'none', snapshots: 0, scanned_snapshots: 0, rows: 0, filled_from: null,
    note: recorded ? 'recorded before secret scanning existed: there is no screen text to scan' : 'not recorded yet' };
  if (hasText) {
    const screen = scanScreen(fs.readFileSync(txt, 'utf8'), tapeText, { context: ctx, scope: scene.id });
    found.push(...screen.hits);
    coverage = screen.coverage;
  }
  if (prev.coverage && prev.coverage.reviewed) coverage.reviewed = prev.coverage.reviewed;

  const before = new Map((prev.hits || []).map(h => [h.id, h]));
  const hits = found.map(h => {
    const old = before.get(h.id);
    before.delete(h.id);
    const keep = old && old.status !== 'open' ? { status: old.status, reason: old.reason, decided: old.decided, redaction: old.redaction } : { status: 'open' };
    return JSON.parse(JSON.stringify({ ...h, ...keep }));
  });
  // A redacted value is blanked in the screen text, so it is no longer found; keep the record of it.
  for (const old of before.values()) if (old.status === 'redacted' || old.status === 'accepted') hits.push(old);

  const result = {
    version: VERSION,
    scene: scene.id,
    tape: scene.visual,
    snapshot: hasText ? path.relative(dir, txt) : null,
    scanned: { tape: Boolean(tapeText), screen: hasText },
    coverage,
    hits,
  };
  if (prev.manual_regions) result.manual_regions = prev.manual_regions;
  if (opts.write !== false) writeScan(file, result);
  return {
    ...result,
    file,
    recorded,
    open_secrets: hits.filter(h => h.severity === 'secret' && h.status === 'open'),
    open_identity: hits.filter(h => h.severity === 'identity' && h.status === 'open'),
  };
}

function describe(h) {
  const where = h.where.map(w => (h.source === 'tape'
    ? `tape line ${w.line}, col ${w.col}${w.typed ? ` (typed, ${w.typed})` : ''}`
    : `screen row ${w.row}, col ${w.col}, snapshot${w.snapshots.length > 1 ? 's' : ''} ${w.snapshots[0]}${w.snapshots.length > 1 ? `-${w.snapshots[w.snapshots.length - 1]}` : ''}` +
      (w.first_after ? ` (first after ${w.first_after.step}, tape line ${w.first_after.tape_line})` : ''))).join('; ');
  return `${h.id}  ${h.kind}${h.env ? ` (value of $${h.env})` : ''}  ${h.masked}  ${where}`;
}

function blockMessage(scene, dir, res, secrets) {
  const rel = path.relative(dir, res.file);
  const short = p => { const r = path.relative(process.cwd(), p); return r && !r.startsWith('..') ? r : p; };
  const script = name => short(path.join(__dirname, name));
  const lines = [`${scene.id}: ${secrets.length} credential${secrets.length > 1 ? 's' : ''} in this terminal demo (${rel}):`];
  for (const h of secrets) lines.push(`    ${describe(h)}`);
  lines.push('  Resolve each one, then run again:');
  if (secrets.some(h => h.source === 'screen')) {
    lines.push(`    1. Best: keep the value off the screen (mask it in the command or its output), then record again:`);
    lines.push(`         node ${script('render-scenes.js')} ${short(dir)} --only ${scene.id} --force`);
    lines.push('    2. Blur it in the recording:');
    lines.push(`         node ${script('redact.js')} ${short(dir)} --scene ${scene.id} --hit <id>`);
    lines.push('    3. It is not a real credential:');
    lines.push(`         node ${script('secret-scan.js')} ${short(dir)} --accept <id> --reason "why it is safe to show"`);
  }
  if (secrets.some(h => h.source === 'tape')) {
    lines.push(`    In the tape: do not write a credential into ${scene.visual}; read it from the environment (for example $GH_TOKEN).`);
    lines.push('    If it is a made-up value:');
    lines.push(`         node ${script('secret-scan.js')} ${short(dir)} --accept <id> --reason "why it is safe to show"`);
  }
  return lines.join('\n');
}

// Called by render-scenes.js for every terminal scene on every run. Stops the run while a secret is open.
function terminalGate(scene, dir, raw, opts = {}) {
  const res = checkScene(scene, dir, raw, opts);
  const say = opts.log || (m => console.error(m));
  if (res.open_secrets.length) L.die(blockMessage(scene, dir, res, res.open_secrets));
  const rel = path.relative(dir, res.file);
  if (res.recorded && !res.scanned.screen) {
    say(`  ${scene.id}: recorded before secret scanning existed, so its screen was not scanned (re-recording it adds the scan)`);
  } else if (res.coverage.screen === 'partial' && !res.coverage.reviewed) {
    // A scan that could not see the whole recording proves nothing about the rest, so this stops
    // the run until someone has looked. It costs a minute; a credential in a published video does not.
    L.die(`${scene.id}: only part of this recording could be scanned for credentials: ${res.coverage.note}.\n` +
      `  1. Write stills of the whole recording and look at them:\n` +
      `       node ${path.join(__dirname, 'redact.js')} ${dir} --scene ${scene.id} --stills\n` +
      `  2. If nothing secret is on screen, record that you looked:\n` +
      `       node ${path.join(__dirname, 'secret-scan.js')} ${dir} --scene ${scene.id} --reviewed --reason "what you looked at"\n` +
      `     If something is, cover it (redact.js --rows or --box) or re-record with the value masked.\n` +
      `  To make the next recording fully scannable, keep the demo within one screen or run \`clear\` between commands.`);
  }
  if (res.open_identity.length) {
    const kinds = [...new Set(res.open_identity.map(h => h.kind))].join(', ');
    say(`  ${scene.id}: ${res.open_identity.length} identity detail${res.open_identity.length > 1 ? 's' : ''} in this demo (${kinds}); see ${rel}`);
  }
  return res;
}

// Before recording: a credential written into the tape stops the recording. Hits from the old
// recording's screen do not, because re-recording is one of the ways to resolve them.
function tapeGate(scene, dir, raw, opts = {}) {
  const res = checkScene(scene, dir, raw, opts);
  const secrets = res.open_secrets.filter(h => h.source === 'tape');
  if (secrets.length) L.die(blockMessage(scene, dir, res, secrets));
  return res;
}

// After a new recording: decisions about the old picture no longer apply. Accepted values stay accepted.
function resetAfterRecording(scene, dir, raw) {
  const file = scanPath(raw);
  const prev = readScan(file);
  if (!prev) return;
  prev.hits = (prev.hits || []).filter(h => h.status === 'accepted');
  if (prev.coverage) delete prev.coverage.reviewed;
  delete prev.manual_regions;
  writeScan(file, prev);
}

// ---- CLI -------------------------------------------------------------------

function terminalScenes(sb, dir, only) {
  const scenes = (sb.scenes || []).filter(s => s.renderer === 'terminal' && (!only || s.id === only));
  if (only && !scenes.length) L.die(`no terminal scene "${only}" in ${path.join(dir, 'storyboard.json')}`);
  return scenes.map(scene => ({ scene, raw: path.join(dir, 'build', 'raw', `${scene.id}.mp4`) }));
}

function decide(dir, scenes, id, change) {
  for (const { scene, raw } of scenes) {
    const data = readScan(scanPath(raw));
    const hit = data && (data.hits || []).find(h => h.id === id);
    if (!hit) continue;
    change(hit);
    writeScan(scanPath(raw), data);
    return { scene: scene.id, hit };
  }
  return L.die(`no hit "${id}" in this video's scan results; run secret-scan.js ${dir} to list them`);
}

function usage(code) {
  const text = fs.readFileSync(__filename, 'utf8').split('\n').slice(2, 30).map(l => l.replace(/^ \*\/?( |$)/, '')).join('\n');
  (code ? console.error : console.log)(text);
  process.exit(code);
}

function main() {
  const args = L.parseArgs(process.argv.slice(2), ['help', 'reviewed']);
  if (args.help) usage(0);

  if (args.text) {
    if (!fs.existsSync(args.text)) L.die(`no file at ${args.text}`);
    const hits = scanText(fs.readFileSync(args.text, 'utf8'));
    const secrets = hits.filter(h => h.severity === 'secret');
    console.log(JSON.stringify({ file: path.resolve(args.text), secrets: secrets.length, identity: hits.length - secrets.length, hits }, null, 2));
    process.exit(secrets.length ? 1 : 0);
  }
  if (!args._[0]) usage(2);
  const { sb, dir } = L.loadStoryboard(args._[0]);
  const scenes = terminalScenes(sb, dir, args.scene);

  if (args.accept || args.reopen) {
    if (args.accept && !(args.reason || '').trim()) L.die('--accept needs --reason "why this value is safe to show"');
    scenes.forEach(({ scene, raw }) => checkScene(scene, dir, raw));
    const done = decide(dir, scenes, args.accept || args.reopen, hit => {
      if (args.accept) Object.assign(hit, { status: 'accepted', reason: args.reason.trim(), decided: new Date().toISOString() });
      else { hit.status = 'open'; delete hit.reason; delete hit.decided; delete hit.redaction; }
    });
    console.log(JSON.stringify({ scene: done.scene, id: done.hit.id, status: done.hit.status, kind: done.hit.kind, masked: done.hit.masked }, null, 2));
    return;
  }
  if (args.reviewed) {
    if (!args.scene || !(args.reason || '').trim()) L.die('--reviewed needs --scene <id> and --reason "what you looked at"');
    const { scene, raw } = scenes[0];
    checkScene(scene, dir, raw);
    const data = readScan(scanPath(raw));
    data.coverage.reviewed = { at: new Date().toISOString(), reason: args.reason.trim() };
    writeScan(scanPath(raw), data);
    console.log(JSON.stringify({ scene: scene.id, coverage: data.coverage }, null, 2));
    return;
  }

  const out = scenes.map(({ scene, raw }) => {
    const r = checkScene(scene, dir, raw);
    return { scene: r.scene, file: path.relative(dir, r.file), scanned: r.scanned, coverage: r.coverage, hits: r.hits };
  });
  const open = sev => out.reduce((n, s) => n + s.hits.filter(h => h.severity === sev && h.status === 'open').length, 0);
  const result = { scenes: out, open_secrets: open('secret'), open_identity: open('identity') };
  console.log(JSON.stringify(result, null, 2));
  for (const s of out) {
    for (const h of s.hits) if (h.status === 'open') console.error(`${h.severity === 'secret' ? 'SECRET  ' : 'identity'} ${s.scene}  ${describe(h)}`);
    if (!s.scanned.screen) console.error(`note: ${s.scene}: screen not scanned (${s.coverage.note})`);
    else if (s.coverage.screen === 'partial' && !s.coverage.reviewed) console.error(`note: ${s.scene}: ${s.coverage.note}`);
  }
  process.exit(result.open_secrets ? 1 : 0);
}

module.exports = {
  scanText, scanTape, scanScreen, checkScene, terminalGate, tapeGate, resetAfterRecording,
  parseSnapshots, serializeSnapshots, snapshotSteps, screenLayout, tapeSettings, terminalCols,
  snapshotPath, scanPath, readScan, writeScan, describe,
};

if (require.main === module) main();
