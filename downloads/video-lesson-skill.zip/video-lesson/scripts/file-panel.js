#!/usr/bin/env node
/**
 * Put a real file on screen: turn it into the "file panel" fragment a scene uses.
 *
 * Usage:
 *   node file-panel.js --file <path> [--lang yaml] [--show 1-12,40-52]
 *        [--mark 4=report,5=report] [--mark '30=pattern:monochrome'] [--mark hidden:13=skipped]
 *        [--expect '20=You have a skill'] [--id spec] [--label evals/eval.yaml]
 *        [--width 62] [--rows 10] [--no-minimap] [--no-tail] [--no-label]
 *        [--into <scene.html> | --out <fragment.html>]
 *
 * The text is the file's, verbatim, with its real 1-based line numbers. The panel is a window
 * of --rows rows over every shown range; "scroll" cues move the window (MOTION-GRAPHICS.md),
 * and a minimap beside it shows the whole file in miniature (each word a small block in its
 * syntax colour) with the region in the window marked.
 *
 * --file     the file to show (a copy kept with the video, so the video can be rebuilt).
 * --lang     highlighter language; guessed from the extension when omitted.
 * --show     lines to show: "12", "1-12", "200-end", comma-separated and ascending. Default:
 *            the whole file. Every stretch left out, before, between, and after the ranges,
 *            becomes one row: "14 lines hidden · 20–33". A stretch of exactly one line is
 *            shown instead, since the row would take the same space; the summary lists such
 *            lines under "filled".
 * --mark     make a highlight target for "focus" cues. Repeatable, or comma-separated:
 *              4=report             line 4, from its first non-space character
 *              86-90=grader         each of those lines; one concept, highlighted together
 *              30=pattern:monochrome   only that substring of line 30 (it must occur once)
 *              hidden:13=skipped    the "lines hidden" row that covers line 13
 *            The same concept on several lines highlights them together.
 * --expect   LINE=substring. Repeatable. Stops with an error unless that line contains the
 *            substring, so a source file that changed cannot silently shift what is shown.
 * --id       element id of the panel, the target of scroll cues ("#spec"). Default: file.
 * --label    name shown above the panel. Default: the file's base name.
 * --width    characters per row before a long line wraps (default 62). Wrapped rows break at
 *            a space, outside a double-quoted string when possible, and carry ↪ in the gutter.
 * --rows     rows in the window (default 9, the most that fits under an eyebrow and a one-line
 *            headline; 12 fits when the panel has the scene to itself).
 * --no-minimap  leave the minimap out, for a panel with no room for one (it shares the scene
 *            with notes or another panel; a panel under 40 columns leaves it out by itself).
 *            A viewer must always be able to tell that they are seeing part of a file. The
 *            minimap says so when there is room. Without it, the "lines hidden" rows say so,
 *            provided every row is in the window at once and every left-out stretch has its
 *            row. When that is not the case (the window scrolls, or --no-tail dropped the last
 *            row), a scrollbar is drawn in the minimap's place. A panel that shows the whole
 *            file has neither.
 * --no-tail  no "lines hidden" row after the last shown range.
 * --no-label no name above the panel.
 * --into     write the panel into a scene file, replacing what is between
 *            <!-- file-panel:ID --> and <!-- /file-panel:ID -->; the command is recorded in
 *            the opening marker so the panel can be regenerated.
 * --out      write the fragment to a file.
 *
 * With --into or --out the JSON summary goes to stdout. With neither, the fragment goes to
 * stdout (like code.js) and the summary to stderr.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const L = require('./lib');
const C = require('./code');

// Geometry shared with assets/theme.css (.file-panel …). Keep the two in step.
const ROW_PX = 58;         // --file-row: the height of every row
const CH_PX = 21.6;        // one character of the 36px code font
const PAD_X = 36;          // .file-body padding, left and right
const PAD_Y = 24;          // .file-body padding, top and bottom
const LABEL_PX = 42;       // the .code-file line above the panel, with its gap
const MAP_PX = 120;        // .file-map width
const MAP_GAP_PX = 40;     // gap between the window and the minimap
const BAR_PX = 10;         // .file-bar width: the scrollbar drawn when there is no room for the minimap
const BAR_GAP_PX = 24;     // gap between the window and the scrollbar
const NARROW_COLS = 40;    // a panel under this many columns has no room for the minimap
const CONTENT_W = L.VIDEO.width - 240;         // canvas minus the 120px safe margins
const CONTENT_H = L.VIDEO.height - 104 - 160;  // minus the scene's top padding and the caption band
const MAX_ROWS = 12;
const DEFAULT_ROWS = 9;
const DEFAULT_WIDTH = 62;

const LANG_BY_EXT = {
  yml: 'yaml', yaml: 'yaml', json: 'json', jsonc: 'jsonc', js: 'js', mjs: 'js', cjs: 'js', jsx: 'jsx',
  ts: 'ts', mts: 'ts', cts: 'ts', tsx: 'tsx', py: 'python', rb: 'ruby', go: 'go', rs: 'rust',
  sh: 'bash', bash: 'bash', zsh: 'bash', md: 'markdown', toml: 'toml', ini: 'ini', html: 'html',
  css: 'css', sql: 'sql', java: 'java', kt: 'kotlin', swift: 'swift', c: 'c', h: 'c', cpp: 'cpp',
  cs: 'csharp', php: 'php', xml: 'xml', tf: 'terraform', bicep: 'bicep', patch: 'diff', diff: 'diff',
  dockerfile: 'docker', makefile: 'makefile', // matched on the whole name when there is no extension
};

const BOOLEAN = ['no-minimap', 'no-tail', 'no-label', 'help'];
const REPEATED = ['mark', 'expect'];
const VALUED = ['file', 'lang', 'show', 'id', 'label', 'width', 'rows', 'into', 'out'];

const fail = L.die; // content problems: the message names the fix
function usage(msg) { L.die(`${msg}\n  (node file-panel.js --help lists the flags)`); }

function parseArgv(argv) {
  const a = { mark: [], expect: [] };
  for (let i = 0; i < argv.length; i++) {
    const k = argv[i];
    if (k === '-h') { a.help = true; continue; }
    if (!k.startsWith('--')) usage(`unexpected argument "${k}"`);
    const key = k.slice(2);
    if (BOOLEAN.includes(key)) { a[key] = true; continue; }
    if (!REPEATED.includes(key) && !VALUED.includes(key)) usage(`unknown flag ${k}`);
    const v = argv[++i];
    if (v === undefined) usage(`${k} needs a value`);
    if (REPEATED.includes(key)) a[key].push(v); else a[key] = v;
  }
  return a;
}

function help() {
  const src = fs.readFileSync(__filename, 'utf8');
  console.log(src.slice(src.indexOf('/**') + 3, src.indexOf('*/')).split('\n').map(l => l.replace(/^ \* ?/, '')).join('\n').trim());
}

const fmtRange = ([a, b]) => (a === b ? String(a) : `${a}-${b}`);

function parseShow(spec, total, name) {
  if (!spec) return [[1, total]];
  const out = [];
  for (const part of spec.split(',').map(s => s.trim()).filter(Boolean)) {
    const m = /^(\d+)(?:-(\d+|end))?$/.exec(part);
    if (!m) usage(`--show "${part}" is not a line or a range; write 12, 1-12, or 200-end`);
    const a = +m[1];
    const b = m[2] === undefined ? a : m[2] === 'end' ? total : +m[2];
    if (a < 1 || b > total) fail(`--show ${part} is outside the file: ${name} has ${total} lines`);
    if (b < a) fail(`--show ${part} runs backwards`);
    const prev = out[out.length - 1];
    if (prev && a <= prev[1]) fail(`--show ranges must ascend without overlapping: ${part} starts at or before line ${prev[1]}`);
    if (prev && a === prev[1] + 1) prev[1] = b; else out.push([a, b]);
  }
  if (!out.length) fail('--show names no lines');
  return out;
}

function parseMarks(values) {
  const out = [];
  for (const v of values) {
    // Commas separate marks only where the next piece starts like a mark, so a substring may hold commas.
    for (const piece of v.split(/,(?=\s*(?:hidden:)?\d+(?:-\d+)?=)/)) {
      const m = /^\s*(hidden:)?(\d+)(?:-(\d+))?=([a-z0-9][a-z0-9_-]*)(?:\s*$|:([\s\S]+)$)/.exec(piece);
      if (!m) usage(`--mark "${piece}" should look like 4=concept, 86-90=concept, 30=concept:substring, or hidden:13=concept (concept ids are kebab-case)`);
      const mark = { hidden: !!m[1], a: +m[2], b: m[3] ? +m[3] : +m[2], id: m[4], sub: m[5] === undefined ? null : m[5], raw: piece.trim() };
      if (mark.b < mark.a) fail(`--mark ${mark.raw} runs backwards`);
      if (mark.hidden && (m[3] || mark.sub !== null)) fail(`--mark ${mark.raw}: a hidden row takes one line number and no substring`);
      if (mark.sub !== null && m[3]) fail(`--mark ${mark.raw}: a substring mark names one line, not a range`);
      out.push(mark);
    }
  }
  return out;
}

// Split one source line into display rows of at most `width` columns. Rows break after a
// space (it stays, invisible, at the end of the row above), so the rows concatenate back to
// the line exactly. Returns [start, end) offsets and the hanging indent of continuation rows.
function wrapLine(line, width) {
  const col = [0]; // col[i] = columns used by the first i characters (a tab counts as 2)
  for (let i = 0; i < line.length; i++) col.push(col[i] + (line[i] === '\t' ? 2 : 1));
  const end = line.replace(/\s+$/, '').length; // trailing whitespace never forces a wrap
  if (col[end] <= width) return { segs: [[0, line.length]], hang: 0 };
  const indent = line.length - line.replace(/^\s+/, '').length;
  const hang = Math.min(col[indent] + 4, Math.floor(width / 2));
  const outsideQuotes = i => (line.slice(0, i).split('"').length - 1) % 2 === 0;
  const segs = [];
  let pos = 0, avail = width, floor = indent;
  while (col[end] - col[pos] > avail) {
    let hi = pos;
    while (hi < end && col[hi + 1] - col[pos] <= avail) hi++;
    let c = line.lastIndexOf(' ', hi);
    // Prefer a break outside a double-quoted string, unless that leaves a stub of a row.
    let q = c;
    while (q > floor && !outsideQuotes(q)) q = line.lastIndexOf(' ', q - 1);
    if (q > floor + 8) c = q;
    let cut = c > floor ? c + 1 : hi; // no usable space: break at the width
    if (cut <= pos) cut = Math.max(hi, pos + 1);
    while (cut < end && line[cut] === ' ') cut++;
    segs.push([pos, cut]);
    pos = cut; avail = width - hang; floor = pos;
  }
  segs.push([pos, line.length]);
  return { segs, hang };
}

// One display row's highlighted HTML: the tokens between offsets s and e, with each mark that
// touches the row wrapped as a concept from its first to its last non-space character.
function rowHtml(line, toks, s, e, marks) {
  const live = [];
  for (const m of marks) {
    let a = Math.max(m.start, s), b = Math.min(m.end, e);
    while (a < b && /\s/.test(line[a])) a++;
    while (b > a && /\s/.test(line[b - 1])) b--;
    if (a < b) live.push({ id: m.id, a, b });
  }
  live.sort((x, y) => x.a - y.a || y.b - x.b); // outer first
  const cuts = new Set([s, e]);
  for (const t of toks) if (t.s > s && t.s < e) cuts.add(t.s);
  for (const m of live) { cuts.add(m.a); cuts.add(m.b); }
  const pts = [...cuts].sort((x, y) => x - y);
  const stack = [];
  let html = '', ti = 0;
  for (let k = 0; k < pts.length; k++) {
    const p = pts[k];
    while (stack.length && stack[stack.length - 1].b === p) { html += '</span>'; stack.pop(); }
    if (p === e) break;
    for (const m of live) if (m.a === p) { html += `<span data-concept="${m.id}" data-rep="code">`; stack.push(m); }
    while (toks[ti] && toks[ti].e <= p) ti++;
    // A tab gets a fixed two-column box: tab stops would otherwise be measured from the gutter.
    const text = C.esc(line.slice(p, pts[k + 1])).replace(/\t/g, '<span class="tab">\t</span>');
    html += `<span${toks[ti] ? C.tokenStyle(toks[ti].tok, 'panel') : ''}>${text}</span>`;
  }
  return html + '</span>'.repeat(stack.length);
}

// The minimap: the whole file in miniature, the way an editor draws one. Every line sits at its
// own indentation and every word is a small block in its syntax colour, so the shape of the
// file (headings, blank lines, nesting, long and short lines) is recognisable at a glance.
// Lines the panel does not show are fainter. A long file puts several lines on one row (the
// longest of them is drawn). Everything is on a whole-pixel pitch so the blocks stay crisp.
function minimap(lines, shown, windowRows, firstSpan, toksFor) {
  const total = lines.length, mapH = windowRows * ROW_PX;
  let per = 1;
  while (Math.ceil(total / per) * 2 > mapH) per++;
  const bars = Math.ceil(total / per);
  const pitch = Math.max(2, Math.min(7, Math.floor(mapH / bars)));
  const bar = Math.max(1, Math.round(pitch * 0.62));
  const longest = Math.max(...lines.map(l => l.replace(/\s+$/, '').length));
  const cap = Math.max(48, Math.min(100, longest)); // columns across the map; longer lines are cut off, as in an editor
  const cw = MAP_PX / cap;
  const isShown = n => shown.some(([a, b]) => n >= a && n <= b);
  const px = v => Number(v.toFixed(2));
  let rects = '';
  for (let j = 0; j < bars; j++) {
    let pick = 0, on = false;
    for (let n = j * per + 1; n <= Math.min(total, (j + 1) * per); n++) {
      if (isShown(n)) on = true;
      if (!pick || lines[n - 1].trimEnd().length > lines[pick - 1].trimEnd().length) pick = n;
    }
    if (!pick || !lines[pick - 1].trim()) continue; // a blank line is a gap
    // Runs of non-space characters, each in the colour of the token it starts in.
    let col = 0;
    for (const { s, e, tok } of toksFor(pick)) {
      const text = lines[pick - 1].slice(s, e);
      const fill = (tok && tok.color) || 'var(--code-fg)';
      const re = /\S+/g;
      let m;
      while ((m = re.exec(text))) {
        const before = text.slice(0, m.index);
        const x0 = col + [...before].reduce((n, ch) => n + (ch === '\t' ? 2 : 1), 0);
        if (x0 >= cap) break;
        const w = Math.min(m[0].length, cap - x0);
        rects += `<rect x="${px(x0 * cw)}" y="${j * pitch}" width="${px(Math.max(1.5, w * cw - 0.6))}" height="${bar}" fill="${fill}"${on ? '' : ' opacity=".38"'}/>`;
      }
      col += [...text].reduce((n, ch) => n + (ch === '\t' ? 2 : 1), 0);
    }
  }
  const y = v => Math.round(v / per * pitch);
  const h = bars * pitch;
  const view = `<b class="file-map-view" style="top:${y(firstSpan[0])}px;height:${Math.max(pitch, y(firstSpan[1]) - y(firstSpan[0]))}px"></b>`;
  return {
    html: `<div class="file-map" data-per="${per}" data-bars="${bars}" style="height:${h}px" aria-hidden="true">${view}` +
      `<svg width="${MAP_PX}" height="${h}" viewBox="0 0 ${MAP_PX} ${h}" shape-rendering="crispEdges">${rects}</svg></div>`,
    bars, per,
  };
}

// The scrollbar: what a panel gets when there is no room for the minimap and its "lines hidden"
// rows cannot all be seen at once (it scrolls, or the last stretch has no row). A track as tall
// as the window stands for the whole file, and the thumb marks the lines in the window; the
// runtime moves it with every scroll, exactly as it moves the minimap's marker.
function scrollbar(total, windowRows, firstSpan) {
  const h = windowRows * ROW_PX;
  const y = v => Math.round(v / total * h);
  const view = `<b class="file-map-view" style="top:${y(firstSpan[0])}px;height:${Math.max(8, y(firstSpan[1]) - y(firstSpan[0]))}px"></b>`;
  return { html: `<div class="file-map file-bar" data-per="1" data-bars="${total}" style="height:${h}px" aria-hidden="true">${view}</div>` };
}

function shellQuote(s) { return /^[\w@%+=:,./-]+$/.test(s) ? s : `'${s.replace(/'/g, `'\\''`)}'`; }

async function main() {
  const args = parseArgv(process.argv.slice(2));
  if (args.help) { help(); return; }
  if (!args.file) usage('pass --file <path>: the file to show');
  if (args.into && args.out) usage('pass --into or --out, not both');
  const file = path.resolve(args.file);
  if (!fs.existsSync(file) || !fs.statSync(file).isFile()) fail(`--file ${args.file}: no such file (looked at ${file})`);
  const name = args.label || path.basename(file);
  const id = args.id || 'file';
  if (!/^[a-z][a-z0-9_-]*$/i.test(id)) usage(`--id "${id}" must be a plain element id (letters, digits, - and _)`);

  const lines = fs.readFileSync(file, 'utf8').replace(/\r\n?/g, '\n').split('\n');
  if (lines[lines.length - 1] === '') lines.pop();
  const total = lines.length;
  if (!total) fail(`--file ${args.file} is empty`);

  const width = args.width === undefined ? DEFAULT_WIDTH : Number(args.width);
  if (!Number.isInteger(width) || width < 24) usage(`--width must be a whole number of characters, 24 or more (got "${args.width}")`);
  const rowsWanted = args.rows === undefined ? DEFAULT_ROWS : Number(args.rows);
  if (!Number.isInteger(rowsWanted) || rowsWanted < 3 || rowsWanted > MAX_ROWS) {
    usage(`--rows must be 3 to ${MAX_ROWS} (got "${args.rows}"): more rows than that do not fit above the caption band at this type size; scroll instead`);
  }

  // Guards first: a source file that changed under the video should stop everything.
  for (const e of args.expect) {
    const m = /^(\d+)=([\s\S]+)$/.exec(e);
    if (!m) usage(`--expect "${e}" should look like 20=text that line 20 contains`);
    const n = +m[1];
    if (n < 1 || n > total) fail(`--expect ${n}: ${name} has only ${total} lines; the file has changed, so re-check the line numbers in --show and --mark`);
    if (!lines[n - 1].includes(m[2])) {
      fail(`--expect ${n}: line ${n} of ${name} is\n    ${lines[n - 1].trim() || '(blank)'}\n  which does not contain\n    ${m[2]}\n  The file has changed; re-check the line numbers in --show and --mark.`);
    }
  }

  // A "lines hidden" row takes one row, the same as the line it would hide, and several of them
  // in a row are harder to read than the file. So a skipped stretch of exactly one line is shown
  // instead. (The last line is left alone under --no-tail, which draws no row after the ranges.)
  const filled = []; // lines shown because hiding them would have saved nothing
  const shown = [];
  for (const [a0, b] of parseShow(args.show, total, name)) {
    let a = a0;
    const last = shown[shown.length - 1];
    const prevEnd = last ? last[1] : 0;
    if (a - prevEnd === 2) { filled.push(a - 1); a -= 1; }
    if (last && a === prevEnd + 1) last[1] = b; else shown.push([a, b]);
  }
  if (shown.length && !args['no-tail'] && total - shown[shown.length - 1][1] === 1) {
    filled.push(total); shown[shown.length - 1][1] = total;
  }
  const isShown = n => shown.some(([a, b]) => n >= a && n <= b);
  const hidden = []; // [first, last] of every stretch left out
  let prev = 0;
  for (const [a, b] of shown) { if (a > prev + 1) hidden.push([prev + 1, a - 1]); prev = b; }
  if (prev < total && !args['no-tail']) hidden.push([prev + 1, total]);

  // Marks -> per-line character ranges, and concepts on hidden rows.
  const lineMarks = new Map(); // line -> [{ id, start, end }]
  const hiddenMarks = new Map(); // first hidden line -> concept id
  const concepts = {};
  const note = (cid, what) => { (concepts[cid] = concepts[cid] || []).push(what); };
  const shownList = shown.map(fmtRange).join(', ');
  for (const m of parseMarks(args.mark)) {
    if (m.hidden) {
      const h = hidden.find(([a, b]) => m.a >= a && m.a <= b);
      if (!h) fail(`--mark ${m.raw}: line ${m.a} is not in a hidden stretch (hidden: ${hidden.map(fmtRange).join(', ') || 'none'})${filled.includes(m.a) ? `; a single skipped line is shown, not hidden, so mark it as ${m.a}=${m.id}` : ''}`);
      hiddenMarks.set(h[0], m.id); note(m.id, `hidden:${fmtRange(h)}`);
      continue;
    }
    for (let n = m.a; n <= m.b; n++) {
      if (n > total) fail(`--mark ${m.raw}: ${name} has only ${total} lines`);
      if (!isShown(n)) fail(`--mark ${m.raw}: line ${n} is not shown (shown: ${shownList}); add it to --show, or mark the hidden row with hidden:${n}=${m.id}`);
      const line = lines[n - 1];
      let start, end;
      if (m.sub !== null) {
        const count = line.split(m.sub).length - 1;
        if (count !== 1) fail(`--mark ${m.raw}: "${m.sub}" occurs ${count} times on line ${n}; give a substring that occurs exactly once\n    ${line.trim()}`);
        start = line.indexOf(m.sub); end = start + m.sub.length;
      } else {
        start = line.length - line.replace(/^\s+/, '').length; end = line.replace(/\s+$/, '').length;
        if (end <= start) { if (m.a === m.b) fail(`--mark ${m.raw}: line ${n} is blank; there is nothing to highlight`); continue; }
      }
      const list = lineMarks.get(n) || lineMarks.set(n, []).get(n);
      for (const o of list) {
        if ((o.start < start && start < o.end && o.end < end) || (start < o.start && o.start < end && end < o.end)) {
          fail(`--mark ${m.raw}: overlaps "${o.id}" on line ${n} without containing it; marks on one line must nest or stay apart`);
        }
      }
      list.push({ id: m.id, start, end }); note(m.id, n);
    }
  }

  const lang = args.lang || LANG_BY_EXT[path.extname(file).slice(1).toLowerCase()] || LANG_BY_EXT[path.basename(file).toLowerCase()] || 'text';
  let tokens;
  try { tokens = await C.tokenize(lines.join('\n'), lang, true); } // the whole file, so multi-line constructs colour correctly
  catch (e) { fail(`could not highlight as "${lang}" (${e.message.split('\n')[0]}); pass --lang with a language Shiki knows, or --lang text`); }
  // The panel is dark: move every colour to the variant that reads on it (code.js).
  for (const row of tokens) for (const tok of row) tok.color = C.darkColor(tok.color);
  const toksFor = n => {
    const line = lines[n - 1], out = [];
    let off = 0;
    for (const tok of tokens[n - 1] || []) { out.push({ s: off, e: off + tok.content.length, tok }); off += tok.content.length; }
    return off === line.length ? out : [{ s: 0, e: line.length, tok: {} }]; // never show text the file does not have
  };

  // Rows: every shown line (wrapped where needed) and one row per hidden stretch.
  const digits = Math.max(2, String(total).length);
  const rows = []; // { html, span: [fromLine, toLine) in 0-based line units }
  const wrapped = [];
  const hiddenRow = ([a, b]) => {
    const n = b - a + 1;
    const text = `${n} line${n === 1 ? '' : 's'} hidden · ${a === b ? a : `${a}–${b}`}`;
    const cid = hiddenMarks.get(a);
    rows.push({
      html: `<span class="file-row file-skip" data-hidden="${a}-${b}"><span class="ln">⋮</span><span class="elide"${cid ? ` data-concept="${cid}" data-rep="code"` : ''}>${text}</span></span>`,
      span: [a - 1, b], skip: true,
    });
  };
  prev = 0;
  for (const [a, b] of shown) {
    if (a > prev + 1) hiddenRow([prev + 1, a - 1]);
    for (let n = a; n <= b; n++) {
      const line = lines[n - 1], toks = toksFor(n), marks = lineMarks.get(n) || [];
      const { segs, hang } = wrapLine(line, width);
      if (segs.length > 1) wrapped.push(n);
      segs.forEach(([s, e], i) => {
        const gutter = i === 0 ? `<span class="ln">${n}</span>` : `<span class="ln">↪</span><i class="hang" style="width:${hang}ch"></i>`;
        rows.push({
          html: `<span class="file-row" data-line="${n}"${i ? ' data-wrap="1"' : ''}>${gutter}${rowHtml(line, toks, s, e, marks)}</span>`,
          span: [n - 1 + i / segs.length, n - 1 + (i + 1) / segs.length],
        });
      });
    }
    prev = b;
  }
  if (prev < total && !args['no-tail']) hiddenRow([prev + 1, total]);

  const windowRows = Math.min(rowsWanted, rows.length);
  // A viewer must always be able to tell that they are looking at part of a file.
  //   - With room for it, the minimap says so (and where the window is).
  //   - Without room (--no-minimap, or a narrow panel), the "lines hidden" rows say so, as long
  //     as the viewer can see them all: every row is in the window, and every left-out stretch
  //     has its row. Then nothing more is needed.
  //   - Otherwise (the window scrolls, or --no-tail dropped the row for the last stretch) a
  //     scrollbar is drawn in the minimap's place. Never nothing.
  // A panel that shows the whole file has nothing to map.
  const wholeFile = shown.length === 1 && shown[0][0] === 1 && shown[0][1] === total && rows.length <= windowRows;
  const room = !args['no-minimap'] && width >= NARROW_COLS;
  const marked = rows.length <= windowRows && !(args['no-tail'] && shown[shown.length - 1][1] < total);
  const position = wholeFile ? null : room ? 'minimap' : marked ? null : 'scrollbar';
  const withMap = position === 'minimap';
  const sidePx = position === 'minimap' ? MAP_GAP_PX + MAP_PX : position === 'scrollbar' ? BAR_GAP_PX + BAR_PX : 0;
  const withLabel = !args['no-label'];
  const widthPx = Math.ceil(PAD_X * 2 + (digits + 1.5 + width) * CH_PX + sidePx);
  const heightPx = (withLabel ? LABEL_PX : 0) + PAD_Y * 2 + windowRows * ROW_PX;
  if (widthPx > CONTENT_W) {
    const fit = extra => Math.floor((CONTENT_W - PAD_X * 2 - extra) / CH_PX - digits - 1.5);
    fail(`--width ${width} makes the panel ${widthPx}px wide; the canvas has ${CONTENT_W}px between its margins. ` +
      `Use --width ${fit(sidePx)} or less${withMap ? ` (${fit(BAR_GAP_PX + BAR_PX)} with --no-minimap, which draws a scrollbar instead when the panel scrolls)` : ''}; long lines wrap, the type never shrinks.`);
  }
  if (heightPx > CONTENT_H) {
    fail(`${windowRows} rows${withLabel ? ' and the label' : ''} make the panel ${heightPx}px tall; ${CONTENT_H}px is free above the caption band. Use fewer --rows${withLabel ? ' or --no-label' : ''}.`);
  }

  // The marker's starting place: the first run of real lines inside the window (the runtime
  // keeps one marker per run from there on; a "lines hidden" row marks nothing).
  let m0 = rows.findIndex(r => !r.skip), m1 = m0;
  while (m1 + 1 < windowRows && !rows[m1 + 1].skip) m1++;
    const firstSpan = [rows[m0].span[0], rows[m1].span[1]];
  const map = position === 'minimap' ? minimap(lines, shown, windowRows, firstSpan, toksFor)
    : position === 'scrollbar' ? scrollbar(total, windowRows, firstSpan) : null;
  const label = withLabel ? `<div class="code-file">${C.esc(name)}<span class="file-meta">${total} line${total === 1 ? '' : 's'}</span></div>\n` : '';
  const fragment =
    `<div class="file-panel" id="${id}" data-file="${C.esc(name).replace(/"/g, '&quot;')}" data-lines="${total}" data-rows="${windowRows}" style="--rows:${windowRows};--cols:${width};--ln:${digits}">\n` +
    label +
    `<div class="file-body">\n<div class="file-window">\n<pre class="code dark file-code" data-lang="${C.esc(lang)}"><code>\n` +
    rows.map(r => r.html).join('\n') +
    `\n</code></pre>\n</div>\n` + (map ? map.html + '\n' : '') + `</div>\n</div>`;

  const summary = {
    id, file, label: name, lang, lines: total,
    shown: shown.map(fmtRange), hidden: hidden.map(fmtRange), filled,
    rows: rows.length, window_rows: windowRows, scrollable: rows.length > windowRows,
    wrapped_lines: wrapped, concepts,
    position, // minimap, scrollbar, or null (the whole file is visible, or its "lines hidden" rows are all in view)
    minimap: withMap ? { bars: map.bars, lines_per_bar: map.per } : null,
    size_px: { width: widthPx, height: heightPx },
    written: null,
  };

  if (args.into) {
    const scene = path.resolve(args.into);
    if (!fs.existsSync(scene)) fail(`--into ${args.into}: no such scene file`);
    const html = fs.readFileSync(scene, 'utf8');
    const re = new RegExp(`<!--\\s*file-panel:${id}(?![\\w-])[\\s\\S]*?-->[\\s\\S]*?(<!--\\s*/file-panel:${id}\\s*-->)`);
    if (!re.test(html)) {
      fail(`--into ${args.into}: no markers for this panel. Put\n    <!-- file-panel:${id} -->\n    <!-- /file-panel:${id} -->\n  where the panel belongs (assets/layouts/file.html has a pair), then run this again.`);
    }
    const command = 'node file-panel.js ' + process.argv.slice(2).map(shellQuote).join(' ');
    const open = command.includes('-->') ? `<!-- file-panel:${id} -->` : `<!-- file-panel:${id} · regenerate with: ${command} -->`;
    fs.writeFileSync(scene, html.replace(re, (_, close) => `${open}\n${fragment}\n${close}`));
    summary.written = scene;
  } else if (args.out) {
    const out = path.resolve(args.out);
    L.mkdirp(path.dirname(out));
    fs.writeFileSync(out, fragment + '\n');
    summary.written = out;
  }

  if (summary.written) console.log(JSON.stringify(summary, null, 2));
  else { console.log(fragment); console.error(JSON.stringify(summary, null, 2)); }
}

main().catch(e => { console.error(`error: ${e.message}`); process.exit(1); });
