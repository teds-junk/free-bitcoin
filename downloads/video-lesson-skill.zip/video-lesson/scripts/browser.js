'use strict';
// Headless Chrome helpers (puppeteer-core + the system Chrome).

const { pathToFileURL } = require('url');
const L = require('./lib');

let browserPromise = null;

function browser() {
  if (!browserPromise) {
    let puppeteer;
    try { puppeteer = require('puppeteer-core'); }
    catch { L.die('puppeteer-core missing: run node scripts/setup.js'); }
    const exe = L.chromePath();
    if (!exe) L.die('Chrome not found; set CHROME_PATH');
    browserPromise = puppeteer.launch({
      executablePath: exe,
      headless: true,
      args: ['--hide-scrollbars', '--force-device-scale-factor=1', '--font-render-hinting=none', '--allow-file-access-from-files'],
    });
  }
  return browserPromise;
}

// Open a local HTML file at 1920x1080 with window.__VL timing data injected.
// page.problems collects script errors, failed loads, and non-local requests.
async function openPage(file, vl) {
  const page = await (await browser()).newPage();
  page.problems = [];
  page.on('pageerror', e => page.problems.push(`script error: ${e.message}`));
  page.on('console', m => { if (m.type() === 'error') page.problems.push(`console error: ${m.text()}`); });
  page.on('requestfailed', r => page.problems.push(`failed to load: ${r.url()}`));
  page.on('request', r => { if (!/^(file|data|about|blob):/.test(r.url())) page.problems.push(`remote request (renders must be offline): ${r.url()}`); });
  await page.setViewport({ width: L.VIDEO.width, height: L.VIDEO.height, deviceScaleFactor: 1 });
  await page.evaluateOnNewDocument(v => { window.__VL = v; window.__VL_RENDER = true; }, vl);
  await page.goto(pathToFileURL(file).href, { waitUntil: 'networkidle0' });
  // Wait for fonts and for the motion runtime to measure geometry (its explicit ready signal).
  const status = await page.evaluate(async () => {
    await document.fonts.ready;
    if (window.__vlReady) await window.__vlReady;
    const failed = [...document.fonts].filter(f => f.status === 'error').map(f => `${f.family} ${f.weight} ${f.style}`);
    return { failed, problems: window.__vlProblems || [] };
  });
  status.failed.forEach(f => page.problems.push(`font failed to load: ${f} (is _theme/fonts/ present?)`));
  status.problems.forEach(p => page.problems.push(`cue problem: ${p}`));
  return page;
}

// Deterministic seek: vl-runtime cues via window.__seek, plus every CSS/WAAPI animation.
async function seek(page, t) {
  await page.evaluate(sec => {
    if (typeof window.__seek === 'function') window.__seek(sec);
    for (const a of document.getAnimations()) { a.pause(); a.currentTime = sec * 1000; }
  }, t);
}

// Visible elements that extend past the 1920x1080 canvas (content that would be cut off).
async function overflow(page) {
  return page.evaluate((W, H) => {
    const out = [];
    for (const el of document.querySelectorAll('body *')) {
      const cs = getComputedStyle(el);
      if (cs.display === 'none' || cs.visibility === 'hidden' || Number(cs.opacity) === 0) continue;
      const r = el.getBoundingClientRect();
      if (!r.width || !r.height) continue;
      if (r.right > W + 1 || r.bottom > H + 1 || r.left < -1 || r.top < -1) {
        const name = el.tagName.toLowerCase() + (el.className && typeof el.className === 'string' ? '.' + el.className.trim().split(/\s+/).join('.') : '');
        out.push(`${name} extends to ${Math.round(r.right)}x${Math.round(r.bottom)}`);
      }
    }
    return out.slice(0, 5);
  }, L.VIDEO.width, L.VIDEO.height);
}

// Text that is hard to read against what is behind it, measured on the page as it stands (WCAG
// contrast ratio). A video is watched small and compressed, so the floor is 4:1 for text under
// 40px and 3:1 for larger text. Line-number gutters and the minimap are marks, not text.
// One finding per colour pair, with a sample of the text.
async function contrast(page) {
  const found = await page.evaluate(() => {
    const parse = c => {
      const m = /rgba?\(([^)]+)\)/.exec(c || '');
      if (!m) return null;
      const p = m[1].split(/[,\s/]+/).filter(Boolean).map(parseFloat);
      return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 };
    };
    const lum = ({ r, g, b }) => {
      const f = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
      return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
    };
    const hex = ({ r, g, b }) => '#' + [r, g, b].map(v => Math.round(v).toString(16).padStart(2, '0')).join('');
    const paper = parse(getComputedStyle(document.documentElement).backgroundColor) || { r: 253, g: 246, b: 227, a: 1 };
    const bgOf = el => {
      for (let e = el; e; e = e.parentElement) { const c = parse(getComputedStyle(e).backgroundColor); if (c && c.a >= 0.5) return c; }
      return paper.a >= 0.5 ? paper : { r: 253, g: 246, b: 227, a: 1 };
    };
    const seen = new Map();
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      const text = n.nodeValue.replace(/\s+/g, ' ').trim();
      if (!text || !/[A-Za-z0-9]/.test(text)) continue;
      const el = n.parentElement;
      if (!el || el.closest('script, style, svg, .vl-transitions, .file-map, .ln')) continue;
      const cs = getComputedStyle(el);
      if (cs.visibility === 'hidden' || cs.display === 'none') continue;
      let opacity = 1;
      for (let e = el; e; e = e.parentElement) opacity *= Number(getComputedStyle(e).opacity);
      if (opacity < 0.05) continue; // not on screen now (a part that has not expanded yet)
      const box = el.getBoundingClientRect();
      if (!box.width || !box.height) continue;
      const fg = parse(cs.color);
      if (!fg) continue;
      const bg = bgOf(el), a = fg.a * opacity;
      const shown = { r: fg.r * a + bg.r * (1 - a), g: fg.g * a + bg.g * (1 - a), b: fg.b * a + bg.b * (1 - a) };
      const l1 = lum(shown), l2 = lum(bg);
      const ratio = (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
      const size = parseFloat(cs.fontSize) || 0;
      const need = size >= 40 ? 3 : 4;
      if (ratio + 0.05 >= need) continue;
      const key = `${hex(shown)}/${hex(bg)}`;
      if (!seen.has(key)) seen.set(key, { text: text.slice(0, 32), size: Math.round(size), fg: hex(shown), bg: hex(bg), ratio: Number(ratio.toFixed(1)), need, dark: lum(bg) < 0.2, count: 0 });
      seen.get(key).count += 1;
    }
    return [...seen.values()];
  });
  return found.slice(0, 6).map(f => `low contrast: "${f.text}" (${f.size}px${f.count > 1 ? `, and ${f.count - 1} more` : ''}) is ${f.fg} on ${f.bg}, ${f.ratio}:1; it needs ${f.need}:1 to read on a small or compressed video. ` +
    (f.dark ? 'On a dark panel use the colours code.js and file-panel.js give (do not hand-colour code)' : 'On the paper, text is --ink, --ink-soft or --ink-muted, nothing lighter'));
}

// Layout and legibility problems of the page as it stands: content off the canvas, pale text.
async function pageProblems(page) {
  return [...(await overflow(page)).map(o => `overflow: ${o}`), ...(await contrast(page))];
}

// Screenshot the final state (all cues visible). Returns the list of problems found.
async function screenshotFinal(file, png, vl) {
  const page = await openPage(file, vl);
  await seek(page, vl.duration);
  await page.screenshot({ path: png, type: 'png' });
  const problems = [...page.problems, ...(await pageProblems(page))];
  await page.close();
  return problems;
}

async function close() {
  if (browserPromise) {
    const b = await browserPromise;
    const proc = typeof b.process === 'function' ? b.process() : null;
    await b.close();
    // Chrome's crash handler and updater inherit these pipes and can outlive the browser,
    // which keeps a finished script from exiting. Nothing reads them after close.
    if (proc) for (const s of [proc.stdin, proc.stdout, proc.stderr]) { try { if (s) s.destroy(); } catch { /* already closed */ } }
  }
  browserPromise = null;
}

module.exports = { browser, openPage, seek, overflow, contrast, pageProblems, screenshotFinal, close };
