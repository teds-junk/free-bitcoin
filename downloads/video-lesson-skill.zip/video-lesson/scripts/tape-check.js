'use strict';
// Static checks for vhs tapes. Tapes type real commands into a real shell, so this
// runs in lint-storyboard.js --strict and again in render-scenes.js before vhs.
//
// checkTape(text) -> { errors: [], warnings: [], commands: [{ hidden, text }] }

// Commands never allowed in a tape. rm -rf is allowed only on /tmp paths (scratch cleanup).
const DENY = [
  [/\brm\s+-[a-zA-Z]*[rR][a-zA-Z]*\s+(?!\/tmp\/|"\/tmp\/|'\/tmp\/)/, 'recursive rm outside /tmp'],
  [/\bgit\s+(push|commit|reset|rebase|clean|checkout\s+--)\b/, 'git command that changes history or discards work'],
  [/\bsudo\b/, 'sudo'],
  [/\b(curl|wget|http)\b[^\n]*\s(-X\s*(POST|PUT|PATCH|DELETE)|--data|-d\s)/i, 'network write (POST/PUT/DELETE)'],
  [/\b(npm|pnpm|yarn)\s+publish\b|\bgh\s+(pr|release|repo)\s+(create|delete|merge)\b/, 'publishing or remote mutation'],
  [/\b(mkfs|dd\s+if=|shutdown|reboot|killall)\b/, 'system-level command'],
  [/>\s*~\/|>\s*\$HOME/, 'writes into the home directory'],
];

// A recorded command should look like one a guide would print: one plain command with literal
// paths. A long command with several flags may be split over lines with a trailing backslash, one
// flag per line, the way a guide prints it; that needs no warning and no explanation on screen. Each entry: [pattern, what it is, what to do instead]. Applied to visible commands only;
// the hidden setup block may do whatever it needs.
const QUERY_TOOLS = 'jq|sed|awk|grep|egrep|rg|cut|head|tail|sort|uniq|wc|fold|tr|xargs|column';
const PLAIN = [
  [/\$\(|`[^`]+`/, 'command substitution', 'run the inner command in the hidden setup, or type the literal value'],
  [/^[A-Za-z_][A-Za-z0-9_]*=\S/, 'a shell variable assignment', 'type the literal path; if it is too long, shorten it by changing the setup (hidden `cd` into the folder, a shorter file name)'],
  [/\$\{?[A-Za-z_][A-Za-z0-9_]*/, 'a shell variable', 'type the literal value'],
  [/<<-?\s*['"]?\w+/, 'a here-document', 'create the file in the hidden setup and show it in a file panel'],
  [/&&|;\s*\S/, 'several commands on one line', 'type them one at a time so each gets its own sentence and its own output'],
  [/\|[^|]+\|/, 'a pipeline of three or more stages', 'show the full output, or show the file in a file panel and move through it'],
  [new RegExp(`(^|\\|)\\s*(${QUERY_TOOLS})\\b`), 'a text-query tool (jq, sed, grep, head, …)', 'querying a file assumes the viewer already understands it: show the file in a file panel and move through it (FILES-ON-SCREEN.md)'],
];

// "# Spend: 2 agent runs" in a tape's comments declares what one recording costs.
function declaredSpend(text) {
  const m = String(text).match(/^\s*#\s*Spend:\s*(\d+(?:\.\d+)?)\s*(.*)$/im);
  return m ? { amount: Number(m[1]), unit: m[2].trim() || 'runs' } : null;
}

function checkTape(text) {
  const errors = [];
  const warnings = [];
  const commands = [];
  let hidden = false;
  let seenCommand = false;
  let hiddenCdScratch = false;
  let hiddenEnterPending = false; // a hidden Enter with no Wait/Sleep after it yet
  let tailSleep = 0; // seconds of Sleep after the last Wait/Enter: time the final output stays on screen
  // For the event detector (tape-events.js) and for anchors: short settled pauses around each step.
  let cursorBlinkOff = false;
  let typedPending = false; let sleepSinceType = 0;   // visible Type -> Enter
  let waitPending = false; let sleepSinceWait = 0;    // Wait -> next visible Type
  const noPauseBeforeEnter = []; const noPauseAfterWait = [];
  let longSleeps = [];                                 // visible Sleeps over 3 s before the last step

  text.split('\n').forEach((raw, i) => {
    const line = raw.trim();
    const at = `line ${i + 1}`;
    if (!line || line.startsWith('#')) return;
    const [cmd] = line.split(/\s+/);

    if (cmd === 'Output') { warnings.push(`${at}: Output line is ignored (render-scenes.js sets the output)`); return; }
    if (cmd === 'Set') {
      const setting = line.split(/\s+/)[1];
      if (setting === 'CursorBlink' && /\bfalse\b/.test(line)) cursorBlinkOff = true;
      if (['Margin', 'WindowBar', 'BorderRadius', 'MarginFill'].includes(setting)) warnings.push(`${at}: "Set ${setting}" changes where the terminal sits in the picture, so a credential found in the recording cannot be blurred automatically. Leave it out (the template's Padding is the margin)`);
      if (seenCommand && setting !== 'TypingSpeed') errors.push(`${at}: "Set ${setting}" after the first command is ignored by vhs; move it above`);
      return;
    }
    if (cmd === 'Hide') { hidden = true; seenCommand = true; return; }
    if (cmd === 'Show') {
      if (hiddenEnterPending) warnings.push(`${at}: Show comes straight after a hidden Enter, so the recording can start while the setup is still running. Put \`Wait /\\$\\s*$/\` (or a Sleep) before Show`);
      hidden = false; hiddenEnterPending = false; seenCommand = true; return;
    }
    if (cmd.startsWith('Sleep')) {
      const m = line.match(/Sleep\s+([\d.]+)(ms|s)?/);
      const secs = m ? (m[2] === 'ms' ? Number(m[1]) / 1000 : Number(m[1])) : 0;
      if (m && !hidden) tailSleep += secs;
      sleepSinceType += secs; sleepSinceWait += secs;
      if (!hidden && secs > 3) longSleeps.push(`${at} (${secs}s)`);
      hiddenEnterPending = false;
      seenCommand = true;
      return;
    }
    if (cmd.startsWith('Wait') || cmd === 'Enter') tailSleep = 0;
    if (cmd === 'Enter' && !hidden && typedPending) { if (sleepSinceType < 0.2) noPauseBeforeEnter.push(at); typedPending = false; }
    if (cmd.startsWith('Wait')) { waitPending = true; sleepSinceWait = 0; }
    if (cmd === 'Enter') hiddenEnterPending = hidden;
    if (cmd.startsWith('Wait')) {
      hiddenEnterPending = false;
      seenCommand = true;
      if (/ \$\/\s*$/.test(line) || /\\\$ \$/.test(line)) errors.push(`${at}: Wait regex ends in a literal space before $; terminals trim it, so it never matches. Use /\\$\\s*$/`);
      return;
    }
    if (cmd.startsWith('Type')) {
      seenCommand = true;
      const m = line.match(/^Type(?:@\S+)?\s+(["'`])([\s\S]*)\1\s*$/);
      const typed = m ? m[2] : line.replace(/^Type\S*\s+/, '');
      commands.push({ hidden, text: typed });
      if (hidden && /\bcd\s+["']?\/tmp\//.test(typed)) hiddenCdScratch = true;
      for (const [re, why] of DENY) if (re.test(typed)) errors.push(`${at}: not allowed in a tape (${why}): ${typed}`);
      if (!hidden) {
        if (waitPending && sleepSinceWait < 0.5) noPauseAfterWait.push(at);
        waitPending = false; typedPending = true; sleepSinceType = 0;
        if (typed.length > 60) warnings.push(`${at}: typed command is ${typed.length} chars; over ~60 wraps at FontSize 44. Change the setup so the plain command fits (hidden \`cd\` into the folder, shorter file names, FontSize 34 for up to ~80); do not add variables or continuations to shorten it`);
        for (const [re, what, instead] of PLAIN) {
          if (re.test(typed)) warnings.push(`${at}: visible command uses ${what}: \`${typed.slice(0, 70)}\`. A guide would not print this; ${instead}`);
        }
      }
      return;
    }
    seenCommand = true;
  });

  const visible = commands.some(c => !c.hidden);
  if (visible && !cursorBlinkOff) warnings.push('no `Set CursorBlink false`: a blinking cursor makes held frames visible and confuses the detection of screen events. Add it with the other settings');
  if (noPauseBeforeEnter.length) warnings.push(`${noPauseBeforeEnter.join(', ')}: Enter comes straight after Type. Put \`Sleep 400ms\` between them, so the typed command is on screen before it runs and "before": "enter:N" has a frame to hold`);
  if (noPauseAfterWait.length) warnings.push(`${noPauseAfterWait.join(', ')}: a command is typed straight after a Wait. Put \`Sleep 1s\` after the Wait, so the end of one command and the start of the next are separate moments on screen`);
  // Sleeps that are still followed by a step: a long one is sized to the narration.
  const tuned = longSleeps.slice(0, Math.max(0, longSleeps.length - (tailSleep > 3 ? 1 : 0)));
  if (tuned.length) warnings.push(`long Sleep at ${tuned.join(', ')}. A Sleep sized to the narration has to be re-tuned whenever the wording changes; keep sleeps short and tie sentences to the screen with "wait_for" / "before" (TERMINAL-DEMOS.md → Timing to narration)`);
  if (commands.some(c => !c.hidden) && tailSleep < 4) warnings.push(`final output is on screen for only ${tailSleep.toFixed(1)}s after the last command; end with Sleep 4s or more (~1s per output line + 2s) so viewers can read it`);
  if (!hiddenCdScratch) warnings.push('no `cd /tmp/...` in a hidden (Hide) block: demos should run in a scratch directory');
  return { errors, warnings, commands, spend: declaredSpend(text) };
}

module.exports = { checkTape, declaredSpend };
