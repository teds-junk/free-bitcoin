#!/usr/bin/env node
/**
 * Blur or box a credential in a recorded terminal demo, without recording it again.
 *
 * Usage:
 *   node redact.js <video-dir> --scene s14 --hit <id> [--style blur|box] [--whole-row] [--discard-original]
 *   node redact.js <video-dir> --scene s14 [--hit <id>] --box x,y,w,h [--from <s>] [--to <s>]
 *   node redact.js <video-dir> --scene s14 [--hit <id>] --rows 3-5 [--from <s>] [--to <s>]
 *   node redact.js <video-dir> --scene s14 --stills [--count 12]
 *   node redact.js <video-dir> --scene s14 --undo
 *   node redact.js <video-dir> [--scene s14] --purge
 *
 * --hit takes an id from secret-scan.js (build/raw/<id>.scan.json). The hit's row and columns come
 * from the screen text vhs saved; the pixels come from the tape's settings, checked against the
 * picture; the time comes from watching that band for ink. The hit is then marked "redacted", its
 * value is blanked in the screen text, and the scene's clip is deleted so the next
 * render-scenes.js run re-fits it from the redacted recording. Nothing is re-recorded.
 *
 * When the screen filled up (and may have scrolled) or the picture does not match the text, it
 * says so and stops: mark the area yourself with --box (pixels in the 1920x1080 recording) or
 * --rows (whole terminal rows), with --from/--to in seconds of build/raw/<id>.mp4. Left out,
 * --from is the start and --to is the end. --stills writes frames to read coordinates from.
 *
 * The unredacted original: by default it is MOVED OUT of the video folder to
 * <STATE_DIR>/unredacted/ (readable only by you), so a wrong box can be redone with --undo or
 * simply by running redact.js again, and no copy with the credential stays next to the video.
 * --discard-original deletes it instead (nothing to undo; a mistake means recording again).
 * --purge deletes kept originals once the result is checked. Re-recording a scene drops its copy.
 *
 * --style blur (default) smears the area sideways far past the width of a character; --style box
 * paints a solid bar, which keeps no trace of the text at all.
 *
 * Prints JSON on stdout (regions, times, a still of the result to look at) and notes on stderr.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const { spawn, spawnSync } = require('child_process');
const L = require('./lib');
const S = require('./secret-scan');

const ORIGINALS_DIR = path.join(L.STATE_DIR, 'unredacted');
const INK_DELTA = 28; // gray levels away from the background that count as ink
const MIN_INK = 8; // ink pixels in a region before it counts as "something is there"
const PAD_FRAMES = 2; // start this many frames early and end this many late
const BOX_COLOR = '0x586e75'; // Solarized base01: reads as a deliberate bar on the dark panel

// Device cell heights measured on recordings made with the template (1920x1080, Padding 120):
// "<FontSize>/<rows>" -> px. 14 and 18 rows are JetBrains Mono, 16 and 20 are the Menlo fallback.
const MEASURED_CELL_H = { '44/14': 59, '44/16': 52, '34/18': 46, '34/20': 41 };

function fail(msg) {
  console.error(`error: ${msg}`);
  process.exit(1);
}

// ---- geometry ----------------------------------------------------------------
// Measured on recordings of full-block characters in known cells (vhs 0.11): vhs scales the
// terminal canvas to fit the padded area and centres it. A cell is (0.6 x FontSize + LetterSpacing)
// wide before scaling, so the column count is known and the canvas fills the width: the first
// column starts exactly at the padding. The cell height depends on the font that was actually
// used, so it is taken from the row count of the saved screen text and checked against the picture.

const { tapeSettings } = S;

function geometryCandidates(set, rows, info) {
  const P = set.Padding;
  const tw = info.width - 2 * P;
  const th = info.height - 2 * P;
  const cw = 0.6 * set.FontSize + set.LetterSpacing;
  const cols = S.terminalCols(set);
  const out = [];
  for (let k = Math.floor(th / (rows + 1)) + 1; k <= Math.floor(th / rows); k++) {
    const scale = Math.min(tw / (cols * cw), th / (rows * k));
    out.push({
      cell_w: cw * scale, cell_h: k * scale,
      x0: P + (tw - cols * cw * scale) / 2, y0: P + (th - rows * k * scale) / 2,
      rows, cols, device_cell_h: k, area: { x: P, y: P, w: tw, h: th },
    });
  }
  return out;
}

function grayFrames(raw, vf, size, extra = []) {
  const res = spawnSync('ffmpeg', ['-v', 'error', ...extra, '-i', raw, '-vf', vf, '-f', 'rawvideo', '-pix_fmt', 'gray', '-'], { maxBuffer: 1 << 30 });
  if (res.status !== 0) throw new Error(`ffmpeg could not read ${raw}: ${String(res.stderr).slice(-300)}`);
  const out = [];
  for (let i = 0; i + size <= res.stdout.length; i += size) out.push(res.stdout.subarray(i, i + size));
  return out;
}

function background(frame) {
  const hist = new Uint32Array(256);
  for (let i = 0; i < frame.length; i += 7) hist[frame[i]]++;
  let best = 0;
  for (let v = 1; v < 256; v++) if (hist[v] > hist[best]) best = v;
  return best;
}

// Pick the cell height whose row boundaries fall in the ink-free gutters between lines of text.
function fitGeometry(raw, set, rows, info) {
  const cands = geometryCandidates(set, rows, info);
  if (!cands.length) return null;
  const { area } = cands[0];
  const n = 16;
  const frames = grayFrames(raw, `fps=${(n / Math.max(info.duration, 0.1)).toFixed(4)},crop=${area.w}:${area.h}:${area.x}:${area.y}`, area.w * area.h);
  const last = grayFrames(raw, `crop=${area.w}:${area.h}:${area.x}:${area.y}`, area.w * area.h, ['-sseof', '-0.15']).pop();
  if (last) frames.push(last);
  if (!frames.length) return null;
  const bg = background(frames[0]);
  const profile = new Float64Array(area.h);
  for (const f of frames) {
    for (let y = 0; y < area.h; y++) {
      let c = 0;
      for (let x = 0, i = y * area.w; x < area.w; x++, i++) if (Math.abs(f[i] - bg) > INK_DELTA) c++;
      profile[y] += c;
    }
  }
  const total = profile.reduce((a, b) => a + b, 0);
  const at = y => (y >= 0 && y < area.h ? profile[y] : 0);
  for (const c of cands) {
    let off = 0;
    const top = c.y0 - area.y;
    for (let k = 0; k <= rows; k++) { const y = Math.round(top + k * c.cell_h); off += at(y - 1) + at(y) + at(y + 1); }
    for (let y = 0; y < Math.round(top) - 1; y++) off += at(y);
    for (let y = Math.round(top + rows * c.cell_h) + 2; y < area.h; y++) off += at(y);
    const expected = total * (3 * (rows + 1)) / area.h; // what a grid placed at random would catch
    c.gutter_ink = expected > 0 ? Number((off / expected).toFixed(3)) : 0;
  }
  const known = MEASURED_CELL_H[`${set.FontSize}/${rows}`];
  const mid = (cands[0].device_cell_h + cands[cands.length - 1].device_cell_h) / 2;
  // The gutters between lines are several pixels wide, so neighbouring heights can score almost the
  // same. Among near-ties prefer the height measured for this font size and row count, then the middle.
  const best = Math.min(...cands.map(c => c.gutter_ink));
  const near = c => (c.gutter_ink <= best + Math.max(0.03, best * 0.5) ? 0 : 1);
  const rank = c => [near(c), c.device_cell_h === known ? 0 : 1, c.gutter_ink, Math.abs(c.device_cell_h - mid)];
  cands.sort((a, b) => { const ra = rank(a), rb = rank(b); return ra[0] - rb[0] || ra[1] - rb[1] || ra[2] - rb[2] || ra[3] - rb[3]; });
  const g = cands[0];
  g.tried = cands.map(c => ({ device_cell_h: c.device_cell_h, gutter_ink: c.gutter_ink }));
  g.measured = g.device_cell_h === known;
  g.background = bg;
  g.last_frame = last || null;
  return g;
}

// Does the last frame show text on the rows where the last screen snapshot has text?
function pictureMatchesText(geom, lastRows) {
  const f = geom.last_frame;
  if (!f) return { ok: false, why: 'could not read the last frame' };
  const { area } = geom;
  let wrong = 0;
  for (let r = 0; r < geom.rows; r++) {
    const y0 = Math.max(0, Math.round(geom.y0 - area.y + r * geom.cell_h) + 3);
    const y1 = Math.min(area.h, Math.round(geom.y0 - area.y + (r + 1) * geom.cell_h) - 3);
    let ink = 0;
    for (let y = y0; y < y1; y++) for (let x = 0, i = y * area.w; x < area.w; x++, i++) if (Math.abs(f[i] - geom.background) > INK_DELTA) ink++;
    const text = (lastRows[r] || '').trim() !== '';
    // The cursor may sit on an otherwise empty row; anything bigger than one cell is text.
    if (text !== (ink > (text ? MIN_INK : geom.cell_w * geom.cell_h * 1.2))) wrong++;
  }
  return wrong ? { ok: false, why: `${wrong} of ${geom.rows} rows in the last frame do not match the saved screen text` } : { ok: true };
}

function evenRect(x, y, w, h, info) {
  const x0 = Math.max(0, Math.floor(x / 2) * 2);
  const y0 = Math.max(0, Math.floor(y / 2) * 2);
  const x1 = Math.min(info.width, Math.ceil((x + w) / 2) * 2);
  const y1 = Math.min(info.height, Math.ceil((y + h) / 2) * 2);
  return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
}

// One screen position -> pixels: the hit's cells plus one cell either side, and a little above and below.
function cellRect(geom, row, col, len, info, wholeRow) {
  const vpad = Math.round(geom.cell_h * 0.1); // the row origin is good to about 2 px
  const y = geom.y0 + row * geom.cell_h - vpad;
  const h = geom.cell_h + 2 * vpad;
  if (wholeRow) return evenRect(geom.area.x, y, geom.area.w, h, info);
  const x = Math.max(geom.area.x, geom.x0 + (col - 1) * geom.cell_w);
  const right = Math.min(geom.area.x + geom.area.w, geom.x0 + (col + len + 1) * geom.cell_w);
  return evenRect(x, y, right - x, h, info);
}

// Where to WATCH for the value: only its own cells, a few pixels inside the row, so that the
// line above or below (which the padded cover rectangle touches) never starts or ends a redaction.
function watchRect(geom, row, col, len, info, wholeRow) {
  const inset = Math.max(3, Math.round(geom.cell_h * 0.08));
  const y = geom.y0 + row * geom.cell_h + inset;
  const h = geom.cell_h - 2 * inset;
  if (wholeRow) return evenRect(geom.area.x, y, geom.area.w, h, info);
  const x = Math.max(geom.area.x, geom.x0 + col * geom.cell_w);
  const right = Math.min(geom.area.x + geom.area.w, geom.x0 + (col + len) * geom.cell_w);
  return evenRect(x, y, right - x, h, info);
}

// ---- when is something there: ink in the band, frame by frame ------------------

function eachFrame(raw, vf, size, onFrame) {
  return new Promise((resolve, reject) => {
    const ff = spawn('ffmpeg', ['-v', 'error', '-i', raw, '-vf', vf, '-fps_mode', 'passthrough', '-f', 'rawvideo', '-pix_fmt', 'gray', '-'], { stdio: ['ignore', 'pipe', 'pipe'] });
    let pending = Buffer.alloc(0);
    let n = 0;
    let err = '';
    ff.stderr.on('data', d => { err += d; });
    ff.stdout.on('data', chunk => {
      pending = pending.length ? Buffer.concat([pending, chunk]) : chunk;
      while (pending.length >= size) { onFrame(pending.subarray(0, size), n++); pending = pending.subarray(size); }
    });
    ff.on('error', reject);
    ff.on('close', code => (code === 0 ? resolve(n) : reject(new Error(`ffmpeg exited ${code}: ${err.slice(-300)}`))));
  });
}

// Frame ranges [first, last] in which the rectangle holds ink that is more than the bare cursor.
async function inkRanges(raw, r, bg, cellArea) {
  const flags = [];
  await eachFrame(raw, `crop=${r.w}:${r.h}:${r.x}:${r.y}`, r.w * r.h, frame => {
    let ink = 0, lo = 255, hi = 0;
    for (let i = 0; i < frame.length; i++) {
      const v = frame[i];
      if (Math.abs(v - bg) > INK_DELTA) { ink++; if (v < lo) lo = v; if (v > hi) hi = v; }
    }
    // A block cursor resting in the area is one flat-coloured cell; text is anti-aliased, so it never looks like that.
    const cursorOnly = cellArea && hi - lo <= 14 && ink >= cellArea * 0.5 && ink <= cellArea * 1.2;
    flags.push(ink >= MIN_INK && !cursorOnly);
  });
  const ranges = [];
  flags.forEach((on, n) => {
    if (!on) return;
    const last = ranges[ranges.length - 1];
    if (last && n - last[1] <= PAD_FRAMES * 2 + 1) last[1] = n; else ranges.push([n, n]);
  });
  return { ranges, frames: flags.length };
}

function toSpans(ranges, info) {
  const fps = info.fps;
  return ranges.map(([a, b]) => ({
    from: Number((Math.max(0, a - PAD_FRAMES - 0.5) / fps).toFixed(3)),
    to: b + PAD_FRAMES + 1 >= info.frames ? null : Number(((b + PAD_FRAMES + 0.5) / fps).toFixed(3)), // null = to the end
  }));
}

// ---- applying regions ----------------------------------------------------------

function enableExpr(spans, info) {
  return spans.map(s => `between(t,${s.from},${s.to === null ? (info.duration + 10).toFixed(3) : s.to})`).join('+');
}

function applyRegions(source, regions, out, info) {
  const parts = [];
  let cur = '0:v';
  regions.forEach((r, i) => {
    const next = `v${i + 1}`;
    const en = enableExpr(r.spans, info);
    if (r.style === 'box') {
      parts.push(`[${cur}]drawbox=x=${r.x}:y=${r.y}:w=${r.w}:h=${r.h}:color=${BOX_COLOR}:t=fill:enable='${en}'[${next}]`);
    } else {
      parts.push(`[${cur}]split[a${i}][b${i}]`);
      // Three box-blur passes: a smear about 1.75 cells wide each time, so no single character's shape survives.
      const pass = `avgblur=sizeX=${r.blur_x}:sizeY=${r.blur_y}`;
      parts.push(`[b${i}]crop=${r.w}:${r.h}:${r.x}:${r.y},${pass},${pass},${pass}[c${i}]`);
      parts.push(`[a${i}][c${i}]overlay=${r.x}:${r.y}:enable='${en}'[${next}]`);
    }
    cur = next;
  });
  L.ffmpeg(['-i', source, '-filter_complex', parts.join(';'), '-map', `[${cur}]`, '-c:v', 'libx264', '-preset', 'medium', '-crf', '14',
    '-pix_fmt', 'yuv420p', '-fps_mode', 'passthrough', '-an', out]);
}

// ---- the unredacted original (kept outside the video folder) -------------------

function originalPaths(dir, id) {
  const base = path.join(ORIGINALS_DIR, `${path.basename(path.resolve(dir))}-${id}-${L.sha1(path.resolve(dir)).slice(0, 8)}`);
  return { video: `${base}.mp4`, text: `${base}.txt`, meta: `${base}.json` };
}

function dropOriginal(dir, id) {
  const o = originalPaths(dir, id);
  const had = fs.existsSync(o.video);
  for (const f of Object.values(o)) fs.rmSync(f, { force: true });
  return had;
}

const statOf = f => { const s = fs.statSync(f); return { size: s.size, mtimeMs: Math.round(s.mtimeMs) }; };

// The kept original belongs to the recording now in build/raw only if nothing replaced that file since.
function originalFor(dir, id, raw) {
  const o = originalPaths(dir, id);
  if (!fs.existsSync(o.video) || !fs.existsSync(o.meta)) return null;
  let meta;
  try { meta = L.readJSON(o.meta); } catch { return null; }
  const now = statOf(raw);
  return meta.result && meta.result.size === now.size && meta.result.mtimeMs === now.mtimeMs ? o : null;
}

function keepOriginal(dir, id, raw, txt) {
  const o = originalPaths(dir, id);
  fs.mkdirSync(ORIGINALS_DIR, { recursive: true, mode: 0o700 });
  fs.copyFileSync(raw, o.video);
  fs.chmodSync(o.video, 0o600);
  if (fs.existsSync(txt)) { fs.copyFileSync(txt, o.text); fs.chmodSync(o.text, 0o600); }
  return o;
}

// ---- scene context -------------------------------------------------------------

function loadScene(dirArg, sceneId) {
  const { sb, dir } = L.loadStoryboard(dirArg);
  if (!sceneId) fail('pass --scene <id> (a terminal scene of this video)');
  const scene = (sb.scenes || []).find(s => s.id === sceneId);
  if (!scene || scene.renderer !== 'terminal') fail(`no terminal scene "${sceneId}" in ${path.join(dir, 'storyboard.json')}`);
  const raw = path.join(dir, 'build', 'raw', `${scene.id}.mp4`);
  return { sb, dir, scene, raw, txt: S.snapshotPath(raw), scanFile: S.scanPath(raw) };
}

function videoInfo(raw) {
  const p = L.probe(raw);
  const v = p.streams.find(s => s.codec_type === 'video');
  const [a, b] = String(v.avg_frame_rate || v.r_frame_rate).split('/').map(Number);
  return { width: v.width, height: v.height, fps: a / (b || 1), frames: Number(v.nb_frames) || 0, duration: Number(p.format.duration) };
}

// Tape as it was recorded (kept next to the recording), else the scene's tape.
function recordedTape(c) {
  const kept = path.join(path.dirname(c.raw), `${c.scene.id}.tape`);
  const file = fs.existsSync(kept) ? kept : path.resolve(c.dir, c.scene.visual);
  return fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : '';
}

function geometryFor(c, info, source) {
  if (!fs.existsSync(c.txt)) return { geom: null, why: 'this recording has no saved screen text (it was made before scanning existed)' };
  const set = tapeSettings(recordedTape(c));
  if (set.Margin || set.WindowBar || set.BorderRadius) return { geom: null, why: 'the tape uses Margin, WindowBar or BorderRadius, which move the terminal inside the frame' };
  if (set.Width !== info.width || set.Height !== info.height) return { geom: null, why: `the recording is ${info.width}x${info.height} but the tape says ${set.Width}x${set.Height}` };
  const userTape = path.resolve(c.dir, c.scene.visual);
  const lay = S.screenLayout(fs.readFileSync(c.txt, 'utf8'), fs.existsSync(userTape) ? fs.readFileSync(userTape, 'utf8') : '');
  if (!lay.rows) return { geom: null, why: 'the saved screen text is empty', lay };
  const geom = fitGeometry(source, set, lay.rows, info);
  if (!geom) return { geom: null, why: `no cell height fits ${lay.rows} rows in this frame`, lay };
  return { geom, lay, set };
}

const publicGeometry = g => (g ? {
  cell_w: Number(g.cell_w.toFixed(3)), cell_h: Number(g.cell_h.toFixed(3)), x0: Number(g.x0.toFixed(2)), y0: Number(g.y0.toFixed(2)),
  rows: g.rows, cols: g.cols, device_cell_h: g.device_cell_h, gutter_ink: g.gutter_ink, tried: g.tried,
  from: g.measured ? 'best fit to the picture, and the cell height measured for this font size and row count' : 'best fit to the picture',
} : null);

function manualHelp(c, g) {
  const short = p => { const r = path.relative(process.cwd(), p); return r && !r.startsWith('..') ? r : p; };
  const cmd = `node ${short(__filename)} ${short(c.dir)} --scene ${c.scene.id}`;
  const lines = [
    '  Mark the area yourself. Frames to read coordinates and times from:',
    `    ${cmd} --stills`,
    '  Then cover a rectangle (pixels in the recording):',
    `    ${cmd} --hit <id> --box x,y,w,h --from <s> --to <s>`,
  ];
  if (g) {
    lines.push(`  or whole terminal rows: --rows <first>-<last> --from <s> --to <s>  (${g.rows} rows, 0 at the top; row r spans y = ${g.y0.toFixed(0)} + r x ${g.cell_h.toFixed(1)}, ${g.cell_h.toFixed(0)} px tall)`);
  }
  lines.push('  Times are seconds in build/raw/<id>.mp4. Or re-record with the value kept off the screen.');
  return lines.join('\n');
}

// ---- commands ------------------------------------------------------------------

function stills(c, args) {
  if (!fs.existsSync(c.raw)) fail(`${c.scene.id}: no recording at ${c.raw}`);
  const info = videoInfo(c.raw);
  const n = Math.max(1, Math.min(60, Number(args.count || 12)));
  const outDir = reviewDir(c.raw);
  fs.rmSync(outDir, { recursive: true, force: true });
  fs.mkdirSync(outDir, { recursive: true });
  const out = [];
  for (let i = 0; i < n; i++) {
    const t = Number((info.duration * (i + 0.5) / n).toFixed(2));
    const file = path.join(outDir, `t${t.toFixed(2).padStart(7, '0')}.png`);
    L.ffmpeg(['-ss', String(t), '-i', c.raw, '-frames:v', '1', file]);
    out.push({ t, file });
  }
  const { geom } = geometryFor(c, info, c.raw);
  console.log(JSON.stringify({
    scene: c.scene.id, recording: c.raw, duration: info.duration, stills: out, geometry: publicGeometry(geom),
    note: 'These frames show the recording as it is now, anything sensitive included. They are deleted when the scene is redacted or recorded again.',
  }, null, 2));
}

const reviewDir = raw => raw.replace(/\.mp4$/, '.review');

// Things made from the recording before it changed: the fitted clip (deleting it and its key makes
// render-scenes.js re-fit the scene; the raw recording's own key is untouched, so nothing is
// re-recorded) and any review stills, which show the screen as it was.
function removeClip(c) {
  const removed = [];
  const clips = path.join(c.dir, 'build', 'clips');
  for (const f of [path.join(clips, `${c.scene.id}.mp4`), path.join(clips, `${c.scene.id}.mp4.key`), reviewDir(c.raw)]) {
    if (fs.existsSync(f)) { fs.rmSync(f, { recursive: true }); removed.push(path.relative(c.dir, f)); }
  }
  return removed;
}

function undo(c) {
  const o = originalFor(c.dir, c.scene.id, c.raw);
  if (!o) fail(`${c.scene.id}: there is no kept original for the recording in build/raw (it was discarded, purged, or the scene was recorded again). Re-record to start over.`);
  fs.copyFileSync(o.video, c.raw);
  if (fs.existsSync(o.text)) fs.copyFileSync(o.text, c.txt);
  const scan = S.readScan(c.scanFile) || { hits: [] };
  const reopened = [];
  for (const h of scan.hits || []) if (h.status === 'redacted') { h.status = 'open'; delete h.redaction; delete h.decided; reopened.push(h.id); }
  delete scan.manual_regions;
  S.writeScan(c.scanFile, scan);
  dropOriginal(c.dir, c.scene.id);
  console.log(JSON.stringify({ scene: c.scene.id, restored: path.relative(c.dir, c.raw), reopened, removed: removeClip(c) }, null, 2));
}

function purge(dirArg, sceneId) {
  const { sb, dir } = L.loadStoryboard(dirArg);
  const ids = (sb.scenes || []).filter(s => s.renderer === 'terminal' && (!sceneId || s.id === sceneId)).map(s => s.id);
  console.log(JSON.stringify({ purged: ids.filter(id => dropOriginal(dir, id)), from: ORIGINALS_DIR }, null, 2));
}

// Blank a redacted value in the saved screen text, so the credential is not left in build/ as text either.
function scrubText(txt, hit) {
  if (!fs.existsSync(txt) || hit.source !== 'screen') return;
  const parsed = S.parseSnapshots(fs.readFileSync(txt, 'utf8'));
  let whole = '';
  const first = hit.where[0] && hit.where[0].snapshots[hit.where[0].snapshots.length - 1];
  for (const w of hit.where) {
    if (w.snapshots.includes(first)) whole += (parsed.snaps[first][w.row] || '').substr(w.col, w.len);
    for (const k of w.snapshots) {
      const line = parsed.snaps[k] && parsed.snaps[k][w.row];
      if (line === undefined) continue;
      parsed.snaps[k][w.row] = line.slice(0, w.col) + '*'.repeat(Math.min(w.len, Math.max(0, line.length - w.col))) + line.slice(w.col + w.len);
    }
  }
  if (whole.length >= 6) {
    for (const snap of parsed.snaps) for (let r = 0; r < snap.length; r++) if (snap[r].includes(whole)) snap[r] = snap[r].split(whole).join('*'.repeat(whole.length));
  }
  fs.writeFileSync(txt, S.serializeSnapshots(parsed));
}

async function redact(c, args) {
  if (!fs.existsSync(c.raw)) fail(`${c.scene.id}: no recording at ${c.raw}`);
  const style = args.style || 'blur';
  if (!['blur', 'box'].includes(style)) fail('--style is blur or box');
  const manual = Boolean(args.box || args.rows);
  if (!args.hit && !manual) fail('pass --hit <id> (from secret-scan.js), or mark an area with --box or --rows');

  S.checkScene(c.scene, c.dir, c.raw); // make sure the scan results exist and are current
  const scan = S.readScan(c.scanFile);
  const hit = args.hit ? (scan.hits || []).find(h => h.id === args.hit) : null;
  if (args.hit && !hit) fail(`${c.scene.id}: no hit "${args.hit}" in ${c.scanFile}. Run secret-scan.js to list them.`);
  if (hit && hit.source === 'tape') {
    fail(`${hit.id} is in the tape file itself (line ${hit.where[0].line}), not only in the picture. Take the value out of ${c.scene.visual} ` +
      '(read it from the environment), or accept it with secret-scan.js --accept if it is made up. If it also shows on screen, that is a separate hit.');
  }

  // Work from the unredacted original when we still have it, so every run redoes all regions cleanly.
  let orig = originalFor(c.dir, c.scene.id, c.raw);
  const redactedBefore = (scan.hits || []).some(h => h.status === 'redacted') || (scan.manual_regions || []).length > 0;
  if (!orig) {
    dropOriginal(c.dir, c.scene.id); // a stale copy from an older recording
    if (!redactedBefore) orig = keepOriginal(c.dir, c.scene.id, c.raw, c.txt);
  }
  const source = orig ? orig.video : c.raw;
  const info = videoInfo(source);
  const { geom, lay, why } = geometryFor(c, info, source);
  const clamp = (v, size) => Math.max(1, Math.min(Math.round(v), Math.floor((size - 2) / 2)));
  const blurOf = r => ({ ...r, style, blur_x: clamp(geom ? 1.75 * geom.cell_w : 48, r.w), blur_y: clamp(geom ? geom.cell_h / 7 : 8, r.h) });
  const stop = msg => { if (orig && !redactedBefore) dropOriginal(c.dir, c.scene.id); fail(`${msg}\n${manualHelp(c, geom)}`); };

  let regions = [];
  const notes = [];
  if (manual) {
    let rect;
    if (args.box) {
      const n = String(args.box).split(',').map(Number);
      if (n.length !== 4 || n.some(v => !Number.isFinite(v)) || n[2] <= 0 || n[3] <= 0) stop('--box is x,y,w,h in pixels of the recording');
      rect = evenRect(n[0], n[1], n[2], n[3], info);
    } else {
      const m = String(args.rows).match(/^(\d+)(?:-(\d+))?$/);
      if (!m) stop('--rows is a row number or a range such as 3-5 (0 is the top row)');
      if (!geom) stop(`${c.scene.id}: --rows needs the row geometry, and ${why}. Use --box`);
      const a = Number(m[1]);
      const b = Number(m[2] === undefined ? m[1] : m[2]);
      if (a > b || b >= geom.rows) stop(`--rows must be within 0-${geom.rows - 1}`);
      const top = cellRect(geom, a, 0, 0, info, true);
      const bottom = cellRect(geom, b, 0, 0, info, true);
      rect = { x: top.x, y: top.y, w: top.w, h: bottom.y + bottom.h - top.y };
    }
    const from = args.from === undefined ? 0 : Number(args.from);
    const to = args.to === undefined || args.to === 'end' ? null : Number(args.to);
    if (!Number.isFinite(from) || (to !== null && (!Number.isFinite(to) || to <= from))) stop('--from and --to are seconds in the raw recording, with --to after --from');
    if (args.from === undefined && args.to === undefined) notes.push('no --from/--to given: the area is covered for the whole recording');
    regions = [{ ...blurOf(rect), spans: [{ from, to }], placed: 'manual' }];
  } else {
    if (!geom) stop(`${c.scene.id}: cannot place ${hit.id} automatically: ${why}.`);
    const firstSnap = Math.min(...hit.where.flatMap(w => w.snapshots));
    const filledAt = lay.filled.findIndex((f, k) => f && k >= firstSnap);
    if (lay.filled.slice(0, firstSnap).some(Boolean) || filledAt >= 0) {
      stop(`${c.scene.id}: cannot place ${hit.id} automatically: the screen was full around snapshot ${filledAt >= 0 ? filledAt : firstSnap} and may have scrolled. ` +
        'Once it scrolls, the saved screen text no longer says which row the value is on.');
    }
    const lastScanned = [...lay.snaps.keys()].reverse().find(k => lay.scanned[k]);
    const match = pictureMatchesText(geom, lay.snaps[lastScanned]);
    if (!match.ok) stop(`${c.scene.id}: cannot place ${hit.id} automatically: ${match.why}, so the rows cannot be trusted.`);
    if (geom.gutter_ink > 0.35) stop(`${c.scene.id}: cannot place ${hit.id} automatically: the row grid does not line up with the text in the picture (gutter ink ${geom.gutter_ink}).`);
    for (const w of hit.where) {
      const line = lay.snaps[w.snapshots[0]][w.row] || '';
      const wide = /[^\x00-\x7f]/.test(line.slice(0, w.col + w.len)); // wide characters shift columns
      const whole = Boolean(args['whole-row']) || wide;
      const rect = cellRect(geom, w.row, w.col, w.len, info, whole);
      if (wide && !args['whole-row']) notes.push(`row ${w.row} has non-ASCII characters before the value, so the whole row is covered`);
      const { ranges, frames } = await inkRanges(source, watchRect(geom, w.row, w.col, w.len, info, whole), geom.background, geom.cell_w * geom.cell_h);
      if (info.frames && Math.abs(frames - info.frames) > 2) notes.push(`decoded ${frames} frames but the file reports ${info.frames}`);
      info.frames = frames;
      if (!ranges.length) { notes.push(`nothing ever appears at row ${w.row}, col ${w.col} in the picture; no region made for it`); continue; }
      regions.push({ ...blurOf(rect), spans: toSpans(ranges, info), placed: 'auto', row: w.row, col: w.col, len: w.len });
    }
    if (!regions.length) stop(`${c.scene.id}: ${hit.id} is in the saved screen text but never shows in the picture at that place.`);
  }

  // Everything that must be covered in this recording: earlier regions (when redoing from the original) plus the new ones.
  const record = { style, at: new Date().toISOString(), regions };
  if (hit && hit.redaction && manual) record.regions = [...hit.redaction.regions, ...regions]; // another box for the same hit adds to it
  let all = regions; // without the original, earlier regions are already in the picture
  if (orig) {
    const earlier = [];
    for (const h of scan.hits || []) {
      if (h === hit || !h.redaction) continue;
      earlier.push(...h.redaction.regions);
    }
    for (const m of scan.manual_regions || []) earlier.push(...m.regions);
    all = [...earlier, ...record.regions];
  }

  const tmp = c.raw.replace(/\.mp4$/, '.redacting.mp4');
  try {
    applyRegions(source, all, tmp, info);
  } catch (e) {
    fs.rmSync(tmp, { force: true });
    if (orig && !redactedBefore) dropOriginal(c.dir, c.scene.id);
    throw e;
  }
  fs.renameSync(tmp, c.raw);

  if (hit) {
    hit.status = 'redacted';
    hit.decided = record.at;
    hit.redaction = record;
    scrubText(c.txt, hit);
  } else {
    scan.manual_regions = [...(scan.manual_regions || []), { id: `man-${(scan.manual_regions || []).length + 1}`, ...record }];
  }
  S.writeScan(c.scanFile, scan);

  let original;
  if (args['discard-original'] || !orig) {
    dropOriginal(c.dir, c.scene.id);
    original = { kept: false, note: orig ? 'deleted (--discard-original): this redaction cannot be undone' : 'none: it was discarded by an earlier run, so this region was added on top' };
  } else {
    L.writeJSON(orig.meta, { dir: c.dir, scene: c.scene.id, kept: new Date().toISOString(), result: statOf(c.raw) });
    fs.chmodSync(orig.meta, 0o600);
    original = { kept: true, path: orig.video, note: 'holds the credential; delete it with --purge once the still looks right, or restore it with --undo' };
  }

  // A frame from the middle of the first new region, for a human or agent to look at.
  const span = regions[0].spans[0];
  const mid = span.to === null ? Math.min(info.duration - 0.05, span.from + 1) : (span.from + span.to) / 2;
  const still = c.raw.replace(/\.mp4$/, '.redacted.png');
  L.ffmpeg(['-ss', Math.max(0, mid).toFixed(3), '-i', c.raw, '-frames:v', '1', still]);

  const removed = removeClip(c);
  const finalVideo = path.join(c.dir, `${c.sb.slug}.mp4`);
  if (fs.existsSync(finalVideo)) notes.push(`${c.sb.slug}.mp4 was assembled before this redaction and still shows the value; render and assemble again`);
  notes.forEach(n => console.error(`note: ${n}`));
  console.log(JSON.stringify({
    scene: c.scene.id,
    hit: hit ? { id: hit.id, kind: hit.kind, masked: hit.masked, status: hit.status } : null,
    style,
    regions: regions.map(r => ({ x: r.x, y: r.y, w: r.w, h: r.h, spans: r.spans, placed: r.placed })),
    geometry: publicGeometry(geom),
    recording: path.relative(c.dir, c.raw),
    still_to_check: still,
    still_at: Number(mid.toFixed(2)),
    original,
    removed,
    notes,
    next: `node render-scenes.js ${c.dir}   (re-fits ${c.scene.id} from the redacted recording; nothing is re-recorded)`,
  }, null, 2));
}

function usage(code) {
  const text = fs.readFileSync(__filename, 'utf8').split('\n').slice(2, 34).map(l => l.replace(/^ \*\/?( |$)/, '')).join('\n');
  (code ? console.error : console.log)(text);
  process.exit(code);
}

async function main() {
  const args = L.parseArgs(process.argv.slice(2), ['help', 'whole-row', 'discard-original', 'undo', 'purge', 'stills']);
  if (args.help) usage(0);
  if (!args._[0]) usage(2);
  if (args.purge) return purge(args._[0], args.scene);
  const c = loadScene(args._[0], args.scene);
  if (args.stills) return stills(c, args);
  if (args.undo) return undo(c);
  return redact(c, args);
}

module.exports = { dropOriginal, originalPaths, reviewDir, tapeSettings, geometryCandidates, fitGeometry, ORIGINALS_DIR };

if (require.main === module) main().catch(e => { console.error(`error: ${e.message}`); process.exit(1); });
