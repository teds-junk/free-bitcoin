#!/usr/bin/env node
/**
 * Lint a storyboard before the approval checkpoint (and again before rendering).
 *
 * Usage:
 *   node lint-storyboard.js <video-dir> [--strict] [--json] [--no-analyze]
 *
 * Always regenerates script.md (the human review copy) from storyboard.json, keeping
 * anything between <!-- notes --> and <!-- /notes -->. Never edit script.md by hand.
 *
 * Checks structure, renderer names, sentence length, chapter rules, the opening hook,
 * slide text density, the wording (stated lengths, orders to the viewer, absolute claims),
 * and words likely to be mispronounced that no lexicon covers. Prints the workspace's standing
 * notes from the user (preferences.json → style_notes) at the top of every run.
 * Estimates runtime from ~150 wpm at speed 1.0, scaled by the voice speed (default 1.2).
 * --strict (use before rendering) also requires every visual file to exist, checks
 * the design system in scene HTML (theme link, no progressive reveals, code size), validates cues
 * (types, targets, sentence indexes, conflicts), flags timers and remote URLs, checks the look
 * (headline length, a second stylesheet, pale text, long paths, arrows, lingering highlights),
 * runs the tape safety check, and lists every command the terminal demos will type.
 * Prints a review table (or JSON with --json). Exits 1 on errors, 0 with warnings.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const L = require('./lib');
const { checkTape } = require('./tape-check');
const { checkStory } = require('./story-checks');
const { checkWording, checkLook, checkPathsInTape, workspaceNotes } = require('./craft-checks');
// Narration anchors (wait_for / before) are validated by the timing module when it is present.
let validateAnchors = null;
try { ({ validateAnchors } = require('./tape-events')); } catch { /* optional */ }
// What recording costs, and credentials written into a tape, come from the recording modules.
let declaredSpend = null; let scanTape = null;
try { ({ declaredSpend } = require('./recording')); } catch { /* optional */ }
try { ({ scanTape } = require('./secret-scan')); } catch { /* optional */ }

const RENDERERS = ['slide', 'html', 'terminal', 'manim', 'video'];
const WPM = 150;

function loadLexiconKeys(dir, sb) {
  const files = [path.join(L.ASSETS_DIR, 'pronunciations.json'), path.join(dir, '..', 'pronunciations.json'), path.join(dir, 'pronunciations.json')];
  if (sb.pronunciations) files.push(path.resolve(dir, sb.pronunciations));
  const keys = new Set();
  for (const f of files) if (fs.existsSync(f)) Object.keys(L.readJSON(f)).filter(k => !k.startsWith('_')).forEach(k => keys.add(k.replace(/^=/, '').toLowerCase()));
  return keys;
}

// What the voice will actually say, read from its own text-to-phoneme step: words outside its
// dictionary, heteronyms and the reading it chose, lexicon entries, names. Needs the narration
// environment (a few seconds, no audio). Returns null when it is not installed, so the lint
// falls back to the pattern check below.
function analyzePronunciation(dir) {
  if (!fs.existsSync(L.VENV_PY)) return null;
  const r = spawnSync(L.VENV_PY, [path.join(__dirname, 'tts.py'), '--analyze', dir, '--json'], { encoding: 'utf8', maxBuffer: 1 << 27, timeout: 180000 });
  if (r.status !== 0) return { error: ((r.stderr || '').trim().split('\n').slice(-2).join(' ')) || `exit ${r.status}` };
  try { return JSON.parse(r.stdout); } catch (e) { return { error: `unreadable output: ${e.message}` }; }
}

// Fallback when the narration environment is missing: tokens TTS models commonly get wrong.
function riskyTokens(sentence) {
  const found = new Set();
  const patterns = [
    /\b[A-Z]{2,}[a-z]?s?\b/g,                 // acronyms: JSON, YAML, CLIs
    /\b[a-z]+_[a-z0-9_]+\b/g,                 // snake_case
    /\b[a-z]+[A-Z][A-Za-z0-9]*\b/g,           // camelCase
    /(^|\s)--?[a-z][\w-]*/g,                  // --flags
    /[~.]?\/[\w.-]+(\/[\w.-]*)*/g,            // paths
    /\bv?\d+\.\d+\.\d+\b/g,                   // multi-dot versions
    /\b\w+\.(json|yaml|yml|md|js|ts|py|html|sh)\b/g, // file names
  ];
  for (const re of patterns) for (const m of sentence.matchAll(re)) found.add(m[0].trim());
  return [...found];
}

function visibleWords(htmlFile) {
  const html = fs.readFileSync(htmlFile, 'utf8')
    .replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/<head[\s\S]*?<\/head>/gi, ' ')
    .replace(/<(script|style)[\s\S]*?<\/\1>/gi, ' ')
    .replace(/<pre[\s\S]*?<\/pre>/gi, ' ') // code blocks are judged by line count instead
    .replace(/<table[\s\S]*?<\/table>/gi, ' ') // tables are evidence, judged by rows (story-checks.js)
    .replace(/<[^>]+>/g, ' ');
  return html.split(/\s+/).filter(w => /[A-Za-z0-9]/.test(w)).length;
}

// ---- script.md (generated) -------------------------------------------------

function renderScript(sb, notes) {
  const v = sb.voice || {};
  const out = [`# ${sb.title} — narration script`, '',
    '<!-- Generated from storyboard.json by lint-storyboard.js. Edit storyboard.json, not this file.',
    '     Free-form notes (sources, open questions) go between the notes markers and are kept. -->', '',
    `Source: ${sb.source || '—'}  `, `Voice: ${v.voice || 'am_echo'} @ ${v.speed || 1.2}x`, '',
    '<!-- notes -->', (notes || '').trim(), '<!-- /notes -->', ''];
  const n = sb.narrative;
  if (n) {
    out.push('## The story', '', `**The question this video answers:** ${n.question || '—'}  `, `**The viewer starts:** ${n.viewer_starts || '—'}`, '');
    (n.arc || []).forEach((a, i) => out.push(`${i + 1}. **${a.stage}**: after this, the viewer can ${a.viewer_can || '—'}`));
    out.push('');
  }
  for (const s of sb.scenes || []) {
    out.push(`## ${s.id}${s.chapter ? ` — ${s.chapter}` : ''}`, '');
    const meta = [s.role && `**Role:** ${s.role}`, s.mode && `**Mode:** ${s.mode}`, s.stage && `**Stage:** ${s.stage}`,
      (s.introduces || []).length && `**Introduces:** ${s.introduces.join(', ')}`].filter(Boolean);
    if (meta.length) out.push(`${meta.join(' · ')}  `);
    out.push(`**On screen:** ${s.on_screen || '—'}  `, `**Renderer:** ${s.renderer} (${s.visual || '—'})`, '');
    (s.narration || []).forEach((line, i) => {
      const item = (s.narration_items || [])[i] || {};
      const notes = [item.pause && `pause ${item.pause}s first`, item.read && `${item.read}s to read after`, item.wait_for && `waits for ${item.wait_for}`,
        item.before && `finishes before ${item.before}`, item.outcome && 'depends on what the demo produced'].filter(Boolean);
      out.push(`> ${line}${notes.length ? `  _(${notes.join('; ')})_` : ''}`);
    });
    out.push('');
  }
  return out.join('\n');
}

function writeScript(dir, sb) {
  const f = path.join(dir, 'script.md');
  const old = fs.existsSync(f) ? fs.readFileSync(f, 'utf8') : '';
  const m = old.match(/<!-- notes -->([\s\S]*?)<!-- \/notes -->/);
  const next = renderScript(sb, m ? m[1] : '');
  if (next !== old) fs.writeFileSync(f, next);
  return f;
}

// ---- strict checks on visuals ------------------------------------------------

const CUE_TYPES = ['focus', 'morph', 'connect', 'expand', 'collapse', 'scroll'];
const FOCUS_COLORS = ['cyan', 'blue', 'yellow', 'green', 'orange', 'red', 'violet'];

// Static checks for one scene's HTML against the design system (references/SOLARIZED-TECHNICAL-ESSAY.md).
// `sentences` is the scene's narration text, one string per sentence, for "N~word" cue times.
function checkHtmlVisual(where, file, sentenceCount, est, errors, warnings, renderer, sentences = []) {
  const html = fs.readFileSync(file, 'utf8').replace(/<!--[\s\S]*?-->/g, '');
  const err = m => errors.push(`${where}: ${m}`);
  const warn = m => warnings.push(`${where}: ${m}`);

  if (!/href="[^"]*_theme\/theme\.css"/.test(html)) err('does not link ../_theme/theme.css (fonts, palette, layouts)');
  if (!/class="[^"]*\bscene\b/.test(html)) err('no <main class="scene …"> root; start from assets/layouts/*.html');
  if (/data-(cue|effect)=/.test(html)) err('old progressive-reveal attributes (data-cue/data-effect): text must be fully visible from the first frame; use focus/morph/connect/expand cues');
  const remote = html.match(/(?:src|href)\s*=\s*["']https?:\/\/[^"']+/);
  if (remote) err(`remote resource (${remote[0].split(/["']/)[1]}); renders must be offline (fonts are bundled in _theme/fonts)`);
  if (/\b(setTimeout|setInterval|requestAnimationFrame)\s*\(/.test(html) || /[^-]transition\s*:/.test(html) || /@keyframes/.test(html)) {
    warn('timers, CSS transitions, or @keyframes found; motion must come from cues (or window.onSeek) so frames are a pure function of time');
  }

  // Code limits at the default 42px / 1.75 line height.
  for (const pre of html.matchAll(/<pre[^>]*class="([^"]*\bcode\b[^"]*)"[^>]*>([\s\S]*?)<\/pre>/g)) {
    if (/\bfile-code\b/.test(pre[1])) continue; // a file panel scrolls its rows; its window is checked below
    const dense = /\b(dark|small)\b/.test(pre[1]);
    const text = pre[2].replace(/<[^>]+>/g, '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
    const lines = text.split('\n').filter(l => l.trim());
    const maxLines = dense ? 12 : 9;
    if (lines.length > maxLines) warn(`code has ${lines.length} lines (aim ≤${maxLines} at this size); split it into scenes, never shrink it`);
    const maxChars = dense ? 64 : 56;
    const wide = lines.filter(l => l.length > maxChars);
    if (wide.length) warn(`${wide.length} code line(s) over ${maxChars} chars (e.g. "${wide[0].trim().slice(0, 40)}…")`);
  }

  // Cues.
  const tag = html.match(/<script[^>]*id="cues"[^>]*>([\s\S]*?)<\/script>/);
  let cues = [];
  if (tag) {
    try { cues = JSON.parse(tag[1] || '[]'); } catch (e) { err(`cues JSON does not parse: ${e.message}`); return; }
    if (!Array.isArray(cues)) { err('cues must be a JSON array'); return; }
  }
  if (renderer === 'html' && !cues.length) warn('renderer "html" but no cues; use "slide" for a static scene (much faster)');
  if (renderer === 'slide' && cues.length) warn('renderer "slide" captures only the final state; use "html" so the cues animate');

  const concepts = new Set([...html.matchAll(/data-concept="([^"]+)"/g)].map(m => m[1]));
  const pairs = new Set([...html.matchAll(/<[^>]*data-concept="([^"]+)"[^>]*>/g)].map(m => {
    const rep = (m[0].match(/data-rep="([^"]+)"/) || [])[1];
    return rep ? `${m[1]}@${rep}` : null;
  }).filter(Boolean));
  const ids = new Set([...html.matchAll(/\bid="([^"]+)"/g)].map(m => m[1]));
  const refOk = ref => ref === 'none' || (ref.startsWith('#') ? ids.has(ref.slice(1)) : ref.includes('@') ? pairs.has(ref) : concepts.has(ref));

  // File panels (scripts/file-panel.js): the rows each one holds, in order, and its window size.
  const panels = new Map(); // id -> { rows: [{ line } | { hidden: [first, last] }], windowRows }
  const panelTags = [...html.matchAll(/<div[^>]*class="[^"]*\bfile-panel\b[^"]*"[^>]*>/g)];
  panelTags.forEach((m, k) => {
    const body = html.slice(m.index, k + 1 < panelTags.length ? panelTags[k + 1].index : html.length);
    const id = (m[0].match(/\bid="([^"]+)"/) || [])[1];
    const windowRows = Number((m[0].match(/data-rows="(\d+)"/) || [])[1]) || 0;
    const rows = [...body.matchAll(/<span class="file-row[^"]*"[^>]*>/g)].map(r => {
      const h = r[0].match(/data-hidden="(\d+)-(\d+)"/);
      return h ? { hidden: [+h[1], +h[2]] } : { line: Number((r[0].match(/data-line="(\d+)"/) || [])[1]) };
    });
    if (!id) { warn('a file panel has no id, so no scroll cue can move it; regenerate it with file-panel.js --id'); return; }
    if (windowRows > 12) warn(`file panel #${id} has a ${windowRows}-row window; 12 is the most that fits above the caption band (file-panel.js --rows)`);
    // The viewer must be able to tell they are seeing part of a file. A minimap or a scrollbar
    // says so. So do the "lines hidden" rows, but only when all of them are in view: every row
    // fits the window, and every left-out line is covered by a row.
    const fileLines = Number((m[0].match(/data-lines="(\d+)"/) || [])[1]) || 0;
    const linesShown = new Set(rows.filter(r => r.line).map(r => r.line)).size;
    const linesMarked = rows.filter(r => r.hidden).reduce((n, r) => n + r.hidden[1] - r.hidden[0] + 1, 0);
    const scrolls = rows.length > windowRows;
    const unmarked = fileLines && linesShown + linesMarked < fileLines;
    if ((scrolls || unmarked) && !/class="file-map\b/.test(body)) {
      err(`file panel #${id} shows only part of its file (${linesShown} of ${fileLines || '?'} lines) and nothing tells the viewer so: ` +
        (scrolls ? `it has ${rows.length} rows in a ${windowRows}-row window` : `${fileLines - linesShown - linesMarked} left-out line(s) have no "lines hidden" row`) +
        ', and it has neither a minimap nor a scrollbar. Regenerate it with file-panel.js: it draws the minimap, or a scrollbar where there is no room for one');
    }
    panels.set(id, { rows, windowRows });
  });

  const timeOf = at => {
    const v = String(at == null ? '' : at).trim();
    if (v.startsWith('t=')) { const t = parseFloat(v.slice(2)); if (t > est + 2) warn(`cue at "${v}" is after the scene's estimated end (~${est.toFixed(0)}s)`); return t; }
    const tilde = v.indexOf('~'); // "N~word": when that word is spoken in sentence N
    const ref = tilde > 0 ? v.slice(0, tilde) : v.split('+')[0];
    const idx = parseInt(ref, 10);
    if (!Number.isInteger(idx) || idx < 0 || idx >= sentenceCount) {
      err(`cue at "${v}" points at sentence ${ref}, but the scene has ${sentenceCount} sentences (0-based)`);
      return null;
    }
    if (tilde > 0) {
      const word = v.slice(tilde + 1).trim(), text = String(sentences[idx] || '');
      const lower = text.toLowerCase(), w = word.toLowerCase();
      // Same rule as the runtime: the first occurrence that starts a word, else the first anywhere.
      let pos = -1;
      for (let i = w ? lower.indexOf(w) : -1; i >= 0; i = lower.indexOf(w, i + 1)) {
        if (pos < 0) pos = i;
        if (i === 0 || !/[a-z0-9]/.test(lower[i - 1])) { pos = i; break; }
      }
      if (pos < 0) {
        err(`cue at "${v}": sentence ${idx} does not say "${word}" ("${text.slice(0, 60)}${text.length > 60 ? '…' : ''}"); use a word or short phrase from that sentence`);
        return idx * 1000;
      }
      const seconds = text.split(/\s+/).filter(Boolean).length / WPM * 60 / 1.2; // rough length of the sentence
      return idx * 1000 + (pos / text.length) * seconds;
    }
    return idx * 1000 + (parseFloat(v.split('+')[1]) || 0); // ordering key, not seconds
  };

  const focusAt = new Map(); const morphTo = new Set(); const blockAt = new Map(); const scrollAt = new Map();
  cues.forEach((c, i) => {
    const at = `cue ${i + 1} (${c.type || '?'})`;
    if (!CUE_TYPES.includes(c.type)) { err(`${at}: type must be one of ${CUE_TYPES.join(', ')}`); return; }
    const t = timeOf(c.at);
    if (c.until != null) timeOf(c.until);
    if (c.type === 'focus') {
      if (!c.target) err(`${at}: needs "target" (a concept id, or "none")`);
      else if (!refOk(c.target)) err(`${at}: target "${c.target}" not found (no matching data-concept / data-rep / id)`);
      if (c.color && !FOCUS_COLORS.includes(c.color)) err(`${at}: color must be one of ${FOCUS_COLORS.join(', ')}`);
      const k = `${c.channel || 'main'}|${t}`;
      if (focusAt.has(k)) err(`${at}: conflicts with another focus cue on channel "${c.channel || 'main'}" at the same moment`);
      focusAt.set(k, true);
    } else if (c.type === 'morph' || c.type === 'connect') {
      for (const end of ['from', 'to']) {
        if (!c[end]) err(`${at}: needs "${end}"`);
        else if (!refOk(c[end])) err(`${at}: ${end} "${c[end]}" not found`);
      }
      if (c.type === 'morph' && c.from && c.to && !c.from.startsWith('#') && !c.to.startsWith('#') && c.from.split('@')[0] !== c.to.split('@')[0]) {
        warn(`${at}: morph from "${c.from}" to "${c.to}" changes concept id; a morph should keep the concept's identity`);
      }
      if (c.type === 'morph' && c.to) { if (morphTo.has(c.to)) err(`${at}: "${c.to}" is already the destination of another morph`); morphTo.add(c.to); }
    } else if (c.type === 'scroll') {
      const p = typeof c.target === 'string' && c.target.startsWith('#') ? panels.get(c.target.slice(1)) : null;
      if (!p) {
        err(`${at}: target "${c.target}" is not a file panel; use "#id" of a panel made by file-panel.js (panels in this scene: ${[...panels.keys()].map(k => '#' + k).join(', ') || 'none'})`);
        return;
      }
      const to = String(c.to == null ? '' : c.to).trim();
      const m = /^(\d+)(?:\s*-\s*(\d+))?$/.exec(to);
      if (to !== 'top' && to !== 'end') {
        if (!m) err(`${at}: "to" must be a line ("44"), a range ("40-52"), "top", or "end" (got "${to}")`);
        else {
          const a = +m[1], b = m[2] ? +m[2] : a;
          if (b < a) err(`${at}: "to" range ${to} runs backwards`);
          for (const n of new Set([a, b])) {
            if (p.rows.some(r => r.line === n)) continue;
            const h = p.rows.find(r => r.hidden && n >= r.hidden[0] && n <= r.hidden[1]);
            err(h
              ? `${at}: line ${n} is not shown in ${c.target} (lines ${h.hidden[0]}–${h.hidden[1]} are one "lines hidden" row); add it to file-panel.js --show, or scroll to a shown line`
              : `${at}: ${c.target} has no line ${n}`);
          }
          const i0 = p.rows.findIndex(r => r.line === a), i1 = p.rows.map(r => r.line).lastIndexOf(b);
          if (i0 >= 0 && i1 >= i0 && i1 - i0 + 1 > p.windowRows) {
            const seen = p.rows.slice(i0, i0 + p.windowRows).filter(r => r.line).pop();
            warn(`${at}: lines ${to} take ${i1 - i0 + 1} rows but the window of ${c.target} has ${p.windowRows}; it will stop on ${a}–${seen.line}, so scroll again to reach the rest`);
          }
        }
      }
      if (c.align != null && !['top', 'center'].includes(c.align)) err(`${at}: align must be "top" or "center"`);
      if (p.rows.length <= p.windowRows) warn(`${at}: ${c.target} already shows every row it has; this scroll does nothing`);
      const k = `${c.target}|${t}`;
      if (scrollAt.has(k)) err(`${at}: conflicts with another scroll of ${c.target} at the same moment`);
      scrollAt.set(k, true);
    } else {
      if (!c.target || !refOk(c.target)) err(`${at}: target "${c.target}" not found`);
      const k = `${c.target}|${t}`;
      if (blockAt.has(k)) err(`${at}: conflicts with another expand/collapse on ${c.target} at the same moment`);
      blockAt.set(k, true);
    }
  });
}

function main() {
  const args = L.parseArgs(process.argv.slice(2), ['strict', 'json', 'no-analyze']);
  const { sb, dir } = L.loadStoryboard(args._[0]);
  const errors = [];
  const warnings = [];
  const lexicon = loadLexiconKeys(dir, sb);
  const unknownTerms = new Map();
  const tapeCommands = [];
  const tapes = {}; // scene id -> { text, commands } for the story checks
  // "schema": 2 storyboards (what new-video.js writes) must carry the narrative plan, modes,
  // roles and introductions; older ones get those findings as warnings.
  const strictSchema = Number(sb.schema || 1) >= 2;

  if (!sb.title) errors.push('storyboard has no title');
  if (!sb.slug || !/^[a-z0-9][a-z0-9-]*$/.test(sb.slug)) errors.push('slug must be kebab-case');
  if (!Array.isArray(sb.scenes) || !sb.scenes.length) errors.push('storyboard has no scenes');
  const scenes = sb.scenes || [];
  const ids = new Set();
  const speedDefault = (sb.voice && sb.voice.speed) || 1.2; // matches tts.py's default
  const rows = [];
  let total = 0;

  scenes.forEach((s, idx) => {
    const where = s.id || `scene #${idx + 1}`;
    if (!s.id) errors.push(`${where}: missing id`);
    else if (ids.has(s.id)) errors.push(`${where}: duplicate id`);
    ids.add(s.id);
    if (!RENDERERS.includes(s.renderer)) errors.push(`${where}: renderer must be one of ${RENDERERS.join(', ')}`);
    if (!s.visual) errors.push(`${where}: missing visual`);
    else if (s.renderer === 'manim' && !s.visual.includes('#')) errors.push(`${where}: manim visual must be file.py#SceneClass`);
    const visualFile = s.visual && path.resolve(dir, s.visual.split('#')[0]);
    const visualExists = visualFile && fs.existsSync(visualFile);
    if (args.strict && s.visual && !visualExists) errors.push(`${where}: visual ${s.visual} does not exist`);
    if (idx === 0 && !s.chapter) warnings.push(`${where}: first scene should start a chapter (YouTube needs one at 0:00)`);
    if (idx === 0 && /^\s*(welcome|hi\b|hello|hey\b|in this (video|lesson)|today we)/i.test((s.narration || [])[0] || '')) {
      warnings.push(`${where}: opens with a greeting/"in this video" filler; open on the payoff or the problem instead (STORYBOARD.md → Shape of a Good Video)`);
    }

    const narration = s.narration || [];
    if (!Array.isArray(narration)) errors.push(`${where}: narration must be an array of sentences`);
    if (!narration.length && !s.min_duration && !s.hold_after) warnings.push(`${where}: no narration and no min_duration`);
    let words = 0;
    for (const sentence of narration) {
      const w = sentence.split(/\s+/).filter(Boolean).length;
      words += w;
      if (w > 45) errors.push(`${where}: sentence over 45 words (hard to follow by ear; makes long captions): "${sentence.slice(0, 60)}…"`);
      if ((sentence.match(/[.!?](\s|$)/g) || []).length > 1) warnings.push(`${where}: one sentence per array item: "${sentence.slice(0, 60)}…"`);
      for (const t of riskyTokens(sentence)) {
        const bare = t.replace(/^[-~./]+/, '');
        if (!lexicon.has(t.toLowerCase()) && !lexicon.has(bare.toLowerCase())) unknownTerms.set(t, (unknownTerms.get(t) || []).concat(s.id));
      }
    }
    const speed = s.speed || speedDefault;
    const est = (words / WPM) * 60 / speed + sb.pacing.lead_in + sb.pacing.tail + sb.pacing.gap * Math.max(0, narration.length - 1)
      + Number(s.hold_after || 0) + (s.narration_items || []).reduce((sum, i) => sum + (Number(i.pause) || 0) + (Number(i.read) || 0), 0);
    const dur = Math.max(est, Number(s.min_duration || 0));
    if (dur > 45) warnings.push(`${where}: ~${dur.toFixed(0)}s is long for one visual; consider splitting (aim 5–30s)`);

    if (['slide', 'html'].includes(s.renderer) && visualExists) {
      const vw = visibleWords(visualFile);
      if (vw > 40) warnings.push(`${where}: ${vw} words on screen (aim ≤40; narration carries the rest)`);
      if (args.strict) {
        checkHtmlVisual(where, visualFile, narration.length, dur, errors, warnings, s.renderer, narration);
        warnings.push(...checkLook(s, visualFile));
      }
    }
    if (s.renderer === 'terminal' && visualExists) {
      const tapeText = fs.readFileSync(visualFile, 'utf8');
      const t = checkTape(tapeText);
      tapes[s.id] = { text: tapeText, commands: t.commands, spend: t.spend };
      // A credential typed into a tape is caught here, before anything records. Values are never printed.
      for (const hit of (scanTape ? scanTape(tapeText) : [])) {
        const at = (hit.where || []).map(w => `line ${w.line}${w.typed ? ` (${w.typed})` : ''}`).join(', ');
        if (hit.severity === 'secret') errors.push(`${where} (${s.visual}): a credential is written in the tape: ${hit.kind} ${hit.masked} at ${at}. Sign in outside the tape and remove the value (TERMINAL-DEMOS.md → Credentials on screen)`);
        else if ((hit.where || []).some(w => w.typed === 'visible')) warnings.push(`${where} (${s.visual}): a visible command types an identity detail (${hit.kind}, ${hit.masked}); it will be on screen`);
      }
      if (validateAnchors && (s.narration_items || []).some(i => i.wait_for || i.before)) {
        const a = validateAnchors(s.narration_items, tapeText);
        (a.errors || []).forEach(e => errors.push(`${where}: ${e}`));
        (a.warnings || []).forEach(w => warnings.push(`${where}: ${w}`));
      }
      if (args.strict) {
        t.errors.forEach(e => errors.push(`${where} (${s.visual}): ${e}`));
        t.warnings.forEach(w => warnings.push(`${where} (${s.visual}): ${w}`));
        t.commands.forEach(c => tapeCommands.push({ scene: s.id, ...c }));
        warnings.push(...checkPathsInTape(s, t.commands));
      }
    }
    rows.push({ id: s.id, chapter: s.chapter || '', renderer: s.renderer, role: s.role || '', mode: s.mode || '', est: dur, on_screen: s.on_screen || '', words, start: total });
    total += dur;
  });

  // The story: narrative plan, modes and roles, explained-before-shown, production notes, italics.
  const story = checkStory(sb, dir, { tapes, strictSchema });
  errors.push(...story.errors);
  warnings.push(...story.warnings);
  // The wording: stated lengths, orders to the viewer, absolute claims, hedges.
  const wording = checkWording(sb);
  warnings.push(...wording.warnings);
  const notes = workspaceNotes(dir);
  if (!strictSchema && !sb.narrative) warnings.push('older storyboard (no "schema": 2): narrative, mode, role and introduction findings are warnings here; they are errors on new videos');
  // What recording this video's demos costs: tape "# Spend:" comments and scene "spend" fields,
  // against the workspace budget and what the spend log already holds.
  let spend = { tapes: Object.entries(tapes).filter(([, t]) => t.spend).map(([scene, t]) => ({ scene, ...t.spend })) };
  if (declaredSpend) { try { spend = declaredSpend(dir); } catch (e) { warnings.push(`could not total the recording cost: ${e.message}`); } }
  if (spend.budget != null && spend.total != null && Number(spend.spent || 0) + spend.total > spend.budget) {
    warnings.push(`recording these demos (${spend.total} ${spend.unit}) on top of ${spend.spent || 0} already spent passes the workspace budget of ${spend.budget}; ask the user before recording`);
  }

  // Chapter length (YouTube minimum 10s).
  const chapterStarts = rows.filter((r, i) => r.chapter || i === 0);
  chapterStarts.forEach((c, i) => {
    const end = i + 1 < chapterStarts.length ? chapterStarts[i + 1].start : total;
    if (end - c.start < 10) warnings.push(`chapter "${c.chapter || sb.title}" is ~${(end - c.start).toFixed(0)}s; YouTube needs ≥10s`);
  });
  if (chapterStarts.length < 3) warnings.push('fewer than 3 chapters: YouTube will not show chapters');

  // Pronunciation. With the narration environment: the voice's own analysis. Without it: patterns.
  let pronunciation = [...unknownTerms].map(([term, where]) => ({ term, scenes: [...new Set(where)], tier: 'pattern', needs: ['ear'] }));
  let heteronyms = [];
  let people = [];
  const analysis = args['no-analyze'] ? null : analyzePronunciation(dir);
  if (analysis && analysis.error) warnings.push(`pronunciation analysis failed (${analysis.error}); fell back to the pattern check, which misses heteronyms, names and words outside the dictionary`);
  else if (!analysis && !args['no-analyze']) warnings.push('narration environment not installed: pronunciation was checked by pattern only (acronyms, identifiers, paths). Heteronyms, names and words outside the voice\'s dictionary are not checked until setup.js has run');
  if (analysis && !analysis.error) {
    pronunciation = (analysis.doubtful || []).map(d => ({
      term: d.word, tier: d.tier, needs: d.needs || [], says: d.sounds_like || d.spoken_as || '', count: d.count,
      scenes: [...new Set((d.occurrences || []).map(o => o.scene))], advice: d.advice,
    }));
    heteronyms = (analysis.heteronyms || []).filter(h => !h.judged).map(h => ({ word: h.word, scene: h.scene, sentence: h.i, text: h.sentence, cue: h.cue }));
    people = analysis.people || [];
    for (const p of people.filter(x => !x.confirmed)) {
      const where = (p.scenes || []).join(', ');
      if (p.source === 'storyboard') {
        (strictSchema ? errors : warnings).push(`"${p.name}" (${where}) is a real person's name the user has not confirmed by ear. Do not narrate it: show the name on screen and say who they are ("the paper's author"), or get it approved on the review page first (PRONUNCIATION.md → Names)`);
      } else {
        warnings.push(`"${p.name}" (${where}) may be a person's name. If it is, list it under "people" in storyboard.json and do not narrate it until the user has confirmed how it is said`);
      }
    }
  }
  const scriptFile = writeScript(dir, sb);
  const result = { ok: errors.length === 0, estimated_seconds: Math.round(total), scenes: rows.length, errors, warnings,
    pronunciation_review: pronunciation, heteronyms_to_judge: heteronyms, people, script: scriptFile, tape_commands: tapeCommands, story: story.report, spend,
    wording: wording.report, style_notes: notes };

  if (args.json) {
    console.log(JSON.stringify({ ...result, rows }, null, 2));
  } else {
    const mmss = t => `${Math.floor(t / 60)}:${String(Math.round(t % 60)).padStart(2, '0')}`;
    console.log(`# ${sb.title} — ${rows.length} scenes, ~${mmss(total)} estimated\n`);
    if (notes.length) {
      console.log('**Standing notes from the user for every video in this workspace** (preferences.json → style_notes). Check every scene and sentence against each one before showing anything:');
      notes.forEach((n, i) => console.log(`${i + 1}. ${n}`));
      console.log('');
    }
    const st = story.report;
    if (sb.narrative) {
      console.log(`**Question:** ${sb.narrative.question || '—'}`);
      (st.arc || []).forEach((a, i) => console.log(`${i + 1}. ${a.stage}: the viewer can ${a.viewer_can || '—'}`));
      console.log('');
    }
    console.log('| # | Start | Scene | Role | Mode | Renderer | Chapter | ~Len | On screen |');
    console.log('|---|-------|-------|------|------|----------|---------|------|-----------|');
    rows.forEach((r, i) => console.log(`| ${i + 1} | ${mmss(r.start)} | ${r.id} | ${r.role} | ${r.mode} | ${r.renderer} | ${r.chapter} | ${r.est.toFixed(0)}s | ${r.on_screen} |`));
    if (st.mode_sequence) {
      console.log(`\n**Mode sequence** (does it read as a story?): ${st.mode_sequence}`);
      if (st.mode_changes.length) {
        console.log('Each change of mode, with the sentence that opens it (it should tell the viewer what kind of thing comes next):');
        for (const c of st.mode_changes) console.log(`- ${c.scene}: ${c.from} → ${c.to}: "${c.opens_with}"`);
      }
    }
    if (st.introductions.length) {
      console.log('\n**Explained before shown** (every command and file, where it first appears and where it is introduced):');
      for (const r of st.introductions) console.log(`- ${r.kind} \`${r.item}\`: shown in ${r.shown_in}, ${r.introduced_in ? `introduced in ${r.introduced_in}` : 'NOT INTRODUCED'}`);
    }
    if (st.outcome_sentences.length) {
      console.log('\n**Sentences that depend on what a demo produced** (confirm each against the recording):');
      for (const o of st.outcome_sentences) console.log(`- ${o.scene} sentence ${o.sentence}: "${o.text}"`);
    }
    if ((spend.tapes || []).length) {
      const budget = spend.budget != null ? ` Budget ${spend.budget}, ${spend.spent || 0} already spent.` : '';
      console.log(`\n**Recording these demos spends** (each time a tape is recorded): ${spend.tapes.map(s => `${s.scene}: ${s.amount} ${s.unit}`).join('; ')}.${budget}`);
    }
    if (heteronyms.length) {
      console.log('\n**Heteronyms to judge by context** (you can do this without hearing: read the cue against the sentence; if the reading is wrong, rewrite the sentence or add a lexicon phrase):');
      for (const h of heteronyms) console.log(`- ${h.scene} sentence ${h.sentence}: "${h.text}"\n  ${h.cue}`);
    }
    if (pronunciation.length) {
      const ear = pronunciation.filter(p => (p.needs || []).includes('ear'));
      console.log(`\n**Pronunciation review** (${ear.length} word(s) for the user to hear once on the review page: pronunciation-review.js):`);
      for (const p of ear) console.log(`- \`${p.term}\` [${p.tier}]${p.says ? ` → "${p.says}"` : ''}${p.count > 1 ? ` ×${p.count}` : ''} (${p.scenes.slice(0, 6).join(', ')}${p.scenes.length > 6 ? ', …' : ''})`);
    }
    if (tapeCommands.length) {
      console.log('\n**Commands the terminal demos will type** (they run for real — show these to the user before rendering):');
      for (const c of tapeCommands) console.log(`- ${c.scene}${c.hidden ? ' (hidden setup)' : ''}: \`${c.text}\``);
    }
    console.log(`\nscript.md regenerated: ${scriptFile}`);
    if (warnings.length) { console.log('\n**Warnings**'); warnings.forEach(w => console.log(`- ${w}`)); }
    if (errors.length) { console.log('\n**Errors**'); errors.forEach(e => console.log(`- ${e}`)); }
  }
  if (errors.length) process.exit(1);
}

main();
