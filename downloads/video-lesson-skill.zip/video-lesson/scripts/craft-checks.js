'use strict';
// Craft checks on a storyboard and its scenes, used by lint-storyboard.js (a library; not run
// directly). Every check here exists because a finished video was sent back for it. They are
// warnings: each names the sentence or scene, what a viewer experiences, and the fix.
//
//   checkWording(sb)                      -> { warnings, report }   narration, any time
//   checkLook(scene, htmlFile, role)      -> warnings               one html/slide scene, with --strict
//   checkPathsInTape(scene, commands)     -> warnings               one terminal scene, with --strict
//   workspaceNotes(dir)                   -> [string]               the user's standing notes for this workspace
//
// Wording (the viewer is watching, not following along; the voice is a guide, not a manual):
//   length     "in the next fifteen minutes": never state how long the video or a part of it is
//   orders     "Start with…", "Now do it yourself", "Pause here": say what we do, not what they must
//   absolutes  "would never have…": a claim sized past its evidence loses the expert viewer
//   hedges     "for now, it's…": say once that it is explained later, and move on
// Look (one design system, readable on a small compressed video):
//   headline   the display serif is for six words or fewer
//   retheme    a second stylesheet, a font-family, or a pale text colour replaces the design system
//   paths      long or machine-specific paths over a panel or in a typed command
//   arrows     connect cues: an arrow means "flows into" or "becomes", nothing else
//   linger     a highlight on a second channel with no "until" stays lit after the voice moves on

const fs = require('fs');
const path = require('path');

const excerpt = (s, n = 70) => (s.length > n ? `${s.slice(0, n)}…` : s);
const NUM = '(?:a few|few|a couple of|couple of|several|\\d+|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|fifteen|twenty|thirty|forty|forty-five|sixty|ninety)';

// A promise or statement of how long the video (or what is left of it) takes. A duration that is
// part of the subject ("about a minute later", "the kind you write in five minutes") is fine.
const LENGTHS = [
  new RegExp(`\\b(?:in|over|for|during|within) the next ${NUM}? ?(?:minutes?|seconds?|hours?)\\b`, 'i'),
  new RegExp(`\\bin (?:under |about |just |only |less than )?${NUM} (?:short |quick )?minutes?,? (?:you(?:'ll| will| can|'d)|we(?:'ll| will))\\b`, 'i'),
  new RegExp(`\\b${NUM}[- ]minutes? (?:video|lesson|course|tour|walk-?through|demo)\\b`, 'i'),
  new RegExp(`\\b(?:this|the) (?:video|lesson) (?:takes|is|runs|lasts) (?:about |around |only |just )?${NUM} minutes?\\b`, 'i'),
  new RegExp(`\\b(?:by the end of|after) (?:these|the next|those) ${NUM} minutes?\\b`, 'i'),
];

// A sentence that opens with a bare verb is an order. (After "Now", "Then", "First", "And"… too.)
const LEAD_IN = /^(?:(?:now|then|next|first|second|third|finally|so|and|but|ok|okay|here|again|also|please|just|go ahead and|go and)[, ]+)*/i;
const ORDER_VERBS = new Set(('start begin run open read look watch pause type copy put check notice remember try do note list show ' +
  'change make find compare add use go see take keep write pick choose stop think consider wait press click scroll give set create ' +
  'move follow turn grab paste install enter save edit delete remove replace select scan focus count name tell ask repeat skip ' +
  'switch close clone download cd pull push hit fill mark swap picture suppose').split(' '));
// Phrases that tell the viewer to leave the video and do something.
const LEAVE_THE_VIDEO = /\bpause (?:here|the video|now|and)\b|\bdo it yourself\b|\b(?:now )?it'?s your turn\b|\byour turn\b|\btry (?:it|this) (?:now|yourself)\b|\bfollow along\b|\bgo ahead and\b/i;

const ABSOLUTES = /\b(?:never|always|impossible|guarantee[sd]?|guaranteed|can(?:'t|not) possibly|no way to|the only way)\b/i;
const HEDGES = /\bfor now\b|\bfor the moment\b|\bin the next few minutes it\b|\bfor the purposes of this (?:video|lesson)\b/i;

function checkWording(sb) {
  const warnings = [];
  const found = { lengths: [], orders: [], absolutes: [], hedges: [] };
  for (const s of sb.scenes || []) {
    (s.narration || []).forEach((text, i) => {
      const at = { scene: s.id, sentence: i, text };
      if (LENGTHS.some(re => re.test(text))) found.lengths.push(at);
      const body = text.replace(LEAD_IN, '');
      const first = (body.match(/^[A-Za-z']+/) || [''])[0].toLowerCase();
      if (LEAVE_THE_VIDEO.test(text) || (ORDER_VERBS.has(first) && !/^(let's|let us)\b/i.test(body))) found.orders.push(at);
      if (ABSOLUTES.test(text)) found.absolutes.push(at);
      if (HEDGES.test(text)) found.hedges.push(at);
    });
  }
  const list = items => items.map(x => `\n    ${x.scene} sentence ${x.sentence}: "${excerpt(x.text, 90)}"`).join('');
  if (found.lengths.length) {
    warnings.push(`${found.lengths.length} sentence(s) say how long the video or a part of it takes. Never state a length: it is wrong the moment the video is edited, and wrong for anyone watching at another speed. Promise what the viewer will be able to do ("In this lesson, you'll …").${list(found.lengths)}`);
  }
  if (found.orders.length) {
    warnings.push(`${found.orders.length} sentence(s) read as orders to the viewer. The viewer is watching, not following along, and nobody stops a video to obey it. Say what we do ("Let's start with…", "First, we check…", "If you tried it yourself, you'd see…"). A sentence that quotes a file or a request is fine; check each.${list(found.orders)}`);
  }
  if (found.absolutes.length) {
    warnings.push(`${found.absolutes.length} sentence(s) make an absolute claim (never, always, impossible, guarantee). Check each is literally true; if it is only usually true, size it to the evidence ("would be hard to find for every model by hand").${list(found.absolutes)}`);
  }
  if (found.hedges.length) {
    warnings.push(`${found.hedges.length} sentence(s) hedge with "for now" or "in the next few minutes it…". If something is explained later, say so once ("we'll explain the check later") and move on; do not describe a permanent fact as temporary.${list(found.hedges)}`);
  }
  return { warnings, report: found };
}

// ---- the look of one html/slide scene ------------------------------------------------------------

const PALE = /color\s*:\s*(?:var\(--base(?:0|1|00)\)|#(?:93a1a1|839496|657b83)\b)/i; // 2.5:1, 2.9:1, 4.1:1 on the paper
const MAX_HEADLINE_WORDS = 6;
const MAX_HEADLINE_CHARS = 40;
const MAX_LABEL_SLASHES = 2;

function longPath(p) {
  const s = String(p || '').trim();
  if (/^(\/Users\/|\/home\/|[A-Za-z]:\\|\/private\/|\/var\/folders\/)/.test(s)) return 'is specific to one machine';
  if (/^[./]+$/.test(s)) return null; // ../../..
  if ((s.match(/\//g) || []).length > MAX_LABEL_SLASHES) return `is ${(s.match(/\//g) || []).length + 1} folders deep`;
  return null;
}

function checkLook(scene, file) {
  const warnings = [];
  const where = scene.id;
  const warn = m => warnings.push(`${where}: ${m}`);
  const raw = fs.readFileSync(file, 'utf8').replace(/<!--[\s\S]*?-->/g, '');

  // Headline: short, in the display face.
  const h = raw.match(/<(h[1-3])[^>]*class="[^"]*\bscene-title\b[^"]*"[^>]*>([\s\S]*?)<\/\1>/);
  if (h) {
    const text = h[2].replace(/<[^>]+>/g, ' ').replace(/&[a-z]+;/g, '&').replace(/\s+/g, ' ').trim();
    const words = text.split(' ').filter(w => /[A-Za-z0-9]/.test(w)).length;
    if (words > MAX_HEADLINE_WORDS || text.length > MAX_HEADLINE_CHARS) {
      warn(`headline is ${words} words ("${excerpt(text, 60)}"). The display serif is a condensed face for SHORT headlines: ${MAX_HEADLINE_WORDS} words or fewer, one line. Keep the claim and cut the words ("A skill is advice."); a full sentence belongs in a .lead under it or in the narration`);
    }
  } else if (!/class="[^"]*\btitle-card\b/.test(raw)) {
    warn('no headline (<h2 class="scene-title">). Every scene but a title card opens with a short headline that states its point');
  }

  // One design system: the look is the theme's. A second stylesheet or a font-family replaces it.
  for (const m of raw.matchAll(/<link[^>]*rel="stylesheet"[^>]*href="([^"]+)"/gi)) {
    if (!/_theme\/theme\.css$/.test(m[1])) warn(`links a second stylesheet (${m[1]}). The look lives in _theme/theme.css; a stylesheet of your own that restyles headlines, colours or fonts replaces the design system for the whole video. Use the theme's classes (SLIDES.md) and keep per-scene CSS to sizes and spacing`);
  }
  const css = [...raw.matchAll(/<style[^>]*>([\s\S]*?)<\/style>/gi)].map(m => m[1]).join('\n') + '\n' + [...raw.matchAll(/\sstyle="([^"]*)"/gi)].map(m => m[1]).join(';\n');
  const titleRules = (css.match(/[^{}]*\.scene-title[^{}]*\{[^}]*\}/g) || []).join(' ');
  if ((/font-family\s*:/i.test(titleRules) && !/font-family\s*:[^;}]*var\(--font-display\)/i.test(titleRules)) || /font\s*:[^;}]*var\(--font-(?:body|code)\)/i.test(titleRules)) {
    warn('restyles the headline in another face. Headlines are in the display serif; if a headline looks wrong in it, the headline is too long: shorten it, do not change the font');
  }
  if (PALE.test(css)) {
    warn('sets text to a pale Solarized grey (base0, base1 or base00). On the paper those are 2.5:1 to 4.1:1 and disappear on a small or compressed video. Text on the paper is --ink, --ink-soft or --ink-muted, nothing lighter');
  }

  // Long or machine-specific paths over a panel.
  const labels = new Set();
  for (const m of raw.matchAll(/data-file="([^"]+)"/g)) labels.add(m[1]);
  for (const m of raw.matchAll(/class="[^"]*\bcode-file\b[^"]*"[^>]*>([^<]+)</g)) labels.add(m[1].trim().split(/\s+/)[0]);
  for (const l of labels) {
    const why = longPath(l);
    if (why) warn(`the panel label "${l}" ${why}. Label a file with the shortest name that identifies it (file-panel.js --label notes-cli/CHANGELOG.md): a long path over a panel is something the viewer reads instead of the file`);
  }

  // Cues: arrows that are not flows, and highlights that outstay the voice.
  const tag = raw.match(/<script[^>]*id="cues"[^>]*>([\s\S]*?)<\/script>/);
  let cues = [];
  try { cues = tag ? JSON.parse(tag[1] || '[]') : []; } catch { cues = []; }
  if (!Array.isArray(cues)) cues = [];
  const arrows = cues.filter(c => c && c.type === 'connect' && c.arrow !== false).length;
  if (arrows) {
    warn(`${arrows} arrow(s) (connect cues). An arrow says one thing flows into or becomes the next. If these are items in a list, drop the arrows and highlight each as it is named; if they are steps in order, number them (<div class="step">1</div>)`);
  }
  const lingering = cues.filter(c => c && c.type === 'focus' && c.channel && c.channel !== 'main' && c.target !== 'none' && c.until == null);
  if (lingering.length) {
    warn(`${lingering.length} highlight(s) on a second channel (${[...new Set(lingering.map(c => c.channel))].join(', ')}) have no "until", so they stay lit after the voice has moved on and two things compete for the eye. Give each "until": the sentence where the voice leaves it. For a note beside code, use a .callout instead: it lights with its line and goes out with it`);
  }
  // Notes beside code that are not callouts drift out of line with what they explain.
  if (/class="[^"]*\b(?:side-notes|annotations)\b/.test(raw) && /class="[^"]*\b(?:file-panel|code dark)\b/.test(raw) && !/class="[^"]*\bcallout\b/.test(raw)) {
    warn('notes sit beside a code box but are not callouts, so nothing lines them up with the lines they explain. Use <div class="annotated"> with <p class="callout" data-anchor="concept-id"> (assets/layouts/code.html): the runtime puts each note level with its line');
  }
  return warnings;
}

// Paths in the commands a tape types where the viewer can see them.
function checkPathsInTape(scene, commands) {
  const warnings = [];
  for (const c of commands || []) {
    if (c.hidden) continue;
    for (const tok of String(c.text).split(/\s+/)) {
      const t = tok.replace(/^["'`]|["'`,;]$/g, '');
      if (!t.includes('/')) continue;
      const why = longPath(t);
      if (why) warnings.push(`${scene.id}: the typed path \`${t}\` ${why}. A path the viewer has to read is a distraction: \`cd\` into the folder in the hidden setup, give the demo folder a short made-up name, or show the file in a panel instead of printing it (TERMINAL-DEMOS.md → Paths on screen)`);
    }
  }
  return warnings;
}

// The user's standing notes for every video in this workspace: <workspace>/videos/preferences.json
// → "style_notes". The lint prints them on every run so they are re-read before every checkpoint.
function workspaceNotes(dir) {
  const file = path.join(dir, '..', 'preferences.json');
  try {
    const notes = JSON.parse(fs.readFileSync(file, 'utf8')).style_notes;
    return Array.isArray(notes) ? notes.map(String).filter(Boolean) : [];
  } catch { return []; }
}

module.exports = { checkWording, checkLook, checkPathsInTape, workspaceNotes, longPath, MAX_HEADLINE_WORDS };
