#!/usr/bin/env node
/**
 * Verify a finished video against the skill's definition of done.
 *
 * Usage:
 *   node verify.js <video-dir> [--frames] [--at 0:56,1:43,9:22]
 *   node verify.js --file <video.mp4> --timeline <timeline.json> --srt <file.srt> --chapters <chapters.txt> [--frames]
 *
 * Checks: 1920x1080 H.264 yuv420p 30fps; AAC audio; a subtitle track; A/V sync (frame
 * count = timeline, video stream within 2 frames of the timeline, audio and video streams
 * the same length); every narrated scene has non-empty audio clips; SRT cues valid and
 * ascending. Warnings: captions over 2x42 chars or 20 chars/s; chapters that break
 * YouTube's rules (first at 0:00, >=3, >=10s each).
 * --frames grabs one still per scene into build/review/ so the agent can look at them.
 * --at grabs a still at each given time of the finished video (m:ss or seconds) into
 *   build/review/at/, named by its time and scene: use it to look at the exact moments a
 *   reviewer's notes point at, before and after a fix.
 * Prints JSON { ok, checks[], warnings[] } and exits 1 if any check fails.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const L = require('./lib');

function parseSrt(text) {
  const toSec = s => { const [h, m, rest] = s.split(':'); const [sec, ms] = rest.split(','); return +h * 3600 + +m * 60 + +sec + +ms / 1000; };
  return text.trim().split(/\n\s*\n/).map(block => {
    const lines = block.split('\n');
    const m = (lines[1] || '').match(/(\d\d:\d\d:\d\d,\d\d\d) --> (\d\d:\d\d:\d\d,\d\d\d)/);
    return m ? { start: toSec(m[1]), end: toSec(m[2]), text: lines.slice(2).join(' '), lines: lines.slice(2) } : null;
  });
}

function main() {
  const args = L.parseArgs(process.argv.slice(2), ['frames']);
  let file, tlFile, srtFile, chFile, baseDir;
  if (args.file) {
    file = args.file; tlFile = args.timeline; srtFile = args.srt; chFile = args.chapters;
    baseDir = path.dirname(path.resolve(tlFile));
  } else {
    const { sb, dir } = L.loadStoryboard(args._[0]);
    baseDir = dir;
    file = path.join(dir, `${sb.slug}.mp4`);
    tlFile = path.join(dir, 'build', 'timeline.json');
    srtFile = path.join(dir, `${sb.slug}.srt`);
    chFile = path.join(dir, 'chapters.txt');
  }

  const checks = [];
  const warnings = [];
  const check = (name, ok, detail) => checks.push({ name, ok: Boolean(ok), detail });

  check('video file exists', fs.existsSync(file), file);
  if (!fs.existsSync(file)) return finish(checks, warnings);
  const tl = L.readJSON(tlFile);
  const info = L.probe(file);
  const v = info.streams.find(s => s.codec_type === 'video');
  const a = info.streams.find(s => s.codec_type === 'audio');
  const sub = info.streams.find(s => s.codec_type === 'subtitle');

  check('1920x1080', v && v.width === 1920 && v.height === 1080, v && `${v.width}x${v.height}`);
  check('h264 yuv420p', v && v.codec_name === 'h264' && v.pix_fmt === 'yuv420p', v && `${v.codec_name} ${v.pix_fmt}`);
  check('30 fps', v && v.r_frame_rate === '30/1', v && v.r_frame_rate);
  check('aac audio', a && a.codec_name === 'aac', a && a.codec_name);
  check('subtitle track', Boolean(sub), sub && sub.codec_name);
  const dur = Number(info.format.duration);
  // A/V sync: the container duration is forced by -t, so check the streams themselves.
  const frameDur = 1 / L.VIDEO.fps;
  const expectFrames = L.frames(tl.total);
  const vFrames = Number(v && v.nb_frames);
  const vDur = Number(v && v.duration);
  const aDur = Number(a && a.duration);
  check('frame count matches timeline', Math.abs(vFrames - expectFrames) <= 1, `${vFrames} frames vs ${expectFrames} expected`);
  check('video stream length matches timeline', Math.abs(vDur - tl.total) < 2 * frameDur, `${vDur.toFixed(3)}s vs ${tl.total.toFixed(3)}s`);
  check('audio and video streams same length', Math.abs(aDur - vDur) < 0.05, `audio ${aDur.toFixed(3)}s, video ${vDur.toFixed(3)}s`);

  // Every scene with narration has its own non-empty clips.
  const missing = [];
  for (const s of tl.scenes) {
    for (const x of s.sentences || []) {
      const f = path.resolve(baseDir, x.file || '');
      if (!x.file || !fs.existsSync(f) || fs.statSync(f).size < 1000) missing.push(`${s.id}:${x.file}`);
    }
    if (!(s.sentences || []).length && !s.silent) warnings.push(`${s.id} has no narration`);
  }
  check('every sentence has audio', missing.length === 0, missing.slice(0, 5).join(', ') || `${tl.scenes.length} scenes`);
  const drift = tl.scenes.filter(s => Math.abs(s.duration * L.VIDEO.fps - Math.round(s.duration * L.VIDEO.fps)) > 1e-3);
  check('scene lengths are whole frames', drift.length === 0, drift.map(s => s.id).join(', ') || 'ok');

  // Captions.
  const cues = fs.existsSync(srtFile) ? parseSrt(fs.readFileSync(srtFile, 'utf8')) : [];
  const badCue = cues.findIndex((c, i) => !c || c.end <= c.start || (i > 0 && cues[i - 1] && c.start < cues[i - 1].start - 1e-3));
  check('srt valid and ascending', cues.length > 0 && badCue === -1, `${cues.length} cues${badCue >= 0 ? `, bad cue #${badCue + 1}` : ''}`);
  check('captions end within video', cues.length > 0 && cues[cues.length - 1].end <= dur + 0.1, '');
  const longCues = cues.filter(c => c && (c.lines.length > 2 || c.lines.some(l => l.length > 42)));
  if (longCues.length) warnings.push(`${longCues.length} caption cue(s) exceed 2 lines x 42 chars (first: "${longCues[0].text.slice(0, 50)}…")`);
  const fast = cues.filter(c => c && c.text.length / Math.max(0.1, c.end - c.start) > 20);
  if (fast.length) warnings.push(`${fast.length} caption cue(s) faster than 20 chars/s reading speed`);

  // Chapters (YouTube rules are warnings: a short video may legitimately have fewer).
  const chapters = fs.existsSync(chFile) ? fs.readFileSync(chFile, 'utf8').trim().split('\n').filter(Boolean) : [];
  check('chapters.txt exists', chapters.length > 0, `${chapters.length} chapters`);
  if (chapters.length) {
    const secs = chapters.map(l => l.split(' ')[0].split(':').reduce((acc, n) => acc * 60 + Number(n), 0));
    if (secs[0] !== 0) warnings.push('first chapter must be 0:00 for YouTube');
    if (chapters.length < 3) warnings.push('YouTube needs at least 3 chapters to show them');
    secs.forEach((s, i) => {
      const end = i + 1 < secs.length ? secs[i + 1] : dur;
      if (end - s < 10) warnings.push(`chapter "${chapters[i]}" is shorter than 10s (YouTube minimum)`);
    });
  }

  if (args.at) {
    const dirAt = L.mkdirp(path.join(path.dirname(path.resolve(file)), 'build', 'review', 'at'));
    const toSec = t => String(t).trim().split(':').reduce((acc, n) => acc * 60 + Number(n), 0);
    const stills = [];
    for (const spec of String(args.at).split(',').map(x => x.trim()).filter(Boolean)) {
      const at = toSec(spec);
      if (!Number.isFinite(at) || at < 0 || at > dur) { warnings.push(`--at ${spec}: not a time inside the video (it is ${dur.toFixed(1)}s long)`); continue; }
      const scene = tl.scenes.find(x => at >= x.start && at < x.start + x.duration) || tl.scenes[tl.scenes.length - 1];
      const mmss = `${Math.floor(at / 60)}m${String(Math.floor(at % 60)).padStart(2, '0')}s`;
      const png = path.join(dirAt, `${mmss}-${String(scene.id).replace(/\//g, '_')}.png`);
      try { L.ffmpeg(['-ss', at.toFixed(2), '-i', file, '-frames:v', '1', png]); stills.push(`${spec} (${scene.id}, ${(at - scene.start).toFixed(1)}s in): ${png}`); }
      catch (e) { warnings.push(`--at ${spec}: could not grab a still`); }
    }
    if (stills.length) warnings.push(`stills at the requested times:\n  ${stills.join('\n  ')}`);
  }

  if (args.frames) {
    const review = L.mkdirp(path.join(path.dirname(path.resolve(file)), 'build', 'review'));
    const failed = [];
    for (const s of tl.scenes) {
      const at = s.start + s.duration * 0.6;
      // A compilation's scene ids are "<lesson-slug>/<scene-id>", so each still gets a subfolder.
      const png = path.join(review, `${s.id}.png`);
      L.mkdirp(path.dirname(png));
      try { L.ffmpeg(['-ss', at.toFixed(2), '-i', file, '-frames:v', '1', png]); }
      catch (e) { failed.push(s.id); } // keep going: one bad still must not hide the rest
    }
    if (failed.length) warnings.push(`could not grab a still for: ${failed.join(', ')}`);
    warnings.push(`${tl.scenes.length - failed.length} review stills written to ${review} — look at them before calling the video done`);
  }

  finish(checks, warnings);
}

function finish(checks, warnings) {
  const ok = checks.every(c => c.ok);
  console.log(JSON.stringify({ ok, checks, warnings }, null, 2));
  if (!ok) process.exit(1);
}

try { main(); } catch (e) { console.error(e.message); process.exit(1); }
