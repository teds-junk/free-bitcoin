#!/usr/bin/env node
/**
 * Assemble the final video from rendered clips and narration, then verify it.
 *
 * Usage:
 *   node assemble.js <video-dir>
 *
 * Needs build/timeline.json from render-scenes.js. Steps:
 *   1. Place every sentence WAV at its exact timeline offset in one PCM track
 *      (no per-scene AAC, so no drift), then two-pass loudnorm to -14 LUFS.
 *   2. Concat the clips with stream copy (they share one encoding spec).
 *   3. Mux video + narration + soft captions + chapters into <slug>.mp4.
 *   4. Write poster.png: a frame from the scene named by storyboard "poster", else the title
 *      scene, else the first scene.
 *   5. Run verify.js.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const L = require('./lib');

function main() {
  const args = L.parseArgs(process.argv.slice(2));
  const { sb, dir } = L.loadStoryboard(args._[0]);
  const build = path.join(dir, 'build');
  const tlFile = path.join(build, 'timeline.json');
  if (!fs.existsSync(tlFile)) L.die('no build/timeline.json: run render-scenes.js first');
  const tl = L.readJSON(tlFile);

  // 1. Narration master.
  const placements = tl.scenes.flatMap(s => s.sentences.map(x => ({ file: path.join(dir, x.file), at: x.start })));
  const rawWav = path.join(build, 'narration.raw.wav');
  const normWav = path.join(build, 'narration.wav');
  console.error(`narration: ${placements.length} sentences over ${tl.total.toFixed(2)}s`);
  L.writeWav(rawWav, L.mixTrack(placements, tl.total));
  L.loudnorm(rawWav, normWav);

  // 2. Video-only master.
  const list = path.join(build, 'clips.ffconcat');
  fs.writeFileSync(list, 'ffconcat version 1.0\n' + tl.scenes.map(s => L.ffconcatLine(path.join(dir, s.clip))).join('\n') + '\n');
  const video = path.join(build, 'video.mp4');
  L.ffmpeg(['-f', 'concat', '-safe', '0', '-i', list, '-c', 'copy', video]);

  // 3. Final mux.
  const out = path.join(dir, `${sb.slug}.mp4`);
  L.ffmpeg([
    '-i', video, '-i', normWav, '-i', path.join(dir, `${sb.slug}.srt`), '-i', path.join(build, 'chapters.ffmeta'),
    '-map', '0:v', '-map', '1:a', '-map', '2:s', '-map_metadata', '3', '-map_chapters', '3',
    '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-c:s', 'mov_text', '-metadata:s:s:0', 'language=eng',
    '-t', tl.total.toFixed(4), '-movflags', '+faststart', out,
  ]);
  console.error(`wrote ${out}`);

  // 4. Poster: a still for pages that embed the video.
  const wanted = sb.poster || ((sb.scenes || []).find(s => s.role === 'title') || {}).id;
  const scene = tl.scenes.find(s => s.id === wanted) || tl.scenes[0];
  if (scene) {
    try { L.writePoster(out, scene.start + scene.duration * 0.6, path.join(dir, 'poster.png')); console.error(`wrote poster.png (scene ${scene.id})`); }
    catch (e) { console.error(`warning: could not write poster.png: ${e.message.split('\n')[0]}`); }
  }

  // 5. Verify.
  const v = spawnSync(process.execPath, [path.join(__dirname, 'verify.js'), dir], { stdio: 'inherit' });
  process.exit(v.status);
}

try { main(); } catch (e) { console.error(e.message); process.exit(1); }
