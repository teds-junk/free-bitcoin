#!/usr/bin/env node
/**
 * Does the narration follow the screen? For every terminal scene, one timeline that interleaves
 * what the recording shows (typed, enter, output, done for each command) with what is said
 * (each sentence's start and end), followed by findings you can act on.
 *
 * Usage:
 *   node sync-report.js <video-dir> [--scene s14] [--json] [--still 3] [--cache]
 *
 *   --scene s14   Only this scene (comma-separated for several).
 *   --json        Print the report as JSON instead of text.
 *   --still 3     Report stretches of at least this many seconds where the screen is still and
 *                 nobody is speaking (default 3).
 *   --cache       Save detected events to build/raw/<id>.events.json so the next run is instant.
 *
 * Reads storyboard.json, audio/timings.json, the tapes and build/raw/<id>.mp4. It shows what a
 * render of the storyboard as it is now would do, so anchors can be tried without rendering.
 * Writes nothing into the video directory unless --cache is passed.
 *
 * Findings:
 *   dead-air             the screen is still and nobody speaks
 *   starts-before-output a sentence begins before a command's output appears and is still speaking when it does
 *   output-unspoken      output appears and is replaced before any sentence starts
 *   untied               sentences with no wait_for / before in a scene with several commands, each with a suggestion
 *   not-recorded, not-aligned, anchor-error, detector   why a scene could not be fully checked
 *
 * Hidden setup left on screen after a Show is covered by the renderer; the timeline shows it as a
 * line ("N frames of hidden setup covered"), not as a finding.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const L = require('./lib');
const TE = require('./tape-events');

const HELP = `Report where narration and a terminal recording line up, and where they do not.

Usage:
  node sync-report.js <video-dir> [--scene s14] [--json] [--still 3] [--cache]

  --scene s14   Only this scene (comma-separated for several).
  --json        Print the report as JSON instead of text.
  --still 3     Flag stretches of at least this many seconds with a still screen and no speech (default 3).
  --cache       Save detected events to build/raw/<id>.events.json (the only thing this script can write).

For each terminal scene: a timeline of screen events (typed:N, enter:N, output:N, done:N) and
sentences, then findings: dead air, sentences that start before the output they describe, output
that is replaced before anyone speaks, and sentences not tied to the screen, with a suggested
"wait_for" / "before" for each. Times are seconds from the scene's start.
Needs the scene's recording (build/raw/<id>.mp4): run render-scenes.js first.`;

const WPM = 150;
const f2 = x => x.toFixed(2);
const excerpt = (text, n = 46) => (text.length > n ? `${text.slice(0, n - 1)}…` : text);
const firstLine = (text, n = 40) => excerpt(String(text).split('\n')[0], n);
// Screen order of an event: a parsed anchor ({ name: 'output', n }) or a report event ({ kind, n }).
const rank = a => (a.n - 1) * 4 + TE.EVENT_NAMES.indexOf(a.kind || a.name);

// Sentence clips for a scene: exact from tts.py when they match the narration, otherwise estimated.
function clipsFor(scene, timings, sb) {
  const have = timings && timings.scenes && timings.scenes[scene.id];
  const narration = scene.narration || [];
  if (have && have.length === narration.length && have.every((c, i) => c.text === narration[i])) return { clips: have, estimated: false };
  const speed = Number(scene.speed || (sb.voice && sb.voice.speed) || 1) || 1;
  return {
    estimated: true,
    clips: narration.map(text => ({ text, file: null, duration: (text.split(/\s+/).filter(Boolean).length / WPM) * 60 / speed })),
  };
}

// Union of [start, end] intervals, sorted.
function union(list) {
  const out = [];
  for (const [a, b] of [...list].sort((x, y) => x[0] - y[0])) {
    const last = out[out.length - 1];
    if (last && a <= last[1] + 1e-9) last[1] = Math.max(last[1], b); else out.push([a, b]);
  }
  return out;
}

async function sceneReport(scene, dir, sb, timings, rendered, opts) {
  const rep = { id: scene.id, tape: scene.visual, findings: [], suggestions: [], rows: [] };
  const find = (kind, at, message, extra = {}) => rep.findings.push({ kind, at: at == null ? null : Number(at.toFixed(2)), message, ...extra });
  const tapeFile = path.resolve(dir, scene.visual);
  const raw = path.join(dir, 'build', 'raw', `${scene.id}.mp4`);
  if (!fs.existsSync(tapeFile)) { find('not-recorded', null, `tape ${scene.visual} not found`); return rep; }
  const tapeText = fs.readFileSync(tapeFile, 'utf8');
  rep.commands = TE.visibleCommands(tapeText);
  const check = TE.validateAnchors(scene.narration_items, tapeText);
  check.errors.forEach(e => find('anchor-error', null, e));
  rep.tape_advice = check.warnings;
  if (!fs.existsSync(raw)) {
    find('not-recorded', null, `no recording yet (${path.relative(dir, raw)}): run render-scenes.js, then this report`);
    return rep;
  }
  const det = await TE.eventsFor(tapeText, raw, { write: opts.cache });
  rep.recording = det.duration;
  rep.detector_warnings = det.warnings || [];
  if (!det.aligned) {
    find('not-aligned', null, `the tape could not be lined up with its recording: ${(det.warnings || []).join('; ') || 'no reason given'}. Re-record the scene (render-scenes.js <dir> --only ${scene.id} --force)`);
    return rep;
  }
  const { clips, estimated } = clipsFor(scene, timings, sb);
  rep.estimated = estimated;
  let layout;
  try {
    // With anchor errors the anchors cannot be placed: lay the sentences out without them.
    const plain = check.errors.length ? { ...scene, narration_items: (scene.narration_items || []).map(i => ({ text: i.text, pause: i.pause })) } : scene;
    layout = TE.layoutNarration(plain, clips, sb.pacing, det, { frameAlign: L.frameAlign });
  } catch (e) {
    find('anchor-error', null, e.message);
    layout = TE.layoutNarration({ ...scene, narration_items: [] }, clips, sb.pacing, det, { frameAlign: L.frameAlign });
  }
  const fps = det.fps;
  const at = layout.at;
  const retimed = det.duration + layout.extra;
  const duration = L.frameAlign(Math.max(layout.length, retimed, 1 / L.VIDEO.fps));
  rep.retimed = retimed;
  rep.duration = duration;
  rep.holds = layout.holds.map(h => ({ at: at(h.frame) - h.seconds, seconds: h.seconds, for: h.for, sentence: h.sentence }));
  layout.warnings.forEach(w => rep.detector_warnings.push(w));

  // Events at their time in the finished clip.
  const events = Object.entries(det.events).map(([name, e]) => {
    const a = TE.parseAnchor(name);
    return { name, kind: a.name, n: a.n, t: at(e.frame), raw: e.t, confidence: e.confidence, doubts: e.doubts, notes: e.notes || [] };
  })
    .sort((a, b) => a.t - b.t || rank(a) - rank(b));
  rep.events = events.map(e => ({ name: e.name, t: Number(e.t.toFixed(3)), raw: e.raw, confidence: e.confidence, ...(e.doubts.length ? { doubts: e.doubts } : {}) }));
  const ev = name => events.find(e => e.name === name);
  const items = scene.narration_items || [];
  const sentences = layout.sentences.map((s, i) => ({ i, text: s.text, start: s.start, end: s.end, ...layout.notes[i], outcome: !!(items[i] && items[i].outcome) }));
  rep.sentences = sentences.map(s => ({ ...s, start: Number(s.start.toFixed(3)), end: Number(s.end.toFixed(3)) }));

  // Is the rendered video the one this report describes?
  if (rendered) {
    rep.scene_start = rendered.start;
    const same = Math.abs(rendered.duration - duration) < 0.02 && (rendered.sentences || []).length === sentences.length &&
      sentences.every((s, i) => Math.abs((rendered.sentences[i].start - rendered.start) - s.start) < 0.02);
    rep.rendered = same;
  } else rep.rendered = false;

  // ---- the timeline rows -----------------------------------------------------
  const rows = [];
  const cmdText = n => { const c = rep.commands.find(x => x.n === n); return c ? firstLine(c.text) : ''; };
  // Events of one command that share an instant go on one row.
  const groups = [];
  for (const e of events) {
    const last = groups[groups.length - 1];
    if (last && last.n === e.n && Math.abs(last.t - e.t) < 1e-6) last.names.push(e.name); else groups.push({ t: e.t, n: e.n, names: [e.name], first: e.name });
  }
  for (const g of groups) {
    const typed = g.names.some(n => n.startsWith('typed:'));
    const weak = g.names.map(n => ev(n)).filter(e => e.confidence !== 'high');
    rows.push({ t: g.t, order: 2, screen: `${g.names.join(' ')}${typed ? `  ${cmdText(g.n)}` : ''}${weak.length ? `  (${weak[0].confidence} confidence)` : ''}` });
  }
  for (const h of rep.holds) rows.push({ t: h.at, order: 1, screen: /^read /.test(h.for) ? `-- held ${f2(h.seconds)}s to ${h.for} (sentence ${h.sentence}) --` : `-- held ${f2(h.seconds)}s before ${h.for} (sentence ${h.sentence}) --` });
  for (const c of det.cuts || []) if (c.frame > 0) rows.push({ t: at(c.frame), order: 0, screen: c.typed ? '-- cut: a hidden block ran (the screen is usually cleared here) --' : c.jump ? '-- jump cut (Hide, Wait, Show) --' : '-- cut (Hide ... Show) --' });
  // Information, not a finding: the renderer already hides these frames.
  rep.covers = (det.covers || []).map(c => ({ t: at(c.from), line: c.line, frames: c.frames, seconds: c.seconds }));
  for (const c of rep.covers) rows.push({ t: c.t, order: 0, screen: `-- ${c.frames} frame${c.frames === 1 ? '' : 's'} (${f2(c.seconds)}s) of hidden setup covered --` });
  rep.tape_advice = [...rep.tape_advice, ...(det.advice || [])];
  for (const s of sentences) {
    const tags = [s.pause ? `pause ${s.pause}` : '', s.read ? `read ${s.read}` : '', s.wait_for ? `wait_for ${s.wait_for}${s.waited > 0.005 ? ` (waited ${f2(s.waited)}s)` : ''}` : '',
      s.before ? `before ${s.before}${s.held ? ` (held ${f2(s.held)}s)` : ''}` : '', s.outcome ? 'outcome' : ''].filter(Boolean).join(', ');
    rows.push({ t: s.start, order: 3, say: `${s.i}  ${f2(s.start)}-${f2(s.end)}  "${excerpt(s.text)}"${tags ? `  [${tags}]` : ''}` });
  }
  rows.push({ t: retimed, order: 4, screen: '-- recording ends (last frame stays) --' });
  rows.sort((a, b) => a.t - b.t || a.order - b.order);
  rep.rows = rows.map(r => ({ t: Number(r.t.toFixed(2)), ...(r.screen ? { screen: r.screen } : {}), ...(r.say ? { say: r.say } : {}) }));

  // ---- findings --------------------------------------------------------------
  const realOutput = n => { const o = ev(`output:${n}`); return o && !o.notes.some(x => /little or no visible output/.test(x)); };
  const isClear = n => { const c = rep.commands.find(x => x.n === n); return c && /^\s*clear\s*$/.test(c.text); };

  // 1. Still screen, nobody speaking.
  const rawTimeOf = t => { // clip time -> raw time (inside a hold: the held frame)
    let shift = 0;
    for (const h of layout.holds) {
      const start = h.frame / fps + shift;
      if (t >= start + h.seconds) shift += h.seconds; else if (t > start) return h.frame / fps;
    }
    return t - shift;
  };
  const moving = [];
  for (const [a, b] of det.activity || []) {
    // A stretch of screen movement may straddle a hold: split it there.
    let start = a;
    for (const h of layout.holds) {
      const cutAt = h.frame / fps;
      if (cutAt > start && cutAt < b) { moving.push([at(Math.round(start * fps)), at(h.frame - 1) + 1 / fps]); start = cutAt; }
    }
    moving.push([at(Math.round(start * fps)), at(Math.round(b * fps) - 1) + 1 / fps]);
  }
  // Reading time is not dead air: the quiet a sentence asked for with "read", and the default
  // hold the renderer gives output before a hidden clear takes it away.
  const quiet = s => Math.max(Number(s.read) || 0, s.read_hold ? (TE.READ_HOLD || 0) : 0);
  const busy = union([...moving, ...sentences.map(s => [s.start, s.end + quiet(s)])]);
  let cursor = 0;
  const gaps = [];
  for (const [a, b] of [...busy, [duration, duration]]) { if (a - cursor >= opts.still) gaps.push([cursor, Math.min(a, duration)]); cursor = Math.max(cursor, b); }
  for (const [g0, g1] of gaps) {
    if (g1 - g0 < opts.still) continue;
    const r0 = rawTimeOf(g0), r1 = rawTimeOf(g1);
    const sleeps = (det.sleeps || []).filter(s => Math.min(s.end, r1) - Math.max(s.start, r0) >= 0.5);
    // The end of a scene is reading time for the final output (the tape ends with Sleep 4s or
    // more on purpose): only a long silent tail is worth a finding, and the fix is different.
    if (g1 >= duration - 0.05 && !sentences.some(x => x.start >= g0)) {
      if (g1 - g0 < Math.max(opts.still, 5)) continue;
      find('dead-air', g0, `${f2(g0)}-${f2(g1)} (${f2(g1 - g0)}s): the scene ends on a still screen with nobody speaking. Some of that is reading time for the final output; ` +
        (sleeps.length ? `if it is too long, shorten the final Sleep (tape line ${sleeps[sleeps.length - 1].line}, ${sleeps[sleeps.length - 1].seconds}s), keeping about 4s after the last output, ` : 'if it is too long, lower hold_after or min_duration, ') +
        'or have a sentence talk about what is on screen.', { seconds: Number((g1 - g0).toFixed(2)), tape_lines: sleeps.map(x => x.line), tail: true });
      continue;
    }
    const next = sentences.find(s => s.start >= g1 - 0.05);
    const causes = [];
    if (sleeps.length) causes.push(`${sleeps.map(s => `tape line ${s.line} (Sleep ${s.seconds}s${s.running ? ', while the command runs' : ''})`).join(' and ')} sits here`);
    if (g1 > retimed + 0.5) causes.push(next ? 'the recording has ended and the next sentence has not started' : 'the recording and the narration have both ended (hold_after or min_duration)');
    const waitsFor = next && next.wait_for && next.waited > 0.5 ? ` Sentence ${next.i} is waiting for ${next.wait_for}; if the command is slow, jump-cut the wait (Hide, Wait, Show) or say something while it runs.` : '';
    const fix = sleeps.length && !waitsFor ? ' Shorten that Sleep to about 1s; "wait_for" and "before" keep the sentences in step without it.' : '';
    find('dead-air', g0, `${f2(g0)}-${f2(g1)} (${f2(g1 - g0)}s): the screen is still and nobody is speaking${causes.length ? `; ${causes.join('; ')}` : ''}.${fix}${waitsFor}`, { seconds: Number((g1 - g0).toFixed(2)), tape_lines: sleeps.map(s => s.line) });
  }

  // 2. A sentence that begins before a command's output appears and is still speaking when it does.
  const flaggedOutputs = new Set();
  for (const c of rep.commands) {
    const o = ev(`output:${c.n}`);
    if (!o || !realOutput(c.n)) continue;
    const s = sentences.find(x => x.start < o.t - 0.3 && x.end > o.t + 0.5 && !(x.wait_for && rank(TE.parseAnchor(x.wait_for)) >= rank(o)));
    if (!s) continue;
    // Typing still being explained (the sentence must end before this command's Enter) is not this problem.
    if (s.before && rank(TE.parseAnchor(s.before)) <= rank(o)) continue;
    flaggedOutputs.add(c.n);
    find('starts-before-output', s.start, `sentence ${s.i} ("${excerpt(s.text, 40)}") starts at ${f2(s.start)}, ${f2(o.t - s.start)}s before the output of command ${c.n} appears (${f2(o.t)}), and is still speaking when it does. ` +
      `If it describes that output, add "wait_for": "output:${c.n}"${s.outcome ? ' (it is marked "outcome", so it does depend on what the demo printed)' : ''}.`, { sentence: s.i, event: `output:${c.n}` });
  }

  // 3. Output that is replaced before any sentence starts.
  for (const c of rep.commands) {
    const o = ev(`output:${c.n}`);
    if (!o || !realOutput(c.n) || flaggedOutputs.has(c.n) || isClear(c.n)) continue;
    // When is this output no longer the newest thing on screen?
    const enders = [];
    for (const d of rep.commands.filter(x => x.n > c.n)) {
      if (isClear(d.n)) { const e = ev(`enter:${d.n}`); if (e) enders.push({ t: e.t, why: `is cleared by command ${d.n}` }); break; }
      const o2 = ev(`output:${d.n}`);
      if (o2 && realOutput(d.n)) { enders.push({ t: o2.t, why: `is pushed up by the output of command ${d.n}` }); break; }
    }
    for (const cut of det.cuts || []) { const t = at(cut.frame); if (cut.frame > 0 && t > o.t + 1e-6) { enders.push({ t, why: 'is replaced at a cut' }); break; } }
    enders.push({ t: duration, why: 'stays until the scene ends' });
    enders.sort((a, b) => a.t - b.t);
    const end = enders[0];
    const spoken = sentences.some(s => s.start >= o.t - 0.5 && s.start < end.t) || sentences.some(s => s.start < o.t && s.end > o.t + 0.5);
    if (spoken) continue;
    find('output-unspoken', o.t, `the output of command ${c.n} (\`${firstLine(c.text, 36)}\`) appears at ${f2(o.t)} and ${end.why} at ${f2(end.t)} (${f2(end.t - o.t)}s on screen), and no sentence starts in that time. ` +
      `Tie the sentence about it to "wait_for": "output:${c.n}", or keep the next command back with "before": "typed:${c.n + 1}".`, { event: `output:${c.n}`, seconds: Number((end.t - o.t).toFixed(2)) });
  }

  // 4. Sentences tied to nothing, with the nearest event for each.
  const untied = sentences.filter(s => !s.wait_for && !s.before);
  if (rep.commands.length >= 2 && untied.length) {
    let lastAny = -1, lastWait = -1;
    for (const s of sentences) {
      const sug = { sentence: s.i, text: excerpt(s.text, 40) };
      const w0 = s.wait_for ? TE.parseAnchor(s.wait_for) : null;
      const b0 = s.before ? TE.parseAnchor(s.before) : null;
      if (!w0) {
        // The newest thing on screen when the sentence starts (or within 0.75 s after).
        const seen = events.filter(e => e.t <= s.start + 0.75 && s.start - e.t <= 6);
        const e = seen[seen.length - 1];
        if (e) {
          const name = e.name.startsWith('typed') ? e.name : e.name.startsWith('enter') && ev(`output:${e.n}`).t - e.t > 0.2 ? e.name : `output:${e.n}`;
          const a = TE.parseAnchor(name);
          if (rank(a) >= lastAny && (!b0 || rank(a) < rank(b0))) { sug.wait_for = name; sug.wait_why = `${name} is on screen at ${f2(ev(name).t)}; the sentence starts at ${f2(s.start)}`; }
        }
      }
      const w = w0 || (sug.wait_for ? TE.parseAnchor(sug.wait_for) : null);
      if (w) { lastWait = Math.max(lastWait, rank(w)); lastAny = Math.max(lastAny, rank(w)); }
      if (!b0) {
        // The next typing or Enter that happens once the sentence is under way, if it comes soon after.
        const e = events.find(x => (x.name.startsWith('typed') || x.name.startsWith('enter')) && x.t >= s.start + 0.3 && x.t <= s.end + 4 &&
          rank(x) > lastWait && rank(x) >= lastAny && !(x.name.startsWith('enter') && ev(`typed:${x.n}`).t >= s.start + 0.3));
        if (e) { sug.before = e.name; sug.before_why = `${e.name} happens at ${f2(e.t)}; the sentence ends at ${f2(s.end)}`; }
      }
      const b = b0 || (sug.before ? TE.parseAnchor(sug.before) : null);
      if (b) lastAny = Math.max(lastAny, rank(b));
      if (sug.wait_for || sug.before) rep.suggestions.push(sug);
    }
    find('untied', null, `${untied.length} of ${sentences.length} sentences are not tied to the screen in a scene with ${rep.commands.length} commands (sentences ${untied.map(s => s.i).join(', ')}). ` +
      'Their timing depends on Sleep lengths in the tape; see the suggested anchors.', { sentences: untied.map(s => s.i) });
  }

  // 5. What the detector could not be sure of, when an anchor could use it.
  for (const w of det.uncovered || []) find('detector', null, w);
  for (const e of events.filter(x => x.confidence !== 'high')) find('detector', e.t, `${e.name} is a ${e.confidence}-confidence time: ${e.doubts.join('; ')}`);
  return rep;
}

function printText(report) {
  const out = [];
  out.push(`${report.title}: ${report.scenes.length} terminal scene${report.scenes.length === 1 ? '' : 's'}${report.estimated ? ' (sentence lengths are ESTIMATES: run tts.py for exact times)' : ''}`);
  for (const s of report.scenes) {
    out.push('');
    const head = [`${s.id}  ${s.tape}`];
    if (s.recording != null) head.push(`recording ${f2(s.recording)}s`);
    if (s.duration != null) head.push(`scene ${f2(s.duration)}s${s.holds && s.holds.length ? ` (${s.holds.length} hold${s.holds.length > 1 ? 's' : ''} add ${f2(s.retimed - s.recording)}s)` : ''}`);
    if (s.commands) head.push(`${s.commands.length} command${s.commands.length === 1 ? '' : 's'}`);
    if (s.scene_start != null) head.push(`starts at ${L.fmtChapterTime(s.scene_start)} in the video`);
    out.push(head.join(' | '));
    if (s.duration != null && !s.rendered) out.push('  (not what is rendered now: this is what the next render-scenes.js run will produce)');
    if (s.rows.length) {
      out.push(`  ${'time'.padStart(6)}  ${'screen'.padEnd(52)}narration`);
      for (const r of s.rows) out.push(`  ${f2(r.t).padStart(6)}  ${(r.screen || '').padEnd(52)}${r.say || ''}`.trimEnd());
    }
    const shown = s.findings;
    if (shown.length) {
      out.push('  Findings');
      shown.forEach((x, i) => out.push(`  ${String(i + 1).padStart(2)}. [${x.kind}] ${x.message}`));
    } else if (s.duration != null) out.push('  No findings.');
    if (s.suggestions.length) {
      out.push('  Suggested anchors (add to the narration items; check each against what the sentence says)');
      for (const g of s.suggestions) {
        const parts = [g.wait_for ? `"wait_for": "${g.wait_for}"` : '', g.before ? `"before": "${g.before}"` : ''].filter(Boolean).join(', ');
        const why = [g.wait_why, g.before_why].filter(Boolean).join('; ');
        out.push(`    sentence ${g.sentence} "${g.text}": ${parts}   (${why})`);
      }
    }
    if (s.tape_advice && s.tape_advice.length) { out.push('  Tape advice'); s.tape_advice.forEach(w => out.push(`    - ${w}`)); }
  }
  out.push('');
  const kinds = Object.entries(report.summary.findings).map(([k, n]) => `${n} ${k}`).join(', ');
  out.push(`Summary: ${kinds || 'no findings'}.`);
  console.log(out.join('\n'));
}

async function main() {
  const argv = process.argv.slice(2);
  if (argv.includes('--help') || argv.includes('-h')) { console.log(HELP); return; }
  const args = L.parseArgs(argv, ['json', 'cache']);
  if (!args._[0]) { console.error(HELP); L.die('pass the video directory (the folder holding storyboard.json)'); }
  if (!fs.existsSync(args._[0])) L.die(`${args._[0]} not found: pass the video directory (the folder holding storyboard.json)`);
  const still = args.still === undefined ? 3 : Number(args.still);
  if (!(still > 0)) L.die('--still takes a number of seconds greater than 0 (default 3)');
  const { sb, dir } = L.loadStoryboard(args._[0]);
  const only = args.scene ? new Set(String(args.scene).split(',')) : null;
  const scenes = (sb.scenes || []).filter(s => s.renderer === 'terminal' && (!only || only.has(s.id)));
  if (only) for (const id of only) if (!scenes.some(s => s.id === id)) L.die(`--scene ${id}: no terminal scene with that id (terminal scenes: ${(sb.scenes || []).filter(s => s.renderer === 'terminal').map(s => s.id).join(', ') || 'none'})`);
  const timingsFile = path.join(dir, 'audio', 'timings.json');
  const timings = fs.existsSync(timingsFile) ? L.readJSON(timingsFile) : null;
  const tlFile = path.join(dir, 'build', 'timeline.json');
  const timeline = fs.existsSync(tlFile) ? L.readJSON(tlFile) : null;

  const report = { title: sb.title, slug: sb.slug, dir, estimated: false, scenes: [], summary: { findings: {} } };
  for (const scene of scenes) {
    if (!args.json) process.stderr.write(`  ${scene.id}...\r`);
    const rendered = timeline ? (timeline.scenes || []).find(s => s.id === scene.id) : null;
    const rep = await sceneReport(scene, dir, sb, timings, rendered, { still, cache: !!args.cache });
    if (rep.estimated) report.estimated = true;
    for (const x of rep.findings) report.summary.findings[x.kind] = (report.summary.findings[x.kind] || 0) + 1;
    report.scenes.push(rep);
  }
  if (args.json) console.log(JSON.stringify(report, null, 2)); else printText(report);
}

main().catch(e => { console.error(`error: ${e.message}`); process.exit(1); });
