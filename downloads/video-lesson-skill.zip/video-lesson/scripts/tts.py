#!/usr/bin/env python3
"""Narration for video-lesson: Kokoro via mlx-audio, one sentence per clip.

Run with the skill's venv interpreter: ~/.video-lesson/venv/bin/python scripts/tts.py ...

  tts.py <video-dir> [--only s01,s03] [--force] [--words]
      Synthesize every narration sentence in storyboard.json.
      Writes <video-dir>/audio/<scene>_<nn>.wav and <video-dir>/audio/timings.json.
      Newly synthesized clips also get per-word times ("words" in timings.json); --words
      computes them for clips that were cached before word times existed.

  tts.py --analyze <video-dir> [--json] [--all] [--include word,word]
  tts.py --analyze --say "text" [--video <video-dir>] [--json]      (one sentence per line)
      Pronunciation analysis without synthesizing anything (no model weights are loaded and
      nothing is written). For every word: where its pronunciation comes from (lexicon,
      dictionary, or the fallback speller), its phonemes, and for words with two
      pronunciations which one the voice will use. Ends with one "doubtful" list of words to
      audition. Words approved in <video-dir>/../pronunciation-ledger.json are left out
      unless --all. --include forces words onto the list (jargon, preference words).

  tts.py --transcribe <video-dir> [--out DIR] [--only s01,s03]
      Speech-to-text over the synthesized clips, compared word by word with the script.
      Writes <video-dir>/audio/transcript.json (or DIR/transcript.json). Catches dropped,
      garbled and unknown words. It cannot catch a word said in the wrong tense ("read") or
      a real word said in a valid but unwanted way. Needs `setup.js --yes --stt` once.

  tts.py --say "text" --video <video-dir> [--voices af_heart,bm_george] [--speed 1.2]
         [--out DIR] [--lexicon FILE] [--no-lexicon] [--play]
      Audition text (a word, a sentence, a lexicon fix). With --video it uses exactly the
      lexicons, voice and speed that video will use, and writes to <video-dir>/auditions/.
      Without --video only the global lexicon (plus --lexicon) applies.

  tts.py --say-batch requests.json --out DIR
      Many auditions in one process (used by pronunciation-review.js). requests.json is a
      list of {"id", "text", "video"?, "override"?: {word: value|null}, "focus"?: word,
      "voice"?, "speed"?}. "override" changes lexicon entries for that request only
      (null = say the word as written).

  tts.py --samples [--video <video-dir>] [--say "text"] [--speed 1.2] [--british] [--out DIR] [--open]
      Render every American voice (plus British with --british) saying the same line and
      write a playable index.html. With --video: uses a real sentence from that video, its
      speed and lexicons, marks its current voice, and writes to <video-dir>/auditions/voices/.

  tts.py --fetch-stt | --stt-status
      Download the speech-to-text model into ~/.video-lesson/models/ (setup.js --stt runs
      this), or report whether it is there.

  tts.py --selftest
      Used by setup.js. Synthesizes a test line and checks the lexicon and phoneme overrides.

Pronunciation lexicons (JSON, word -> respelling or "/phonemes/") are merged in
this order, later wins: <skill>/assets/pronunciations.json, <video-dir>/../pronunciations.json,
<video-dir>/pronunciations.json, and any file named by storyboard "pronunciations".
Keys match whole words and ignore case; when two keys differ only by case the one that
matches the text exactly wins; a key written "=IT" matches that exact case only.
They change only the text sent to the TTS model, never captions.
"""
import argparse
import difflib
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
import time
import wave
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parent
SKILL_DIR = SCRIPTS_DIR.parent
# Machine-local state lives outside the skill (same layout as scripts/lib.js).
STATE_DIR = Path(os.environ.get("VIDEO_LESSON_HOME") or Path.home() / ".video-lesson")
CACHE_DIR = STATE_DIR / "tts-cache"
MODELS_DIR = STATE_DIR / "models"
DEFAULT_VOICE = {"model": "mlx-community/Kokoro-82M-bf16", "voice": "am_echo", "speed": 1.2}
STT = json.loads((SCRIPTS_DIR / "stt-model.json").read_text())  # {"repo", "dir", ...}; shared with setup.js
LEDGER_NAME = "pronunciation-ledger.json"


def load_storyboard(video_dir):
    """Read storyboard.json the way scripts/lib.js does: narration items may be strings or
    {"text": ...} objects (scene["narration"] becomes the texts), and the voice falls back to
    <video-dir>/../preferences.json, then to DEFAULT_VOICE."""
    sb = json.loads((video_dir / "storyboard.json").read_text())
    prefs_file = video_dir.parent / "preferences.json"
    prefs = json.loads(prefs_file.read_text()) if prefs_file.is_file() else {}
    sb["voice"] = {**DEFAULT_VOICE, **prefs.get("voice", {}), **sb.get("voice", {})}
    for scene in sb.get("scenes", []):
        items = [{"text": n} if isinstance(n, str) else dict(n) for n in scene.get("narration", [])]
        scene["narration_items"] = items
        scene["narration"] = [i["text"] for i in items]
    return sb
VOICES = {
    "male": ["am_echo", "am_michael", "am_fenrir", "am_puck", "am_adam", "am_eric", "am_liam", "am_onyx", "am_santa"],
    "female": ["af_heart", "af_bella", "af_nicole", "af_aoede", "af_kore", "af_sarah", "af_nova", "af_alloy",
               "af_sky", "af_jessica", "af_river"],
    "british": ["bm_george", "bm_daniel", "bm_fable", "bm_lewis", "bf_emma", "bf_alice", "bf_isabella", "bf_lily"],
}
SAMPLE_TEXT = "Every eval starts with a stimulus: a prompt, plus the checks that grade it. So what happens when the grader says no?"

# misaki's phoneme alphabet (see NARRATION.md). Used to warn about typos in overrides.
SHARED = set("ˈˌbdfhjklmnpstvwzɡŋɹʃʒðθʤʧəiuɑɔɛɜɪʊʌAIWYᵊ ")
US_ONLY = set("æOᵻɾ")
GB_ONLY = set("aQɒː")

_model = None
OUT = sys.stdout  # results only; libraries chatter on stdout, so main() points sys.stdout at stderr


def log(*a):
    print(*a, file=sys.stderr)


def emit(obj):
    print(json.dumps(obj, indent=2, ensure_ascii=False), file=OUT)


# ---------------------------------------------------------------- lexicon ---

def _wordch(c):
    return c.isascii() and (c.isalnum() or c == "_")


def is_phonemes(val):
    return isinstance(val, str) and len(val) > 2 and val.startswith("/") and val.endswith("/")


class Lexicon:
    """Merged pronunciation entries.

    Matching rules (apply()):
    - whole words only, longest key first, one pass;
    - case does not matter ("YAML" also covers "yaml" and "Yaml");
    - when two keys differ only by case, the key that equals the text exactly wins;
    - a key written with a leading "=" ("=IT") matches that exact case only;
    - a key that starts with punctuation (".jsonl") also matches glued to the word before it
      ("results.jsonl") and is spoken as its own word.
    Merging rules (add()): a later file replaces an earlier file's entry for the same word
    whatever its case; a value of null or "" removes the earlier entry (say it as written).
    """

    def __init__(self):
        self.entries = []  # {"key", "word", "exact", "value", "file"}
        self.files = []
        self._compiled = None

    def __bool__(self):
        return bool(self.entries)

    def add(self, data, source):
        new = []
        for key, value in data.items():
            if key.startswith("_"):
                continue
            exact = key.startswith("=") and len(key) > 1
            new.append({"key": key, "word": key[1:] if exact else key, "exact": exact, "value": value, "file": str(source)})
        for e in new:
            fold = e["word"].lower()
            if e["exact"]:
                drop = lambda old: old["word"] == e["word"]  # noqa: E731
            else:
                drop = lambda old: old["word"].lower() == fold and (not old["exact"] or old["word"] == e["word"])  # noqa: E731
            self.entries = [old for old in self.entries if not drop(old)]
        self.entries += [e for e in new if e["value"] not in (None, "")]
        self.files.append(str(source))
        self._compiled = None
        return self

    def with_override(self, data, source="(audition)"):
        other = Lexicon()
        other.entries = list(self.entries)
        other.files = list(self.files)
        return other.add(data, source)

    def keys(self):
        return [e["key"] for e in self.entries]

    def _compile(self):
        if self._compiled is None:
            by_fold = {}
            for e in self.entries:
                by_fold.setdefault(e["word"].lower(), []).append(e)
            order = sorted(self.entries, key=lambda e: (-len(e["word"]), not e["exact"]))
            pieces = []
            for e in order:
                body = re.escape(e["word"])
                if e["exact"]:
                    body = f"(?-i:{body})"
                lead = r"(?<![A-Za-z0-9_])" if _wordch(e["word"][0]) else ""
                pieces.append(f"{lead}{body}(?![A-Za-z0-9_])")
            pattern = re.compile("|".join(pieces), re.IGNORECASE) if pieces else None
            self._compiled = (pattern, by_fold)
        return self._compiled

    def pick(self, text):
        """The entry that applies to this exact text, or None."""
        _, by_fold = self._compile()
        cands = by_fold.get(text.lower(), [])
        same = [e for e in cands if e["word"] == text]
        if same:
            return sorted(same, key=lambda e: not e["exact"])[0]
        loose = [e for e in cands if not e["exact"]]
        return loose[-1] if loose else None

    def apply(self, text, british=False, spans=None):
        """Return the text to send to the TTS model. If `spans` is a list, one record per
        replacement is appended: start/end in `text`, plain_start/plain_end in the result with
        [word](/phonemes/) links collapsed to the word (what misaki tokenizes), plus the entry."""
        pattern, _ = self._compile()
        if pattern is None:
            return text
        out, pos, plain_len = [], 0, 0
        stripped_end = len(text.rstrip())
        for m in pattern.finditer(text):
            word = m.group(0)
            entry = self.pick(word)
            if entry is None:
                continue
            val = entry["value"]
            if isinstance(val, dict):  # {"us": "/../", "gb": "/../"}
                val = val.get("gb" if british else "us") or next(iter(val.values()))
            before = text[pos:m.start()]
            # ".jsonl" in "results.jsonl": speak the key as its own word.
            if not _wordch(word[0]) and m.start() > 0 and _wordch(text[m.start() - 1]):
                before += " "
            # A key like "etc." at the end of a sentence also carries the full stop; keep one.
            end = "." if word.endswith(".") and m.end() >= stripped_end else ""
            if is_phonemes(val):
                check_phonemes(word, val[1:-1], british)
                piece, plain = f"[{word}]({val}){end}", word + end
            else:
                # "repo" matched "Repo" at the start of a sentence: keep the capital.
                if entry["word"].islower() and word[:1].isupper() and (len(word) == 1 or word[1:].islower()) and val[:1].islower():
                    val = val[:1].upper() + val[1:]
                piece = plain = val + end
            out.append(before)
            plain_len += len(before)
            if spans is not None:
                spans.append({"start": m.start(), "end": m.end(), "plain_start": plain_len, "plain_end": plain_len + len(plain),
                              "match": word, "key": entry["key"], "value": entry["value"], "file": entry["file"],
                              "phonemes": is_phonemes(val)})
            out.append(piece)
            plain_len += len(plain)
            pos = m.end()
        out.append(text[pos:])
        return "".join(out)


def load_lexicon(video_dir=None, extra=None, use=True):
    files = [SKILL_DIR / "assets" / "pronunciations.json"]
    if video_dir:
        files += [video_dir.parent / "pronunciations.json", video_dir / "pronunciations.json"]
    if extra:
        files.append(Path(extra))
    lex = Lexicon()
    if not use:
        return lex, []
    for f in files:
        if f.is_file():
            lex.add(json.loads(f.read_text()), f)
    return lex, list(lex.files)


def check_phonemes(word, ph, british):
    allowed = SHARED | (GB_ONLY if british else US_ONLY)
    bad = sorted({c for c in ph if c not in allowed})
    if bad:
        log(f"warning: lexicon entry {word!r} uses symbols {bad} outside misaki's "
            f"{'GB' if british else 'US'} set; they may be dropped")


def apply_lexicon(text, lex, british=False, spans=None):
    """Whole-word, case-insensitive (exact case wins), single pass, longest key first."""
    if not lex:
        return text
    if isinstance(lex, dict):
        lex = Lexicon().add(lex, "(dict)")
    return lex.apply(text, british, spans)


# ----------------------------------------------- words <-> tokens mapping ---

_LINK = re.compile(r"\[([^\]]+)\]\(([^\)]*)\)")


def plain_text(tts_text):
    """The text misaki tokenizes: [word](/phonemes/) links collapsed to the word."""
    return _LINK.sub(lambda m: m.group(1), tts_text)


def group_units(original, tts_text, spans, token_texts):
    """Line misaki's tokens up with the words of the original sentence.

    Returns a list of units {"tokens": [indexes], "span": span-or-None, "word": original text}.
    A lexicon replacement that became several tokens ("N P M") is one unit, so every unit
    stands for one word as the script (and the captions) spell it."""
    plain = plain_text(tts_text)
    # If the script itself contains [text](...) markup the offsets no longer line up; then
    # every token simply stands for itself.
    mapped = all(s["plain_end"] <= len(plain) for s in spans)

    def to_orig(p, side):
        shift = 0  # (offset in the spoken text) - (offset in the script), after the last replacement passed
        for s in spans:
            if p < s["plain_start"] or (p == s["plain_start"] and side == "end"):
                break
            if p < s["plain_end"] or (p == s["plain_end"] and side == "end"):
                return s["start"] if side == "start" else s["end"]
            shift = s["plain_end"] - s["end"]
        return max(0, p - shift)

    units, cursor = [], 0
    for idx, text in enumerate(token_texts):
        at = plain.find(text, cursor) if text else -1
        if at < 0:
            at = cursor
        start, end = at, at + len(text)
        cursor = end
        hit = next((s for s in spans if s["plain_start"] < end and s["plain_end"] > start), None) if mapped else None
        if hit is not None and units and units[-1]["span"] is hit:
            units[-1]["tokens"].append(idx)
            units[-1]["plain_end"] = end
        else:
            units.append({"tokens": [idx], "span": hit, "plain_start": start, "plain_end": end})
    for u in units:
        if mapped:
            a, b = to_orig(u["plain_start"], "start"), to_orig(u["plain_end"], "end")
            u["word"] = original[a:b] if b > a else plain[u["plain_start"]:u["plain_end"]]
            u["orig_start"], u["orig_end"] = a, b
        else:
            u["word"] = plain[u["plain_start"]:u["plain_end"]]
            u["orig_start"], u["orig_end"] = u["plain_start"], u["plain_end"]
    return units


# ------------------------------------------------------------- synthesis ---

_token_sink = []  # one list of (text, start, end) per synthesized chunk, filled by the hook below


def _capture_token_times():
    """Kokoro's pipeline computes a start and end time for every token but model.generate()
    drops them. Wrap the step that computes them so synthesize() can keep them; the audio
    path is untouched. If mlx-audio changes this internal, word times are simply absent."""
    try:
        from mlx_audio.tts.models.kokoro.pipeline import KokoroPipeline
        if getattr(KokoroPipeline, "_vl_capture", False):
            return
        inner = KokoroPipeline.__dict__["join_timestamps"].__func__

        def join_timestamps(cls, tokens, pred_dur):
            inner(cls, tokens, pred_dur)
            _token_sink.append([(t.text, t.start_ts, t.end_ts) for t in tokens])

        KokoroPipeline.join_timestamps = classmethod(join_timestamps)
        KokoroPipeline._vl_capture = True
    except Exception as e:  # noqa: BLE001
        log(f"note: per-word times unavailable ({e})")


def get_model(model_id):
    global _model
    if _model is None or _model[0] != model_id:
        from mlx_audio.tts.utils import load_model  # imported lazily: slow
        log(f"loading {model_id} (first run downloads weights to ~/.cache/huggingface)")
        _model = (model_id, load_model(model_id))
        _capture_token_times()
    return _model[1]


def synthesize(text, voice, speed, model_id):
    """Return (samples, sample_rate, tokens). tokens is [[text, start, end], ...] in seconds
    for the text as sent to the model, or None when the model does not report them."""
    import numpy as np
    model = get_model(model_id)
    lang = voice[0] if voice[:1] in ("a", "b") else "a"  # Kokoro: a=US, b=GB. Never the "en" default.
    chunks, rate = [], None
    _token_sink.clear()
    for result in model.generate(text=text, voice=voice, speed=speed, lang_code=lang):
        chunks.append(np.asarray(result.audio, dtype=np.float32).reshape(-1))
        rate = rate or getattr(result, "sample_rate", None)
    if not chunks:
        raise RuntimeError(f"no audio produced for: {text!r}")
    rate = rate or getattr(model, "sample_rate", None) or 24000
    tokens = None
    if len(_token_sink) == len(chunks):
        tokens, offset = [], 0.0
        for chunk, toks in zip(chunks, _token_sink):
            for t, start, end in toks:
                if start is not None and end is not None:
                    tokens.append([t, round(offset + float(start), 3), round(offset + float(end), 3)])
            offset += len(chunk) / rate
    return np.concatenate(chunks), int(rate), tokens


def write_wav(path, samples, rate):
    import numpy as np
    pcm = (np.clip(samples, -1.0, 1.0) * 32767).astype("<i2")
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm.tobytes())


def rms(samples):
    import numpy as np
    return float(np.sqrt(np.mean(np.square(samples)))) if len(samples) else 0.0


def cached_clip(tts_text, voice, speed, model_id, force=False, want_tokens=False):
    """Synthesize through a content-addressed cache. Returns (path, duration).
    Token times are kept next to the clip as <key>.words.json (see clip_tokens)."""
    key = hashlib.sha1(f"{model_id}|{voice}|{speed}|{tts_text}".encode()).hexdigest()[:16]
    path = CACHE_DIR / f"{key}.wav"
    side = path.with_suffix(".words.json")
    dur = 0.0 if force else wav_seconds(path)
    if dur <= 0:  # miss, forced, or a truncated file from an interrupted run
        samples, rate, tokens = synthesize(tts_text, voice, speed, model_id)
        level = rms(samples)
        if level < 1e-3 or not math.isfinite(level):
            raise RuntimeError(f"silent or invalid audio (rms={level:.5f}) for: {tts_text!r}")
        tmp = path.with_suffix(".tmp")
        write_wav(tmp, samples, rate)
        os.replace(tmp, path)  # atomic: the cache never holds a half-written clip
        dur = wav_seconds(path)
        if tokens:
            side.write_text(json.dumps({"duration": round(dur, 4), "tokens": tokens}, ensure_ascii=False))
        elif side.exists():
            side.unlink()
    elif want_tokens and not side.exists():
        # A clip cached before word times existed: run the model again for its token times
        # and keep them only if it produced the same clip (the cached audio is not replaced).
        samples, rate, tokens = synthesize(tts_text, voice, speed, model_id)
        if tokens and abs(len(samples) / rate - dur) < 0.02:
            side.write_text(json.dumps({"duration": round(dur, 4), "tokens": tokens}, ensure_ascii=False))
    return path, dur


def clip_tokens(path):
    side = Path(path).with_suffix(".words.json")
    try:
        return json.loads(side.read_text())["tokens"]
    except (FileNotFoundError, ValueError, KeyError):
        return None


def word_times(sentence, tts_text, spans, tokens):
    """[{w, start, end}] for the words of the original sentence, from the model's token times."""
    if not tokens:
        return None
    units = group_units(sentence, tts_text, spans, [t[0] for t in tokens])
    words = []
    for u in units:
        if not re.search(r"[A-Za-z0-9]", u["word"]):
            continue
        words.append({"w": u["word"], "start": tokens[u["tokens"][0]][1], "end": tokens[u["tokens"][-1]][2]})
    return words


def wav_seconds(path):
    try:
        with wave.open(str(path)) as w:
            return w.getnframes() / w.getframerate()
    except (FileNotFoundError, wave.Error, EOFError, ZeroDivisionError):
        return 0.0


# -------------------------------------------------------------- analysis ---

VOWELS = set("AIOQWYaiuæɑɒɔəɛɜɪʊʌᵻᵊɐ")
_RESPELL = {
    "A": "ay", "I": "igh", "O": "oh", "W": "ow", "Y": "oy", "Q": "oh", "i": "ee", "u": "oo", "æ": "a", "a": "a",
    "ɑ": "ah", "ɒ": "o", "ɔ": "aw", "ə": "uh", "ɐ": "uh", "ɛ": "eh", "ɜ": "ur", "ɪ": "ih", "ʊ": "uu", "ʌ": "uh",
    "ᵊ": "uh", "ᵻ": "ih", "ɹ": "r", "ʃ": "sh", "ʒ": "zh", "ð": "th", "θ": "th", "ʤ": "j", "ʧ": "ch", "ŋ": "ng",
    "ɡ": "g", "j": "y", "T": "d", "ɾ": "d", "ʔ": "t", "ː": "",
}
PUNCT_STRIP = " \t\n\"'“”‘’.,;:!?()[]{}<>—–-…*`"
TAG_MEANING = {"VBD": "past tense", "VBN": "past participle", "VBP": "present tense", "VERB": "a verb", "NOUN": "a noun",
               "ADJ": "an adjective", "ADV": "an adverb", "DT": "a determiner"}
# Rhyme hints for common words whose two pronunciations differ in a vowel or a final consonant,
# keyed by a tag that selects the variant. Everything else gets a mechanical respelling.
HETERONYM_HINTS = {
    "read": {"DEFAULT": ("reed", "present or base form: 'to read', 'please read', 'will read'"),
             "VBD": ("red", "past: 'she read it yesterday', 'has been read'")},
    "reread": {"DEFAULT": ("ree-REED", "present or base form"), "VBD": ("ree-RED", "past"), "NOUN": ("REE-reed", "a noun")},
    "live": {"VERB": ("liv, rhymes with give", "a verb: 'the tests live in this folder'"),
             "DEFAULT": ("lyve, rhymes with five", "an adjective or adverb: 'a live model', 'go live'")},
    "lives": {"VERB": ("livz, rhymes with gives", "a verb: 'it lives in this folder'"),
              "DEFAULT": ("lyvz, rhymes with fives", "the plural of life")},
    "close": {"VERB": ("cloze, ends in z", "a verb or noun: 'close the file', 'at the close'"),
              "DEFAULT": ("cloce, ends in s", "an adjective or adverb: 'close to', 'a close match'")},
    "use": {"DEFAULT": ("yooz, ends in z", "a verb: 'use the flag'"), "NOUN": ("yooss, ends in s", "a noun: 'the use of'")},
    "uses": {"DEFAULT": ("YOO-ziz", "a verb: 'it uses'"), "NOUN": ("YOO-siz", "a noun: 'two uses'")},
    "used": {"DEFAULT": ("yoozd", "'used the flag', 'is used for'"), "VBD": ("yoost", "'used to'")},
    "wind": {"DEFAULT": ("rhymes with pinned", "a noun: moving air"), "VERB": ("rhymes with find", "a verb: 'wind down'")},
    "wound": {"DEFAULT": ("woond", "an injury"), "VBD": ("rhymes with found", "past of wind: 'wound up'")},
    "tear": {"DEFAULT": ("rhymes with here", "a noun: a teardrop"), "VERB": ("rhymes with hair", "a verb: 'tear down'")},
    "bow": {"DEFAULT": ("rhymes with go", "a noun: a knot, a weapon"), "VERB": ("rhymes with now", "a verb: to bend")},
    "minute": {"DEFAULT": ("MIN-it", "sixty seconds"), "ADJ": ("my-NOOT", "an adjective: tiny")},
    "content": {"NOUN": ("KON-tent", "a noun: 'the content of the file'"), "DEFAULT": ("kun-TENT", "an adjective or verb: satisfied")},
    "contents": {"NOUN": ("KON-tents", "a noun: 'the contents of the file'"), "DEFAULT": ("kun-TENTS", "a verb")},
    "object": {"DEFAULT": ("OB-jekt", "a noun: 'a JSON object'"), "VERB": ("ub-JEKT", "a verb: to protest")},
    "record": {"DEFAULT": ("REK-urd", "a noun or adjective: 'a record of'"), "VERB": ("ri-KORD", "a verb: 'record the run'")},
    "present": {"DEFAULT": ("PREZ-unt", "a noun or adjective: 'is present'"), "VERB": ("pree-ZENT", "a verb: 'present the results'")},
    "project": {"DEFAULT": ("PROJ-ekt", "a noun: 'the project'"), "VERB": ("pruh-JEKT", "a verb: to estimate or throw forward")},
    "invalid": {"DEFAULT": ("in-VAL-id", "an adjective: not valid"), "NOUN": ("IN-vuh-lid", "a noun: a sick person")},
}
IDENTIFIER_PATTERNS = [
    re.compile(r"^[A-Za-z0-9]+(_[A-Za-z0-9]+)+$"),                 # snake_case
    re.compile(r"^[a-z]+[A-Z][A-Za-z0-9]*$"),                      # camelCase
    re.compile(r"^--?[a-z][\w-]*$"),                               # --flags
    re.compile(r"^[~.]?/[\w.-]+(/[\w.-]*)*$|^[\w.-]+(/[\w.-]+)+$"),  # paths
    re.compile(r"^[\w-]+\.(json|jsonl|yaml|yml|md|js|ts|py|html|sh|txt|toml|csv)$", re.I),  # file names
]
TIERS = ["person", "fallback", "identifier", "heteronym", "lexicon", "acronym", "number", "proper-noun", "requested"]
ADVICE = {
    "person": "A person's name. Do not narrate it until the user has confirmed how it sounds.",
    "fallback": "Not in the voice's dictionary or a lexicon: the pronunciation is a guess from spelling. Audition it; add a lexicon entry if it is wrong.",
    "identifier": "Code, a flag, a path or a file name. Rewrite the sentence in spoken form rather than adding a lexicon entry.",
    "heteronym": "Two pronunciations. Judge the chosen one against the sentence; if it is wrong, rewrite the sentence.",
    "lexicon": "Said through a lexicon entry. Heard once, then recorded in the ledger.",
    "acronym": "Letters or an acronym. Check whether it should be spelled out or said as a word.",
    "number": "A number, version or symbol. Check how it is read; write it out in words if it is wrong.",
    "proper-noun": "A name. Usually right when it is in the dictionary; confirm it once.",
    "requested": "Added to the list on request.",
}


def norm_ph(p):
    """The identity of a pronunciation: main stress kept, secondary stress dropped (misaki adds
    and removes it by position in the sentence), and the flap written one way."""
    return (p or "").replace("ˌ", "").replace("T", "ɾ").strip()


def bare_ph(p):
    """Just the sounds, no stress at all (for comparing with what a transcriber heard)."""
    return norm_ph(p).replace("ˈ", "")


def clean_word(w):
    """A word as the script spells it, without the punctuation around it. A leading "." or "-"
    stays: ".jsonl" and "--output" are words of their own."""
    w = w.strip(" \t\n\"“”‘’'()[]{}<>*`").rstrip(".,;:!?…—–-").lstrip("—–")
    return w.strip(" \t\n\"“”‘’'()[]{}<>*`")


def word_key(w):
    """The ledger key for a word: lower case, no surrounding punctuation, no possessive."""
    return re.sub(r"['’]s$", "", clean_word(w).lower())


def respell(ph):
    """A rough, mechanical English respelling of misaki phonemes, stressed syllable in capitals."""
    out = []
    for part in (ph or "").split():
        units, stress, i = [], False, 0
        while i < len(part):
            c = part[i]
            i += 1
            if c == "ˈ":
                stress = True
            elif c == "ˌ":
                continue
            elif c in VOWELS:
                text = _RESPELL.get(c, c)
                if c in "əɜ" and i < len(part) and part[i] == "ɹ":  # "er"
                    text, i = "ur", i + 1
                units.append(["v", text, stress])
                stress = False
            else:
                units.append(["c", _RESPELL.get(c, c), False])
        syllables, cur, seen_vowel = [], ["", False], False
        for n, (kind, text, st) in enumerate(units):
            if kind == "c" and seen_vowel and n + 1 < len(units) and units[n + 1][0] == "v":
                syllables.append(cur)  # one consonant starts the next syllable
                cur, seen_vowel = ["", False], False
            cur[0] += text
            if kind == "v":
                if seen_vowel:  # two vowels in a row
                    cur[0] = cur[0][:-len(text)]
                    syllables.append(cur)
                    cur = [text, False]
                seen_vowel = True
                cur[1] = cur[1] or st
        syllables.append(cur)
        out.append("-".join(s.upper() if st and len(syllables) > 1 else s for s, st in syllables if s))
    return " ".join(out)


def stress_syllable(p):
    n = 0
    for c in p or "":
        if c == "ˈ":
            return n
        if c in VOWELS:
            n += 1
    return None


class Analyzer:
    """misaki's text-to-phoneme step exactly as Kokoro's pipeline builds it, without the model."""

    def __init__(self, british=False):
        import warnings
        warnings.filterwarnings("ignore")
        from misaki import en, espeak
        self.en = en
        self.british = british
        try:
            fallback = espeak.EspeakFallback(british=british)
        except Exception as e:  # noqa: BLE001
            log(f"warning: espeak fallback unavailable ({e}); unknown words will be skipped")
            fallback = None
        self.g2p = en.G2P(trf=False, british=british, fallback=fallback, unk="")
        self.lexn = self.g2p.lexicon
        import importlib.resources
        from misaki import data
        name = "gb" if british else "us"
        # The raw dictionaries: misaki adds a capitalized copy of every word, which hides
        # whether a word is a name or just starts a sentence. In the files, a name is
        # capitalized in gold ("Wilson") and lower case only in silver; an ordinary word is
        # lower case in gold ("lint", "python").
        with importlib.resources.open_text(data, f"{name}_gold.json") as r:
            self.raw_gold = set(json.load(r).keys())
        with importlib.resources.open_text(data, f"{name}_silver.json") as r:
            self.raw = self.raw_gold | set(json.load(r).keys())
        self._ner = None
        self.declared = []  # people named in the storyboard ("people": [...]): always treated as names

    # -- tokens --------------------------------------------------------------
    def tokens(self, tts_text):
        ps, toks = self.g2p(re.sub(r"\n", " ", tts_text))
        out = []
        for t in toks:
            rating = getattr(t, "rating", None)
            if rating is None and t._ is not None:
                rating = t._.rating
            if rating is None and t.phonemes:
                rating = self.rate(t.text, t.tag)
            out.append({"text": t.text, "tag": t.tag, "phonemes": t.phonemes or "", "rating": rating})
        return ps, out

    def rate(self, text, tag):
        """misaki leaves a token made of several pieces ("That's", "fine-grained") unrated.
        Work out where its sounds came from: 4 gold, 3 silver, 2 the fallback speller."""
        ctx = self.en.TokenContext()

        def one(w):
            try:
                ps, r = self.lexn.get_word(w, tag, None, ctx)
            except Exception:  # noqa: BLE001
                return None
            if ps is None and self.lexn.is_number(w, True):
                return 4
            return r if ps is not None else None

        whole = one(text.strip(PUNCT_STRIP))
        if whole is not None:
            return whole
        parts = [one(p) for p in self.en.subtokenize(text) if any(c.isalnum() for c in p)]
        if parts and all(r is not None for r in parts):
            return min(parts)
        return 2

    def entities(self, text):
        if self._ner is None:
            import spacy
            try:
                self._ner = spacy.load("en_core_web_sm", exclude=["parser", "lemmatizer"])
            except Exception as e:  # noqa: BLE001
                log(f"warning: no entity recognizer ({e}); people's names will not be detected")
                self._ner = False
        out = []
        for name in self.declared:
            for m in re.finditer(r"(?<![A-Za-z])" + re.escape(name) + r"(?![A-Za-z])", text, re.IGNORECASE):
                out.append((m.start(), m.end(), "PERSON", name))
        if not self._ner or "ner" not in self._ner.pipe_names:
            return out
        for e in self._ner(text).ents:
            if any(e.start_char < b and e.end_char > a for a, b, _, _ in out):
                continue
            label = e.label_
            if label == "PERSON" and not self.name_like(e.text):
                label = "MISC"  # the small model calls "Lesson", "Node" and "JSON" people
            out.append((e.start_char, e.end_char, label, e.text))
        return out

    def name_like(self, name):
        """Two or more capitalized words ("Mark Brown"), or one that is not an ordinary
        dictionary word ("Wilson", but not "Lesson" or "Node")."""
        caps = [w for w in re.findall(r"[A-Za-z][A-Za-z'’-]*", name) if w[:1].isupper() and not w.isupper()]
        return len(caps) >= 2 or any(not self.common(w) for w in caps)

    # -- where a pronunciation comes from -------------------------------------
    def source(self, text, rating):
        if rating is None:
            return "none"
        if rating >= 5:
            return "lexicon"
        if rating == 4:
            return "gold"
        if rating == 3:
            w = text.strip(PUNCT_STRIP)
            if any(x in self.lexn.silvers or x in self.lexn.golds for x in (w, w.lower())):
                return "silver"
            if re.search(r"\d", w):
                return "silver"
            if re.fullmatch(r"[A-Z][A-Z.]*s?", w):
                return "spelled"  # letter by letter
            return "silver"
        return "fallback"

    def common(self, word):
        """Is this an ordinary dictionary word once lower-cased ("Results", "That's",
        "Should-trigger")? A name ("Wilson", "Claude") is in the dictionary only capitalized."""
        parts = [p for p in re.split(r"[-/]", word.replace("’", "'")) if p]
        return bool(parts) and all(self._common_part(p) for p in parts)

    def _common_part(self, w):
        if w.isupper():
            return True  # an acronym inside a compound ("AI-written") is not a name
        if w[:1].upper() + w[1:].lower() in self.raw_gold and w.lower() not in self.raw_gold:
            return False  # in the dictionary as a name only
        w = w.lower()
        forms = [w, re.sub(r"'(s|ll|d|re|ve)$|n't$", "", w)]
        for suffix, repl in (("ies", "y"), ("es", ""), ("s", ""), ("ed", ""), ("ed", "e"), ("ing", ""), ("ing", "e"), ("ly", "")):
            if w.endswith(suffix) and len(w) > len(suffix) + 2:
                forms.append(w[:-len(suffix)] + repl)
        return any(f in self.raw for f in forms)

    # -- words with two pronunciations ----------------------------------------
    def heteronym_variants(self, word):
        """{tag: phonemes} for a word misaki pronounces by part of speech, else None."""
        golds, silvers = self.lexn.golds, self.lexn.silvers
        for w in (word, word.lower()):
            v = golds.get(w)
            if isinstance(v, dict):
                return dict(v)
            if v is not None or w in silvers:
                return None
        wl = word.lower()
        stems = []
        if len(wl) >= 3 and wl.endswith("s"):
            stems += [(wl[:-1], self.lexn._s), (wl[:-2], self.lexn._s), (wl[:-3] + "y", self.lexn._s)]
        if len(wl) >= 4 and wl.endswith("d"):
            stems += [(wl[:-1], self.lexn._ed), (wl[:-2], self.lexn._ed)]
        if len(wl) >= 5 and wl.endswith("ing"):
            stems += [(wl[:-3], self.lexn._ing), (wl[:-3] + "e", self.lexn._ing)]
        for stem, fn in stems:
            v = golds.get(stem)
            if isinstance(v, dict):
                return {k: (fn(p) if p else p) for k, p in v.items()}
            if v is not None or stem in silvers:
                return None
        return None

    def heteronym(self, word, phonemes, tag):
        variants = self.heteronym_variants(word)
        if not variants:
            return None
        groups = {}  # phonemes -> [tags]
        for k, p in variants.items():
            if p:
                groups.setdefault(p, []).append(k)
        if len(groups) < 2 or set(variants) == {"DEFAULT", "None"}:
            return None
        if len({bare_ph(p) for p in groups}) == 1:
            pos = {stress_syllable(p) for p in groups}
            if len(pos) < 2 or None in pos:
                return None  # only the strength of the stress differs
        hints = HETERONYM_HINTS.get(word.lower(), {})
        other = [TAG_MEANING.get(k, k) for ks in groups.values() for k in ks if k != "DEFAULT"]
        out_variants = []
        for p, ks in groups.items():
            hint = next((hints[k] for k in ks if k in hints), None)
            if hint:
                sounds, means, src = hint[0], hint[1], "table"
            else:
                names = list(dict.fromkeys(TAG_MEANING.get(k, k) for k in ks if k != "DEFAULT"))
                means = " or ".join(names) if "DEFAULT" not in ks else "any use except " + " or ".join(dict.fromkeys(other))
                sounds, src = respell(p), "mechanical"
            out_variants.append({"phonemes": p, "tags": ks, "sounds_like": sounds, "when": means, "hint": src})
        got = bare_ph(phonemes)
        chosen = None
        exact = [v for v in out_variants if norm_ph(v["phonemes"]) == norm_ph(phonemes)]
        if len(exact) == 1:
            chosen = exact[0]
        else:
            same = [v for v in out_variants if bare_ph(v["phonemes"]) == got]
            if len(same) == 1:
                chosen = same[0]
            elif len(same) > 1:  # stress-shift pair: match the stressed syllable
                at = stress_syllable(phonemes)
                same = [v for v in same if stress_syllable(v["phonemes"]) == at]
                chosen = same[0] if len(same) == 1 else None
            else:  # inside a compound ("read-me"): which variant's sounds appear?
                inside = [v for v in out_variants if bare_ph(v["phonemes"]) in got]
                chosen = inside[0] if len(inside) == 1 else None
        if chosen:
            cue = f'{word} → "{chosen["sounds_like"]}" ({chosen["when"]}; tagged {tag})'
            others = "; ".join(f'"{v["sounds_like"]}" when {v["when"]}' for v in out_variants if v is not chosen)
            cue += f". The other reading is {others}."
        else:
            cue = f"{word}: could not tell which reading was chosen from the phonemes ({phonemes}); audition it."
        return {"variants": out_variants, "chosen": chosen["phonemes"] if chosen else None,
                "sounds_like": chosen["sounds_like"] if chosen else None, "when": chosen["when"] if chosen else None,
                "hint": chosen["hint"] if chosen else None, "cue": cue}

    # -- one sentence ---------------------------------------------------------
    def sentence(self, text, lex):
        spans = []
        tts_text = apply_lexicon(text, lex, self.british, spans)
        ps, toks = self.tokens(tts_text)
        units = group_units(text, tts_text, spans, [t["text"] for t in toks])
        ents = self.entities(text)
        words, first = [], True
        for u in units:
            tks = [toks[i] for i in u["tokens"]]
            phon = " ".join(t["phonemes"] for t in tks if t["phonemes"]).strip()
            spoken = " ".join(t["text"] for t in tks)
            if not re.search(r"[A-Za-z0-9]", u["word"]) and not any(c in VOWELS for c in phon):
                if re.search(r"[.!?:]", u["word"]):
                    first = True
                continue
            ratings = [t["rating"] for t in tks]
            rating = None if None in ratings else min(ratings)
            word = clean_word(u["word"]) or u["word"]
            span = u["span"]
            src = self.source(spoken, rating)
            w = {"word": word, "tag": tks[0]["tag"], "phonemes": phon, "sounds_like": respell(phon), "rating": rating}
            if span is not None:
                w["source"] = "lexicon"
                w["lexicon"] = {"key": span["key"], "value": span["value"], "file": span["file"]}
                if not span["phonemes"]:
                    w["spoken_as"] = spoken.strip(PUNCT_STRIP)
                    w["respelling_source"] = src
            else:
                w["source"] = src
            reasons = []
            # A person's name (entity recognizer over the sentence as written).
            ent = next((e for e in ents if e[0] < u["orig_end"] and e[1] > u["orig_start"]), None)
            if ent and ent[2] == "PERSON":
                reasons.append("person")
                w["person"] = ent[3]
            if span is None and src in ("fallback", "none"):
                reasons.append("fallback")
            # Code stays code even when a lexicon entry covers part of it ("config.yaml").
            if (span is None or word.lower() != span["match"].lower()) and any(p.match(word) for p in IDENTIFIER_PATTERNS):
                reasons.append("identifier")
            # Two pronunciations: check the words actually sent to the voice (a respelling
            # such as "read-me" can contain one).
            for part, tk in [(p, t) for t in tks for p in re.findall(r"[A-Za-z']+", t["text"])][:6]:
                het = self.heteronym(part, tk["phonemes"] if part == tk["text"].strip(PUNCT_STRIP) else phon, tk["tag"])
                if het:
                    reasons.append("heteronym")
                    w["heteronym"] = het
                    break
            if span is not None:
                reasons.append("lexicon")
            else:
                if re.fullmatch(r"[A-Z][A-Z0-9]+s?|([A-Z]\.){2,}|[A-Z]+-\d+", word) or src == "spelled":
                    reasons.append("acronym")
                elif re.search(r"\d", word) or not re.search(r"[A-Za-z0-9]", word):
                    reasons.append("number")
                elif (word[:1].isupper() and not word.isupper() and len(word) > 1
                      and re.fullmatch(r"[A-Za-z'’-]+", word) and not self.common(word)
                      and not (ent and ent[2] in ("DATE", "TIME"))):
                    reasons.append("proper-noun")
            if reasons:
                w["reasons"] = reasons
            words.append(w)
            first = bool(re.search(r"[.!?:]$", u["word"].rstrip("\"'”’)")))
        return {"tts_text": tts_text, "phonemes": ps, "words": words,
                "people": sorted({e[3] for e in ents if e[2] == "PERSON"})}


def load_ledger(video_dir):
    path = (video_dir.parent / LEDGER_NAME) if video_dir else None
    if path and path.is_file():
        try:
            return path, json.loads(path.read_text()).get("words", {})
        except ValueError as e:
            log(f"warning: {path} is not valid JSON ({e}); treating every word as unapproved")
    return path, {}


def ear_approved(ledger, key, phonemes):
    """Has the user approved this word sounding like this?"""
    want = norm_ph(phonemes)
    return any(a.get("by", "user") == "user" and norm_ph(a.get("phonemes")) == want
               for a in ledger.get(key, {}).get("approved", []))


def context_judged(ledger, key, sentence, phonemes):
    want = norm_ph(phonemes)
    return any(c.get("sentence") == sentence and norm_ph(c.get("phonemes")) == want
               for c in ledger.get(key, {}).get("contexts", []))


AMERICAN_ISE = ("surprise", "promise", "premise", "exercise", "advise", "advertise", "revise", "devise", "supervise",
                "improvise", "compromise", "despise", "disguise", "arise", "rise", "wise", "precise", "concise",
                "expertise", "franchise", "enterprise", "merchandise", "raise", "praise", "noise", "poise", "paradise",
                "televise", "comprise", "excise", "incise", "demise", "chastise", "apprise", "appraise", "treatise")
DOUBLED_L = ("label", "cancel", "travel", "model", "level", "fuel", "signal", "total", "dial", "channel", "tunnel",
             "panel", "counsel", "marvel", "quarrel", "equal", "initial", "pencil", "jewel")


def british_spelling(an, word):
    """The American spelling when `word` is a British one ("colour" -> "color"), else None.
    Pronunciation is the same; this is for captions and on-screen text under an American voice."""
    w = word.lower()
    if len(w) < 6 or an.british or not w.isalpha():
        return None
    for a, b in (("isation", "ization"), ("ising", "izing"), ("ised", "ized"), ("ises", "izes"), ("ise", "ize"),
                 ("ysed", "yzed"), ("yses", "yzes"), ("yse", "yze"), ("ours", "ors"), ("oured", "ored"),
                 ("ouring", "oring"), ("our", "or"), ("ogue", "og"), ("tre", "ter"),
                 ("lled", "led"), ("lling", "ling"), ("ence", "ense")):
        if not w.endswith(a):
            continue
        us = w[:-len(a)] + b
        if us not in an.raw:
            return None
        if a.startswith("is") and w[:-len(a)] + "ise" in AMERICAN_ISE:
            return None
        if a in ("lled", "lling") and w[:-len(a)] + "l" not in DOUBLED_L:
            return None
        if a == "ence" and w not in ("defence", "offence", "licence", "pretence"):
            return None
        return us
    return None


def analyze(sentences, lex, british, ledger, include=(), show_all=False, declared_people=()):
    """sentences: [{"scene", "i", "text"}]. Returns the analysis dict (see --analyze)."""
    t0 = time.time()
    an = Analyzer(british)
    an.declared = [n for n in declared_people if isinstance(n, str) and n.strip()]
    include = {word_key(w) for w in include if w.strip()}
    out_sentences, items, heteronyms, people, spellings = [], {}, [], {}, {}
    skipped = 0
    for s in sentences:
        r = an.sentence(s["text"], lex)
        rec = {"scene": s["scene"], "i": s["i"], "text": s["text"], "tts_text": r["tts_text"], "phonemes": r["phonemes"],
               "words": r["words"]}
        if s.get("speed") is not None:
            rec["speed"] = s["speed"]
        out_sentences.append(rec)
        for name in r["people"]:
            people.setdefault(name, []).append(s["scene"])
        for w in r["words"]:
            key = word_key(w["word"])
            us = british_spelling(an, w["word"])
            if us:
                spellings.setdefault(key, {"word": w["word"], "american": us, "scenes": []})["scenes"].append(s["scene"])
            reasons = list(w.get("reasons", []))
            if key in include:
                reasons.append("requested")
            if not reasons:
                continue
            occ = {"scene": s["scene"], "i": s["i"], "sentence": s["text"], "tag": w["tag"], "phonemes": w["phonemes"]}
            het = w.get("heteronym")
            if het:
                occ["judged"] = context_judged(ledger, key, s["text"], w["phonemes"])
                heteronyms.append({"word": w["word"], **occ, "chosen": het["chosen"], "sounds_like": het["sounds_like"],
                                   "when": het["when"], "cue": het["cue"]})
            tier = next(t for t in TIERS if t in reasons)
            # One row per word; a word with two pronunciations gets one row per pronunciation.
            item_id = f"{key}|{norm_ph(w['phonemes'])}" if tier == "heteronym" else key
            it = items.get(item_id)
            if it is None:
                it = items[item_id] = {
                    "id": item_id, "word": re.sub(r"['’]s$", "", w["word"]), "key": key, "tier": tier, "reasons": [], "source": w["source"],
                    "phonemes": w["phonemes"], "sounds_like": w["sounds_like"], "count": 0, "occurrences": [],
                }
                for k in ("spoken_as", "lexicon", "respelling_source", "person"):
                    if k in w:
                        it[k] = w[k]
                if het:
                    it["heteronym"] = {k: het[k] for k in ("variants", "chosen", "sounds_like", "when", "hint", "cue")}
                    if het["sounds_like"]:
                        it["sounds_like"] = het["sounds_like"]
            for r_ in reasons:
                if r_ not in it["reasons"]:
                    it["reasons"].append(r_)
            if TIERS.index(tier) < TIERS.index(it["tier"]):
                it["tier"] = tier
            it["count"] += 1
            it["occurrences"].append(occ)
    doubtful = []
    for it in items.values():
        it["reasons"].sort(key=TIERS.index)
        needs = []
        if not all(ear_approved(ledger, it["key"], o["phonemes"]) for o in it["occurrences"]):
            needs.append("ear")
        if "heteronym" in it["reasons"] and not all(o.get("judged") for o in it["occurrences"]):
            needs.append("context")
        it["needs"] = needs
        it["advice"] = it.get("heteronym", {}).get("cue") if it["tier"] == "heteronym" else ADVICE[it["tier"]]
        if it["tier"] != "heteronym" and "heteronym" in it["reasons"]:
            it["advice"] += " " + it["heteronym"]["cue"]
        if needs or show_all or "requested" in it["reasons"]:
            doubtful.append(it)
        else:
            skipped += 1
    doubtful.sort(key=lambda it: (TIERS.index(it["tier"]), -it["count"], it["key"]))

    def confirmed(name):
        parts = [word_key(p) for p in re.findall(r"[A-Za-z][A-Za-z'’-]*", name)]
        whole = ledger.get(word_key(name), {}).get("approved", [])
        if any(a.get("by", "user") == "user" for a in whole):
            return True
        return bool(parts) and all(any(a.get("by", "user") == "user" for a in ledger.get(p, {}).get("approved", []))
                                   for p in parts)

    tiers = {}
    for it in doubtful:
        tiers[it["tier"]] = tiers.get(it["tier"], 0) + 1
    return {
        "sentences": out_sentences,
        "heteronyms": heteronyms,
        "doubtful": doubtful,
        "people": [{"name": n, "confirmed": confirmed(n), "scenes": sorted(set(sc)),
                    "source": "storyboard" if n in an.declared else "entity-recognizer"} for n, sc in sorted(people.items())],
        "british_spellings": sorted(({**v, "scenes": sorted(set(v["scenes"]))} for v in spellings.values()),
                                    key=lambda v: v["word"].lower()),
        "summary": {"sentences": len(out_sentences), "words": sum(len(s["words"]) for s in out_sentences),
                    "doubtful": len(doubtful), "by_tier": tiers, "approved_and_left_out": skipped,
                    "heteronym_occurrences": len(heteronyms),
                    "heteronyms_unjudged": sum(1 for h in heteronyms if not h["judged"]),
                    "seconds": round(time.time() - t0, 2)},
    }


def run_analyze(video_dir, text, as_json, show_all, include, lexicon=None, use_lexicon=True):
    british, voice = False, DEFAULT_VOICE["voice"]
    if video_dir:
        sb = load_storyboard(video_dir)
        voice = sb["voice"]["voice"]
        british = voice.startswith("b")
        lex, used = load_lexicon(video_dir, lexicon or (sb.get("pronunciations") and video_dir / sb["pronunciations"]), use_lexicon)
    else:
        sb = {"scenes": []}
        lex, used = load_lexicon(None, lexicon, use_lexicon)
    if text:  # one sentence per line
        lines = text if isinstance(text, list) else [t.strip() for t in text.split("\n") if t.strip()]
        sentences = [{"scene": "say", "i": n, "text": t} for n, t in enumerate(lines)]
    else:
        sentences = [{"scene": sc["id"], "i": i, "text": t, "speed": sc.get("speed")}
                     for sc in sb["scenes"] for i, t in enumerate(sc.get("narration", []))]
    ledger_path, ledger = load_ledger(video_dir)
    result = analyze(sentences, lex, british, ledger, include, show_all, sb.get("people") or ())
    result = {"video": str(video_dir) if video_dir else None, "slug": sb.get("slug"), "title": sb.get("title"),
              "voice": voice, "speed": sb.get("voice", DEFAULT_VOICE).get("speed"), "lexicons": used,
              "ledger": str(ledger_path) if ledger_path else None, **result}
    if as_json:
        print(json.dumps(result, ensure_ascii=False), file=OUT)
        return
    s = result["summary"]
    p = lambda *a: print(*a, file=OUT)  # noqa: E731
    p(f"{result['slug'] or 'text'}: {s['sentences']} sentences, {s['words']} words, {s['seconds']}s")
    p(f"doubtful: {s['doubtful']}  (approved and left out: {s['approved_and_left_out']})")
    for it in result["doubtful"]:
        o = it["occurrences"][0]
        says = f'"{it["spoken_as"]}" ' if it.get("spoken_as") else ""
        p(f"  {it['tier']:<11} {it['word']} → {says}\"{it['sounds_like']}\" ({it['phonemes']}; {it['source']}) ×{it['count']}"
          f"  needs {'+'.join(it['needs']) or 'nothing'}  {o['scene']}/{o['i']}")
    if result["heteronyms"]:
        p(f"words with two pronunciations ({s['heteronym_occurrences']} uses, {s['heteronyms_unjudged']} not yet judged in context):")
        for h in result["heteronyms"]:
            mark = "ok " if h["judged"] else "?  "
            p(f"  {mark}{h['scene']}/{h['i']} {h['word']} → \"{h['sounds_like']}\" ({h['when']}; tagged {h['tag']}): {h['sentence']}")
    if result["people"]:
        p("people: " + ", ".join(f"{x['name']} ({'confirmed' if x['confirmed'] else 'NOT confirmed'})" for x in result["people"]))
    if result["british_spellings"]:
        p("British spellings: " + ", ".join(f"{x['word']} ({x['american']})" for x in result["british_spellings"]))


# ------------------------------------------------------------- transcript ---

def stt_dir():
    return MODELS_DIR / STT["dir"]


def stt_status():
    d = stt_dir()
    ok = (d / "config.json").is_file() and any(d.glob("*.safetensors"))
    size = sum(f.stat().st_size for f in d.rglob("*") if f.is_file()) if d.is_dir() else 0
    return {"present": ok, "model": STT["repo"], "dir": str(d), "bytes": size}


_stt = None


def stt_model():
    global _stt
    if _stt is None:
        st = stt_status()
        if not st["present"]:
            log(f"error: the speech-to-text model is not installed ({st['dir']}).\n"
                f"Ask the user, then run: node {SCRIPTS_DIR / 'setup.js'} --yes --stt   (downloads about {STT.get('size_mb', '?')} MB)")
            sys.exit(2)
        from mlx_audio.stt import load
        _stt = load(st["dir"])
    return _stt


def transcribe_file(path):
    result = stt_model().generate(str(path), **STT.get("generate", {}))
    return re.sub(r"\s+", " ", getattr(result, "text", "") or "").strip()


def run_fetch_stt():
    from huggingface_hub import snapshot_download
    d = stt_dir()
    d.mkdir(parents=True, exist_ok=True)
    log(f"downloading {STT['repo']} to {d}")
    snapshot_download(STT["repo"], local_dir=str(d))
    st = stt_status()
    # Smoke test: synthesize a line and read it back.
    line = "This is a narration test for the video lesson skill."
    path, _ = cached_clip(line, "af_heart", 1.0, DEFAULT_VOICE["model"])
    t0 = time.time()
    heard = transcribe_file(path)  # includes loading the model
    t1 = time.time()
    transcribe_file(path)
    st.update({"heard": heard, "load_seconds": round(t1 - t0, 2), "seconds": round(time.time() - t1, 2),
               "ok": compare_heard(Analyzer(False), line, line, heard, Lexicon())["ok"]})
    emit(st)
    if not st["ok"]:
        sys.exit(1)


def _keyed(tokens):
    out = []
    for t in tokens:
        k = re.sub(r"[^a-z0-9]", "", t["text"].lower())
        if k:
            out.append({"key": k, "text": t["text"].strip(PUNCT_STRIP), "ph": bare_ph(t["phonemes"]).replace(" ", "")})
    return out


def number_readings(text):
    """Other ways a transcriber's digits may have been spoken: "22.15" is "twenty-two point
    fifteen" as well as misaki's "twenty-two point one five"; "100" is also "a hundred"."""
    from num2words import num2words

    def words(m):
        tok = m.group(0)
        try:
            if re.fullmatch(r"\d+(st|nd|rd|th)", tok):
                return num2words(int(tok[:-2]), to="ordinal")
            if "." in tok:
                a, b = tok.split(".", 1)
                return f"{num2words(int(a))} point {num2words(int(b))}"
            return num2words(int(tok.replace(",", "")))
        except (ValueError, OverflowError):
            return tok

    spoken = re.sub(r"\d+(?:st|nd|rd|th)\b|\d[\d,]*\.\d+|\d[\d,]*", words, text).replace("%", " percent").replace("$", "")
    out = [spoken]
    if re.search(r"\bone (hundred|thousand|million)\b", spoken):
        out.append(re.sub(r"\bone (hundred|thousand|million)\b", r"a \1", spoken))
    return out


def compare_heard(an, text, tts_text, heard, lex):
    """Word-level diff between what the script should have said and what was heard.
    Both sides go through misaki, so "Vally" → "Valley", "JSON" → "jay-son" and "0.21" →
    "zero point two one" compare equal however the transcriber spells them. The heard text is
    tried with and without the lexicon (a transcriber may write ".jsonl" for letters that were
    spelled out), and the reading with fewer mismatches is kept."""
    spans = []
    same_lexicon = apply_lexicon(text, lex, an.british, spans) == tts_text
    _, toks = an.tokens(tts_text)
    units = group_units(text if same_lexicon else plain_text(tts_text), tts_text, spans if same_lexicon else [],
                        [t["text"] for t in toks])
    exp = []
    for u in units:
        for k in _keyed([toks[i] for i in u["tokens"]]):
            exp.append({**k, "word": clean_word(u["word"]) or u["word"]})
    readings = list(dict.fromkeys([apply_lexicon(heard, lex, an.british), heard])) if heard else [""]
    best = None
    for reading in readings:
        got = _keyed(an.tokens(reading)[1]) if reading else []
        r = _diff(an, exp, got)
        if best is None or len(r["mismatches"]) < len(best["mismatches"]):
            best = r
    return {"ok": not best["mismatches"], **best, "words": [e["word"] for e in exp]}


_FILLER = re.compile(r"dot|point|slash|dash")


def _diff(an, exp, got):
    sm = difflib.SequenceMatcher(None, [e["key"] for e in exp], [g["key"] for g in got], autojunk=False)
    mismatches, close = [], 0
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op == "equal":
            continue
        a, b = exp[i1:i2], got[j1:j2]
        pa, pb = "".join(x["ph"] for x in a), "".join(x["ph"] for x in b)
        ka, kb = "".join(x["key"] for x in a), "".join(x["key"] for x in b)
        # "time stamped" / "timestamped", "dot vally dot yaml" / ".vally.yaml", "J S O N" / "JSON"
        if a and b and (ka == kb or _FILLER.sub("", ka) == _FILLER.sub("", kb)):
            sim = 1.0
        else:
            sim = difflib.SequenceMatcher(None, pa, pb, autojunk=False).ratio() if pa and pb else 0.0
            heard_text = " ".join(x["text"] for x in b)
            if sim < 1 and pa and re.search(r"\d", heard_text):
                for reading in number_readings(heard_text):
                    alt = "".join(k["ph"] for k in _keyed(an.tokens(reading)[1]))
                    sim = max(sim, difflib.SequenceMatcher(None, pa, alt, autojunk=False).ratio())
        if sim >= STT.get("same_sound", 0.8):
            close += 1  # the same sounds spelled another way
        else:
            mismatches.append({"kind": "missing" if not b else "extra" if not a else "different",
                               "expected": " ".join(dict.fromkeys(x["word"] for x in a)),
                               "heard": " ".join(x["text"] for x in b), "similarity": round(sim, 2)})
    return {"mismatches": mismatches, "same_sound_spelled_differently": close}


def run_transcribe(video_dir, out, only):
    timings_path = video_dir / "audio" / "timings.json"
    if not timings_path.is_file():
        log(f"error: no {timings_path}; run tts.py {video_dir} first")
        sys.exit(1)
    timings = json.loads(timings_path.read_text())
    sb = load_storyboard(video_dir)
    british = sb["voice"]["voice"].startswith("b")
    lex, _ = load_lexicon(video_dir, sb.get("pronunciations") and video_dir / sb["pronunciations"])
    current = {(sc["id"], i): t for sc in sb["scenes"] for i, t in enumerate(sc.get("narration", []))}
    out_dir = Path(out).resolve() if out else video_dir / "audio"
    out_path = out_dir / "transcript.json"
    previous = {}
    if out_path.is_file():
        try:
            old = json.loads(out_path.read_text())
            if old.get("model") == STT["repo"]:
                previous = {s["clip_sha"]: s["heard"] for s in old.get("sentences", []) if s.get("clip_sha")}
        except ValueError:
            pass
    wanted = set(only.split(",")) if only else None
    an = Analyzer(british)
    sentences, spent, fresh, seen, flagged = [], 0.0, 0, {}, {}
    for sid, clips in timings.get("scenes", {}).items():
        if wanted and sid not in wanted:
            continue
        for clip in clips:
            wav = video_dir / clip["file"]
            if not wav.is_file():
                log(f"warning: {wav} is missing; skipped")
                continue
            sha = hashlib.sha1(wav.read_bytes()).hexdigest()[:16]
            heard = previous.get(sha)
            if heard is None:
                t0 = time.time()
                heard = transcribe_file(wav)
                spent += time.time() - t0
                fresh += 1
            d = compare_heard(an, clip["text"], clip.get("tts_text", clip["text"]), heard, lex)
            for w in set(d.pop("words")):
                seen[word_key(w)] = seen.get(word_key(w), 0) + 1
            for m in d["mismatches"]:
                for w in set(m["expected"].split()):
                    e = flagged.setdefault(word_key(w), {"word": clean_word(w), "sentences": 0, "heard": []})
                    e["sentences"] += 1
                    if m["heard"] and m["heard"] not in e["heard"]:
                        e["heard"].append(m["heard"])
            rec = {"scene": sid, "i": clip["i"], "file": clip["file"], "clip_sha": sha, "text": clip["text"],
                   "tts_text": clip.get("tts_text", clip["text"]), "heard": heard, **d}
            if current.get((sid, clip["i"])) != clip["text"]:
                rec["stale"] = True  # the storyboard changed after this clip was synthesized
            sentences.append(rec)
    bad = [s for s in sentences if not s["ok"]]
    # A word misheard nearly every time it is spoken is probably mispronounced; one misheard
    # once in twenty is probably the transcriber.
    by_word = sorted(({**e, "of": seen.get(k, e["sentences"]), "share": round(e["sentences"] / max(1, seen.get(k, e["sentences"])), 2)}
                      for k, e in flagged.items()), key=lambda e: (-e["share"], -e["sentences"], e["word"]))
    result = {
        "video": str(video_dir), "model": STT["repo"], "sentences": sentences, "by_word": by_word,
        "limits": "Catches dropped, garbled and unknown words. Cannot catch a word said in the wrong tense "
                  "(read/read, live/live) or a real word said in a valid but unwanted way: the transcriber writes the "
                  "same spelling either way. A mismatch can also be the transcriber's own error; listen before changing anything.",
        "summary": {"sentences": len(sentences), "mismatched": len(bad), "transcribed": fresh, "reused": len(sentences) - fresh,
                    "seconds_per_sentence": round(spent / fresh, 3) if fresh else None},
    }
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    emit({"transcript": str(out_path), "model": STT["repo"], **result["summary"], "limits": result["limits"],
          "by_word": by_word,
          "mismatches": [{"scene": s["scene"], "i": s["i"], "text": s["text"], "heard": s["heard"],
                          "mismatches": s["mismatches"]} for s in bad]})


# ---------------------------------------------------------------- modes ---

def run_storyboard(video_dir, only=None, force=False, words=False):
    sb = load_storyboard(video_dir)
    cfg = sb["voice"]
    british = cfg["voice"].startswith("b")
    lex, used = load_lexicon(video_dir, sb.get("pronunciations") and video_dir / sb["pronunciations"])
    if used:
        log("lexicons: " + ", ".join(used))
    audio_dir = video_dir / "audio"
    timings_path = audio_dir / "timings.json"
    timings = json.loads(timings_path.read_text()) if timings_path.exists() else {"scenes": {}}
    timings.update({"model": cfg["model"], "voice": cfg["voice"]})
    wanted = set(only.split(",")) if only else None

    for scene in sb["scenes"]:
        sid = scene["id"]
        if wanted and sid not in wanted:
            continue
        speed = scene.get("speed", cfg["speed"])
        clips = []
        for i, sentence in enumerate(scene.get("narration", [])):
            spans = []
            tts_text = apply_lexicon(sentence, lex, british, spans)
            src, dur = cached_clip(tts_text, cfg["voice"], speed, cfg["model"], force, want_tokens=words)
            dest = audio_dir / f"{sid}_{i:02d}.wav"
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(src, dest)
            clip = {"i": i, "text": sentence, "tts_text": tts_text,
                    "file": f"audio/{dest.name}", "duration": round(dur, 4)}
            times = word_times(sentence, tts_text, spans, clip_tokens(src))
            if times:
                clip["words"] = times
            clips.append(clip)
        timings["scenes"][sid] = clips
        total = sum(c["duration"] for c in clips)
        log(f"{sid}: {len(clips)} sentences, {total:.1f}s")

    # Drop timings for scenes no longer in the storyboard.
    ids = {s["id"] for s in sb["scenes"]}
    timings["scenes"] = {k: v for k, v in timings["scenes"].items() if k in ids}
    timings_path.write_text(json.dumps(timings, indent=2, ensure_ascii=False) + "\n")
    print(str(timings_path), file=OUT)


def run_say(text, voices, speed, out, lexicon, use_lexicon, play, video_dir=None):
    """Audition text. With video_dir, use that video's lexicon chain, voice, and speed."""
    model = DEFAULT_VOICE["model"]
    if video_dir:
        sb = load_storyboard(video_dir)
        cfg = sb["voice"]
        model = cfg["model"]
        voices = voices or cfg["voice"]
        speed = speed if speed is not None else cfg["speed"]
        extra = lexicon or (sb.get("pronunciations") and video_dir / sb["pronunciations"])
        lex, used = load_lexicon(video_dir, extra, use_lexicon)
    else:
        lex, used = load_lexicon(None, lexicon, use_lexicon)
    voices = voices or DEFAULT_VOICE["voice"]
    speed = DEFAULT_VOICE["speed"] if speed is None else speed
    out = Path(out) if out else ((video_dir / "auditions") if video_dir else Path("auditions"))
    out.mkdir(parents=True, exist_ok=True)
    can_play = bool(shutil.which("afplay"))
    if play and not can_play:
        log("afplay not found: nothing was played; open the WAV files listed below to listen")
    results = []
    for voice in voices.split(","):
        voice = voice.strip()
        tts_text = apply_lexicon(text, lex, voice.startswith("b"))
        src, dur = cached_clip(tts_text, voice, speed, model)
        slug = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")[:40] or "say"
        dest = out / f"{slug}.{voice}.wav"
        shutil.copyfile(src, dest)
        played = False
        if play and can_play:
            played = subprocess.run(["afplay", str(dest)]).returncode == 0
        results.append({"voice": voice, "tts_text": tts_text, "file": str(dest), "duration": round(dur, 2),
                        "played": played, "lexicons": used})
    print(json.dumps(results, indent=2, ensure_ascii=False), file=OUT)


def run_say_batch(req_file, out):
    """Many auditions in one process: the model loads once. See the module docstring."""
    reqs = json.loads(Path(req_file).read_text())
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    contexts, analyzers, results = {}, {}, []

    def context(video):
        if video not in contexts:
            if video:
                sb = load_storyboard(video)
                lex, _ = load_lexicon(video, sb.get("pronunciations") and video / sb["pronunciations"])
                contexts[video] = (sb["voice"], lex)
            else:
                contexts[video] = (dict(DEFAULT_VOICE), load_lexicon(None)[0])
        return contexts[video]

    for r in reqs:
        try:
            video = Path(r["video"]).resolve() if r.get("video") else None
            cfg, lex = context(video)
            if r.get("override"):
                lex = lex.with_override(r["override"])
            voice = r.get("voice") or cfg["voice"]
            speed = r.get("speed") or cfg["speed"]
            british = voice.startswith("b")
            tts_text = apply_lexicon(r["text"], lex, british)
            src, dur = cached_clip(tts_text, voice, speed, cfg["model"])
            name = re.sub(r"[^A-Za-z0-9._-]+", "-", str(r["id"])).strip("-") or "clip"
            dest = out / f"{name}.wav"
            shutil.copyfile(src, dest)
            res = {"id": r["id"], "file": str(dest), "tts_text": tts_text, "duration": round(dur, 2), "voice": voice}
            if r.get("focus"):
                an = analyzers.get(british) or analyzers.setdefault(british, Analyzer(british))
                want = word_key(r["focus"])
                words = an.sentence(r["text"], lex)["words"]
                hit = (next((w for w in words if word_key(w["word"]) == want), None)
                       or next((w for w in words if want in w["word"].lower()), None))  # ".jsonl" inside "results.jsonl"
                if hit:
                    res["focus"] = {k: hit[k] for k in ("word", "phonemes", "sounds_like", "source", "spoken_as") if k in hit}
            results.append(res)
        except Exception as e:  # noqa: BLE001  one bad request must not lose the rest
            results.append({"id": r.get("id"), "error": str(e)})
    emit(results)


def pick_sample_sentence(sb):
    """A real line from the video: prefer a question (varied intonation), else the longest sentence."""
    lines = [t for s in sb.get("scenes", []) for t in s.get("narration", [])]
    if not lines:
        return SAMPLE_TEXT
    questions = [t for t in lines if t.rstrip().endswith("?")]
    longest = max(lines, key=len)
    return f"{longest} {questions[0]}" if questions and questions[0] != longest else longest


def run_samples(video_dir, text, speed, british, out, open_page):
    import html as h
    model, current, lex, subtitle = DEFAULT_VOICE["model"], DEFAULT_VOICE["voice"], Lexicon(), "Default settings"
    if video_dir:
        sb = load_storyboard(video_dir)
        cfg = sb["voice"]
        model, current = cfg["model"], cfg["voice"]
        speed = speed if speed is not None else cfg["speed"]
        text = text or pick_sample_sentence(sb)
        lex, _ = load_lexicon(video_dir, sb.get("pronunciations") and video_dir / sb["pronunciations"])
        subtitle = f"For “{h.escape(sb.get('title', video_dir.name))}”"
    else:
        lex, _ = load_lexicon(None)
    text = text or SAMPLE_TEXT
    speed = DEFAULT_VOICE["speed"] if speed is None else speed
    out = Path(out) if out else ((video_dir / "auditions" / "voices") if video_dir else Path("voice-samples"))
    out.mkdir(parents=True, exist_ok=True)

    groups = ["male", "female"] + (["british"] if british else [])
    files = {}
    for g in groups:
        for voice in VOICES[g]:
            src, _ = cached_clip(apply_lexicon(text, lex, voice.startswith("b")), voice, speed, model)
            shutil.copyfile(src, out / f"{voice}.wav")
            files[voice] = f"{voice}.wav"
            log(f"  {voice}")

    def cards(g):
        out_ = []
        for v in VOICES[g]:
            cur = v == current
            tag = '<span class="tag">current</span>' if cur else ""
            out_.append(f'<div class="v{" current" if cur else ""}"><div class="n">{v}{tag}</div>'
                        f'<audio controls preload="none" src="{files[v]}"></audio></div>')
        return "".join(out_)

    british_html = (f'<h2>British ({len(VOICES["british"])})</h2><div class="grid">{cards("british")}</div>' if british else "")
    page = (SKILL_DIR / "assets" / "voice-samples.html").read_text()
    for k, v in {"SUBTITLE": subtitle, "SPEED": f"{speed:g}", "CURRENT": current, "SENTENCE": h.escape(text),
                 "MALE_COUNT": str(len(VOICES["male"])), "FEMALE_COUNT": str(len(VOICES["female"])),
                 "MALE_CARDS": cards("male"), "FEMALE_CARDS": cards("female"), "BRITISH_SECTION": british_html}.items():
        page = page.replace("{{" + k + "}}", v)
    index = out / "index.html"
    index.write_text(page)
    if open_page and shutil.which("open"):
        subprocess.run(["open", str(index)])
    print(json.dumps({"page": str(index), "voices": len(files), "current": current, "speed": speed, "text": text},
                     ensure_ascii=False), file=OUT)


def lexicon_selftest():
    """The matching rules, checked without any model."""
    lex = Lexicon().add({"YAML": "yammel", "Vally": "Valley", "vally": "valley", "=IT": "I T", ".jsonl": "dot jay-son-ell",
                         "output dir": "output dur", "dir": "deer", "repo": "reepo", "Kokoro": "/kˈOkəɹO/",
                         "etc.": "et cetera"}, "(selftest)")
    cases = [
        ("Write yaml, Yaml and YAML.", "Write yammel, yammel and yammel."),
        ("Vally, vally and VALLY.", "Valley, valley and valley."),
        ("IT said it and It.", "I T said it and It."),
        ("Open results.jsonl now.", "Open results dot jay-son-ell now."),
        ("The output dir and a dir.", "The output dur and a deer."),
        ("Repo names, etc.", "Reepo names, et cetera."),
        ("kokoro speaks.", "[kokoro](/kˈOkəɹO/) speaks."),
        ("yamls and direct stay.", "yamls and direct stay."),
    ]
    failed = [{"text": t, "want": w, "got": apply_lexicon(t, lex)} for t, w in cases if apply_lexicon(t, lex) != w]
    later = lex.with_override({"yaml": "yam-ul", "vally": None})
    if apply_lexicon("YAML and Vally.", later) != "yam-ul and Vally.":
        failed.append({"text": "override", "got": apply_lexicon("YAML and Vally.", later)})
    return failed


def run_selftest():
    out = {}
    path, dur = cached_clip("This is a narration test for the video lesson skill.", "af_heart", 1.0,
                            DEFAULT_VOICE["model"], force=True)
    out["synthesis_ok"] = dur > 1.0
    out["sample_seconds"] = round(dur, 2)
    out["word_times"] = bool(clip_tokens(path))
    failed = lexicon_selftest()
    out["lexicon_ok"] = not failed
    if failed:
        out["lexicon_failures"] = failed
    # Phoneme overrides: confirm misaki honours the [word](/phonemes/) syntax.
    try:
        from misaki import en
        g2p = en.G2P(trf=False, british=False, fallback=None)
        phonemes, _ = g2p("[Vally](/vˈæli/) works.")
        out["override_ok"] = "vˈæli" in phonemes
        out["override_phonemes"] = phonemes
    except Exception as e:  # noqa: BLE001
        out["override_ok"] = False
        out["override_error"] = str(e)
    out["stt"] = {k: v for k, v in stt_status().items() if k in ("present", "model")}
    print(json.dumps(out, ensure_ascii=False), file=OUT)
    if not out["synthesis_ok"] or not out["lexicon_ok"]:
        sys.exit(1)


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("video_dir", nargs="?")
    p.add_argument("--only")
    p.add_argument("--force", action="store_true")
    p.add_argument("--words", action="store_true", help="also compute per-word times for clips cached without them")
    p.add_argument("--say")
    p.add_argument("--say-batch", help="JSON file of audition requests (see the docstring)")
    p.add_argument("--voices")
    p.add_argument("--speed", type=float)
    p.add_argument("--out")
    p.add_argument("--video", help="with --say or --analyze --say: use this video's lexicons, voice and speed")
    p.add_argument("--lexicon")
    p.add_argument("--no-lexicon", action="store_true")
    p.add_argument("--play", action="store_true")
    p.add_argument("--analyze", action="store_true", help="pronunciation analysis; loads no model weights, writes nothing")
    p.add_argument("--json", action="store_true", help="with --analyze: the full analysis as JSON")
    p.add_argument("--all", action="store_true", help="with --analyze: include words already approved in the ledger")
    p.add_argument("--include", help="with --analyze: comma-separated words to put on the doubtful list")
    p.add_argument("--transcribe", action="store_true", help="speech-to-text over the clips, compared with the script")
    p.add_argument("--fetch-stt", action="store_true", help="download the speech-to-text model")
    p.add_argument("--stt-status", action="store_true")
    p.add_argument("--selftest", action="store_true")
    p.add_argument("--samples", action="store_true", help="render all voices into a playable sample page")
    p.add_argument("--british", action="store_true", help="with --samples: include British voices")
    p.add_argument("--open", action="store_true", help="with --samples: open the page in the browser")
    a = p.parse_args()
    sys.stdout = sys.stderr
    video = Path(a.video).resolve() if a.video else None
    target = Path(a.video_dir).resolve() if a.video_dir else None

    if a.analyze:
        if not (target or video or a.say):
            p.error("--analyze needs a video directory or --say \"text\"")
        run_analyze(target or video, a.say, a.json, a.all, (a.include or "").split(","), a.lexicon, not a.no_lexicon)
    elif a.transcribe:
        if not target:
            p.error("--transcribe needs a video directory")
        run_transcribe(target, a.out, a.only)
    elif a.fetch_stt:
        run_fetch_stt()
    elif a.stt_status:
        emit(stt_status())
    elif a.say_batch:
        if not a.out:
            p.error("--say-batch needs --out DIR")
        run_say_batch(a.say_batch, a.out)
    elif a.samples:
        run_samples(video, a.say, a.speed, a.british, a.out, a.open)
    elif a.selftest:
        run_selftest()
    elif a.say:
        run_say(a.say, a.voices, a.speed, a.out, a.lexicon, not a.no_lexicon, a.play, video)
    elif target:
        run_storyboard(target, a.only, a.force, a.words)
    else:
        p.error("pass a video directory, --say, --analyze, --transcribe, or --selftest")


if __name__ == "__main__":
    main()
