#!/usr/bin/env node
/**
 * Render every storyboard scene to a video-only clip of exactly the right length,
 * then write the timeline, captions and chapters.
 *
 * Usage:
 *   node render-scenes.js <video-dir> [--only s03,s05] [--force] [--no-record] [--allow-spend]
 *
 * Needs audio/timings.json from tts.py. Scene length = max(narration, natural
 * length of a terminal/manim/video visual), rounded up to whole frames.
 *
 * Narration timing: sentences play back to back (pacing.lead_in, pacing.gap). A narration
 * item may add "pause" (silent seconds before it) and "read" (quiet seconds after it, for the
 * viewer to read the screen), in any renderer, and, in terminal scenes,
 * "wait_for": "output:2" (do not start before that screen event, optional +seconds) and
 * "before": "typed:3" (hold the recording on the frame before that event until the sentence
 * has ended plus pacing.before_margin, default 0.3 s). Output a hidden `clear` would wipe is held
 * until the sentences about it have ended plus reading time (pacing.read_hold, default 2.5 s, or
 * the sentence's "read"). Events come from tape-events.js and are cached in
 * build/raw/<id>.events.json.
 *
 * Hidden setup that is still on screen for a few frames after a Show (the tape did not wait
 * for it) is covered when the clip is fitted: those frames show the first clean frame instead.
 * Nothing is re-recorded and no time moves.
 *
 * --no-record and --allow-spend control terminal recording (see recording.js).
 *
 * Caching: every clip and raw recording has a content-hash key (build/**\/<id>.key)
 * covering its visual files, theme, narration timing and encode settings. A plain run
 * re-renders only scenes whose inputs changed — always run it without --only unless
 * you need to. --force re-renders everything (or only the --only scenes). With --only,
 * a stale scene outside the list is an error, so clips can never drift from the timeline.
 *
 * Writes:
 *   build/clips/<id>.mp4    1920x1080 30fps yuv420p H.264, no audio
 *   build/timeline.json     absolute start/end of every scene and sentence; terminal scenes also
 *                           carry their screen events, holds and each sentence's anchor
 *   build/chapters.ffmeta   MP4 chapter metadata
 *   <slug>.srt              captions (original text, not lexicon respellings)
 *   chapters.txt            YouTube description chapter list
 */
'use strict';

const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const L = require('./lib');
const B = require('./browser');
const { checkTape } = require('./tape-check');
const TE = require('./tape-events');
// The credential scan of terminal recordings lives in its own module; a missing module is fine,
// a broken one is not (skipping the scan silently would be worse than stopping).
let terminalGate = null;
try { ({ terminalGate } = require('./secret-scan')); } catch (e) {
  if (!(e.code === 'MODULE_NOT_FOUND' && /secret-scan/.test(e.message))) throw e;
}

const RENDERERS = ['slide', 'html', 'terminal', 'manim', 'video'];
const CACHE_VERSION = '2';

// Sentences back to back: lead_in, then each clip, `gap` between them. An item's "pause" adds
// silence before its sentence. (A scene with no pauses lays out exactly as it always has, so its
// cache keys do not change.)
function narrationLayout(scene, clips, pacing) {
  const items = scene.narration_items || [];
  const sentences = [];
  let t = pacing.lead_in;
  clips.forEach((c, i) => {
    const pause = Number(items[i] && items[i].pause) || 0;
    if (pause > 0) t += pause;
    sentences.push({ text: c.text, file: c.file, start: t, end: t + c.duration });
    const read = Number(items[i] && items[i].read) || 0; // quiet time after the sentence, to read the screen
    t += c.duration + read + (i < clips.length - 1 ? pacing.gap : 0);
  });
  const spoken = clips.length ? t + pacing.tail : 0;
  const hold = Number(scene.hold_after || 0);
  const min = Number(scene.min_duration || 0);
  return { sentences, length: Math.max(spoken + hold, min) };
}

// ---- narration tied to a terminal recording ----------------------------------

const { usesAnchors } = TE;

// What an item asked for, for the timeline (never part of a cache key).
function itemNotes(scene) {
  return (scene.narration_items || []).map(i => {
    const a = {};
    if (Number(i && i.pause) > 0) a.pause = Number(i.pause);
    if (Number(i && i.read) > 0) a.read = Number(i.read);
    return a;
  });
}

// When each command of a terminal scene is typed, submitted, shows output and finishes in its
// raw recording. Cached in build/raw/<id>.events.json, keyed by the tape and the recording's
// bytes, so a re-recording is always re-read and nothing else is.
function recordingEvents(scene, dir, raw) {
  return TE.eventsFor(fs.readFileSync(path.resolve(dir, scene.visual), 'utf8'), raw, { write: true });
}

// ---- cache keys -----------------------------------------------------------

const readKey = f => (fs.existsSync(f + '.key') ? fs.readFileSync(f + '.key', 'utf8').trim() : null);
const writeKey = (f, k) => fs.writeFileSync(f + '.key', k + '\n');
const fresh = (f, k) => fs.existsSync(f) && readKey(f) === k;
const contents = f => (fs.existsSync(f) && fs.statSync(f).isFile() ? fs.readFileSync(f) : '');

function themeHash(dir) {
  const t = path.join(dir, '_theme');
  if (!fs.existsSync(t)) return '';
  return L.sha1(...fs.readdirSync(t).sort().map(n => [n, contents(path.join(t, n))]).flat());
}

function rawKey(scene, dir, narr) {
  const file = path.resolve(dir, scene.visual.split('#')[0]);
  if (scene.renderer === 'terminal') return L.sha1(CACHE_VERSION, 'terminal', contents(file));
  if (scene.renderer === 'manim') return L.sha1(CACHE_VERSION, 'manim', contents(file), scene.visual, narr.sentences, narr.length);
  const st = fs.existsSync(file) ? fs.statSync(file) : { size: 0, mtimeMs: 0 };
  return L.sha1(CACHE_VERSION, 'video', file, st.size, st.mtimeMs);
}

// ---- natural-length renderers (produce build/raw/<id>.mp4) -----------------

// Records the tape with vhs. The rules around a recording live in recording.js: --no-record,
// the spend guard (--allow-spend, spend-log.json, the budget), one recording at a time on this
// machine, and saving the screen as text for secret-scan.js. `args` is the parsed command line.
function renderTerminal(scene, dir, raw, args) {
  require('./recording').recordTerminal(scene, dir, raw, args || {});
}

function renderManim(scene, dir, raw, narr) {
  const [file, cls] = scene.visual.split('#');
  if (!cls) L.die(`${scene.id}: manim visual must be "path/to/file.py#SceneClass"`);
  if (!fs.existsSync(L.VENV_PY)) L.die('manim scenes need the venv: ask the user, then node scripts/setup.js --yes --manim');
  const src = path.resolve(dir, file);
  const media = L.mkdirp(path.join(dir, 'build', 'manim'));
  // manim caches rendered Text as SVG by text + font name; a stale entry (e.g. from before fonts
  // were registered) would keep the wrong typeface. Text SVGs are cheap to regenerate.
  fs.rmSync(path.join(media, 'texts'), { recursive: true, force: true });
  console.error(`  manim ${file} ${cls}`);
  L.run(L.VENV_PY, ['-m', 'manim', 'render', '-qh', '--fps', String(L.VIDEO.fps), '-r', `${L.VIDEO.width},${L.VIDEO.height}`,
    '--disable_caching', '--media_dir', media, '-o', `${scene.id}.mp4`, src, cls], {
    cwd: dir,
    env: { ...process.env, VL_SENTENCES: JSON.stringify(narr.sentences), VL_NARRATION_SECONDS: String(narr.length) },
  });
  const found = findFile(media, `${scene.id}.mp4`);
  if (!found) L.die(`${scene.id}: manim finished but ${scene.id}.mp4 was not found under ${media}`);
  fs.copyFileSync(found, raw);
}

function findFile(root, name) {
  for (const entry of fs.readdirSync(root, { withFileTypes: true })) {
    const p = path.join(root, entry.name);
    if (entry.isDirectory()) { const f = findFile(p, name); if (f) return f; }
    else if (entry.name === name && !p.includes('partial_movie_files')) return p;
  }
  return null;
}

// ---- clip renderers (produce build/clips/<id>.mp4 at the exact scene length) -

async function renderSlide(scene, dir, clip, vl) {
  const file = path.resolve(dir, scene.visual);
  const png = path.join(dir, 'build', 'frames', `${scene.id}.png`);
  L.mkdirp(path.dirname(png));
  const problems = await B.screenshotFinal(file, png, vl); // final state: every cue visible
  L.stillToClip(png, vl.duration, clip);
  return problems;
}

async function renderHtml(scene, dir, clip, vl) {
  const file = path.resolve(dir, scene.visual);
  const page = await B.openPage(file, vl);
  const total = L.frames(vl.duration);
  const ff = spawn('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'image2pipe', '-framerate', String(L.VIDEO.fps),
    '-c:v', 'png', '-i', '-', '-vf', L.normalizeVf(), ...L.ENCODE, clip], { stdio: ['pipe', 'inherit', 'inherit'] });
  const done = new Promise((res, rej) => {
    ff.on('error', rej);
    ff.stdin.on('error', rej);
    ff.on('close', c => (c === 0 ? res() : rej(new Error(`ffmpeg exited ${c}`))));
  });
  done.catch(() => {}); // observed below; avoid an unhandled rejection while frames are written
  let problems = [];
  // Determinism check: fingerprint a few frames in order, re-render them shuffled afterwards.
  const sample = new Set([0, 1, 2, 3, 4, 5].map(k => Math.min(total - 1, Math.floor((k * (total - 1)) / 5))));
  const seen = new Map(); // frame index -> screenshot from the in-order pass
  try {
    for (let i = 0; i < total; i++) {
      await B.seek(page, i / L.VIDEO.fps);
      const buf = await page.screenshot({ type: 'png' });
      if (sample.has(i)) seen.set(i, buf);
      if (!ff.stdin.write(buf)) await Promise.race([new Promise(r => ff.stdin.once('drain', r)), done]);
      if (i % 150 === 0) process.stderr.write(`  ${scene.id}: frame ${i}/${total}\r`);
    }
    const order = [...seen.keys()].reverse();
    order.push(order.shift()); // out of order and backwards
    for (const i of order) {
      await B.seek(page, i / L.VIDEO.fps);
      const again = await page.screenshot({ type: 'png' });
      if (L.sha1(again) === L.sha1(seen.get(i))) continue;
      const diff = L.visiblyDifferent(seen.get(i), again);
      if (diff.different) {
        problems.push(`not deterministic: frame ${i} (t=${(i / L.VIDEO.fps).toFixed(2)}s) differs when seeked out of order ` +
          `(${diff.changed} values, max delta ${diff.maxDelta}); motion must be a pure function of t`);
      }
    }
    await B.seek(page, vl.duration);
    problems = [...problems, ...page.problems, ...(await B.pageProblems(page))];
    ff.stdin.end();
    await done;
  } catch (e) {
    ff.kill();
    throw new Error(`${scene.id}: HTML render failed: ${e.message}`);
  } finally {
    await page.close();
  }
  return problems;
}

// Normalize a natural-length clip, then pad (freeze last frame) or cut to an exact frame count.
// A hold delays every raw frame from `frame` on by `seconds`; the fps filter then fills the gap
// by repeating the frame just before it, so the freeze shows exactly that frame.
// A cover hides what a hidden block left on screen after a Show: raw frames [from, to) are dropped
// and frame `to` (the first clean one) is moved back to where `from` was, so the same filter
// repeats it across the gap. Every other frame keeps its time, so nothing downstream moves.
function fitVideo(raw, clip, dur, holds = [], covers = [], fps = 25) {
  const edge = frame => ((frame - 0.5) / fps).toFixed(6); // a time between raw frame - 1 and raw frame
  const later = holds.map(h => `gte(T\\,${edge(h.frame)})*${h.seconds.toFixed(6)}`).join('+') || '0';
  const earlier = covers.map(c => `between(T\\,${edge(c.to)}\\,${edge(c.to + 1)})*${((c.to - c.from) / fps).toFixed(6)}`).join('+') || '0';
  const drop = covers.length ? `select='${covers.map(c => `not(between(n\\,${c.from}\\,${c.to - 1}))`).join('*')}',` : '';
  const shift = holds.length || covers.length ? `setpts='PTS+((${later})-(${earlier}))/TB',` : '';
  L.ffmpeg(['-i', raw, '-vf', `${drop}${shift}${L.normalizeVf()},tpad=stop_mode=clone:stop_duration=${dur.toFixed(3)}`,
    '-frames:v', String(L.frames(dur)), ...L.ENCODE, clip]);
}

// Events of a terminal scene's recording and, when its sentences use wait_for / before, the
// retimed narration layout. Event detection never stops a render that does not depend on it.
async function terminalTiming(scene, dir, raw, clips, pacing, natural, warnings) {
  const anchored = usesAnchors(scene);
  let det;
  try { det = await recordingEvents(scene, dir, raw); } catch (e) {
    if (anchored) throw e;
    det = { fps: 25, events: {}, commands: [], cuts: [], aligned: false, warnings: [`events not detected: ${e.message}`] };
  }
  let layout = null;
  if (anchored) {
    const check = TE.validateAnchors(scene.narration_items, fs.readFileSync(path.resolve(dir, scene.visual), 'utf8'));
    if (check.errors.length) L.die(`${scene.id}: narration anchors do not fit the tape ${scene.visual}:\n  ${check.errors.join('\n  ')}`);
    if (!det.aligned) {
      L.die(`${scene.id}: the tape could not be lined up with its recording, so "wait_for" / "before" cannot be placed:\n  ` +
        `${(det.warnings || []).join('\n  ')}\nRe-record the scene (render-scenes.js <dir> --only ${scene.id} --force) or remove the anchors`);
    }
    (det.warnings || []).forEach(w => warnings.push(`${scene.id}: ${w}`));
    // The layout itself (wait_for, before, holds) is shared with sync-report.js.
    try { layout = TE.layoutNarration(scene, clips, pacing, det, { frameAlign: L.frameAlign }); } catch (e) { L.die(e.message); }
    layout.warnings.forEach(w => warnings.push(w));
  } else {
    // Covered frames need no word here. Hidden content that could not be covered does.
    (det.uncovered || []).forEach(w => warnings.push(`${scene.id}: ${w}`));
  }
  return { det, layout, timeline: TE.sceneTimeline(det, layout, natural) };
}

function clipFrames(clip) {
  try {
    const v = L.probe(clip).streams.find(s => s.codec_type === 'video');
    return Number(v && v.nb_frames);
  } catch { return -1; }
}

// ---- outputs ---------------------------------------------------------------

function escapeMeta(s) {
  return String(s).replace(/([=;#\\\n])/g, '\\$1');
}

// Wrap text into lines of <= 42 chars.
function wrap(text, width = 42) {
  const lines = [];
  let cur = '';
  for (const w of text.split(/\s+/)) {
    if (cur && (cur + ' ' + w).length > width) { lines.push(cur); cur = w; } else cur = cur ? cur + ' ' + w : w;
  }
  if (cur) lines.push(cur);
  return lines;
}

// One sentence -> cues of at most 2 lines x 42 chars, timed by character share.
function splitCue(text, start, end) {
  const lines = wrap(text);
  const groups = [];
  for (let i = 0; i < lines.length; i += 2) groups.push(lines.slice(i, i + 2));
  const total = groups.reduce((n, g) => n + g.join(' ').length, 0) || 1;
  let t = start;
  return groups.map((g, i) => {
    const share = (end - start) * (g.join(' ').length / total);
    const cue = { text: g.join('\n'), start: t, end: i === groups.length - 1 ? end : t + share };
    t = cue.end;
    return cue;
  });
}

function writeOutputs(sb, dir, timeline) {
  const cues = timeline.scenes.flatMap(s => s.sentences.flatMap(x => splitCue(x.text, x.start, x.end)));
  const srt = cues.map((c, i) => `${i + 1}\n${L.fmtSrtTime(c.start)} --> ${L.fmtSrtTime(c.end)}\n${c.text}\n`).join('\n');
  fs.writeFileSync(path.join(dir, `${sb.slug}.srt`), srt);

  const chapters = chapterList(timeline);
  timeline.chapters = chapters;
  fs.writeFileSync(path.join(dir, 'chapters.txt'), chapters.map(c => `${L.fmtChapterTime(c.start)} ${c.title}`).join('\n') + '\n');
  const meta = [';FFMETADATA1', `title=${escapeMeta(sb.title)}`, ''];
  for (const c of chapters) {
    meta.push('[CHAPTER]', 'TIMEBASE=1/1000', `START=${Math.round(c.start * 1000)}`, `END=${Math.round(c.end * 1000)}`, `title=${escapeMeta(c.title)}`, '');
  }
  fs.writeFileSync(path.join(dir, 'build', 'chapters.ffmeta'), meta.join('\n'));
}

function chapterList(timeline) {
  const out = [];
  for (const s of timeline.scenes) {
    if (s.chapter || out.length === 0) out.push({ title: s.chapter || timeline.title, start: s.start });
  }
  out.forEach((c, i) => { c.end = i + 1 < out.length ? out[i + 1].start : timeline.total; });
  return out;
}

// ---- main ------------------------------------------------------------------

async function main() {
  const args = L.parseArgs(process.argv.slice(2), ['force', 'no-record', 'allow-spend']);
  const { sb, dir } = L.loadStoryboard(args._[0]);
  const timingsFile = path.join(dir, 'audio', 'timings.json');
  if (!fs.existsSync(timingsFile)) L.die('no audio/timings.json: run tts.py first');
  const timings = L.readJSON(timingsFile);
  const only = args.only ? new Set(args.only.split(',')) : null;
  const build = L.mkdirp(path.join(dir, 'build'));
  L.mkdirp(path.join(build, 'clips'));
  L.mkdirp(path.join(build, 'raw'));
  const theme = themeHash(dir);

  const timeline = { title: sb.title, slug: sb.slug, fps: L.VIDEO.fps, scenes: [], total: 0 };
  const warnings = [];
  const stale = [];
  let cursor = 0;
  let rendered = 0;

  for (const scene of sb.scenes) {
    if (!RENDERERS.includes(scene.renderer)) L.die(`${scene.id}: unknown renderer "${scene.renderer}" (use ${RENDERERS.join(', ')})`);
    const clips = timings.scenes[scene.id] || [];
    if (clips.length !== (scene.narration || []).length || clips.some((c, i) => c.text !== scene.narration[i])) {
      L.die(`${scene.id}: narration changed since tts.py ran; re-run tts.py`);
    }
    if (scene.renderer !== 'terminal' && usesAnchors(scene)) {
      L.die(`${scene.id}: "wait_for" and "before" tie a sentence to a terminal recording; this scene's renderer is "${scene.renderer}". Use "pause" instead`);
    }
    let narr = narrationLayout(scene, clips, sb.pacing);
    let notes = itemNotes(scene);
    const raw = path.join(build, 'raw', `${scene.id}.mp4`);
    const clip = path.join(build, 'clips', `${scene.id}.mp4`);
    const selected = !only || only.has(scene.id);
    const forced = args.force && selected;

    // 1. Natural-length source for terminal / manim / video scenes.
    let natural = 0;
    let rk = '';
    let terminal = null; // events of a terminal recording, and the retimed layout when sentences are tied to them
    if (['terminal', 'manim', 'video'].includes(scene.renderer)) {
      const src = path.resolve(dir, scene.visual.split('#')[0]);
      if (!fs.existsSync(src)) L.die(`${scene.id}: visual ${scene.visual} not found`);
      rk = rawKey(scene, dir, narr);
      if (forced || !fresh(raw, rk)) {
        if (!selected) { stale.push(scene.id); } else {
          if (scene.renderer === 'terminal') renderTerminal(scene, dir, raw, args);
          else if (scene.renderer === 'manim') renderManim(scene, dir, raw, narr);
          else fs.copyFileSync(src, raw);
          writeKey(raw, rk);
        }
      }
      if (fs.existsSync(raw)) natural = L.duration(raw);
      if (scene.renderer === 'terminal' && fs.existsSync(raw)) {
        if (terminalGate) terminalGate(scene, dir, raw);
        // Only for a recording of the tape as it is now: a stale one (outside --only) stops the
        // run below, and its events would not match the tape.
        if (fresh(raw, rk)) {
          terminal = await terminalTiming(scene, dir, raw, clips, sb.pacing, natural, warnings);
          if (terminal.layout) { narr = terminal.layout; notes = terminal.layout.notes; natural += terminal.layout.extra; }
        }
      }
    }

    const dur = L.frameAlign(Math.max(narr.length, natural, 1 / L.VIDEO.fps));
    if (natural > narr.length + 3) warnings.push(`${scene.id}: visual runs ${(natural - narr.length).toFixed(1)}s past its narration (silence is padded)`);
    const vl = { scene: scene.id, duration: dur, fps: L.VIDEO.fps, sentences: narr.sentences.map(({ text, start, end }) => ({ text, start, end })) };

    // 2. Exact-length clip.
    const visualFile = path.resolve(dir, scene.visual.split('#')[0]);
    // Holds and covers change the picture, so they join the key, but only when there are some:
    // a scene with neither keeps the key it has always had.
    const holds = terminal && terminal.layout ? terminal.layout.holds : [];
    // Frames after a Show that still show hidden content, replaced by the first clean frame.
    const covers = terminal && terminal.det.aligned ? terminal.det.covers || [] : [];
    const ck = L.sha1(CACHE_VERSION, scene.renderer, L.ENCODE, vl,
      ['slide', 'html'].includes(scene.renderer) ? L.sha1(contents(visualFile), theme) : rk,
      ...(holds.length ? [{ holds: holds.map(h => [h.frame, Number(h.seconds.toFixed(6))]) }] : []),
      ...(covers.length ? [{ covers: covers.map(c => [c.from, c.to]) }] : []));
    const upToDate = fresh(clip, ck) && clipFrames(clip) === L.frames(dur);
    if (forced || !upToDate) {
      if (!selected) {
        stale.push(scene.id);
      } else {
        console.error(`${scene.id} [${scene.renderer}] ${dur.toFixed(2)}s`);
        let problems = [];
        if (scene.renderer === 'slide') problems = await renderSlide(scene, dir, clip, vl);
        else if (scene.renderer === 'html') problems = await renderHtml(scene, dir, clip, vl);
        else fitVideo(raw, clip, dur, holds, covers, terminal ? terminal.det.fps : undefined);
        problems.forEach(p => warnings.push(`${scene.id}: ${p}`));
        writeKey(clip, ck);
        rendered += 1;
      }
    }

    timeline.scenes.push({
      id: scene.id, chapter: scene.chapter || null, renderer: scene.renderer,
      start: cursor, duration: dur, clip: path.relative(dir, clip),
      sentences: narr.sentences.map((s, i) => ({ ...s, start: cursor + s.start, end: cursor + s.end, ...(notes[i] || {}) })),
      // Terminal scenes: screen events in seconds from the scene's start (`t`) and in the raw recording (`raw`).
      ...(terminal ? { terminal: terminal.timeline } : {}),
    });
    cursor += dur;
  }
  timeline.total = cursor;
  await B.close();

  if (stale.length) {
    L.die(`scenes outside --only are out of date: ${[...new Set(stale)].join(', ')}. Run render-scenes.js without --only.`);
  }

  writeOutputs(sb, dir, timeline);
  L.writeJSON(path.join(build, 'timeline.json'), timeline);
  warnings.forEach(w => console.error(`warning: ${w}`));
  console.log(JSON.stringify({ scenes: timeline.scenes.length, rendered, total: Number(cursor.toFixed(2)), chapters: timeline.chapters.length, warnings }));
}

// Leave as soon as the result is written. Headless Chrome starts helpers (its crash handler, and
// the updater once it has been up for ~20 s) that inherit its stderr pipe and outlive it; while
// they run, Node would wait on that pipe for minutes after the work is done.
main().then(
  () => process.stdout.write('', () => process.exit(0)),
  e => { console.error(e.stack || e.message); process.exit(1); },
);
