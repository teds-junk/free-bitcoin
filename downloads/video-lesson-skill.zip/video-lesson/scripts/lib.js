'use strict';
// Shared helpers for the video-lesson scripts. No dependencies beyond Node core.

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const SCRIPTS_DIR = __dirname;
const SKILL_DIR = path.resolve(SCRIPTS_DIR, '..');
const ASSETS_DIR = path.join(SKILL_DIR, 'assets');

// Machine-local state lives outside the skill, so the skill directory stays small and copyable:
// the Python venv, the narration cache, speech-to-text weights, and the recording lock.
const STATE_DIR = process.env.VIDEO_LESSON_HOME || path.join(os.homedir(), '.video-lesson');
const VENV_DIR = path.join(STATE_DIR, 'venv');
const VENV_PY = path.join(VENV_DIR, 'bin', 'python');
const TTS_CACHE_DIR = path.join(STATE_DIR, 'tts-cache');
const MODELS_DIR = path.join(STATE_DIR, 'models');
// Where older versions of this skill kept them; setup.js moves these on its next run.
const LEGACY_VENV_DIR = path.join(SCRIPTS_DIR, '.venv');
const LEGACY_TTS_CACHE_DIR = path.join(SCRIPTS_DIR, '.tts-cache');

// Workspace (course) preferences: <video-dir>/../preferences.json, next to pronunciations.json.
const PREFERENCES = {
  voice: { model: 'mlx-community/Kokoro-82M-bf16', voice: 'am_echo', speed: 1.2 },
  output_dir: 'videos',
  demos: { record_real_runs: true, credentials: 'scan', perform_checkpoint: true },
  spend: { budget: null, unit: 'agent runs' },
  bridging_sentences: 'ask',
  approval: { style_approved: null, batch: true },
};

// One output spec for every clip, so the concat demuxer can stream-copy.
const VIDEO = { width: 1920, height: 1080, fps: 30, crf: 18 };
const AUDIO_RATE = 48000;

// Pacing defaults (seconds). A storyboard can override them under "pacing".
const PACING = { lead_in: 0.4, gap: 0.5, tail: 0.8 };

function die(msg) {
  console.error(`error: ${msg}`);
  process.exit(1);
}

function run(cmd, args, opts = {}) {
  const res = spawnSync(cmd, args, { encoding: 'utf8', maxBuffer: 1 << 28, ...opts });
  if (res.error) throw new Error(`${cmd} failed to start: ${res.error.message}`);
  if (res.status !== 0) {
    const tail = (res.stderr || '').split('\n').slice(-25).join('\n');
    throw new Error(`${cmd} ${args.slice(0, 6).join(' ')} … exited ${res.status}\n${tail}`);
  }
  return res;
}

function ffmpeg(args, opts) {
  return run('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', ...args], opts);
}

function probe(file) {
  const res = run('ffprobe', ['-v', 'error', '-print_format', 'json', '-show_format', '-show_streams', file]);
  return JSON.parse(res.stdout);
}

function duration(file) {
  return Number(probe(file).format.duration);
}

function readJSON(file) {
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function writeJSON(file, data) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(data, null, 2) + '\n');
}

function mkdirp(dir) {
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function chromePath() {
  const candidates = [
    process.env.CHROME_PATH,
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    '/Applications/Chromium.app/Contents/MacOS/Chromium',
    '/usr/bin/google-chrome',
    '/usr/bin/chromium',
    '/usr/bin/chromium-browser',
  ].filter(Boolean);
  return candidates.find(p => fs.existsSync(p)) || null;
}

// Parse "--key value" / "--flag" style args into an object.
function parseArgs(argv, booleans = []) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (!a.startsWith('--')) { out._.push(a); continue; }
    const key = a.slice(2);
    if (booleans.includes(key)) out[key] = true;
    else out[key] = argv[++i];
  }
  return out;
}

// A video directory holds storyboard.json; scripts accept the dir or the file.
function loadStoryboard(target) {
  if (!target) die('pass the video directory (the folder holding storyboard.json)');
  const file = fs.statSync(target).isDirectory() ? path.join(target, 'storyboard.json') : target;
  if (!fs.existsSync(file)) die(`no storyboard at ${file}`);
  const dir = path.dirname(path.resolve(file));
  const sb = readJSON(file);
  sb.pacing = { ...PACING, ...(sb.pacing || {}) };
  // Voice: the storyboard wins, then the workspace preferences, then the built-in default.
  sb.voice_declared = sb.voice || null;
  sb.voice = { ...loadPreferences(dir).voice, ...(sb.voice || {}) };
  // Ids and slugs become file names; reject anything that could escape the video dir.
  const SAFE = /^[a-z0-9][a-z0-9_-]*$/;
  if (!SAFE.test(sb.slug || '')) die(`storyboard slug "${sb.slug}" must match ${SAFE}`);
  for (const s of sb.scenes || []) {
    if (!SAFE.test(s.id || '')) die(`scene id "${s.id}" must match ${SAFE}`);
    normalizeNarration(s);
  }
  return { sb, dir, file };
}

// A narration item is a sentence string, or { text, pause, wait_for, before, outcome }.
// After this, scene.narration is always the sentence strings (what every script reads) and
// scene.narration_items holds the objects. A malformed narration is left for the lint to report.
function normalizeNarration(scene) {
  if (!Array.isArray(scene.narration)) { scene.narration_items = []; return scene; }
  const items = scene.narration.map(n => (typeof n === 'string' ? { text: n } : { ...(n || {}) }));
  const bad = items.findIndex(i => typeof i.text !== 'string' || !i.text.trim());
  if (bad >= 0) die(`${scene.id}: narration item ${bad} has no "text"`);
  scene.narration_items = items;
  scene.narration = items.map(i => i.text);
  return scene;
}

// Preferences for every video in a workspace (voice, demo policy, spend budget, approval flow).
function loadPreferences(videoDir) {
  const file = path.join(videoDir, '..', 'preferences.json');
  let user = {};
  if (fs.existsSync(file)) {
    try { user = readJSON(file); } catch (e) { die(`${file} is not valid JSON: ${e.message}`); }
  }
  const out = { file: fs.existsSync(file) ? file : null };
  for (const k of Object.keys(PREFERENCES)) {
    const d = PREFERENCES[k];
    out[k] = d && typeof d === 'object' ? { ...d, ...(user[k] || {}) } : (user[k] !== undefined ? user[k] : d);
  }
  return out;
}

function frames(seconds) {
  return Math.round(seconds * VIDEO.fps);
}

// Compare two PNG screenshots by pixels. Chrome's rasterizer can differ by a level or two on a
// few anti-aliased edge pixels between runs; that is noise, not nondeterministic motion.
function visiblyDifferent(pngA, pngB) {
  const decode = buf => spawnSync('ffmpeg', ['-v', 'error', '-f', 'png_pipe', '-i', '-', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'],
    { input: buf, maxBuffer: 1 << 26 }).stdout;
  const a = decode(pngA), b = decode(pngB);
  if (!a || !b || a.length !== b.length) return { different: true, changed: -1, maxDelta: 255 };
  let changed = 0, maxDelta = 0;
  for (let i = 0; i < a.length; i++) {
    const d = Math.abs(a[i] - b[i]);
    if (d) { changed++; if (d > maxDelta) maxDelta = d; }
  }
  return { different: maxDelta > 16 || changed > 2000, changed, maxDelta };
}

function sha1(...parts) {
  const h = require('crypto').createHash('sha1');
  for (const p of parts) h.update(typeof p === 'string' || Buffer.isBuffer(p) ? p : JSON.stringify(p)).update('\0');
  return h.digest('hex');
}

// One line of an ffconcat list; single quotes in paths must be escaped as '\''.
function ffconcatLine(p) {
  return `file '${String(p).replace(/'/g, "'\\''")}'`;
}

// Round a duration up to a whole number of frames so clips and audio line up exactly.
function frameAlign(seconds) {
  return Math.ceil(seconds * VIDEO.fps - 1e-6) / VIDEO.fps;
}

function fmtSrtTime(t) {
  const ms = Math.round(t * 1000);
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  const r = ms % 1000;
  const p = (n, w = 2) => String(n).padStart(w, '0');
  return `${p(h)}:${p(m)}:${p(s)},${p(r, 3)}`;
}

function fmtChapterTime(t) {
  const s = Math.floor(t);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return h > 0
    ? `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`
    : `${m}:${String(sec).padStart(2, '0')}`;
}

// ---- WAV mixing -------------------------------------------------------------
// Narration is placed sample-accurately into one PCM master track. This avoids
// the AAC priming/remainder drift that per-scene AAC concat causes.

// Decode any audio file to mono 16-bit PCM at AUDIO_RATE.
function decodePcm(file) {
  const res = spawnSync('ffmpeg', ['-v', 'error', '-i', file, '-f', 's16le', '-ac', '1', '-ar', String(AUDIO_RATE), '-'],
    { maxBuffer: 1 << 30 });
  if (res.status !== 0) throw new Error(`could not decode ${file}: ${res.stderr}`);
  const buf = res.stdout;
  return new Int16Array(buf.buffer, buf.byteOffset, buf.length / 2);
}

function writeWav(file, samples, rate = AUDIO_RATE) {
  const header = Buffer.alloc(44);
  const dataBytes = samples.length * 2;
  header.write('RIFF', 0);
  header.writeUInt32LE(36 + dataBytes, 4);
  header.write('WAVE', 8);
  header.write('fmt ', 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20);
  header.writeUInt16LE(1, 22);
  header.writeUInt32LE(rate, 24);
  header.writeUInt32LE(rate * 2, 28);
  header.writeUInt16LE(2, 32);
  header.writeUInt16LE(16, 34);
  header.write('data', 36);
  header.writeUInt32LE(dataBytes, 40);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, Buffer.concat([header, Buffer.from(samples.buffer, samples.byteOffset, dataBytes)]));
}

// placements: [{ file, at }] where `at` is seconds. Returns an Int16Array of `total` seconds.
function mixTrack(placements, total) {
  const out = new Int16Array(Math.round(total * AUDIO_RATE));
  for (const { file, at } of placements) {
    const pcm = decodePcm(file);
    const start = Math.round(at * AUDIO_RATE);
    for (let i = 0; i < pcm.length && start + i < out.length; i++) {
      const v = out[start + i] + pcm[i];
      out[start + i] = v > 32767 ? 32767 : v < -32768 ? -32768 : v;
    }
  }
  return out;
}

// Two-pass EBU R128 loudness normalization to YouTube's ~-14 LUFS.
function loudnorm(input, output) {
  const target = 'I=-14:TP=-1:LRA=11';
  const pass1 = spawnSync('ffmpeg', ['-hide_banner', '-i', input, '-af', `loudnorm=${target}:print_format=json`, '-f', 'null', '-'],
    { encoding: 'utf8', maxBuffer: 1 << 26 });
  if (pass1.error || pass1.status !== 0) throw new Error(`loudnorm measurement failed: ${pass1.error || (pass1.stderr || '').slice(-400)}`);
  const m = (pass1.stderr || '').match(/\{[\s\S]*?"input_i"[\s\S]*?\}/);
  if (!m) throw new Error('loudnorm measurement failed: no JSON in ffmpeg output');
  const j = JSON.parse(m[0]);
  if (!Number.isFinite(Number(j.input_i)) || !Number.isFinite(Number(j.target_offset))) {
    // Silent track (no narration): nothing to normalize, just convert.
    ffmpeg(['-i', input, '-ar', String(AUDIO_RATE), '-ac', '2', '-c:a', 'pcm_s16le', output]);
    return;
  }
  const af = `loudnorm=${target}:measured_I=${j.input_i}:measured_TP=${j.input_tp}:measured_LRA=${j.input_lra}` +
    `:measured_thresh=${j.input_thresh}:offset=${j.target_offset}:linear=true`;
  ffmpeg(['-i', input, '-af', af, '-ar', String(AUDIO_RATE), '-ac', '2', '-c:a', 'pcm_s16le', output]);
}

// Normalize any video into the house spec (video only), fitted/padded to 1920x1080.
function normalizeVf(bg = '#fdf6e3') { // letterbox in Solarized paper (base3)
  const { width: w, height: h, fps } = VIDEO;
  return `scale=${w}:${h}:force_original_aspect_ratio=decrease,pad=${w}:${h}:(ow-iw)/2:(oh-ih)/2:color=${bg},` +
    `fps=${fps},format=yuv420p,setsar=1`;
}

// Hold a still image for `seconds` as a house-spec clip.
function stillToClip(png, seconds, out) {
  // Exact frame count, not -t: a time trim can leave the clip a fraction of a frame short.
  ffmpeg(['-loop', '1', '-framerate', String(VIDEO.fps), '-i', png, '-frames:v', String(frames(seconds)),
    '-vf', normalizeVf(), ...ENCODE, out]);
}

// A poster frame: the still a page shows before the video plays (a teach-me lesson page looks
// for poster.png beside <stem>.mp4). `at` is seconds into the finished video.
function writePoster(videoFile, at, out) {
  ffmpeg(['-ss', Math.max(0, at).toFixed(2), '-i', videoFile, '-frames:v', '1', out]);
  return out;
}

const ENCODE = ['-c:v', 'libx264', '-preset', 'medium', '-crf', String(VIDEO.crf), '-pix_fmt', 'yuv420p',
  '-r', String(VIDEO.fps), '-video_track_timescale', '30000', '-an'];

module.exports = {
  SCRIPTS_DIR, SKILL_DIR, ASSETS_DIR, STATE_DIR, VENV_DIR, VENV_PY, TTS_CACHE_DIR, MODELS_DIR,
  LEGACY_VENV_DIR, LEGACY_TTS_CACHE_DIR, PREFERENCES, VIDEO, AUDIO_RATE, PACING, ENCODE,
  die, run, ffmpeg, probe, duration, readJSON, writeJSON, mkdirp, chromePath, parseArgs,
  loadStoryboard, loadPreferences, normalizeNarration, frameAlign, fmtSrtTime, fmtChapterTime, decodePcm, writeWav, mixTrack, loudnorm, normalizeVf,
  stillToClip, frames, sha1, ffconcatLine, visiblyDifferent, writePoster,
};
