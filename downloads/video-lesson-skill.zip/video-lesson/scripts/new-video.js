#!/usr/bin/env node
/**
 * Scaffold a video folder from the skill's templates.
 *
 * Usage:
 *   node new-video.js --out <dir> --title "First run" [--slug 0001-first-run]
 *        [--source path/to/lesson.html] [--kind lesson|intro|outro|bridges] [--lesson 3]
 *        [--voice af_heart] [--speed 1.1] [--force]
 *
 * The voice and speed come from the workspace preferences (<dir>/../preferences.json);
 * pass --voice / --speed only when this one video should differ.
 *
 * Creates:
 *   <dir>/storyboard.json   narrative plan and scene list (fill in)
 *   <dir>/script.md         narration script for review (fill in)
 *   <dir>/_theme/           theme.css, vl-runtime.js, fonts/ (Solarized Technical Essay)
 *   <dir>/scenes/ tapes/ manim/   (scene HTML starts from assets/layouts/*.html)
 * Refuses to overwrite an existing storyboard.json unless --force.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const L = require('./lib');

function fill(template, values) {
  return template.replace(/\{\{([A-Z0-9_]+)\}\}/g, (m, k) => (k in values ? values[k] : m));
}

// The theme travels with each video: CSS, motion runtime, and the bundled fonts.
function copyTheme(dir) {
  const t = L.mkdirp(path.join(dir, '_theme'));
  fs.copyFileSync(path.join(L.ASSETS_DIR, 'theme.css'), path.join(t, 'theme.css'));
  fs.copyFileSync(path.join(L.ASSETS_DIR, 'vl-runtime.js'), path.join(t, 'vl-runtime.js'));
  fs.cpSync(path.join(L.ASSETS_DIR, 'fonts'), path.join(t, 'fonts'), { recursive: true });
}

function slugify(s) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 60);
}

function main() {
  const args = L.parseArgs(process.argv.slice(2), ['force']);
  if (!args.out || !args.title) L.die('usage: new-video.js --out <dir> --title "Title" [--slug s] [--source file]');
  const dir = path.resolve(args.out);
  const sbFile = path.join(dir, 'storyboard.json');
  if (fs.existsSync(sbFile) && !args.force) L.die(`${sbFile} exists; pass --force to overwrite`);

  const slug = args.slug || (args.source ? path.basename(args.source).replace(/\.[^.]+$/, '') : slugify(args.title));
  const values = {
    TITLE: args.title.replace(/"/g, '\\"'),
    SLUG: slug,
    SOURCE: args.source ? path.resolve(args.source) : '',
    KIND: args.kind || 'lesson',
    DATE: new Date().toISOString().slice(0, 10),
  };

  for (const sub of ['scenes', 'tapes', 'manim', '_theme']) L.mkdirp(path.join(dir, sub));
  const read = f => fs.readFileSync(path.join(L.ASSETS_DIR, f), 'utf8');
  // The voice comes from the workspace preferences (<dir>/../preferences.json), so a storyboard
  // carries a "voice" block only when this one video should differ (--voice / --speed).
  const sb = JSON.parse(fill(read('storyboard.template.json'), values));
  if (args.voice || args.speed) {
    sb.voice = { ...(args.voice ? { voice: args.voice } : {}), ...(args.speed ? { speed: Number(args.speed) } : {}) };
  }
  if (args.lesson) sb.lesson_number = Number(args.lesson);
  L.writeJSON(sbFile, sb);
  fs.writeFileSync(path.join(dir, 'script.md'), fill(read('script.template.md'), values));
  copyTheme(dir);

  const prefs = L.loadPreferences(dir);
  console.log(JSON.stringify({ dir, slug, storyboard: sbFile, script: path.join(dir, 'script.md'),
    preferences: prefs.file, voice: { ...prefs.voice, ...(sb.voice || {}) } }, null, 2));
}

main();
