#!/usr/bin/env node
/**
 * One audition page for every word the narrator might get wrong, and the ledger of words the
 * user has approved. The agent cannot hear; this is how the user's ears get used once per word.
 *
 * Build the page (static HTML + a clips/ folder; opened from disk, no server):
 *   node pronunciation-review.js <video-dir>              -> <video-dir>/auditions/review/index.html
 *   node pronunciation-review.js --course <workspace>/videos   one page for every video, each word once
 *                                                         -> <workspace>/videos/auditions/review/index.html
 *   node pronunciation-review.js --text "A sentence." [--text "Another."] [--video <video-dir>] --out DIR
 *                                                         audition sentences that are not in a storyboard
 *   Options:
 *     --alt "dir=dur|deer|/dˈɪɹ/"   candidates for one word, rendered side by side (repeatable). Each is a
 *                                   lexicon value: a respelling or /phonemes/. The word is added to the page.
 *     --include eval,rubric         also audition these words (jargon, preference words the dictionary knows)
 *     --tiers fallback,person       only these reasons (person, fallback, identifier, heteronym, lexicon,
 *                                   acronym, number, proper-noun, requested)
 *     --all                         include words already approved in the ledger
 *     --max-contexts 3              sentences played for each reading of a two-pronunciation word, one card
 *                                   each (default 1: the agent judges the other sentences from the text)
 *     --transcripts DIR             where `tts.py --transcribe --out` wrote (DIR/<slug>/transcript.json or
 *                                   DIR/transcript.json); default <video-dir>/audio/transcript.json
 *     --out DIR                     write the page somewhere else
 *     --no-synth                    reuse existing clips only; never run the voice model
 *     --open                        open the page in the browser when done
 *
 * Record the user's answers (the page copies them to the clipboard or downloads them):
 *   node pronunciation-review.js --import results.json [--course <workspace>/videos | <video-dir>] [--apply]
 *     Approved words go to <workspace>/videos/pronunciation-ledger.json. Prints the words marked wrong with
 *     their notes, and the lexicon changes the user chose. --apply writes those to the workspace lexicon.
 *
 * Words with two pronunciations ("read", "live") are judged by context, not by ear:
 *   node pronunciation-review.js --heteronyms <video-dir> | --course DIR
 *     Prints a results file with every use not yet judged. Fill in "verdict" ("right" or "wrong") and a
 *     "note" for each, save it, and --import it. "wrong" ones are yours to fix by rewriting the sentence.
 *
 * Prints JSON on stdout, diagnostics on stderr.
 */
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const L = require('./lib');

const TTS = path.join(L.SCRIPTS_DIR, 'tts.py');
const TEMPLATE = path.join(L.ASSETS_DIR, 'pronunciation-review.html');
const LEDGER_NAME = 'pronunciation-ledger.json';
const RESULTS_KIND = 'pronunciation-review-results';
const TIERS = [
  { id: 'person', short: 'People', title: 'People’s names', why: 'Looks like a person’s name',
    blurb: 'A person’s name is never narrated until you have confirmed how it sounds. If one of these is not a person, confirm it anyway and it will not come back.' },
  { id: 'fallback', short: 'Not in the dictionary', title: 'Not in the voice’s dictionary', why: 'Not in the dictionary: the pronunciation is a guess from the spelling',
    blurb: 'The voice has no entry for these, so it guessed from the spelling. These are the most likely to be wrong.' },
  { id: 'identifier', short: 'Code', title: 'Code, flags, paths and file names', why: 'Code or a file name',
    blurb: 'Usually better rewritten in spoken form. Mark it wrong and say how you would read it aloud.' },
  { id: 'heteronym', short: 'Two pronunciations', title: 'Words with two pronunciations', why: 'Two pronunciations: the right one depends on the sentence',
    blurb: 'The voice picks a reading from the grammar of the sentence and is sometimes wrong (“read” as “red”). Listen for the right one in each sentence.' },
  { id: 'lexicon', short: 'Lexicon', title: 'Said through a lexicon entry', why: 'Said through a lexicon entry',
    blurb: 'Someone already chose how to say these. Confirm each once and it is never asked again.' },
  { id: 'acronym', short: 'Acronyms', title: 'Acronyms and letters', why: 'Letters or an acronym',
    blurb: 'Should it be spelled out, or said as a word?' },
  { id: 'number', short: 'Numbers', title: 'Numbers, versions and symbols', why: 'A number or symbol',
    blurb: 'Check how the figure is read.' },
  { id: 'proper-noun', short: 'Names', title: 'Other names', why: 'A name',
    blurb: 'Names the dictionary knows. Usually right; confirm once.' },
  { id: 'requested', short: 'Requested', title: 'Added for review', why: 'Added for review',
    blurb: 'Words the dictionary knows that were put here on purpose: jargon and words you may want said differently.' },
];

// ---- arguments ---------------------------------------------------------------

function parse(argv) {
  const flags = ['all', 'no-synth', 'open', 'apply', 'heteronyms', 'help'];
  const repeat = ['alt', 'text'];
  const a = { _: [], alt: [], text: [] };
  for (let i = 0; i < argv.length; i++) {
    const t = argv[i];
    if (t === '-h') { a.help = true; continue; }
    if (!t.startsWith('--')) { a._.push(t); continue; }
    const k = t.slice(2);
    if (flags.includes(k)) a[k] = true;
    else if (i + 1 >= argv.length) L.die(`--${k} needs a value`);
    else if (repeat.includes(k)) a[k].push(argv[++i]);
    else a[k] = argv[++i];
  }
  return a;
}

function usage() {
  const src = fs.readFileSync(__filename, 'utf8');
  console.log(src.slice(src.indexOf('/**') + 3, src.indexOf('*/')).replace(/^ \* ?/gm, '').trim());
}

// The same rules as tts.py clean_word()/word_key()/norm_ph(), so keys agree across the two.
const EDGE = ' \t\n"“”‘’\'()[]{}<>*`';
function strip(s, chars, left = true, right = true) {
  let a = 0, b = s.length;
  if (left) while (a < b && chars.includes(s[a])) a++;
  if (right) while (b > a && chars.includes(s[b - 1])) b--;
  return s.slice(a, b);
}
function cleanWord(w) {
  w = strip(strip(strip(String(w), EDGE), '.,;:!?…—–-', false, true), '—–', true, false);
  return strip(w, EDGE);
}
const wordKey = w => cleanWord(w).toLowerCase().replace(/['’]s$/, '');
const normPh = p => String(p || '').replace(/ˌ/g, '').replace(/T/g, 'ɾ').trim();
const today = () => { const d = new Date(), p = n => String(n).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`; };

function py(args, what) {
  if (!fs.existsSync(L.VENV_PY)) L.die('the narration environment is not set up: ask the user, then run `node setup.js --yes`');
  const res = spawnSync(L.VENV_PY, [TTS, ...args], { encoding: 'utf8', maxBuffer: 1 << 28 });
  if (res.status !== 0) {
    L.die(`${what} failed (tts.py ${args.slice(0, 3).join(' ')} … exited ${res.status})\n${(res.stderr || '').split('\n').slice(-12).join('\n')}`);
  }
  try { return JSON.parse(res.stdout); } catch (e) { L.die(`${what}: tts.py did not print JSON (${e.message})`); }
}

function isVideoDir(d) { return fs.existsSync(path.join(d, 'storyboard.json')); }

function courseVideos(root) {
  if (!fs.existsSync(root) || !fs.statSync(root).isDirectory()) L.die(`${root} is not a directory`);
  const dirs = fs.readdirSync(root).filter(n => !n.startsWith('_') && !n.startsWith('.'))
    .map(n => path.join(root, n)).filter(d => fs.statSync(d).isDirectory() && isVideoDir(d)).sort();
  if (!dirs.length) L.die(`no video directories (folders with storyboard.json) under ${root}`);
  return dirs;
}

function parseAlts(list) {
  // "dir=dur|deer|/dˈɪɹ/"; the word itself may start with "=" (an exact-case key such as "=A").
  return list.map(spec => {
    const at = spec.indexOf('=', 1);
    if (at < 0) L.die(`--alt "${spec}": expected word=candidate|candidate`);
    const word = spec.slice(0, at).trim();
    const candidates = spec.slice(at + 1).split('|').map(s => s.trim()).filter(Boolean);
    if (!word || !candidates.length) L.die(`--alt "${spec}": expected word=candidate|candidate`);
    return { word, key: wordKey(word.replace(/^=/, '')), candidates };
  });
}

// ---- build -------------------------------------------------------------------

function analyze(videoDir, a, include) {
  const args = ['--analyze', videoDir, '--json'];
  if (a.all) args.push('--all');
  if (include.length) args.push('--include', include.join(','));
  return py(args, `analysis of ${path.basename(videoDir)}`);
}

function existingClips(videoDir) {
  const file = path.join(videoDir, 'audio', 'timings.json');
  const map = new Map();
  if (!fs.existsSync(file)) return map;
  let timings;
  try { timings = L.readJSON(file); } catch { return map; }
  for (const [scene, clips] of Object.entries(timings.scenes || {})) {
    for (const c of clips) map.set(`${scene}/${c.i}`, c);
  }
  return map;
}

function loadTranscript(videoDir, slug, dir) {
  const candidates = dir
    ? [path.join(dir, slug || '', 'transcript.json'), path.join(dir, path.basename(videoDir), 'transcript.json'), path.join(dir, 'transcript.json')]
    : [path.join(videoDir, 'audio', 'transcript.json')];
  const map = new Map();
  for (const f of candidates) {
    if (!fs.existsSync(f)) continue;
    try {
      const t = L.readJSON(f);
      if (dir && t.video && path.resolve(t.video) !== path.resolve(videoDir)) continue;
      for (const s of t.sentences || []) map.set(`${s.scene}/${s.i}`, s);
      break;
    } catch { /* unreadable transcript: show the page without it */ }
  }
  return map;
}

function build(a) {
  const alts = parseAlts(a.alt);
  const include = [...new Set([...(a.include ? a.include.split(',') : []), ...alts.map(x => x.word.replace(/^=/, ''))].map(s => s.trim()).filter(Boolean))];
  const tiers = a.tiers ? a.tiers.split(',').map(s => s.trim()) : null;
  const maxContexts = Math.max(1, Number(a['max-contexts'] || 1));
  let scope, analyses, root, outDir, title;

  if (a.text.length) {
    const video = a.video ? path.resolve(a.video) : null;
    if (video && !isVideoDir(video)) L.die(`${video} has no storyboard.json`);
    if (!a.out) L.die('--text needs --out DIR (there is no video directory to put the page in)');
    const args = ['--analyze', '--say', a.text.join('\n'), '--json'];
    if (video) args.push('--video', video);
    if (a.all) args.push('--all');
    if (include.length) args.push('--include', include.join(','));
    const res = py(args, 'analysis');
    res.video = video; // sentences are synthesized with this video's voice and lexicons, or the defaults
    res.adhoc = true;
    analyses = [res];
    scope = { kind: 'text', root: video ? path.dirname(video) : null };
    root = scope.root;
    outDir = path.resolve(a.out);
    title = 'Sample sentences';
  } else if (a.course) {
    root = path.resolve(a.course);
    const dirs = courseVideos(root);
    analyses = dirs.map(d => analyze(d, a, include));
    scope = { kind: 'course', root, videos: analyses.map(x => x.slug) };
    outDir = path.resolve(a.out || path.join(root, 'auditions', 'review'));
    title = `${path.basename(path.dirname(root))} course`;
  } else {
    const dir = a._[0] && path.resolve(a._[0]);
    if (!dir) { usage(); process.exit(1); }
    if (!isVideoDir(dir)) L.die(`${dir} has no storyboard.json (pass a video directory, --course, or --text)`);
    const res = analyze(dir, a, include);
    analyses = [res];
    root = path.dirname(dir);
    scope = { kind: 'video', root, videos: [res.slug] };
    outDir = path.resolve(a.out || path.join(dir, 'auditions', 'review'));
    title = res.title || res.slug;
  }

  // One row per doubtful word across every video.
  const rows = new Map();
  for (const an of analyses) {
    const ttsText = new Map(an.sentences.map(s => [`${s.scene}/${s.i}`, s]));
    const clips = an.video && !an.adhoc ? existingClips(an.video) : new Map();
    const heard = an.video && !an.adhoc ? loadTranscript(an.video, an.slug, a.transcripts && path.resolve(a.transcripts)) : new Map();
    for (const it of an.doubtful) {
      const wanted = a.all || it.needs.includes('ear') || it.reasons.includes('requested');
      if (!wanted || (tiers && !tiers.includes(it.tier))) continue;
      let row = rows.get(it.id);
      if (!row) {
        row = { ...it, count: 0, videos: [], occurrences: [] };
        rows.set(it.id, row);
      }
      row.count += it.count;
      if (an.slug && !row.videos.includes(an.slug)) row.videos.push(an.slug);
      for (const o of it.occurrences) {
        const id = `${o.scene}/${o.i}`;
        const s = ttsText.get(id) || {};
        const clip = clips.get(id);
        const reuse = clip && clip.text === o.sentence && clip.tts_text === s.tts_text && fs.existsSync(path.join(an.video, clip.file))
          ? path.join(an.video, clip.file) : null;
        const t = heard.get(id);
        row.occurrences.push({ ...o, video: an.video, slug: an.slug || null, speed: s.speed, reuse,
          heard: t && t.text === o.sentence ? t : null });
      }
    }
  }

  // Choose the sentences to play, and plan the clips.
  fs.mkdirSync(path.join(outDir, 'clips'), { recursive: true });
  const requests = [];
  const list = [...rows.values()].sort((x, y) => TIERS.findIndex(t => t.id === x.tier) - TIERS.findIndex(t => t.id === y.tier)
    || y.count - x.count || x.key.localeCompare(y.key));
  let reused = 0;
  const pageRows = list.map((row, n) => {
    const seen = new Set();
    const unique = row.occurrences.filter(o => !seen.has(o.sentence) && seen.add(o.sentence));
    unique.sort((x, y) => (y.reuse ? 1 : 0) - (x.reuse ? 1 : 0) || x.sentence.length - y.sentence.length);
    const shown = unique.slice(0, row.tier === 'heteronym' ? maxContexts : 1);
    const contexts = shown.map((o, c) => {
      const name = `w${String(n + 1).padStart(3, '0')}-c${c}`;
      let clip = null;
      if (o.reuse) {
        fs.copyFileSync(o.reuse, path.join(outDir, 'clips', `${name}.wav`));
        clip = `clips/${name}.wav`;
        reused++;
      } else if (!a['no-synth']) {
        requests.push({ id: name, text: o.sentence, video: o.video || undefined, speed: o.speed || undefined });
        clip = `clips/${name}.wav`;
      }
      const flag = !!(o.heard && (o.heard.mismatches || []).some(m => m.expected.split(' ').some(w => wordKey(w) === row.key)));
      return { video: o.slug, scene: o.scene, i: o.i, sentence: o.sentence, phonemes: o.phonemes, clip,
        heard: o.heard ? o.heard.heard : null, heard_flag: flag };
    });

    // Alternatives: what the video says now, the word as written (when a lexicon entry is in
    // force), and any candidates passed with --alt.
    const first = shown[0];
    const alternatives = [];
    const supplied = alts.find(x => x.key === row.key);
    const lexKey = row.lexicon ? row.lexicon.key : null;
    if (first && !a['no-synth'] && (supplied || lexKey)) {
      const current = { id: 'current', label: row.spoken_as || (row.lexicon ? String(valueOf(row.lexicon.value)) : `${row.word} (as written)`),
        current: true, clip: contexts[0].clip, rendering: row.spoken_as || row.word, phonemes: row.phonemes, sounds_like: row.sounds_like,
        lexicon_key: lexKey, value: row.lexicon ? row.lexicon.value : null };
      alternatives.push(current);
      const add = (label, key, value) => {
        const id = `a${alternatives.length}`;
        const name = `w${String(n + 1).padStart(3, '0')}-${id}`;
        requests.push({ id: name, text: first.sentence, video: first.video || undefined, speed: first.speed || undefined,
          override: { [key]: value }, focus: row.word });
        alternatives.push({ id, label, clip: `clips/${name}.wav`, request: name, lexicon_key: key, value, rendering: value === null ? row.word : value });
      };
      if (lexKey) add(`${row.word} (as written)`, lexKey, null);
      for (const cand of supplied ? supplied.candidates : []) {
        if (lexKey && cand === valueOf(row.lexicon.value)) continue;
        add(cand, supplied.word.startsWith('=') ? supplied.word : (lexKey || row.word), cand);
      }
    }
    const tier = TIERS.find(t => t.id === row.tier) || TIERS[TIERS.length - 1];
    return {
      id: row.id, word: row.word, key: row.key, tier: row.tier, reasons: row.reasons, why: tier.why,
      says: { word_lower: row.word.toLowerCase(), spoken_as: row.spoken_as || null, sounds_like: row.sounds_like, phonemes: row.phonemes, source: row.source },
      cue: listenerCue(row),
      count: row.count, videos: row.videos, contexts, more_contexts: Math.max(0, unique.length - shown.length), alternatives,
    };
  });

  // A word with two pronunciations is judged sentence by sentence ("red" can be right in one
  // and wrong in the next), so each sentence gets a card of its own.
  for (let n = pageRows.length - 1; n >= 0; n--) {
    const row = pageRows[n];
    if (row.tier !== 'heteronym' || row.contexts.length < 2) continue;
    const cards = row.contexts.map((c, k) => ({ ...row, id: `${row.id}#${k}`, contexts: [c],
      more_contexts: k === row.contexts.length - 1 ? row.more_contexts : 0, alternatives: k === 0 ? row.alternatives : [] }));
    pageRows.splice(n, 1, ...cards);
  }

  // Synthesize what is missing, in one process.
  let synthesized = 0;
  const failed = [];
  if (requests.length) {
    const reqFile = path.join(os.tmpdir(), `pronunciation-review-${process.pid}.json`);
    fs.writeFileSync(reqFile, JSON.stringify(requests));
    console.error(`synthesizing ${requests.length} clip(s)…`);
    const res = py(['--say-batch', reqFile, '--out', path.join(outDir, 'clips')], 'synthesis');
    fs.rmSync(reqFile, { force: true });
    const byId = new Map(res.map(r => [r.id, r]));
    for (const row of pageRows) {
      for (const c of row.contexts) {
        const r = c.clip && byId.get(path.basename(c.clip, '.wav'));
        if (r && r.error) { failed.push({ word: row.word, error: r.error }); c.clip = null; } else if (r) synthesized++;
      }
      for (const alt of row.alternatives) {
        const r = alt.request && byId.get(alt.request);
        delete alt.request;
        if (!r) continue;
        if (r.error) { failed.push({ word: row.word, alternative: alt.label, error: r.error }); alt.clip = null; continue; }
        synthesized++;
        if (r.focus) { alt.phonemes = r.focus.phonemes; alt.sounds_like = r.focus.sounds_like; }
      }
      // An alternative that comes out as the same sounds is not a choice.
      const cur = row.alternatives.find(x => x.current);
      const exact = ph => String(ph || '').replace(/T/g, 'ɾ');
      row.alternatives = row.alternatives.filter(x => x.current || !x.clip || !cur || exact(x.phonemes) !== exact(cur.phonemes));
      if (row.alternatives.length < 2) row.alternatives = [];
    }
  }

  const ledger = root ? path.join(root, LEDGER_NAME) : null;
  const voices = [...new Set(analyses.map(x => x.voice))];
  const importCmd = `node ${path.join(L.SCRIPTS_DIR, 'pronunciation-review.js')} --import <results file>` +
    (scope.kind === 'course' ? ` --course ${root}` : scope.kind === 'video' ? ` ${path.join(root, scope.videos[0])}` : (a.video ? ` ${path.resolve(a.video)}` : ''));
  const data = {
    title, generated: new Date().toISOString(), scope, ledger, voice: voices.join(', '),
    subtitle: `${title} · ${pageRows.length} to check · voice ${voices.join(', ')}` +
      (scope.kind === 'course' ? ` · ${analyses.length} videos` : ''),
    storage_key: L.sha1(outDir).slice(0, 12), results_file: 'pronunciation-results.json', import_command: importCmd,
    tiers: TIERS.map(({ id, short, title: t, blurb }) => ({ id, short, title: t, blurb })), rows: pageRows,
  };
  const page = fs.readFileSync(TEMPLATE, 'utf8').replace('{{DATA}}', () => JSON.stringify(data).replace(/</g, '\\u003c'));
  const index = path.join(outDir, 'index.html');
  fs.writeFileSync(index, page);
  if (a.open) spawnSync('open', [index]);

  const byTier = {};
  for (const r of pageRows) byTier[r.tier] = (byTier[r.tier] || 0) + 1;
  console.log(JSON.stringify({
    page: index, cards: pageRows.length, words: new Set(pageRows.map(r => r.key)).size, by_tier: byTier, clips_reused: reused, clips_synthesized: synthesized,
    without_clip: pageRows.filter(r => r.contexts.some(c => !c.clip)).map(r => r.word), failed,
    ledger, people: analyses.flatMap(x => x.people.map(p => ({ ...p, video: x.slug }))),
    heteronyms_unjudged: analyses.reduce((n, x) => n + x.summary.heteronyms_unjudged, 0),
    next: `Open the page for the user. When they give you the results, run: ${importCmd}`,
  }, null, 2));
}

// What to listen for, in the listener's words (the analysis cue is written for the agent).
function listenerCue(row) {
  const h = row.heteronym;
  if (!h) return null;
  if (!h.chosen) return 'This word has two pronunciations and the analysis could not tell which one the voice will use. Listen for it.';
  const others = h.variants.filter(v => v.phonemes !== h.chosen).map(v => `“${v.sounds_like}” (${v.when})`);
  return `This reading is right for ${h.when}. The other reading is ${others.join(' or ')}.`;
}

function valueOf(v) {
  return v && typeof v === 'object' ? (v.us || Object.values(v)[0]) : v;
}

// ---- heteronyms: a results file for the agent to fill in --------------------------

function heteronyms(a) {
  const dirs = a.course ? courseVideos(path.resolve(a.course)) : [a._[0] && path.resolve(a._[0])];
  if (!dirs[0] || !isVideoDir(dirs[0])) L.die('--heteronyms needs a video directory or --course DIR');
  const root = path.dirname(dirs[0]);
  const results = [];
  for (const d of dirs) {
    const an = analyze(d, {}, []);
    for (const h of an.heteronyms) {
      if (h.judged) continue;
      results.push({ word: h.word, video: an.slug, scene: h.scene, i: h.i, sentence: h.sentence, phonemes: h.phonemes,
        voice_will_say: h.sounds_like, right_when: h.when, tagged: h.tag, verdict: null, note: '' });
    }
  }
  console.log(JSON.stringify({
    kind: RESULTS_KIND, version: 1, by: 'agent',
    how: 'For each use, read the sentence and decide whether "voice_will_say" is the right reading there. Set verdict to "right" or "wrong" and say why in note. Rewrite the sentences you mark wrong, then import this file.',
    page: { ledger: path.join(root, LEDGER_NAME) }, results,
  }, null, 2));
}

// ---- import ------------------------------------------------------------------

function importResults(a) {
  const file = path.resolve(a.import);
  if (!fs.existsSync(file)) L.die(`no results file at ${file}`);
  let res;
  try { res = L.readJSON(file); } catch (e) { L.die(`${file} is not valid JSON: ${e.message}`); }
  if (res.kind !== RESULTS_KIND || !Array.isArray(res.results)) L.die(`${file} is not a pronunciation results file (kind "${RESULTS_KIND}")`);
  let ledgerFile = a.ledger ? path.resolve(a.ledger)
    : a.course ? path.join(path.resolve(a.course), LEDGER_NAME)
    : a._[0] ? path.join(path.dirname(path.resolve(a._[0])), LEDGER_NAME)
    : res.page && res.page.ledger;
  if (!ledgerFile) L.die('where is the ledger? Pass --course <workspace>/videos, a video directory, or --ledger FILE');
  if (!fs.existsSync(path.dirname(ledgerFile))) L.die(`${path.dirname(ledgerFile)} does not exist`);
  const by = a.by || res.by || 'user';
  const ledger = fs.existsSync(ledgerFile) ? L.readJSON(ledgerFile) : {};
  ledger._about = 'Pronunciations the user has approved by ear ("approved") and uses of two-pronunciation words judged in ' +
    'context ("contexts"), for every video in this folder. Written by pronunciation-review.js --import; tts.py --analyze ' +
    'leaves approved words out. Keys are lower-case words.';
  ledger.version = 1;
  ledger.words = ledger.words || {};
  const date = today();
  const out = { ledger: ledgerFile, by, approved: [], contexts_judged: 0, wrong: [], lexicon_changes: [], applied: [], unanswered: res.unanswered || 0, skipped: [] };

  for (const r of res.results) {
    const key = r.key || wordKey(r.word || '');
    const contexts = r.contexts || (r.sentence ? [{ video: r.video, scene: r.scene, i: r.i, sentence: r.sentence, phonemes: r.phonemes }] : []);
    if (!key || !r.verdict) { if (key) out.skipped.push(r.word); continue; }
    if (r.verdict === 'wrong') {
      out.wrong.push({ word: r.word, tier: r.tier || 'heteronym', note: r.note || '', said: r.rendering || r.voice_will_say || null,
        phonemes: r.phonemes || null, where: contexts.map(c => ({ video: c.video, scene: c.scene, i: c.i, sentence: c.sentence })) });
      continue;
    }
    if (r.verdict !== 'right') { out.skipped.push(r.word); continue; }
    const entry = ledger.words[key] = ledger.words[key] || { word: r.word };
    if (by === 'user') {
      if (r.choice && !r.choice.current) {
        out.lexicon_changes.push({ word: r.choice.lexicon_key || r.word, value: r.choice.value === undefined ? null : r.choice.value, label: r.choice.label });
      }
      // The user heard it: record the sound that was approved.
      if (!r.phonemes) { out.skipped.push(r.word); continue; }
      entry.approved = (entry.approved || []).filter(x => !(normPh(x.phonemes) === normPh(r.phonemes) && (x.by || 'user') === 'user'));
      const rec = { phonemes: r.phonemes, rendering: r.rendering || r.word, by: 'user', date };
      const c0 = contexts[0];
      if (c0 && c0.video) rec.video = c0.video;
      if (res.page && res.page.voice) rec.voice = res.page.voice;
      if (r.note) rec.note = r.note;
      entry.approved.push(rec);
      out.approved.push({ word: r.word, rendering: rec.rendering, phonemes: rec.phonemes });
    }
    // Uses judged in context (the user's ear also settles the sentences they heard).
    const judgeable = (r.tier || 'heteronym') === 'heteronym';
    for (const c of judgeable && !(r.choice && !r.choice.current) ? contexts : []) {
      const ph = c.phonemes || r.phonemes;
      if (!c.sentence || !ph) continue;
      entry.contexts = (entry.contexts || []).filter(x => !(x.sentence === c.sentence && normPh(x.phonemes) === normPh(ph)));
      const rec = { sentence: c.sentence, phonemes: ph, by, date };
      if (r.note) rec.note = r.note;
      entry.contexts.push(rec);
      out.contexts_judged++;
    }
  }

  if (a.apply && out.lexicon_changes.length) {
    const lexFile = path.join(path.dirname(ledgerFile), 'pronunciations.json');
    const lex = fs.existsSync(lexFile) ? L.readJSON(lexFile) : { _about: 'Course lexicon. Overrides the skill’s global lexicon; keys ignore case.' };
    const global = L.readJSON(path.join(L.ASSETS_DIR, 'pronunciations.json'));
    const fold = k => k.replace(/^=/, '').toLowerCase();
    for (const ch of out.lexicon_changes) {
      const exact = ch.word.startsWith('=');
      for (const k of Object.keys(lex)) {
        if (!k.startsWith('_') && fold(k) === fold(ch.word) && (exact ? k === ch.word : !k.startsWith('='))) delete lex[k];
      }
      const inGlobal = Object.keys(global).some(k => !k.startsWith('_') && fold(k) === fold(ch.word));
      if (ch.value !== null) lex[ch.word] = ch.value;
      else if (inGlobal) lex[ch.word] = null; // cancel the global entry: say it as written
      out.applied.push({ file: lexFile, word: ch.word, value: ch.value });
    }
    L.writeJSON(lexFile, lex);
  }
  L.writeJSON(ledgerFile, ledger);
  out.next = [
    out.wrong.length ? 'Fix each word under "wrong" (lexicon entry, or rewrite the sentence), then build the page again: only unapproved words come back.' : null,
    out.lexicon_changes.length && !a.apply ? 'The user chose different renderings (lexicon_changes): add them to the workspace pronunciations.json, or re-run with --apply.' : null,
    out.applied.length ? 'Lexicon updated: re-run tts.py for the videos that use those words.' : null,
  ].filter(Boolean);
  console.log(JSON.stringify(out, null, 2));
}

function main() {
  const a = parse(process.argv.slice(2));
  if (a.help) return usage();
  if (a.import) return importResults(a);
  if (a.heteronyms) return heteronyms(a);
  if (!a._.length && !a.course && !a.text.length) { usage(); process.exit(1); }
  build(a);
}

main();
