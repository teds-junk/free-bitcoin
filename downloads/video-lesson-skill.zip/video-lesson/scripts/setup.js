#!/usr/bin/env node
/**
 * One-time setup of the narration (and optional manim) environment. Machine-local state
 * lives outside the skill, in ~/.video-lesson/ (override with VIDEO_LESSON_HOME): venv/,
 * tts-cache/, models/. Safe to re-run; it skips what is already done, and it moves a venv
 * or narration cache left inside scripts/ by an older version of the skill.
 *
 * Usage:
 *   node setup.js --yes            # Kokoro TTS venv + puppeteer-core
 *   node setup.js --yes --manim    # also install manim (needs brew cairo pango pkg-config)
 *   node setup.js --yes --stt      # also download the speech-to-text model (about 150 MB) that
 *                                  # `tts.py --transcribe` uses to check narration; stored in
 *                                  # ~/.video-lesson/models/, never the Hugging Face cache
 *   node setup.js --yes --install-fonts  # copy the bundled TTFs to ~/Library/Fonts (terminal scenes)
 *   node setup.js --check    # print the setup report and exit; installs nothing
 *
 * Writes ~/.video-lesson/venv/setup-report.json on success.
 * Installing requires --yes, which the agent passes only after the user agreed: it downloads
 * several GB (torch, spaCy, Kokoro weights).
 */
'use strict';

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const { SCRIPTS_DIR, STATE_DIR, VENV_DIR, VENV_PY, TTS_CACHE_DIR, MODELS_DIR, LEGACY_VENV_DIR, LEGACY_TTS_CACHE_DIR, parseArgs, die } = require('./lib');

const PINS = {
  'mlx-audio': '0.6.3',
  'misaki[en]': '0.9.4',
  manim: '0.22.1',
};
const REPORT = path.join(VENV_DIR, 'setup-report.json');
const STT = JSON.parse(fs.readFileSync(path.join(SCRIPTS_DIR, 'stt-model.json'), 'utf8'));

// Is the speech-to-text model on disk? (Checked live: the report file only says what was true at setup.)
function sttStatus() {
  const dir = path.join(MODELS_DIR, STT.dir);
  const present = fs.existsSync(path.join(dir, 'config.json')) && fs.readdirSync(dir).some(n => n.endsWith('.safetensors'));
  return { present, model: STT.repo, dir, ...(present ? {} : { install: 'ask the user, then: node setup.js --yes --stt' }) };
}

function sh(cmd, args, opts = {}) {
  console.error(`$ ${cmd} ${args.join(' ')}`);
  const res = spawnSync(cmd, args, { stdio: 'inherit', ...opts });
  if (res.status !== 0) die(`${cmd} failed (exit ${res.status}). See output above.`);
}

function has(cmd) {
  return spawnSync('/bin/sh', ['-c', `command -v ${cmd}`]).status === 0;
}

function findPython() {
  for (const p of ['python3.12', '/opt/homebrew/opt/python@3.12/bin/python3.12']) {
    if (spawnSync(p, ['--version']).status === 0) return p;
  }
  return null;
}

// Older versions kept the venv and the narration cache inside scripts/. Move them (a rename on
// the same disk, a copy otherwise) so nothing is downloaded or synthesized again. A moved venv
// still works because every script calls its interpreter directly (python -m ...).
function migrateLegacy() {
  const moves = [[LEGACY_VENV_DIR, VENV_DIR], [LEGACY_TTS_CACHE_DIR, TTS_CACHE_DIR]];
  for (const [from, to] of moves) {
    if (!fs.existsSync(from) || fs.existsSync(to)) continue;
    fs.mkdirSync(STATE_DIR, { recursive: true });
    try { fs.renameSync(from, to); }
    catch (e) {
      if (e.code !== 'EXDEV') throw e;
      fs.cpSync(from, to, { recursive: true });
      fs.rmSync(from, { recursive: true, force: true });
    }
    console.error(`moved ${from} -> ${to}`);
  }
}

// Download the speech-to-text model into ~/.video-lesson/models/ and read a test clip back.
function fetchStt() {
  const fetched = spawnSync(VENV_PY, [path.join(SCRIPTS_DIR, 'tts.py'), '--fetch-stt'], { encoding: 'utf8' });
  process.stderr.write(fetched.stderr || '');
  if (fetched.status !== 0) die(`speech-to-text setup failed. The model is ${STT.repo}; see scripts/stt-model.json and NARRATION.md.`);
  const got = JSON.parse(fetched.stdout);
  return { ...sttStatus(), megabytes: Math.round(got.bytes / 1e6), selftest: { ok: got.ok, heard: got.heard, load_seconds: got.load_seconds, seconds_per_sentence: got.seconds } };
}

function main() {
  const args = parseArgs(process.argv.slice(2), ['manim', 'check', 'yes', 'install-fonts', 'stt']);

  if (args.check) {
    if (!fs.existsSync(REPORT) && fs.existsSync(path.join(LEGACY_VENV_DIR, 'setup-report.json'))) {
      die(`set up by an older version (venv inside scripts/). Run \`node setup.js --yes\` once to move it to ${STATE_DIR}; nothing is downloaded again.`);
    }
    if (!fs.existsSync(REPORT)) die('not set up: ask the user, then run `node setup.js --yes`');
    const report = JSON.parse(fs.readFileSync(REPORT, 'utf8'));
    report.stt = { ...(report.stt || {}), ...sttStatus() };
    console.log(JSON.stringify(report, null, 2));
    return;
  }

  if (args['install-fonts']) {
    if (!args.yes) die('installing fonts writes to ~/Library/Fonts. Ask the user first; re-run with --yes once they agree.');
    const src = path.join(SCRIPTS_DIR, '..', 'assets', 'fonts', 'ttf');
    const dest = path.join(require('os').homedir(), 'Library', 'Fonts');
    for (const f of fs.readdirSync(src).filter(n => n.endsWith('.ttf'))) {
      fs.copyFileSync(path.join(src, f), path.join(dest, f));
      console.error(`installed ${f} -> ${dest}`);
    }
    return;
  }
  if (!args.yes) die('setup downloads several GB. Ask the user first; re-run with --yes once they agree.');
  const arm = spawnSync('/bin/sh', ['-c', 'sysctl -n hw.optional.arm64 2>/dev/null'], { encoding: 'utf8' });
  if (process.platform !== 'darwin' || (arm.stdout || '').trim() !== '1') {
    die('narration requires macOS on Apple Silicon (Kokoro runs through MLX); nothing was installed');
  }
  if (!has('espeak-ng')) die('espeak-ng is required (Kokoro silently skips unknown words without it): brew install espeak-ng');

  // Already set up and only the speech-to-text model was asked for: fetch it and stop.
  if (args.stt && !args.manim && fs.existsSync(REPORT) && fs.existsSync(VENV_PY)) {
    const report = JSON.parse(fs.readFileSync(REPORT, 'utf8'));
    report.stt = fetchStt();
    fs.writeFileSync(REPORT, JSON.stringify(report, null, 2) + '\n');
    console.log(JSON.stringify(report, null, 2));
    return;
  }

  // 1. Python venv with a supported interpreter (moved from scripts/ if an older version made it).
  migrateLegacy();
  fs.mkdirSync(STATE_DIR, { recursive: true });
  if (!fs.existsSync(VENV_PY)) {
    const py = findPython();
    if (!py) die('need python 3.12 (misaki 0.9.4 on PyPI requires < 3.13): brew install python@3.12');
    sh(py, ['-m', 'venv', VENV_DIR]);
  }
  const pip = [VENV_PY, '-m', 'pip'];
  sh(pip[0], [...pip.slice(1), 'install', '--upgrade', 'pip', '--quiet']);
  sh(pip[0], [...pip.slice(1), 'install', '--quiet', `mlx-audio==${PINS['mlx-audio']}`, `misaki[en]==${PINS['misaki[en]']}`]);

  // misaki downloads this at runtime otherwise, which fails offline.
  if (spawnSync(VENV_PY, ['-c', 'import en_core_web_sm']).status !== 0) {
    sh(VENV_PY, ['-m', 'spacy', 'download', 'en_core_web_sm']);
  }

  // 2. Optional manim (Text/MarkupText only; no LaTeX).
  if (args.manim) {
    if (spawnSync('pkg-config', ['--exists', 'pangocairo']).status !== 0) {
      die('manim needs cairo + pango: brew install cairo pkg-config pango, then re-run with --manim');
    }
    sh(pip[0], [...pip.slice(1), 'install', '--quiet', `manim==${PINS.manim}`]);
  }

  // 3. Node dependency for headless Chrome rendering.
  // npm ci installs exactly what package-lock.json pins (falls back to install if it is missing).
  const npmCmd = fs.existsSync(path.join(SCRIPTS_DIR, 'package-lock.json')) ? 'ci' : 'install';
  sh('npm', [npmCmd, '--no-audit', '--no-fund', '--silent'], { cwd: SCRIPTS_DIR });

  // 4. Smoke test: real synthesis, silence check, and phoneme-override pass-through.
  const selftest = spawnSync(VENV_PY, [path.join(SCRIPTS_DIR, 'tts.py'), '--selftest'], { encoding: 'utf8' });
  process.stderr.write(selftest.stderr || '');
  if (selftest.status !== 0) die(`TTS self-test failed. Run "${VENV_PY} -m mlx_audio.tts.generate --help" and compare flags with NARRATION.md.`);
  const test = JSON.parse(selftest.stdout);

  // 5. Optional speech-to-text model for the transcript check (tts.py --transcribe).
  const stt = args.stt ? fetchStt() : sttStatus();

  const version = mod => {
    const r = spawnSync(VENV_PY, ['-c', `import importlib.metadata as m; print(m.version("${mod}"))`], { encoding: 'utf8' });
    return r.status === 0 ? r.stdout.trim() : null;
  };
  const report = {
    created: new Date().toISOString(),
    python: spawnSync(VENV_PY, ['--version'], { encoding: 'utf8' }).stdout.trim(),
    mlx_audio: version('mlx-audio'),
    misaki: version('misaki'),
    manim: version('manim'),
    selftest: test,
    stt,
  };
  fs.writeFileSync(REPORT, JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify(report, null, 2));
}

main();
