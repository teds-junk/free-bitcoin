#!/usr/bin/env node
/**
 * Weave finished video-lesson videos into one course video. Never re-renders lessons.
 *
 * Usage:
 *   node compile.js --parts <intro-dir>,<lesson1-dir>,...,<outro-dir> [--bridges <dir>] --plan
 *   node compile.js --out <dir> --title "Course title" --parts <dir>,<dir>,... [--bridges <dir>] [options]
 *   node compile.js --help
 *
 * Each part is a finished video folder (storyboard.json, build/timeline.json, build/clips/,
 * build/narration.wav, <slug>.srt). Lessons are cut by scene role, so the course does not
 * replay every lesson's title, recap, "your turn" and "next lesson" scenes; a bridges video
 * supplies the narrated link at each lesson boundary. Run with --help for every option.
 *
 * Writes <out>/<slug>.mp4, <slug>.srt, chapters.txt, build/timeline.json, runs verify.js,
 * and prints one JSON result on stdout. Nothing is ever written into a part folder.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const L = require('./lib');

const HELP = `Weave finished video-lesson videos into one course video. Lessons are never re-rendered.

Usage:
  node compile.js --parts <dir>,<dir>,... [--bridges <dir>] --plan
  node compile.js --out <dir> --title "Course title" --parts <dir>,<dir>,... [--bridges <dir>] [options]

Parts are finished video folders, in playing order. A storyboard's "kind" says what a part is:
"lesson" (the default), "intro" or "outro". Scene roles come from each storyboard's "role":
hook, title, body, recap, practice, next, bridge (a scene with no role is body).

  --parts <dirs>       Comma-separated video folders, in order. Required.
  --out <dir>          Output folder. Required unless --plan.
  --title <text>       Course title. Required unless --plan.
  --plan               Print what would be kept and dropped, the bridges matched to boundaries,
                       the unmarked boundaries, the lesson references that survive and the
                       resulting length. Renders and writes nothing.
  --drop <roles>       Also drop these roles from lessons (comma-separated).
  --keep <roles>       Keep these roles after all ("--keep all" drops nothing).
                       Dropped by default: title, recap, next. (practice scenes perform the
                       checkpoint, which is teaching content, so they are kept; --drop practice removes them.)
  --bridges <dir>      A finished video folder with kind "bridges". Each of its scenes carries
                       "after": "<part slug>" and plays right after that part's last kept scene.
  --cards              Put a title card before each lesson (the default when there are no bridges).
  --no-cards           No title cards (the default when --bridges is given).
  --card-seconds <n>   Title card length, default 3.
  --numbered           Title chapters and cards "Lesson N: <title>" instead of the title alone.
  --scene-chapters     Keep each part's own chapters instead of one chapter per part.
  --staple             The old join: every lesson's whole video behind a numbered title card,
                       "Lesson N: <title>" chapters. Roles, bridges and the options above are ignored.
  --slug <name>        Output file name; default is made from the title.
  --help               Show this.

Output: <out>/<slug>.mp4, <out>/<slug>.srt, <out>/chapters.txt, <out>/build/timeline.json, then
verify.js runs. stdout is one JSON object: { ok, checks, warnings, parts, boundaries,
lesson_references, chapters, total_seconds, ... }; diagnostics go to stderr. Exit 1 on failure.
`;

const ROLES = ['hook', 'title', 'body', 'recap', 'practice', 'next', 'bridge'];
const DEFAULT_DROP = ['title', 'recap', 'next']; // practice scenes perform the checkpoint: teaching content, kept
const FPS = L.VIDEO.fps;
// Scenes start and end on whole frames, and one frame is a whole number of audio samples
// (48000 / 30 = 1600), so cutting the narration by frame count is exact to the sample.
const SPF = L.AUDIO_RATE / FPS;
const MIN_CHAPTER = 10; // YouTube's minimum chapter length, seconds

function parseSrt(text) {
  const toSec = s => { const [h, m, rest] = s.split(':'); const [sec, ms] = rest.split(','); return +h * 3600 + +m * 60 + +sec + +ms / 1000; };
  return text.trim().split(/\n\s*\n/).map(block => {
    const lines = block.split('\n');
    const m = (lines[1] || '').match(/(\S+) --> (\S+)/);
    return m && { start: toSec(m[1]), end: toSec(m[2]), text: lines.slice(2).join('\n') };
  }).filter(Boolean);
}

function escapeMeta(s) {
  return String(s).replace(/([=;#\\\n])/g, '\\$1');
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

const sec = frames => frames / FPS;
const round2 = x => Number(x.toFixed(2));
function clock(seconds) {
  const s = Math.round(seconds);
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = String(s % 60).padStart(2, '0');
  return h ? `${h}:${String(m).padStart(2, '0')}:${r}` : `${m}:${r}`;
}

// ---- parts -------------------------------------------------------------------

function clipFrames(file) {
  const res = L.run('ffprobe', ['-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=nb_frames', '-of', 'csv=p=0', file]);
  return Number(res.stdout.trim().split(/[\s,]/)[0]);
}

// Load one finished video folder. Reads only; a compilation never writes into a part.
function loadPart(dirArg, { staple }) {
  if (!fs.existsSync(dirArg) || (!fs.statSync(dirArg).isDirectory() && path.basename(dirArg) !== 'storyboard.json')) {
    L.die(`${dirArg}: not a video folder. Parts are the folders holding storyboard.json, not MP4 files`);
  }
  const { sb, dir } = L.loadStoryboard(dirArg);
  const need = {
    timeline: path.join(dir, 'build', 'timeline.json'),
    wav: path.join(dir, 'build', 'narration.wav'),
    srt: path.join(dir, `${sb.slug}.srt`),
  };
  const video = path.join(dir, 'build', 'video.mp4');
  if (staple) need.video = video;
  for (const [k, f] of Object.entries(need)) if (!fs.existsSync(f)) L.die(`${dir}: missing ${k} (${f}); finish that video first`);
  const tl = L.readJSON(need.timeline);
  const part = { sb, dir, ...need, video, tl, slug: sb.slug, kind: sb.kind || 'lesson', title: sb.title, scenes: [] };

  // The masters must match the timeline: a lesson re-rendered but not re-assembled would drift.
  const wavSeconds = L.duration(need.wav);
  const videoStale = fs.existsSync(video) &&
    Number(L.probe(video).streams.find(s => s.codec_type === 'video').nb_frames) !== L.frames(tl.total);
  if (videoStale || Math.abs(wavSeconds - tl.total) > 0.05) {
    L.die(`${dir}: build/video.mp4 or narration.wav does not match timeline.json (stale); re-run assemble.js for that video first`);
  }

  const byId = new Map((sb.scenes || []).map(s => [s.id, s]));
  if (tl.scenes.length !== byId.size || tl.scenes.some(s => !byId.has(s.id))) {
    L.die(`${dir}: storyboard.json and build/timeline.json list different scenes (stale); re-run render-scenes.js and then assemble.js for that video first`);
  }
  let chapterNo = -1, chapterTitle = null;
  for (const s of tl.scenes) {
    const src = byId.get(s.id);
    const role = src.role || 'body';
    if (!ROLES.includes(role)) L.die(`${dir}: scene ${s.id} has role "${role}"; use one of ${ROLES.join(', ')}`);
    if (s.chapter || chapterNo < 0) { chapterNo += 1; chapterTitle = s.chapter || null; } // null: the part's own title
    const visual = src.visual ? path.resolve(dir, String(src.visual).split('#')[0]) : null;
    part.scenes.push({
      id: s.id, role, after: src.after || null, renderer: s.renderer, silent: Boolean(s.silent),
      start: s.start, duration: s.duration, frames: L.frames(s.duration), startFrame: L.frames(s.start),
      clip: path.resolve(dir, s.clip || path.join('build', 'clips', `${s.id}.mp4`)),
      sentences: s.sentences || [], chapterNo, chapterTitle, visual,
    });
  }
  return part;
}

// Every clip that will be used must be exactly as long as the timeline says.
function checkClips(part, scenes) {
  for (const s of scenes) {
    if (!fs.existsSync(s.clip) || clipFrames(s.clip) !== s.frames) {
      L.die(`${part.dir}: build/clips/${s.id}.mp4 is missing or does not match timeline.json (stale); re-run render-scenes.js and then assemble.js for that video first`);
    }
  }
}

// The narration track must agree with the timeline: silent at each scene's edges and between
// its sentences, audible inside every sentence. That is what makes a cut at a scene boundary
// safe, and it catches a track mixed before the lesson was last re-narrated.
function checkNarration(part) {
  const pcm = L.decodePcm(part.wav);
  const QUIET = 48, AUDIBLE = 400, WIN = 0.05;
  const peak = (from, to) => {
    let max = 0;
    const end = Math.min(pcm.length, Math.round(to * L.AUDIO_RATE));
    for (let i = Math.max(0, Math.round(from * L.AUDIO_RATE)); i < end; i++) { const a = Math.abs(pcm[i]); if (a > max) max = a; }
    return max;
  };
  const stale = (id, why) => L.die(`${part.dir}: build/narration.wav does not match timeline.json at ${id} (${why}; stale); re-run assemble.js for that video first`);
  for (const s of part.scenes) {
    const end = s.start + s.duration;
    const x = s.sentences;
    for (const [i, c] of x.entries()) {
      if (c.start < s.start - 1e-3 || c.end > end + 1e-3) stale(s.id, 'a sentence runs outside its scene');
      if (peak(c.start, c.end) < AUDIBLE) stale(s.id, `sentence ${i + 1} is silent in the track`);
      const gap = i + 1 < x.length ? x[i + 1].start - c.end : 0;
      if (gap >= 0.2 && peak(c.end + gap / 2 - WIN / 2, c.end + gap / 2 + WIN / 2) > QUIET) stale(s.id, `sound in the pause after sentence ${i + 1}`);
    }
    const first = x.length ? x[0].start : end, last = x.length ? x[x.length - 1].end : s.start;
    if (first - s.start >= 2 * WIN && peak(s.start, s.start + WIN) > QUIET) stale(s.id, 'sound at the scene start');
    if (end - last >= 2 * WIN && peak(end - WIN, end) > QUIET) stale(s.id, 'sound at the scene end');
  }
}

// ---- lesson references ---------------------------------------------------------

const NUM = '(?:one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|\\d+)';
const REF = new RegExp(
  `(?<![\\w/._-])(?:(?:this|next|last|previous|earlier|later|first|final|the|each|every|in|from)\\s+)?lessons?(?:['’]s)?(?![\\w-])` +
  `(?:\\s+${NUM}\\b(?:\\s+(?:to|and|or|through)\\s+${NUM}\\b)?|\\s+page\\b)?` +
  `|\\byour turn\\b|\\b(?:next|last|previous)\\s+(?:video|episode)\\b`, 'gi');

function visibleText(file) {
  if (!file || !/\.html?$/i.test(file) || !fs.existsSync(file)) return [];
  const ent = { '&amp;': '&', '&lt;': '<', '&gt;': '>', '&quot;': '"', '&#39;': "'", '&nbsp;': ' ', '&middot;': '·' };
  return fs.readFileSync(file, 'utf8').replace(/<(script|style)\b[\s\S]*?<\/\1>|<!--[\s\S]*?-->/gi, ' ')
    .split(/<[^>]+>/).map(t => t.replace(/&[a-z#0-9]+;/gi, e => ent[e] || e).replace(/\s+/g, ' ').trim()).filter(Boolean);
}

// Words that still talk about "lessons" in scenes that stay. They cannot be cut out of a
// finished narration, so they are reported, never blocked on.
function lessonReferences(segments) {
  const out = [];
  for (const seg of segments) {
    if (seg.type !== 'scene') continue;
    const add = (where, text) => {
      const hits = [...new Set((text.match(REF) || []).map(h => h.toLowerCase()))];
      if (hits.length) out.push({ part: seg.part.slug, scene: seg.scene.id, role: seg.scene.role, where, phrase: hits.join(', '), sentence: text.length > 240 ? text.slice(0, 237) + '…' : text });
    };
    seg.scene.sentences.forEach(x => add('narration', x.text || ''));
    visibleText(seg.scene.visual).forEach(t => add('screen', t));
  }
  return out;
}

// ---- the plan: what plays, in what order ---------------------------------------

function buildPlan(parts, bridges, o) {
  const warnings = [];
  const bySlug = new Map(parts.map(p => [p.slug, p]));
  const bridgeAfter = new Map();
  const unused = [];
  for (const s of bridges ? bridges.scenes : []) {
    if (!s.after) L.die(`${bridges.dir}: bridge scene ${s.id} has no "after"; set it to the slug of the part it follows (${parts.map(p => p.slug).join(', ')})`);
    if (!bySlug.has(s.after)) { unused.push(`${s.id} (after "${s.after}")`); continue; }
    if (!bridgeAfter.has(s.after)) bridgeAfter.set(s.after, []);
    bridgeAfter.get(s.after).push(s);
  }
  if (unused.length) warnings.push(`bridge scene(s) not used, because the part they follow is not in --parts: ${unused.join(', ')}`);

  let lessonNo = 0;
  const groups = parts.map(part => {
    const g = { part, lead: [], card: null, body: [], trail: [], dropped: [] };
    if (part.kind === 'lesson') {
      lessonNo += 1;
      g.n = part.sb.lesson_number || lessonNo;
      g.chapter = o.numbered || o.staple ? `Lesson ${g.n}: ${part.title}` : part.title;
      if (o.cards) g.card = { type: 'card', id: `card-${g.n}`, n: g.n, part, frames: L.frames(o.cardSeconds) };
    } else {
      g.chapter = part.kind === 'intro' ? (part.title || 'Introduction') : part.kind === 'outro' ? (part.title || 'Wrap-up') : (o.staple ? null : part.title);
    }
    if (o.staple) {
      g.body.push({ type: 'part', part, clip: part.video, frames: L.frames(part.tl.total) });
      return g;
    }
    for (const s of part.scenes) {
      if (part.kind === 'lesson' && o.dropped.has(s.role)) g.dropped.push(s);
      else g.body.push({ type: 'scene', part, scene: s, clip: s.clip, frames: s.frames });
    }
    if (!g.body.length) L.die(`${part.dir}: every scene has a dropped role (${[...o.dropped].join(', ')}); keep some with --keep, or leave the part out`);
    return g;
  });

  // A bridge plays after its part. It opens the next lesson's chapter, as a title card would;
  // before an outro, or at the very end, it closes the chapter of the part it follows.
  const boundaries = [];
  groups.forEach((g, i) => {
    const next = groups[i + 1];
    const b = (bridgeAfter.get(g.part.slug) || []).map(s => ({ type: 'scene', part: bridges, scene: s, clip: s.clip, frames: s.frames, bridge: true }));
    if (next && next.part.kind === 'lesson') next.lead = b; else g.trail = b;
    if (!next && !b.length) return;
    const marked = b.length > 0 || Boolean(next && next.card);
    const lessonBoundary = Boolean(next) && g.part.kind === 'lesson' && next.part.kind === 'lesson';
    boundaries.push({
      after: g.part.slug, before: next ? next.part.slug : null, bridge: b.map(x => x.scene.id),
      bridge_seconds: round2(sec(b.reduce((n, x) => n + x.frames, 0))), card: Boolean(next && next.card),
      unmarked: lessonBoundary && !marked,
    });
    if (lessonBoundary && !marked) {
      warnings.push(`no bridge and no title card between "${g.part.slug}" and "${next.part.slug}": the video hard-cuts from one lesson into the next. ` +
        `Add a bridge scene with "after": "${g.part.slug}", or pass --cards`);
    }
  });

  // Flatten, with frame-exact start times.
  const segments = [];
  let frame = 0;
  for (const g of groups) {
    g.segments = [...g.lead, ...(g.card ? [g.card] : []), ...g.body, ...g.trail];
    for (const seg of g.segments) { seg.group = g; seg.startFrame = frame; seg.start = sec(frame); seg.duration = sec(seg.frames); frame += seg.frames; segments.push(seg); }
  }
  const total = sec(frame);

  // Chapters.
  const chapters = [];
  for (const g of groups) {
    if (o.staple) {
      // One per part, starting at its title card; a part of another kind joins the chapter before it.
      const at = g.card || (g.chapter ? g.body[0] : null);
      if (at) chapters.push({ title: g.chapter, start: at.start, group: g });
    } else if (!o.sceneChapters) {
      chapters.push({ title: g.chapter, start: g.segments[0].start, group: g });
    } else {
      // The part's own chapters, minus those whose scenes were all dropped. The first one
      // starts where the part starts (its bridge or card), so no bridge is left unchaptered.
      let cur = null;
      for (const seg of g.body) {
        if (seg.scene.chapterNo === cur) continue;
        chapters.push({ title: seg.scene.chapterTitle || g.chapter, start: cur === null ? g.segments[0].start : seg.start, group: g });
        cur = seg.scene.chapterNo;
      }
    }
  }
  if (!o.staple && chapters.length) {
    chapters[0].start = 0;
    // YouTube ignores the whole list if any chapter is under 10 s, so a short one joins a neighbour:
    // one in the same part when there is one, and the longer of the two keeps its title.
    const len = k => (k + 1 < chapters.length ? chapters[k + 1].start : total) - chapters[k].start;
    for (;;) {
      const i = chapters.findIndex((c, k) => len(k) < MIN_CHAPTER - 1e-6);
      if (i < 0 || chapters.length < 2) break;
      const same = k => k >= 0 && k < chapters.length && chapters[k].group === chapters[i].group;
      const j = same(i - 1) ? i - 1 : same(i + 1) ? i + 1 : i > 0 ? i - 1 : i + 1;
      const a = Math.min(i, j), b = Math.max(i, j);
      warnings.push(`chapter "${chapters[i].title}" would be ${len(i).toFixed(1)}s, under YouTube's 10s minimum; merged with "${chapters[j].title}"`);
      if (len(b) > len(a)) chapters[a].title = chapters[b].title;
      chapters.splice(b, 1);
    }
  }
  chapters.forEach((c, i) => { c.end = i + 1 < chapters.length ? chapters[i + 1].start : total; });

  const last = groups[groups.length - 1];
  const lastKept = last.body[last.body.length - 1].scene;
  if (!o.staple && last.part.kind === 'lesson' && !last.trail.length && last.dropped.some(s => s.startFrame > lastKept.startFrame)) {
    warnings.push(`the video ends on "${last.part.slug}/${lastKept.id}" with no wrap-up, because that lesson's closing scenes are dropped and there is no outro part or closing bridge`);
  }

  const refs = o.staple ? [] : lessonReferences(segments);
  if (refs.length) {
    warnings.push(`${refs.length} lesson reference(s) survive in kept scenes (listed under lesson_references). They cannot be removed without re-narrating or re-rendering those scenes`);
  }

  const item = seg => ({ id: seg.scene.id, role: seg.scene.role, seconds: round2(seg.duration) });
  const report = {
    mode: o.staple ? 'staple' : 'weave',
    dropped_roles: o.staple ? [] : [...o.dropped],
    cards: o.cards,
    bridges: bridges ? bridges.dir : null,
    parts: groups.map(g => ({
      slug: g.part.slug, kind: g.part.kind, title: g.part.title, dir: g.part.dir,
      kept: o.staple ? g.part.scenes.map(s => ({ id: s.id, role: s.role, seconds: round2(s.duration) })) : g.body.map(item),
      dropped: g.dropped.map(s => ({ id: s.id, role: s.role, seconds: round2(s.duration) })),
      kept_seconds: round2(sec(g.body.reduce((n, x) => n + x.frames, 0))),
      dropped_seconds: round2(g.dropped.reduce((n, s) => n + s.duration, 0)),
    })),
    boundaries,
    unmarked_boundaries: boundaries.filter(b => b.unmarked).map(b => `${b.after} -> ${b.before}`),
    chapters: chapters.map(c => ({ at: L.fmtChapterTime(c.start), title: c.title })),
    lesson_references: refs,
    source_seconds: round2(parts.reduce((n, p) => n + p.tl.total, 0)),
    dropped_seconds: round2(groups.reduce((n, g) => n + g.dropped.reduce((m, s) => m + s.duration, 0), 0)),
    bridge_seconds: round2(sec(segments.filter(s => s.bridge).reduce((n, s) => n + s.frames, 0))),
    card_seconds: round2(sec(segments.filter(s => s.type === 'card').reduce((n, s) => n + s.frames, 0))),
    total_seconds: round2(total),
    warnings,
  };
  return { groups, segments, chapters, total, totalFrames: frame, report };
}

// The plan as a person reads it (stderr); the same facts are in the JSON on stdout.
function printPlan(r) {
  const e = s => console.error(s);
  const list = xs => xs.map(x => `${x.id} ${x.role} ${x.seconds}s`).join(', ');
  e(r.mode === 'staple' ? 'Plan: staple (whole lessons, a numbered title card each)'
    : `Plan: weave. Dropping from lessons: ${r.dropped_roles.join(', ') || 'nothing'}. Title cards: ${r.cards ? 'yes' : 'no'}. Bridges: ${r.bridges || 'none'}.`);
  e('');
  const w = Math.max(...r.parts.map(p => p.slug.length));
  for (const p of r.parts) {
    e(`${p.slug.padEnd(w)}  ${p.kind.padEnd(6)}  keep ${String(p.kept.length).padStart(2)} scenes ${clock(p.kept_seconds).padStart(7)}` +
      (p.dropped.length ? `   drop ${clock(p.dropped_seconds)}: ${list(p.dropped)}` : '   drop nothing'));
  }
  e('');
  e('Boundaries:');
  for (const b of r.boundaries) {
    const how = [b.bridge.length ? `bridge ${b.bridge.join(', ')} (${b.bridge_seconds}s)` : null, b.card ? 'title card' : null].filter(Boolean).join(' + ');
    e(`  ${b.after} -> ${b.before || '(end)'}: ${how || (b.unmarked ? 'UNMARKED hard cut' : 'straight cut')}`);
  }
  e('');
  e('Chapters:');
  r.chapters.forEach(c => e(`  ${c.at} ${c.title}`));
  if (r.lesson_references.length) {
    e('');
    e(`Lesson references that survive (${r.lesson_references.length}); fixing one means re-narrating or re-rendering its scene:`);
    for (const p of r.parts) {
      const mine = r.lesson_references.filter(x => x.part === p.slug);
      if (!mine.length) continue;
      e(`  ${p.slug}: ${mine.filter(x => x.where === 'narration').length} spoken, ${mine.filter(x => x.where === 'screen').length} on screen`);
      mine.slice(0, 3).forEach(x => e(`    ${x.scene} ${x.role} ${x.where}: ${x.sentence}`));
      if (mine.length > 3) e(`    … ${mine.length - 3} more in the JSON`);
    }
    const other = r.lesson_references.filter(x => !r.parts.some(p => p.slug === x.part));
    other.forEach(x => e(`  bridge ${x.part}/${x.scene} ${x.where}: ${x.sentence}`));
  }
  e('');
  r.warnings.forEach(x => e(`warning: ${x}`));
  e(`Length: ${clock(r.total_seconds)} (lessons as recorded ${clock(r.source_seconds)}, dropped ${clock(r.dropped_seconds)}, bridges ${clock(r.bridge_seconds)}, title cards ${clock(r.card_seconds)}), ${r.chapters.length} chapters`);
}

// ---- compile ---------------------------------------------------------------------

async function renderCards(cards, o, out, build) {
  if (!cards.length) return;
  const B = require('./browser');
  L.mkdirp(path.join(build, 'cards'));
  // Always the skill's current theme, so title cards match the design system.
  const themeDir = L.mkdirp(path.join(out, '_theme'));
  fs.copyFileSync(path.join(L.ASSETS_DIR, 'theme.css'), path.join(themeDir, 'theme.css'));
  fs.cpSync(path.join(L.ASSETS_DIR, 'fonts'), path.join(themeDir, 'fonts'), { recursive: true });
  const template = fs.readFileSync(path.join(L.ASSETS_DIR, 'title-card.html'), 'utf8');
  for (const card of cards) {
    // Numbered: "Lesson N" over the title, course title beneath. Otherwise the course title
    // sits over the lesson title and the card does not count lessons.
    const numbered = o.numbered || o.staple;
    const html = path.join(build, 'cards', `${card.id}.html`);
    fs.writeFileSync(html, template
      .replace(/\{\{THEME_DIR\}\}/g, path.relative(path.dirname(html), themeDir))
      .replace(/\{\{EYEBROW\}\}/g, escapeHtml(numbered ? `Lesson ${card.n}` : o.title))
      .replace(/\{\{TITLE\}\}/g, escapeHtml(card.part.title))
      .replace(/\{\{SUBTITLE\}\}/g, escapeHtml(numbered ? o.title : '')));
    const png = html.replace(/\.html$/, '.png');
    card.clip = html.replace(/\.html$/, '.mp4');
    const problems = await B.screenshotFinal(html, png, { duration: card.duration, sentences: [], fps: FPS });
    problems.forEach(p => console.error(`warning: title card ${card.n}: ${p}`));
    L.stillToClip(png, card.duration, card.clip);
  }
  await B.close();
}

// One PCM track: each kept scene's stretch of its part's (already normalized) narration,
// copied to the scene's new position. Offsets are whole frames times 1600 samples.
function mixNarration(segments, totalFrames) {
  const out = new Int16Array(totalFrames * SPF);
  const byPart = new Map();
  for (const seg of segments) {
    if (seg.type === 'card') continue;
    if (!byPart.has(seg.part)) byPart.set(seg.part, []);
    byPart.get(seg.part).push(seg);
  }
  for (const [part, segs] of byPart) {
    const pcm = L.decodePcm(part.wav);
    for (const seg of segs) {
      const from = seg.type === 'part' ? 0 : seg.scene.startFrame * SPF;
      out.set(pcm.subarray(from, Math.min(pcm.length, from + seg.frames * SPF)), seg.startFrame * SPF);
    }
  }
  return out;
}

async function main() {
  const argv = process.argv.slice(2);
  const flags = ['plan', 'staple', 'cards', 'no-cards', 'numbered', 'scene-chapters', 'help'];
  const args = L.parseArgs(argv, flags);
  if (args.help || argv.includes('-h')) { process.stdout.write(HELP); return; }
  if (!Number.isInteger(SPF)) L.die(`audio rate ${L.AUDIO_RATE} is not a whole number of samples per frame at ${FPS} fps`);
  if (!args.parts) L.die('pass --parts <dir>,<dir>,... (finished video folders, in order). Run compile.js --help for every option');
  if (!args.plan && (!args.out || !args.title)) L.die('pass --out <dir> and --title "Course title" (or --plan to see the plan first). Run compile.js --help for every option');

  const staple = Boolean(args.staple);
  const roles = (name) => (args[name] ? String(args[name]).split(',').map(s => s.trim()).filter(Boolean) : []);
  const bad = [...roles('drop'), ...roles('keep')].filter(r => !ROLES.includes(r) && r !== 'all');
  if (bad.length) L.die(`unknown role(s) ${bad.join(', ')}; roles are ${ROLES.join(', ')}`);
  const keep = roles('keep');
  const dropped = new Set(keep.includes('all') ? [] : [...DEFAULT_DROP, ...roles('drop')].filter(r => !keep.includes(r)));
  if (args.cards && args['no-cards']) L.die('pass --cards or --no-cards, not both');
  const o = {
    staple, dropped, title: args.title || '',
    cards: staple ? true : args['no-cards'] ? false : args.cards ? true : !args.bridges,
    numbered: Boolean(args.numbered), sceneChapters: Boolean(args['scene-chapters']),
    cardSeconds: L.frameAlign(Number(args['card-seconds'] || 3)),
  };
  if (!(o.cardSeconds > 0)) L.die('--card-seconds must be a number above 0');

  const parts = args.parts.split(',').map(p => p.trim()).filter(Boolean).map(p => loadPart(p, { staple }));
  const stray = parts.find(p => p.kind === 'bridges');
  if (stray) L.die(`${stray.dir} is a bridges video; pass it with --bridges, not in --parts`);
  const twice = parts.find((p, i) => parts.findIndex(q => q.slug === p.slug) !== i);
  if (twice) L.die(`two parts share the slug "${twice.slug}"; each part needs its own`);
  let bridges = null;
  if (args.bridges && !staple) {
    bridges = loadPart(args.bridges, { staple: false });
    if (bridges.kind !== 'bridges') L.die(`${bridges.dir}: --bridges needs a video whose storyboard has "kind": "bridges" (this one is "${bridges.kind}")`);
  }

  const plan = buildPlan(parts, bridges, o);
  const { segments, chapters, report } = plan;

  // Stale checks on everything that will be used, before anything is written.
  if (!staple) {
    for (const part of [...parts, ...(bridges ? [bridges] : [])]) {
      checkClips(part, segments.filter(s => s.type === 'scene' && s.part === part).map(s => s.scene));
      checkNarration(part);
    }
  }

  if (args.plan) {
    printPlan(report);
    console.log(JSON.stringify({ plan: true, ...report }, null, 2));
    return;
  }

  const out = path.resolve(args.out);
  const inside = [...parts, ...(bridges ? [bridges] : [])].find(p => out === p.dir || out.startsWith(p.dir + path.sep));
  if (inside) L.die(`--out ${out} is inside the part ${inside.dir}; a compilation gets its own folder`);
  L.mkdirp(out);
  const build = L.mkdirp(path.join(out, 'build'));
  const slug = args.slug || args.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  if (!slug) L.die('the title has no letters or digits to make a file name from; pass --slug <name>');

  await renderCards(segments.filter(s => s.type === 'card'), o, out, build);

  // Timeline and captions, shifted to the new times.
  const total = plan.total;
  const starts = new Map(chapters.map(c => [L.frames(c.start), c.title]));
  const cues = [];
  const timeline = { title: args.title, slug, fps: FPS, scenes: [], total };
  const srtCache = new Map();
  const partCues = part => { if (!srtCache.has(part)) srtCache.set(part, parseSrt(fs.readFileSync(part.srt, 'utf8'))); return srtCache.get(part); };
  for (const seg of segments) {
    const t = seg.start;
    if (seg.type === 'card') {
      timeline.scenes.push({ id: seg.id, chapter: starts.get(seg.startFrame) || null, renderer: 'slide', start: t, duration: seg.duration, sentences: [], silent: true });
    } else if (seg.type === 'part') {
      for (const c of partCues(seg.part)) cues.push({ ...c, start: c.start + t, end: c.end + t });
      for (const s of seg.part.tl.scenes) {
        timeline.scenes.push({
          ...s, id: `${seg.part.slug}/${s.id}`, start: s.start + t,
          sentences: s.sentences.map(x => ({ ...x, file: path.resolve(seg.part.dir, x.file), start: x.start + t, end: x.end + t })),
        });
      }
    } else {
      const s = seg.scene;
      const shift = t - s.start;
      // A cue belongs to the scene its midpoint falls in (cue times are rounded to the millisecond).
      for (const c of partCues(seg.part)) {
        const mid = (c.start + c.end) / 2;
        if (mid >= s.start && mid < s.start + s.duration) cues.push({ ...c, start: Math.max(t, c.start + shift), end: Math.min(t + seg.duration, c.end + shift) });
      }
      timeline.scenes.push({
        id: `${seg.part.slug}/${s.id}`, chapter: starts.get(seg.startFrame) || null, role: seg.bridge ? 'bridge' : s.role, renderer: s.renderer,
        start: t, duration: seg.duration, clip: s.clip, ...(s.silent ? { silent: true } : {}),
        sentences: s.sentences.map(x => ({ ...x, file: path.resolve(seg.part.dir, x.file), start: x.start + shift, end: x.end + shift })),
      });
    }
  }
  timeline.chapters = chapters.map(({ title, start, end }) => ({ title, start, end }));

  const srtFile = path.join(out, `${slug}.srt`);
  fs.writeFileSync(srtFile, cues.map((c, i) => `${i + 1}\n${L.fmtSrtTime(c.start)} --> ${L.fmtSrtTime(c.end)}\n${c.text}\n`).join('\n'));
  const chaptersFile = path.join(out, 'chapters.txt');
  fs.writeFileSync(chaptersFile, chapters.map(c => `${L.fmtChapterTime(c.start)} ${c.title}`).join('\n') + '\n');
  const meta = [';FFMETADATA1', `title=${escapeMeta(args.title)}`, ''];
  for (const c of chapters) meta.push('[CHAPTER]', 'TIMEBASE=1/1000', `START=${Math.round(c.start * 1000)}`, `END=${Math.round(c.end * 1000)}`, `title=${escapeMeta(c.title)}`, '');
  const metaFile = path.join(build, 'chapters.ffmeta');
  fs.writeFileSync(metaFile, meta.join('\n'));
  const timelineFile = path.join(build, 'timeline.json');
  L.writeJSON(timelineFile, timeline);

  // Video: stream-copy concat (all clips share the house encoding spec).
  const list = path.join(build, 'parts.ffconcat');
  fs.writeFileSync(list, 'ffconcat version 1.0\n' + segments.map(s => L.ffconcatLine(s.clip)).join('\n') + '\n');
  const video = path.join(build, 'video.mp4');
  L.ffmpeg(['-f', 'concat', '-safe', '0', '-i', list, '-c', 'copy', video]);

  // Audio: one PCM track, one loudnorm, one AAC encode.
  const rawWav = path.join(build, 'narration.raw.wav');
  const normWav = path.join(build, 'narration.wav');
  L.writeWav(rawWav, mixNarration(segments, plan.totalFrames));
  L.loudnorm(rawWav, normWav);

  const final = path.join(out, `${slug}.mp4`);
  L.ffmpeg(['-i', video, '-i', normWav, '-i', srtFile, '-i', metaFile,
    '-map', '0:v', '-map', '1:a', '-map', '2:s', '-map_metadata', '3', '-map_chapters', '3',
    '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-c:s', 'mov_text', '-metadata:s:s:0', 'language=eng',
    '-t', total.toFixed(4), '-movflags', '+faststart', final]);
  console.error(`wrote ${final} (${(total / 60).toFixed(1)} min, ${chapters.length} chapters)`);
  report.warnings.forEach(w => console.error(`warning: ${w}`));

  // Poster for pages that embed the course video: a frame from early in the first scene.
  try { L.writePoster(final, Math.min(total * 0.5, 2), path.join(out, 'poster.png')); }
  catch (e) { console.error(`warning: could not write poster.png: ${e.message.split('\n')[0]}`); }

  const v = spawnSync(process.execPath, [path.join(__dirname, 'verify.js'), '--file', final, '--timeline', timelineFile,
    '--srt', srtFile, '--chapters', chaptersFile], { encoding: 'utf8', maxBuffer: 1 << 26, stdio: ['ignore', 'pipe', 'inherit'] });
  let verdict;
  try { verdict = JSON.parse(v.stdout); } catch (e) { verdict = { ok: false, checks: [{ name: 'verify.js ran', ok: false, detail: (v.stdout || '').slice(0, 300) }], warnings: [] }; }
  const ok = v.status === 0 && verdict.ok;
  console.log(JSON.stringify({
    ok, file: final, srt: srtFile, chapters_file: chaptersFile, timeline: timelineFile,
    ...report, checks: verdict.checks, warnings: [...report.warnings, ...(verdict.warnings || [])],
  }, null, 2));
  if (!ok) process.exit(1);
}

main().catch(e => { console.error(e.stack || e.message); process.exit(1); });
