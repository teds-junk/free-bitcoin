#!/usr/bin/env node
/**
 * When things happen in a terminal recording.
 *
 * A tape says what was typed and how long each fixed step takes; the recording shows when the
 * screen changed. This module lines the two up and reports, for every visible typed command N
 * (1-based; a command is the Type lines up to the Enter that submits it):
 *
 *   typed:N   its first character appears
 *   enter:N   it is submitted
 *   output:N  its output first appears: at the Enter when it is instant, otherwise the next screen
 *             change after the Enter; for a jump cut (Hide, Wait, Show) the frame after the cut
 *   done:N    the screen stops changing (output finished, prompt back)
 *
 * Usage:
 *   node tape-events.js <tape-file> <recording.mp4> [--debug]
 *   node tape-events.js --commands <tape-file>        # only number the commands (no recording needed)
 *
 * Prints JSON on stdout: { aligned, fps, frames, duration, scale, commands: [...], events: {...},
 * cuts, covers, advice, activity, sleeps, warnings }. Times are seconds into the recording. Every event carries a
 * confidence (high, medium, low) and a list of doubts; an odd tape yields warnings and whatever
 * could be found, never an exception. `aligned: false` means the tape and the recording do not
 * match and the events must not be used (exit code 2).
 *
 * Library:
 *   detectEvents(tapeText, recordingFile) -> Promise<result>
 *   eventsFor(tapeText, recordingFile, { write }) -> the same, cached in <recording>.events.json
 *   validateAnchors(narrationItems, tapeText) -> { errors, warnings }   (pure; used by the lint)
 *   visibleCommands(tapeText) -> [{ n, text, line }]                      (the N that anchors use)
 *   parseAnchor("output:2+0.5") -> { name, n, plus, key } | null
 *   layoutNarration(scene, clips, pacing, result) -> sentence times, holds (used by render-scenes.js and sync-report.js)
 *
 * How it works: vhs captures no frames while hidden, so a Hide ... Show block is a cut that takes
 * no video time. Everything visible becomes a chain of segments: typing (the screen changes about
 * once per character), a Sleep at the prompt (the screen is still), a Sleep or key press while a
 * command runs (anything), and a Wait (anything, unknown length). A dynamic program places the
 * segment boundaries on the frame-to-frame change signal, fitting the recording's time scale
 * (vhs captures slower than real time on a busy machine) and its per-key overhead. Events are then
 * read off the nearest actual screen change.
 */
'use strict';

const fs = require('fs');
const crypto = require('crypto');
const { spawn, spawnSync } = require('child_process');

const DETECTOR_VERSION = '3';
const EVENT_NAMES = ['typed', 'enter', 'output', 'done'];
const ANCHOR_RE = /^(typed|enter|output|done):(\d+)(?:\+(\d+(?:\.\d+)?))?$/;

// Frames are compared at this size in grayscale: big enough that one typed character at the
// smallest font in use changes dozens of pixels, small enough to decode a minute in a second or two.
const W = 480, H = 270;
const PIXEL_DELTA = 24; // a pixel "changed" when its gray level moves more than this (text on the panel moves ~100)
const MIN_PIXELS = 2;   // a frame "changed" when at least this many pixels did (a spinner tick is 2-8)
const COVER_MAX = 1.5;  // seconds of hidden content after a Show that may be covered; longer is left alone and reported

// ---- reading a tape -----------------------------------------------------------------------------

function seconds(s, fallback) {
  const m = /^(\d+(?:\.\d+)?|\.\d+)(ms|s|m)?$/.exec(String(s == null ? '' : s).trim());
  if (!m) return fallback;
  const v = Number(m[1]);
  return m[2] === 'ms' ? v / 1000 : m[2] === 'm' ? v * 60 : v;
}

const KEYS = new Set(['Enter', 'Backspace', 'Delete', 'Insert', 'Down', 'Up', 'Left', 'Right', 'Tab', 'Space',
  'Escape', 'PageUp', 'PageDown', 'Home', 'End', 'Paste']);
const NO_SCREEN_TIME = new Set(['Output', 'Require', 'Env', 'Screenshot', 'Copy']);

// Would a shell still be waiting for more input after this text? (open quote, trailing backslash,
// trailing pipe or && / ||, unfinished here-document)
function shellIncomplete(text) {
  let quote = null;
  let esc = false;
  for (const ch of text) {
    if (esc) { esc = false; continue; }
    if (quote === "'") { if (ch === "'") quote = null; continue; }
    if (ch === '\\') { esc = true; continue; }
    if (quote === '"') { if (ch === '"') quote = null; continue; }
    if (ch === "'" || ch === '"') quote = ch;
  }
  if (quote || esc) return true;
  if (/(\||&&)\s*$/.test(text)) return true;
  const here = text.match(/<<-?\s*(['"]?)([A-Za-z_][A-Za-z0-9_]*)\1/);
  if (here && !text.split('\n').slice(1).some(l => l.trim() === here[2])) return true;
  return false;
}

// parseTape(text) -> { ops, commands, settings, warnings }
//   ops: every screen-relevant line in order: { kind: type|sleep|key|wait|hide|show, line, hidden, ... }
//   commands: typed commands (hidden ones included); visible ones carry n (1-based)
function parseTape(text) {
  const ops = [];
  const warnings = [];
  const settings = { typingSpeed: 0.05, playbackSpeed: 1, cursorBlink: true, framerate: null };
  let speed = 0.05;
  let hidden = false;

  String(text || '').split('\n').forEach((raw, i) => {
    const line = raw.trim();
    if (!line || line.startsWith('#')) return;
    const sp = line.search(/\s/);
    const head = sp < 0 ? line : line.slice(0, sp);
    const rest = sp < 0 ? '' : line.slice(sp + 1).trim();
    const at = head.indexOf('@');
    const name = at < 0 ? head : head.slice(0, at);
    const time = at < 0 ? null : head.slice(at + 1);
    const base = { line: i + 1, hidden };

    if (name === 'Set') {
      const [setting, ...value] = rest.split(/\s+/);
      const v = value.join(' ');
      if (setting === 'TypingSpeed') {
        const s = seconds(v, null);
        if (s == null) warnings.push(`line ${i + 1}: could not read TypingSpeed "${v}"; keeping ${Math.round(speed * 1000)}ms`);
        else { speed = s; if (!ops.length) settings.typingSpeed = s; }
      } else if (setting === 'PlaybackSpeed') settings.playbackSpeed = Number(v) > 0 ? Number(v) : 1;
      else if (setting === 'CursorBlink') settings.cursorBlink = !/^false$/i.test(v);
      else if (setting === 'Framerate') settings.framerate = Number(v) || null;
      return;
    }
    if (NO_SCREEN_TIME.has(name)) return;
    if (name === 'Source') { warnings.push(`line ${i + 1}: Source is not followed; events from the sourced tape are not counted`); return; }
    if (name === 'Hide') { hidden = true; ops.push({ ...base, hidden: true, kind: 'hide' }); return; }
    if (name === 'Show') { hidden = false; ops.push({ ...base, hidden: false, kind: 'show' }); return; }
    if (name === 'Sleep') {
      const s = seconds(rest, null);
      if (s == null) warnings.push(`line ${i + 1}: could not read "Sleep ${rest}"; counted as 0`);
      ops.push({ ...base, kind: 'sleep', sec: s || 0 });
      return;
    }
    if (name === 'Type') {
      const m = rest.match(/^(["'`])([\s\S]*)\1$/);
      const typed = m ? m[2] : rest;
      ops.push({ ...base, kind: 'type', text: typed, chars: [...typed].length, speed: time ? seconds(time, speed) : speed });
      return;
    }
    if (name.startsWith('Wait')) {
      ops.push({ ...base, kind: 'wait', timeout: time ? seconds(time, 15) : 15 });
      return;
    }
    if (!KEYS.has(name) && !/^(Ctrl|Alt|Shift)\+/.test(name)) {
      warnings.push(`line ${i + 1}: unrecognized tape command "${name}" (counted as one key press)`);
    }
    ops.push({ ...base, kind: 'key', key: name, count: Math.max(1, parseInt(rest, 10) || 1), speed: time ? seconds(time, speed) : speed });
  });

  // Group Type lines into commands. An Enter submits the command unless the shell would still be
  // waiting for input (then it is a line break inside one command).
  const commands = [];
  let cur = null;
  ops.forEach((op, idx) => {
    if (op.kind === 'type') {
      if (!cur) cur = { hidden: op.hidden, line: op.line, typeOps: [idx], text: op.text, newline: false };
      else { cur.text += (cur.newline ? '\n' : '') + op.text; cur.newline = false; cur.typeOps.push(idx); }
    } else if (op.kind === 'key' && op.key === 'Enter') {
      if (!cur) return;
      if (shellIncomplete(cur.text)) { cur.newline = true; op.continuation = true; return; }
      cur.enterOp = idx;
      op.submits = true;
      commands.push(cur);
      cur = null;
    } else if (op.kind === 'key' && /^Ctrl\+[CD]$/i.test(op.key)) {
      cur = null;
    }
  });
  let n = 0;
  for (const c of commands) { delete c.newline; if (!c.hidden) c.n = ++n; }
  if (settings.cursorBlink && commands.some(c => !c.hidden)) {
    warnings.push('the tape does not set "Set CursorBlink false": a blinking cursor shows up as screen changes and makes a held frame visible');
  }
  return { ops, commands, settings, warnings };
}

function visibleCommands(tapeText) {
  return parseTape(tapeText).commands.filter(c => !c.hidden).map(c => ({ n: c.n, text: c.text, line: c.line }));
}

// The visible part of a tape as a chain of segments for the aligner.
//   quiet   a Sleep with nothing running: the screen should not change
//   type    a Type: the screen changes about once per character
//   any     a key press, or a Sleep while a command runs: fixed length, anything may happen
//   free    a Wait: unknown length, anything may happen
//   settle  the first frames of the recording, or the frames right after a cut (Hide ... Show):
//           a hidden command may still be drawing
function buildSegments(tape) {
  const segs = [{ kind: 'settle', start: true, line: 0 }];
  const segOf = new Map(); // op index -> segment index
  let running = false;
  let block = null; // the hidden block being read
  tape.ops.forEach((op, idx) => {
    if (op.kind === 'hide') { block = block || { wait: false, unsettled: false, typed: false, line: op.line }; return; }
    if (op.kind === 'show') {
      if (!block) return;
      const cut = { kind: 'settle', cut: true, hiddenWait: block.wait, unsettled: block.unsettled, typed: block.typed, line: op.line, hideLine: block.line };
      const last = segs[segs.length - 1];
      if (last.kind === 'settle' && last.start && segs.length === 1) segs[0] = { ...cut, start: true };
      else segs.push(cut);
      if (block.wait) running = false;
      block = null;
      return;
    }
    if (op.hidden) {
      if (!block) block = { wait: false, unsettled: false, typed: false, line: op.line };
      if (op.kind === 'type' || op.kind === 'key') block.typed = true;
      if (op.kind === 'wait') { block.wait = true; block.unsettled = false; }
      else if (op.kind === 'key' && op.key === 'Enter') block.unsettled = true; // ran something, did not wait for it
      else if (op.kind === 'sleep' && op.sec >= 1) block.unsettled = false;
      return;
    }
    if (op.kind === 'sleep') {
      if (op.sec <= 0) return;
      const after = segs[segs.length - 1];
      const grace = after.kind === 'settle' && after.cut ? (after.unsettled ? 1.2 : 0.12) : 0;
      segs.push({ kind: running ? 'any' : 'quiet', sec: op.sec, running, line: op.line, grace });
    } else if (op.kind === 'type') {
      if (!op.chars) return;
      segs.push({ kind: 'type', sec: op.chars * op.speed, chars: op.chars, speed: op.speed, line: op.line });
      running = false;
    } else if (op.kind === 'key') {
      segs.push({ kind: 'any', key: op.key, sec: op.count * op.speed, submits: !!op.submits, line: op.line });
      if (op.submits) running = true;
      else if (/^Ctrl\+[CD]$/i.test(op.key)) running = false;
    } else if (op.kind === 'wait') {
      segs.push({ kind: 'free', timeout: op.timeout, line: op.line });
      running = false;
    } else return;
    segOf.set(idx, segs.length - 1);
  });
  return { segs, segOf };
}

// ---- reading a recording ------------------------------------------------------------------------

// Per-frame change against the previous frame: how many pixels moved, and the box they fall in.
function readSignal(file) {
  return new Promise((resolve, reject) => {
    const pr = spawnSync('ffprobe', ['-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=avg_frame_rate,r_frame_rate,nb_frames',
      '-of', 'json', file], { encoding: 'utf8' });
    if (pr.error || pr.status !== 0) return reject(new Error(`ffprobe could not read ${file}: ${pr.error ? pr.error.message : (pr.stderr || '').trim()}`));
    let fps = 25;
    try {
      const st = JSON.parse(pr.stdout).streams[0];
      const [a, b] = String(st.avg_frame_rate && st.avg_frame_rate !== '0/0' ? st.avg_frame_rate : st.r_frame_rate).split('/').map(Number);
      if (a > 0 && (b || 1) > 0) fps = a / (b || 1);
    } catch { /* keep the vhs default */ }

    const size = W * H;
    const ff = spawn('ffmpeg', ['-v', 'error', '-i', file, '-an', '-vf', `scale=${W}:${H}:flags=area,format=gray`, '-f', 'rawvideo', '-'],
      { stdio: ['ignore', 'pipe', 'pipe'] });
    let err = '';
    ff.stderr.on('data', d => { err += d; });
    let prev = null;
    let cur = Buffer.alloc(size);
    let fill = 0;
    const count = [], x0s = [], y0s = [], x1s = [], y1s = [], inks = [];
    const frame = () => {
      let n = 0, x0 = W, x1 = -1, y0 = H, y1 = -1;
      // Ink: how many pixels are not background (the corner pixel lies in the padding).
      const bg = cur[0];
      let ink = 0;
      for (let p = 0; p < size; p++) { const d = cur[p] - bg; if (d > PIXEL_DELTA || d < -PIXEL_DELTA) ink++; }
      inks.push(ink);
      if (prev) {
        for (let p = 0; p < size; p++) {
          const d = cur[p] - prev[p];
          if (d > PIXEL_DELTA || d < -PIXEL_DELTA) {
            n++;
            const x = p % W, y = (p - x) / W;
            if (x < x0) x0 = x;
            if (x > x1) x1 = x;
            if (y < y0) y0 = y;
            if (y > y1) y1 = y;
          }
        }
      }
      count.push(n); x0s.push(x0); y0s.push(y0); x1s.push(x1); y1s.push(y1);
      const t = prev || Buffer.alloc(size);
      prev = cur;
      cur = t;
    };
    ff.stdout.on('data', chunk => {
      let off = 0;
      while (off < chunk.length) {
        const take = Math.min(size - fill, chunk.length - off);
        chunk.copy(cur, fill, off, off + take);
        fill += take;
        off += take;
        if (fill === size) { frame(); fill = 0; }
      }
    });
    ff.on('error', e => reject(new Error(`ffmpeg failed to start: ${e.message}`)));
    ff.on('close', code => {
      if (code !== 0 && !count.length) return reject(new Error(`ffmpeg could not decode ${file}: ${err.trim().split('\n').pop()}`));
      resolve({ fps, frames: count.length, count, ink: inks, x0: x0s, y0: y0s, x1: x1s, y1: y1s });
    });
  });
}

// Mark the frames that look like one keystroke: a change one text row high and a few cells wide.
// Output, a line break (the change spans two rows from the left margin) and a clear do not.
function classify(sig) {
  const F = sig.frames;
  const heights = [];
  for (let i = 0; i < F; i++) {
    if (sig.count[i] >= 15 && sig.x1[i] - sig.x0[i] < 40) heights.push(sig.y1[i] - sig.y0[i] + 1);
  }
  const rowH = heights.length >= 5 ? median(heights) : null;
  sig.rowHeight = rowH;
  sig.changed = new Uint8Array(F);
  sig.keylike = new Uint8Array(F);
  for (let i = 0; i < F; i++) {
    if (sig.count[i] < MIN_PIXELS) continue;
    sig.changed[i] = 1;
    if (rowH == null) { sig.keylike[i] = 1; continue; }
    const h = sig.y1[i] - sig.y0[i] + 1, w = sig.x1[i] - sig.x0[i] + 1;
    if (sig.count[i] >= 15 && h <= rowH + 3 && h >= rowH - 4 && w <= 4 * rowH) sig.keylike[i] = 1;
  }
  return sig;
}

// ---- alignment ----------------------------------------------------------------------------------

const QUIET_CHANGE_COST = 1;     // a changed frame inside a Sleep at the prompt
const TYPE_MISS_COST = 0.5;      // typing: each keystroke-like frame more or fewer than one per character
const TYPE_ALIEN_COST = 1;       // typing: a changed frame that does not look like a keystroke
const SETTLE_FRAME_COST = 0.02;  // prefer short settles
const FREE_TAIL_COST = 0.3;     // a still frame at the end of a Wait (it ends when the prompt returns)
const DEV_WEIGHT = 0.25;         // cost of a segment being one sigma off its expected length

function expectedFrames(seg, fps, p) {
  if (seg.kind === 'type') return seg.chars * (seg.speed + p.overhead) * fps * p.scale;
  return (seg.sec || 0) * fps * p.scale;
}

// Semi-Markov alignment: every segment gets a span of frames, in order, covering the recording.
// Returns { cost, bounds } (bounds[k] = first frame of segment k, bounds[K] = frame count) or null.
function align(segs, sig, p) {
  const F = sig.frames;
  const K = segs.length;
  const changed = new Int32Array(F + 1); // prefix sum of "frame i changed"
  const keys = new Int32Array(F + 1);    // prefix sum of "frame i looks like a keystroke"
  for (let i = 0; i < F; i++) { changed[i + 1] = changed[i] + sig.changed[i]; keys[i + 1] = keys[i] + sig.keylike[i]; }
  const lastChange = new Int32Array(F + 1); // index of the last changed frame before e, or -1
  lastChange[0] = -1;
  for (let i = 0; i < F; i++) lastChange[i + 1] = sig.count[i] >= MIN_PIXELS ? i : lastChange[i];
  const INF = 1e18;
  let prev = new Float64Array(F + 1).fill(INF);
  prev[0] = 0;
  const back = new Int32Array(K * (F + 1)).fill(-1);

  for (let k = 0; k < K; k++) {
    const seg = segs[k];
    const cur = new Float64Array(F + 1).fill(INF);
    const row = k * (F + 1);
    const last = k === K - 1;
    if (seg.kind === 'free') {
      // A Wait ends when the prompt is back, so it should end on a screen change: still frames at
      // its tail cost. Without this the cheapest fit shrinks every Sleep and lets Waits soak up the rest.
      let best = INF, at = -1, upTo = -1; // running minimum of prev[0..upTo]
      for (let e = 0; e <= F; e++) {
        const pivot = lastChange[e] + 1; // a Wait starting at or before here has (e - pivot) still tail frames
        while (upTo < pivot) { upTo++; if (prev[upTo] < best) { best = prev[upTo]; at = upTo; } }
        let c = best + FREE_TAIL_COST * (e - pivot), from = at;
        for (let b = pivot + 1; b <= e; b++) {
          const v = prev[b] + FREE_TAIL_COST * (e - b);
          if (v < c) { c = v; from = b; }
        }
        cur[e] = c;
        back[row + e] = from;
      }
    } else if (seg.kind === 'settle') {
      const max = 3;
      for (let e = 0; e <= F; e++) {
        for (let len = 0; len <= max && len <= e; len++) {
          const c = prev[e - len] + SETTLE_FRAME_COST * len;
          if (c < cur[e]) { cur[e] = c; back[row + e] = e - len; }
        }
      }
    } else {
      const mean = expectedFrames(seg, p.fps, p);
      // The last segment takes whatever is left of the recording, at a price.
      const sigma = (p.rel * mean + p.abs) * (last ? 2 : 1);
      const lo = last ? 0 : Math.max(0, Math.floor(mean - 3 * sigma));
      const hi = last ? F : Math.ceil(mean + 3 * sigma);
      // A Sleep right after a cut may still show a hidden command finishing: ignore its first frames.
      const grace = seg.kind === 'quiet' && seg.grace ? Math.round(seg.grace * p.fps) : 0;
      for (let e = 0; e <= F; e++) {
        const maxLen = Math.min(hi, e);
        for (let len = lo; len <= maxLen; len++) {
          const b = e - len;
          if (prev[b] >= INF) continue;
          const z = (len - mean) / sigma;
          let c = prev[b] + DEV_WEIGHT * z * z;
          if (seg.kind === 'quiet') c += QUIET_CHANGE_COST * (changed[e] - changed[Math.min(e, b + grace)]);
          // Typing changes the screen once per character (several characters can share a frame).
          // Two characters can share a frame, so allow a few short.
          else if (seg.kind === 'type') {
            const k = keys[e] - keys[b], want = Math.min(seg.chars, len);
            c += TYPE_MISS_COST * Math.max(0, Math.abs(k - want) - 0.1 * want) + TYPE_ALIEN_COST * (changed[e] - changed[b] - k);
          }
          if (c < cur[e]) { cur[e] = c; back[row + e] = b; }
        }
      }
    }
    prev = cur;
  }
  if (prev[F] >= INF) return null;
  const bounds = new Array(K + 1);
  bounds[K] = F;
  let e = F;
  for (let k = K - 1; k >= 0; k--) { e = back[k * (F + 1) + e]; bounds[k] = e; }
  return { cost: prev[F], bounds };
}

const median = a => { const s = [...a].sort((x, y) => x - y); return s.length ? s[Math.floor(s.length / 2)] : null; };

// Fit the time scale and per-key overhead from segments whose two ends are sharp screen changes.
function refit(segs, sig, bounds, p) {
  const isChanged = i => i >= 0 && i < sig.frames && sig.count[i] >= MIN_PIXELS;
  const scales = [];
  const overheads = [];
  // A Sleep at the prompt that is followed by typing (or ends the recording) is a still run whose
  // true length is the Sleep: measure the run between the nearest changes.
  segs.forEach((seg, k) => {
    const nextSeg = segs[k + 1];
    if (seg.kind !== 'quiet' || seg.sec < 0.8 || (nextSeg && nextSeg.kind !== 'type')) return;
    let b = bounds[k], e = bounds[k + 1];
    for (let i = b + 2; i >= b - 3; i--) if (isChanged(i)) { b = i + 1; break; }
    if (nextSeg) { let found = false; for (let i = e - 2; i <= e + 2; i++) if (isChanged(i)) { e = i; found = true; break; } if (!found) return; }
    if (!(isChanged(b - 1) || b === 0)) return;
    scales.push((e - b) / (seg.sec * p.fps));
  });
  const scale = scales.length >= 1 ? Math.min(1.15, Math.max(0.4, median(scales))) : p.scale;
  segs.forEach((seg, k) => {
    const prevSeg = segs[k - 1], nextSeg = segs[k + 1];
    if (seg.kind !== 'type' || seg.chars < 8 || !prevSeg || !nextSeg) return;
    if (!['quiet', 'settle'].includes(prevSeg.kind) || nextSeg.kind !== 'quiet' || nextSeg.sec < 0.15) return;
    let first = bounds[k], lastCh = bounds[k + 1] - 1;
    while (first < lastCh && !sig.keylike[first]) first++;
    while (lastCh > first && !sig.keylike[lastCh]) lastCh--;
    overheads.push((lastCh - first + 1) / (seg.chars * p.fps * scale) - seg.speed);
  });
  const overhead = overheads.length >= 1 ? Math.min(0.03, Math.max(0, median(overheads))) : p.overhead;
  return { scale, overhead, samples: { scale: scales.length, overhead: overheads.length } };
}

// ---- events -------------------------------------------------------------------------------------

function emptyResult(tape, extra) {
  const cmds = tape.commands.filter(c => !c.hidden);
  return {
    detector: DETECTOR_VERSION, fps: null, frames: 0, duration: 0, scale: null, aligned: false,
    commands: cmds.map(c => ({ n: c.n, text: c.text, line: c.line, typed: null, enter: null, output: null, done: null, confidence: 'none', doubts: [] })),
    events: {}, cuts: [], covers: [], advice: [], uncovered: [], warnings: [...tape.warnings], ...extra,
  };
}

async function detectEvents(tapeText, recordingFile, opts = {}) {
  let tape;
  try { tape = parseTape(tapeText); } catch (e) {
    return emptyResult({ commands: [], warnings: [] }, { warnings: [`could not read the tape: ${e.message}`] });
  }
  let sig;
  try { sig = await readSignal(recordingFile); } catch (e) {
    const r = emptyResult(tape);
    r.warnings.push(`could not read the recording: ${e.message}`);
    return r;
  }
  try {
    return locate(tape, sig, opts);
  } catch (e) {
    const r = emptyResult(tape);
    r.fps = sig.fps; r.frames = sig.frames; r.duration = sig.frames / sig.fps;
    r.warnings.push(`event detection failed (${e.message}); no events for this recording`);
    return r;
  }
}

// detectEvents with a cache beside the recording (<recording>.events.json). The key covers the
// detector version, the tape text and the recording's bytes, so a re-recording is always read
// again. Nothing is written unless `write` is set.
async function eventsFor(tapeText, recordingFile, { write = false } = {}) {
  const file = recordingFile.replace(/\.[^./]+$/, '.events.json');
  const key = crypto.createHash('sha1').update(DETECTOR_VERSION).update('\0').update(String(tapeText)).update('\0')
    .update(fs.readFileSync(recordingFile)).digest('hex');
  try {
    const cached = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (cached.key === key) return cached;
  } catch { /* no cache, or unreadable: detect */ }
  const det = { key, ...(await detectEvents(tapeText, recordingFile)) };
  if (write && det.frames > 0) {
    try { fs.writeFileSync(file, JSON.stringify(det, null, 2) + '\n'); } catch (e) { det.warnings.push(`could not save ${file}: ${e.message}`); }
  }
  return det;
}

function locate(tape, sig, opts) {
  const { segs, segOf } = buildSegments(tape);
  const fps = sig.fps;
  const F = sig.frames;
  const warnings = [...tape.warnings];
  const visible = tape.commands.filter(c => !c.hidden);
  const out = emptyResult(tape);
  out.fps = fps; out.frames = F; out.duration = F / fps;
  if (!F) { out.warnings.push('the recording has no frames'); return out; }
  classify(sig);

  // Pass 1: try a few time scales (video seconds per real second) with loose tolerances.
  const speedup = 1 / (tape.settings.playbackSpeed || 1);
  let best = null;
  for (const s of [0.97, 0.9, 1.04, 0.83, 0.76, 0.68, 0.6]) {
    const p = { fps, scale: s * speedup, overhead: 0.003, rel: 0.08, abs: 1.5 };
    const a = align(segs, sig, p);
    if (a) a.cost += 2 * Math.abs(Math.log(s / 0.97)); // when fits tie, prefer the usual scale
    if (a && (!best || a.cost < best.cost)) best = { ...a, p };
  }
  if (!best) {
    // Something does not fit (a different tape, a truncated recording): try again with very loose lengths.
    const p = { fps, scale: 0.97 * speedup, overhead: 0.003, rel: 0.35, abs: 6 };
    const a = align(segs, sig, p);
    if (a) { best = { ...a, p }; warnings.push('the recording does not match the tape\'s timing closely; events are rough (was the tape edited after recording?)'); }
  }
  if (!best) {
    out.warnings = [...warnings, 'could not line the tape up with the recording (is this the recording of this tape?); no events'];
    return out;
  }
  // Pass 2: refit scale and key overhead from the sharp segments, then tighten.
  let fit = { scale: best.p.scale, overhead: best.p.overhead, samples: { scale: 0, overhead: 0 } };
  if (best.p.rel < 0.2) {
    fit = refit(segs, sig, best.bounds, best.p);
    const p2 = { fps, scale: fit.scale, overhead: fit.overhead, rel: 0.04, abs: 1.5 };
    const a2 = align(segs, sig, p2);
    if (a2) best = { ...a2, p: p2 };
  }
  const b = best.bounds;
  const p = best.p;

  const isChanged = i => i >= 0 && i < F && sig.count[i] >= MIN_PIXELS;
  const firstChanged = (from, to) => { for (let i = Math.max(0, from); i < Math.min(F, to); i++) if (isChanged(i)) return i; return -1; };
  const lastChanged = (from, to) => { for (let i = Math.min(F, to) - 1; i >= Math.max(0, from); i--) if (isChanged(i)) return i; return -1; };
  const changedIn = (from, to) => { let n = 0; for (let i = Math.max(0, from); i < Math.min(F, to); i++) if (isChanged(i)) n++; return n; };

  // What one keystroke changes, so "more than a cursor move" can be told from real output.
  const keyPixels = [];
  segs.forEach((seg, k) => { if (seg.kind === 'type') for (let i = b[k]; i < b[k + 1]; i++) if (sig.keylike[i]) keyPixels.push(sig.count[i]); });
  const keySize = keyPixels.length >= 5 ? median(keyPixels) : 120;
  const big = 2.5 * keySize; // a change that is clearly more than typing: a cut, a clear, a block of output
  // Pressing Enter moves the cursor to the next line (about one keystroke's worth of pixels); a
  // prompt coming straight back adds a "$". Anything beyond that at the Enter is output.
  const beyondEnter = 1.7 * keySize;
  const maybeOutput = 1.35 * keySize;

  // Cuts (Hide ... Show), and hidden content that is still on screen after a Show.
  //
  // What counts as hidden content, decided conservatively:
  //   - only after a Show whose hidden block typed something (a jump cut, Hide / Wait / Show, is never touched);
  //   - only up to the next visible Enter that submits a command: until then the visible tape can
  //     only sleep and type, and neither can erase the screen;
  //   - the sign is a wipe: one frame in which at least half of the text on screen disappears
  //     (a hidden `clear` landing late). Typing, a wrapped line, scrolling and output never do that;
  //   - at most COVER_MAX seconds, and not if more than three typed characters would be skipped.
  // The frames from the first sign of the hidden block (the first frame of the recording, for the
  // opening Show) up to the wipe are a cover: the renderer shows the first clean frame in their
  // place. Anything else that looks late is left exactly as recorded and reported.
  const cuts = [];
  const covers = [];
  const advice = [];
  const uncovered = [];
  const leave = msg => { warnings.push(msg); uncovered.push(msg); }; // hidden content left as recorded
  const cutAt = new Map(); // segment index -> first frame after the cut
  const isWipe = i => i > 0 && sig.count[i] >= big && sig.ink[i] <= 0.5 * sig.ink[i - 1];
  segs.forEach((seg, k) => {
    if (!(seg.cut)) return;
    const f0 = b[k];
    const before = segs[k - 1];
    const reach = 3 + (before && before.kind === 'any' ? Math.ceil(0.04 * (b[k] - b[k - 1])) : 0);
    const opening = !!seg.start;
    const secs = n => (n / fps).toFixed(2);
    let f = f0;
    let clean = -1;
    if (seg.typed) {
      let j = k + 1;
      while (j < segs.length && !(segs[j].kind === 'any' && segs[j].submits)) j++;
      const stop = Math.max(f0, (j < segs.length ? b[j] : F) - 3); // the Enter is found within 3 frames of its segment
      const lo = opening ? 0 : before && before.kind === 'quiet' ? Math.max(b[k - 1], f0 - reach) : f0;
      const hi = Math.min(stop, f0 + Math.round(COVER_MAX * fps) + 1);
      let wipe = -1;
      for (let i = Math.max(1, lo); i < hi; i++) if (isWipe(i)) wipe = i;
      if (wipe >= 0) {
        // The wipe can take a frame or two to finish (the prompt is drawn again).
        let last = wipe;
        for (let n = 0; n < 2 && last + 1 < stop; n++) {
          const i = last + 1;
          if (isChanged(i) && !sig.keylike[i] && sig.count[i] < big && sig.ink[i] <= sig.ink[last] * 1.5 + 60) last = i; else break;
        }
        const sign = opening ? 0 : firstChanged(Math.max(1, lo), wipe);
        const from = sign >= 0 ? sign : wipe;
        let keys = 0;
        for (let i = from; i < last; i++) if (sig.keylike[i]) keys++;
        if (keys > 3) {
          leave(`line ${seg.line}: hidden content seems to stay on screen for ${secs(last - from)}s after Show (at ${secs(from)}s) while ${keys} characters are typed over it; ` +
            'left as recorded because covering it would skip the typing. Put Wait /\\$\\s*$/ before Show and re-record');
        } else {
          f = from;
          clean = last;
          if (last > from) {
            covers.push({ from, to: last, line: seg.line, frames: last - from, seconds: (last - from) / fps });
            if (seg.unsettled) {
              advice.push(`line ${seg.line}: Show ran before the hidden command had finished: ${last - from} frame(s) (${secs(last - from)}s) still show it. ` +
                'The renderer covers them; put Wait /\\$\\s*$/ before Show so the next recording starts clean');
            }
          }
        }
      } else if (seg.unsettled) {
        // No wipe within reach. Say so when something clearly lands late, and leave the frames alone.
        let late = -1;
        for (let i = hi; i < stop; i++) if (isWipe(i)) { late = i; break; }
        if (late >= 0) {
          leave(`line ${seg.line}: hidden content stays on screen for ${secs(late - f0)}s after Show (until ${secs(late)}s), too long to cover. Put Wait /\\$\\s*$/ before Show and re-record`);
        } else {
          const next = segs[k + 1];
          const until = Math.min(hi, next && next.kind === 'quiet' ? b[k + 2] : b[k + 1]);
          for (let i = f0 + 1; i < until; i++) {
            if (sig.count[i] >= big && !sig.keylike[i]) {
              leave(`line ${seg.line}: the screen changes at ${secs(i)}s, ${secs(i - f0)}s after Show, while nothing visible is happening (a hidden command still printing?). ` +
                'It is not a wipe, so it is left as recorded. Put Wait /\\$\\s*$/ before Show and re-record');
              break;
            }
          }
        }
      }
    }
    if (clean < 0) {
      // Nothing to cover. Only a Sleep's expected length places a cut, so move it onto the largest
      // screen change within a few frames (a cut normally replaces most of the screen).
      if (f0 > 0) {
        let at = -1;
        for (let i = Math.max(1, f0 - reach); i <= Math.min(F - 1, f0 + reach); i++) {
          if (sig.count[i] >= big && (at < 0 || sig.count[i] > sig.count[at] || (sig.count[i] === sig.count[at] && Math.abs(i - f0) < Math.abs(at - f0)))) at = i;
        }
        // A jump cut whose output is only a word or two has no large change: take the nearest
        // change that is more than a spinner tick.
        if (at < 0 && seg.hiddenWait) {
          for (let i = Math.max(1, f0 - reach); i <= Math.min(F - 1, f0 + reach); i++) {
            if (sig.count[i] >= 0.5 * keySize && (at < 0 || Math.abs(i - f0) < Math.abs(at - f0))) at = i;
          }
        }
        if (at >= 0) f = at;
      }
      clean = f;
    }
    cutAt.set(k, f);
    cuts.push({ frame: f, t: f / fps, line: seg.line, jump: !!seg.hiddenWait, typed: !!seg.typed, clean_from: clean / fps, clean_frame: clean });
  });

  // Alignment health per quiet segment: changes where the screen should be still.
  const noisy = new Set();
  segs.forEach((seg, k) => { if (seg.kind === 'quiet' && changedIn(b[k] + Math.max(3, Math.round((seg.grace || 0) * fps)), b[k + 1]) > 1) noisy.add(k); });

  const events = {};
  const commands = [];
  let floor = 0; // events never go backwards
  let typingSeen = 0, typingWanted = 0; // across the whole tape: is this the recording of this tape?
  for (const c of visible) {
    const ts = segOf.get(c.typeOps[0]);
    const lastTs = segOf.get(c.typeOps[c.typeOps.length - 1]);
    const enterOp = tape.ops[c.enterOp];
    const es = segOf.get(c.enterOp);
    const all = []; // doubts that apply to every event of this command
    const ev = { typed: { doubts: [], notes: [] }, enter: { doubts: [], notes: [] }, output: { doubts: [], notes: [] }, done: { doubts: [], notes: [] } };
    let low = false;

    if (ts === undefined) { // nothing visible was typed (zero-length Type)
      commands.push({ n: c.n, text: c.text, line: c.line, typed: null, enter: null, output: null, done: null, confidence: 'none', doubts: ['nothing was typed for this command'] });
      continue;
    }

    // typed: first change inside the typing segment.
    let typed = firstChanged(b[ts], b[ts + 1]);
    if (typed < 0) { typed = b[ts]; ev.typed.doubts.push('no screen change where the typing should start'); low = true; }
    const seenTyping = c.typeOps.reduce((n, o) => { const k = segOf.get(o); return k === undefined ? n : n + changedIn(b[k], b[k + 1]); }, 0);
    const wantTyping = c.typeOps.reduce((n, o) => { const k = segOf.get(o); return k === undefined ? n : n + Math.min(tape.ops[o].chars, b[k + 1] - b[k]); }, 0);
    typingSeen += seenTyping;
    typingWanted += wantTyping;
    if (wantTyping >= 4 && seenTyping < 0.5 * wantTyping) { all.push('typing was not seen where the tape says it happens'); low = true; }
    for (const seg of [ts - 1, ts + 1]) if (noisy.has(seg)) { all.push('the screen changed during a Sleep next to this command, so the alignment is uncertain'); low = true; break; }

    // enter: the first change at the end of the pre-Enter pause; or, with no pause, the first
    // change that leaves the line being typed.
    let enter;
    if (es === undefined || (enterOp && enterOp.hidden)) {
      // submitted inside a hidden block: the cut is the best we have
      const cut = cuts.find(x => x.frame >= b[lastTs + 1] - 3);
      enter = cut ? cut.frame : b[lastTs + 1];
      ev.enter.doubts.push('the Enter is inside a Hide block; enter is the cut');
    } else {
      const before = segs[es - 1];
      const beforeLen = b[es] - b[es - 1];
      if (before && before.kind === 'quiet' && beforeLen >= 3) {
        const reach = Math.max(6, Math.ceil(0.15 * beforeLen));
        const f = firstChanged(b[es] - 3, b[es] + reach);
        if (f >= 0) enter = f;
        else { enter = b[es]; ev.enter.doubts.push('no screen change at the Enter; time taken from the tape'); }
      } else {
        const rows = [];
        for (let i = b[lastTs]; i < b[lastTs + 1]; i++) if (isChanged(i)) rows.push([sig.y0[i], sig.y1[i]]);
        const top = median(rows.map(r => r[0])), bottom = median(rows.map(r => r[1]));
        const reach = Math.max(4, Math.ceil(0.2 * (b[lastTs + 1] - b[lastTs])));
        let f = -1;
        if (top != null) {
          for (let i = Math.max(b[lastTs], b[es] - reach); i < Math.min(F, b[es] + reach + 4); i++) {
            if (isChanged(i) && (sig.y1[i] > bottom + 2 || sig.y0[i] < top - 2)) { f = i; break; }
          }
        }
        if (f >= 0) { enter = f; ev.enter.doubts.push('no Sleep between Type and Enter; enter is the first change that leaves the typed line'); }
        else { enter = b[es]; ev.enter.doubts.push('no Sleep between Type and Enter and no clear change; enter estimated from typing speed'); }
      }
    }
    if (enter < typed) enter = typed;

    // The command's own stretch: from Enter to the next Sleep-at-the-prompt or typing.
    let j = es === undefined ? lastTs + 1 : es + 1;
    const spanCuts = [];
    while (j < segs.length && (segs[j].kind === 'free' || segs[j].kind === 'settle' || (segs[j].kind === 'any' && (segs[j].running || segs[j].key)))) {
      if (segs[j].cut) spanCuts.push(j);
      j++;
    }
    const spanEnd = j < segs.length ? b[j] : F;
    // Rendering can trail the Wait by a frame or two: allow the first frames of a following Sleep.
    const grace = j < segs.length && segs[j].kind === 'quiet' && b[j + 1] - b[j] > 8 ? 3 : 0;
    const from = Math.min(enter, spanEnd);
    const to = Math.min(F, spanEnd + grace);
    const jump = spanCuts.find(k => segs[k].hiddenWait);

    let done = Math.max(enter, lastChanged(from, to));
    for (const k of spanCuts) if (cutAt.get(k) < F) done = Math.max(done, cutAt.get(k));
    let output;
    if (jump !== undefined && cutAt.get(jump) < F) {
      output = cutAt.get(jump);
      if (sig.count[output] < MIN_PIXELS) ev.output.doubts.push('nothing changed across the jump cut; the output may be empty');
      const early = (() => { for (let i = from; i < output; i++) if (sig.count[i] >= big) return i; return -1; })();
      if (early >= 0 && early > enter + 1) ev.output.notes.push(`something was printed before the cut (at ${(early / fps).toFixed(2)}s); output is the frame after the cut`);
    } else {
      // Output right at the Enter (an instant command) shows as more than the cursor moving down.
      // Otherwise the next screen change after the Enter is the output (or the prompt returning).
      output = -1;
      for (let i = from; i <= Math.min(to - 1, enter + 1); i++) if (sig.count[i] >= beyondEnter) { output = i; break; }
      if (output < 0) {
        const later = firstChanged(enter + 2, to);
        if (later >= 0) {
          output = later;
          let atEnter = 0;
          for (let i = from; i <= Math.min(to - 1, enter + 1); i++) atEnter = Math.max(atEnter, sig.count[i]);
          if (atEnter >= maybeOutput) ev.output.doubts.push('something small may have been printed right at the Enter; output is the next screen change after it');
        } else {
          output = done;
          ev.output.notes.push('little or no visible output; output is when the prompt came back');
        }
      }
    }
    if (output < enter) output = enter;
    if (done < output) done = output;
    if (j < segs.length && segs[j].kind === 'type' && segs[j - 1] && segs[j - 1].kind === 'free') {
      ev.done.doubts.push('no Sleep between the Wait and the next Type; done and the next typed run together');
    }
    if (j < segs.length && noisy.has(j)) { ev.done.doubts.push('the screen kept changing during the Sleep after this command (output still arriving, or a blinking cursor)'); }

    const frames = { typed, enter, output, done };
    const cmd = { n: c.n, text: c.text, line: c.line, jump_cut: jump !== undefined };
    const cmdDoubts = new Set(all);
    const cmdNotes = [];
    let worst = 'high';
    for (const name of EVENT_NAMES) {
      const f = Math.min(F, Math.max(frames[name], floor));
      floor = f;
      // A doubt lowers confidence in the time; a note only explains what the event means here.
      const doubts = [...all, ...ev[name].doubts];
      const confidence = low ? 'low' : doubts.length ? 'medium' : 'high';
      if (confidence === 'low' || (confidence === 'medium' && worst === 'high')) worst = confidence;
      ev[name].doubts.forEach(d => cmdDoubts.add(`${name}: ${d}`));
      ev[name].notes.forEach(d => cmdNotes.push(`${name}: ${d}`));
      events[`${name}:${c.n}`] = { t: f / fps, frame: f, confidence, doubts, ...(ev[name].notes.length ? { notes: ev[name].notes } : {}) };
      cmd[name] = f / fps;
    }
    cmd.confidence = worst;
    cmd.doubts = [...cmdDoubts];
    if (cmdNotes.length) cmd.notes = cmdNotes;
    commands.push(cmd);
  }

  const quietNoise = [...noisy].length;
  if (quietNoise) warnings.push(`${quietNoise} Sleep(s) at the prompt had the screen changing during them (lines ${[...noisy].map(k => segs[k].line).join(', ')}); events near them are less certain`);
  out.aligned = true;
  // Two checks on the whole fit. A recording that shows less than half of the tape's typing is
  // not a recording of this tape. A costly fit (many frames the tape cannot explain) is usable
  // but not to be trusted to the frame.
  const demote = (to, why) => {
    for (const e of Object.values(events)) { if (to === 'low' || e.confidence === 'high') e.confidence = to; e.doubts.push(why); }
    for (const c of commands) { if (to === 'low' || c.confidence === 'high') c.confidence = to; if (c.doubts) c.doubts.push(why); }
  };
  if (typingWanted >= 6 && typingSeen < 0.5 * typingWanted) {
    out.aligned = false;
    warnings.push('the recording shows less than half of the typing this tape describes: it does not look like a recording of this tape (was the tape edited after recording?)');
    demote('low', 'the recording does not match the tape');
  } else if (best.cost > 4 + 0.6 * segs.length) {
    warnings.push(`the tape fits the recording poorly (cost ${best.cost.toFixed(1)} over ${segs.length} steps); event times are less certain`);
    demote('medium', 'the tape fits the recording poorly');
  }
  out.scale = Number(p.scale.toFixed(4));
  out.key_overhead_ms = Number((p.overhead * 1000).toFixed(1));
  out.fit = { cost: Number(best.cost.toFixed(2)), samples: fit.samples };
  out.commands = commands;
  out.events = events;
  out.cuts = cuts;
  out.covers = out.aligned ? covers : []; // frames to replace with the first clean frame: [{ from, to, line, frames, seconds }]
  out.advice = advice;   // for whoever edits the tape next; nothing is wrong with the video
  out.uncovered = uncovered; // hidden content that looks late but was left as recorded (also in warnings)
  out.warnings = warnings;
  // For the sync report: when the screen is moving (changed frames less than 0.4 s apart are one
  // stretch), and where each Sleep sits, so a dead stretch can be traced to a tape line.
  const activity = [];
  const join = Math.round(0.4 * fps);
  for (let i = 0; i < F; i++) {
    if (!isChanged(i)) continue;
    const last = activity[activity.length - 1];
    if (last && i - last[1] <= join) last[1] = i + 1; else activity.push([i, i + 1]);
  }
  out.activity = activity.map(([a, e]) => [a / fps, e / fps]);
  out.sleeps = segs.map((sg, k) => ({ sg, k })).filter(x => (x.sg.kind === 'quiet' || x.sg.kind === 'any') && !x.sg.key)
    .map(({ sg, k }) => ({ line: sg.line, seconds: sg.sec, start: b[k] / fps, end: b[k + 1] / fps, running: !!sg.running }));
  if (opts.debug) {
    out.after_cuts = cuts.map(c => ({ line: c.line, frame: c.frame, frames: Array.from({ length: Math.min(16, F - c.frame + 2) }, (_, j) => {
      const i = Math.max(0, c.frame - 2) + j;
      return { i, changed: sig.count[i], ink: sig.ink[i], key: sig.keylike[i] };
    }) }));
    out.segments = segs.map((s, k) => ({ kind: s.kind, line: s.line, start: Number((b[k] / fps).toFixed(2)), end: Number((b[k + 1] / fps).toFixed(2)),
      expected: s.kind === 'free' || s.kind === 'settle' ? null : Number((expectedFrames(s, fps, p) / fps).toFixed(2)), changed: changedIn(b[k], b[k + 1]) }));
  }
  return out;
}

// ---- anchors (pure; no recording needed) ---------------------------------------------------------

function parseAnchor(value) {
  const m = ANCHOR_RE.exec(String(value == null ? '' : value).trim());
  if (!m) return null;
  return { name: m[1], n: Number(m[2]), plus: m[3] ? Number(m[3]) : 0, key: `${m[1]}:${m[2]}` };
}

// Position of an event in screen order: typed:1 < enter:1 < output:1 < done:1 < typed:2 ...
const rank = a => (a.n - 1) * 4 + EVENT_NAMES.indexOf(a.name);

// validateAnchors(narrationItems, tapeText) -> { errors, warnings }
// tapeText is the tape of a terminal scene; pass null/undefined for any other scene.
// Sentences are numbered from 0, like the lint's other messages.
function validateAnchors(narrationItems, tapeText) {
  const errors = [];
  const warnings = [];
  const items = Array.isArray(narrationItems) ? narrationItems : [];
  const terminal = typeof tapeText === 'string';
  let tape = null;
  if (terminal) { try { tape = parseTape(tapeText); } catch { tape = null; } }
  const cmds = tape ? tape.commands.filter(c => !c.hidden) : [];
  let lastWait = -1; // highest rank a wait_for has used so far
  let lastAny = -1;  // highest rank any anchor has used so far
  let used = false;

  items.forEach((item, i) => {
    if (!item || typeof item !== 'object') return;
    const where = `sentence ${i}`;
    if (item.pause !== undefined && !(Number.isFinite(Number(item.pause)) && Number(item.pause) >= 0)) {
      errors.push(`${where}: "pause" must be a number of seconds, 0 or more (got ${JSON.stringify(item.pause)})`);
    }
    if (item.read !== undefined && !(Number.isFinite(Number(item.read)) && Number(item.read) >= 0)) {
      errors.push(`${where}: "read" must be a number of seconds, 0 or more (got ${JSON.stringify(item.read)})`);
    }
    const parsed = {};
    for (const field of ['wait_for', 'before']) {
      if (item[field] === undefined || item[field] === null) continue;
      used = true;
      if (!terminal) { errors.push(`${where}: "${field}" ties a sentence to a terminal recording; this scene has no tape (use "pause" instead)`); continue; }
      const a = parseAnchor(item[field]);
      if (!a) {
        const name = String(item[field]).split(':')[0];
        const hint = /^[a-z_]+:\d+/i.test(String(item[field])) && !EVENT_NAMES.includes(name) ? ` ("${name}" is not an event name)` : '';
        errors.push(`${where}: "${field}": "${item[field]}" is not an event${hint}. Use typed:N, enter:N, output:N or done:N, optionally +seconds (e.g. "output:2+0.5")`);
        continue;
      }
      if (a.n < 1 || a.n > cmds.length) {
        errors.push(`${where}: "${field}": "${item[field]}" names command ${a.n}, but the tape has ${cmds.length} visible command${cmds.length === 1 ? '' : 's'}` +
          (cmds.length ? ` (1 = \`${cmds[0].text.split('\n')[0].slice(0, 40)}\`${cmds.length > 1 ? `, ${cmds.length} = \`${cmds[cmds.length - 1].text.split('\n')[0].slice(0, 40)}\`` : ''})` : ''));
        continue;
      }
      parsed[field] = a;
    }
    const w = parsed.wait_for, bf = parsed.before;
    if (w) {
      if (rank(w) < lastAny) errors.push(`${where}: "wait_for": "${item.wait_for}" comes before an event an earlier sentence is already tied to; anchors must follow the order things happen on screen`);
      lastWait = Math.max(lastWait, rank(w));
      lastAny = Math.max(lastAny, rank(w));
    }
    if (bf) {
      if (w && rank(bf) <= rank(w)) {
        errors.push(`${where}: "before": "${item.before}" is not later than "wait_for": "${item.wait_for}": the sentence would wait for something that is held until the sentence ends`);
      } else if (rank(bf) <= lastWait) {
        errors.push(`${where}: "before": "${item.before}" has already happened: an earlier sentence waits for ${rank(bf) === lastWait ? 'it' : 'a later event'}. Move the "before" to an earlier sentence or name a later event`);
      } else if (rank(bf) < lastAny) {
        errors.push(`${where}: "before": "${item.before}" comes before an event an earlier sentence is already tied to; anchors must follow the order things happen on screen`);
      }
      lastAny = Math.max(lastAny, rank(bf));
      // Tape shapes that make this hold unreliable.
      const c = cmds[bf.n - 1];
      if (c && tape) {
        if (bf.name === 'typed') {
          const first = c.typeOps[0];
          const prevOp = tape.ops[first - 1];
          if (prevOp && prevOp.kind === 'show') warnings.push(`${where}: "before": "${item.before}": command ${bf.n} is typed right after Show (line ${c.line}), so there is no settled frame to hold. Add Sleep 500ms after Show (and Wait /\\$\\s*$/ before it)`);
          else if (prevOp && prevOp.kind === 'wait') warnings.push(`${where}: "before": "${item.before}": command ${bf.n} is typed right after a Wait (line ${c.line}); add Sleep 500ms after the Wait so the held frame shows the finished output`);
        }
        if (bf.name === 'enter') {
          const prevOp = tape.ops[c.enterOp - 1];
          if (!prevOp || prevOp.kind !== 'sleep' || prevOp.sec < 0.15) warnings.push(`${where}: "before": "${item.before}": there is no Sleep between Type and Enter for command ${bf.n} (line ${c.line}); add Sleep 300ms so the Enter can be found exactly`);
        }
      }
    }
  });
  if (used && tape && tape.settings.cursorBlink) warnings.push('the tape does not set "Set CursorBlink false"; a frame held for "before" would visibly freeze the cursor, and blinking confuses event detection');
  return { errors, warnings };
}

// ---- narration laid out against the events --------------------------------------------------------

// Quiet time between the end of a sentence and the screen event it must come "before".
const BEFORE_MARGIN = 0.3;
// How long output stays on screen after the last sentence about it, before a hidden `clear` (or
// the end of the scene) takes it away. A viewer cannot scroll back, so this is the floor;
// "read" on a sentence asks for more.
const READ_HOLD = 2.5;

const usesAnchors = scene => (scene.narration_items || []).some(i => i && (i.wait_for || i.before));
// "read" is honoured in any scene; in a terminal scene it also holds a wipe, which needs wait_for to know the screen.

// One ordered pass over the sentences of a terminal scene.
//   pause     extra silence before the sentence
//   wait_for  the sentence starts no earlier than the event (plus its +seconds)
//   before    the event is held back until the sentence has ended (plus the margin and its
//             +seconds) by freezing the recording on the frame just before the event
//   read      quiet seconds after the sentence for the viewer to read what is on screen; the
//             next sentence starts after them
// Output is never wiped while it is being talked about. A sentence with "wait_for" is about the
// screen that event produced, and so is every sentence after it until one names a later event.
// If a hidden block clears that screen (Hide, clear, Show), the recording is frozen on the last
// frame before the wipe until the sentence has ended plus max(read, pacing.read_hold, default
// READ_HOLD). The scene's last screen gets the same time before the scene ends.
// A hold moves every later event, and later sentences see the moved times. With no anchors this
// is exactly the plain back-to-back layout.
//
// clips: [{ text, file, duration }] from audio/timings.json. det: a detectEvents() result.
// Returns { sentences, notes, holds, at, extra, length, warnings }:
//   sentences  [{ text, file, start, end }] in seconds from the scene's start
//   notes      per sentence: { pause, wait_for, waited, before, held } (only what applies)
//   holds      [{ frame, seconds, for, sentence }]: raw frames from `frame` on play `seconds` later
//   at(frame)  time in the finished clip of a raw frame
//   extra      seconds the holds add to the recording
//   length     narration length including tail, hold_after and min_duration
// Throws an Error (with a fix in its message) when an anchor names an event the recording lacks.
function layoutNarration(scene, clips, pacing, det, opts = {}) {
  const items = scene.narration_items || [];
  const fps = (det && det.fps) || 25;
  const events = (det && det.events) || {};
  const margin = opts.margin !== undefined ? opts.margin
    : Number.isFinite(Number(pacing.before_margin)) ? Number(pacing.before_margin) : BEFORE_MARGIN;
  const frameAlign = opts.frameAlign || (x => x);
  const warnings = [];
  const holds = [];
  const at = frame => frame / fps + holds.reduce((sum, h) => sum + (h.frame <= frame ? h.seconds : 0), 0);
  const event = (field, value, i) => {
    const a = parseAnchor(value);
    const e = a && events[a.key];
    if (!e) {
      throw new Error(`${scene.id} sentence ${i}: "${field}": "${value}" was not found in the recording` +
        (det && det.warnings && det.warnings.length ? ` (${det.warnings.join('; ')})` : '') +
        '. Run tape-events.js on the tape and its recording to see what was detected, re-record the scene, or remove the anchor');
    }
    if (e.confidence !== 'high') {
      warnings.push(`${scene.id} sentence ${i}: "${field}": "${value}" is a ${e.confidence}-confidence time (${e.doubts.join('; ')}); check this spot in the video`);
    }
    return { ...a, ...e };
  };
  const sentences = [];
  const notes = [];
  const readHold = opts.readHold !== undefined ? opts.readHold
    : Number.isFinite(Number(pacing.read_hold)) ? Number(pacing.read_hold) : READ_HOLD;
  // Screens a hidden block wipes: every cut whose hidden block typed something (a `clear`, a
  // rename), except the opening setup. A jump cut (Hide, Wait, Show) types nothing and is not one.
  const wipes = ((det && det.cuts) || []).filter(x => x.typed && x.frame > 0).sort((a, b) => a.frame - b.frame);
  const addHold = (frame, seconds, why, i) => {
    const same = holds.find(h => h.frame === frame);
    if (same) same.seconds += seconds;
    else holds.push({ frame, seconds, for: why, sentence: i });
  };
  let screen = null; // raw frame of the event the current sentences are about
  let lastRead = 0;  // when the last screen may go: end of its last sentence plus reading time
  let t = pacing.lead_in;
  clips.forEach((c, i) => {
    const it = items[i] || {};
    const note = {};
    const pause = Number(it.pause) || 0;
    if (pause > 0) { t += pause; note.pause = pause; }
    let start = t;
    if (it.wait_for) {
      const e = event('wait_for', it.wait_for, i);
      const earliest = at(e.frame) + e.plus;
      note.wait_for = it.wait_for;
      note.waited = Math.max(0, earliest - start);
      if (earliest > start) start = earliest;
      screen = e.frame;
    } else if (it.before) {
      // Only introduces something later: it is not about the screen before it.
      screen = null;
    }
    const end = start + c.duration;
    const read = Number(it.read) || 0;
    if (read > 0) note.read = read;
    if (screen !== null) {
      // Keep this screen until the sentence is over and it has been read.
      const until = end + Math.max(read, readHold);
      lastRead = until;
      const wipe = wipes.find(x => x.frame > screen);
      if (wipe && until - at(wipe.frame) > 1e-6) {
        const seconds = frameAlign(until - at(wipe.frame));
        addHold(wipe.frame, seconds, `read before the screen is cleared (tape line ${wipe.line})`, i);
        note.read_hold = seconds;
      }
    }
    if (it.before) {
      const e = event('before', it.before, i);
      const need = end + margin + e.plus - at(e.frame);
      note.before = it.before;
      note.held = 0;
      if (need > 1e-6) {
        // Hold whole output frames, so everything after the hold lands on the same frame grid.
        const seconds = frameAlign(need);
        let frame = e.frame;
        // The frame before the event must be a settled picture. Right after a Show it may still
        // show a hidden command: hold the first clean frame instead and say so.
        const cut = (det.cuts || []).find(x => e.frame - 1 >= x.frame && e.frame - 1 < x.clean_frame);
        if (cut) {
          frame = cut.clean_frame + 1;
          warnings.push(`${scene.id} sentence ${i}: "before": "${it.before}": the frame before this event still shows a hidden command (tape line ${cut.line}), ` +
            'so the hold starts one frame into the event. Put Wait /\\$\\s*$/ before Show and Sleep 500ms after it, then re-record');
        }
        if (frame < 1) {
          // There is no frame before the first one to freeze: the event is already on screen.
          frame = 1;
          warnings.push(`${scene.id} sentence ${i}: "before": "${it.before}" happens in the first frame of the recording, so it cannot be held back. Add Sleep 500ms after Show, then re-record`);
        }
        addHold(frame, seconds, it.before, i);
        note.held = seconds;
      }
    }
    sentences.push({ text: c.text, file: c.file, start, end });
    notes.push(note);
    t = end + read + (i < clips.length - 1 ? pacing.gap : 0);
  });
  const spoken = clips.length ? t + pacing.tail : 0;
  const hold = Number(scene.hold_after || 0);
  const min = Number(scene.min_duration || 0);
  holds.sort((a, b) => a.frame - b.frame);
  // The last screen is taken away by the cut to the next scene: give it its reading time too.
  const lastScreen = screen !== null ? lastRead : 0;
  return { sentences, notes, holds, at, extra: holds.reduce((sum, h) => sum + h.seconds, 0), length: Math.max(spoken + hold, min, lastScreen), warnings };
}

// What build/timeline.json records for a terminal scene: every event at its time in the finished
// clip (`t`, seconds from the scene's start) and in the raw recording (`raw`).
function sceneTimeline(det, layout, natural) {
  const fps = det.fps || 25;
  const at = layout ? layout.at : frame => frame / fps;
  const holds = layout ? layout.holds : [];
  const events = {};
  for (const [name, e] of Object.entries(det.events || {})) {
    events[name] = { t: at(e.frame), raw: e.t, confidence: e.confidence, ...(e.doubts.length ? { doubts: e.doubts } : {}), ...(e.notes ? { notes: e.notes } : {}) };
  }
  return {
    recording: natural, retimed: natural + (layout ? layout.extra : 0), scale: det.scale, aligned: !!det.aligned,
    commands: (det.commands || []).map(c => ({ n: c.n, text: c.text, line: c.line, jump_cut: !!c.jump_cut })),
    events,
    // `at` is where the freeze begins in the clip; the picture is the raw frame before `raw`.
    holds: holds.map(h => ({ at: at(h.frame) - h.seconds, seconds: h.seconds, raw: h.frame / fps, for: h.for, sentence: h.sentence })),
    cuts: (det.cuts || []).map(c => ({ t: at(c.frame), raw: c.t, line: c.line, jump: c.jump })),
    // Hidden content left on screen after a Show, replaced in the clip by the first clean frame.
    covers: (det.covers || []).map(c => ({ t: at(c.from), raw: c.from / fps, line: c.line, frames: c.frames, seconds: c.seconds })),
    advice: det.advice || [],
    warnings: det.warnings || [],
  };
}

// ---- CLI ----------------------------------------------------------------------------------------

const HELP = `Find when each command of a tape is typed, submitted, shows output and finishes in its recording.

Usage:
  node tape-events.js <tape-file> <recording.mp4> [--debug]
  node tape-events.js --commands <tape-file>

  --commands   Only list the visible commands with the numbers anchors use (typed:N ...); needs no recording.
  --debug      Also print the fitted segments (one per visible tape line) under "segments".

Prints JSON on stdout: { fps, frames, duration, scale, commands, events, cuts, warnings }.
Times are seconds into the recording. Reads both files; writes nothing.`;

async function main() {
  const argv = process.argv.slice(2);
  if (!argv.length || argv.includes('--help') || argv.includes('-h')) { console.log(HELP); process.exit(argv.length ? 0 : 1); }
  const flags = new Set(argv.filter(a => a.startsWith('--')));
  const files = argv.filter(a => !a.startsWith('--'));
  const fail = msg => { console.error(`error: ${msg}`); process.exit(1); };
  if (!files[0] || !fs.existsSync(files[0])) fail(`tape not found: ${files[0] || '(none)'}. Pass the .tape file first`);
  const text = fs.readFileSync(files[0], 'utf8');
  if (flags.has('--commands')) { console.log(JSON.stringify(visibleCommands(text), null, 2)); return; }
  if (!files[1] || !fs.existsSync(files[1])) fail(`recording not found: ${files[1] || '(none)'}. Pass build/raw/<id>.mp4 second, or use --commands`);
  const res = await detectEvents(text, files[1], { debug: flags.has('--debug') });
  res.warnings.forEach(w => console.error(`warning: ${w}`));
  (res.advice || []).forEach(w => console.error(`advice: ${w}`));
  console.log(JSON.stringify(res, null, 2));
  if (!res.aligned) process.exit(2);
}

if (require.main === module) main().catch(e => { console.error(`error: ${e.message}`); process.exit(1); });

module.exports = {
  DETECTOR_VERSION, EVENT_NAMES, BEFORE_MARGIN, READ_HOLD,
  detectEvents, eventsFor, validateAnchors, visibleCommands, parseAnchor, parseTape, shellIncomplete,
  usesAnchors, layoutNarration, sceneTimeline,
};
