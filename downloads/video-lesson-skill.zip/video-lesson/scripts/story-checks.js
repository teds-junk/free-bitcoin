'use strict';
// Story-level checks on a storyboard, used by lint-storyboard.js (a library; not run directly).
//
//   checkStory(sb, dir, { tapes, strictSchema }) -> { errors, warnings, report }
//
// What it checks, and why each exists:
//   narrative   the question the video answers and the arc of what the viewer can do after each stage
//   mode        every teaching scene says whether it explains how a thing WORKS, how to THINK about
//               it, or how the viewer would USE it; the sequence is printed so it can be read as a story
//   role        hook / title / body / recap / practice / next / bridge, so a compilation can choose scenes
//   introduces  no command or file appears before the viewer has been told what it is and why it matters
//   tone        production discoveries ("my first attempt…") narrated as if they were the lesson
//   lessons     references to "this lesson" in scenes a compilation cannot drop
//   headlines   an italic phrase in most headlines (it should be the exception); topic labels
//               (length, re-theming, paths, arrows and highlights are in craft-checks.js)
//
// `tapes` maps a scene id to { text, commands } for terminal scenes whose tape file exists
// (commands as returned by tape-check.js). `strictSchema` is true for storyboards with
// "schema": 2 or later: there, a missing narrative, mode, role, or introduction is an error.
// Older storyboards get the same findings as warnings, so they can still be re-linted.

const fs = require('fs');
const path = require('path');
// typed:N must mean the same command here as it does to the renderer.
let visibleCommands = null;
try { ({ visibleCommands } = require('./tape-events')); } catch { /* fall back to counting Type lines */ }

const ROLES = ['hook', 'title', 'body', 'recap', 'practice', 'next', 'bridge'];
const MODES = ['works', 'think', 'use'];
const TEACHING_ROLES = ['hook', 'body', 'practice']; // roles that must declare a mode
const DROPPABLE_ROLES = ['title', 'recap', 'next']; // what a compilation leaves out (compile.js DEFAULT_DROP)

// Commands every viewer knows; running them needs no introduction (a file they show still does).
const EVERYDAY = new Set(['cd', 'ls', 'pwd', 'clear', 'echo', 'printf', 'cat', 'less', 'mkdir', 'cp', 'mv',
  'touch', 'open', 'sleep', 'export', 'true', 'tree', 'which']);

// Narration that reports how the video was made instead of teaching. Each is a prompt to look,
// not proof: a failure that is the lesson's subject is fine; a production discovery is not.
const PRODUCTION_NOTES = [
  [/\b(my|our) first (attempt|try|run|pass)\b/i, 'narrates an earlier attempt'],
  [/\bone honest detail\b|\bto be honest\b|\bthe honest (result|answer)\b/i, 'confession'],
  [/\b(before|while|when) recording\b/i, 'talks about the recording'],
  [/\bI (ran|tried|forgot|left out|missed|didn'?t|don'?t have|haven'?t)\b/i, 'first-person production note'],
  [/\b(oops|whoops)\b|\bturns out\b|\bthat (didn'?t|did not) work\b|\bshould have\b/i, 'mistake narrated after the fact'],
  [/\bon this (machine|account|laptop)\b/i, 'machine-specific detail'],
  [/\b(isn'?t|is not|hasn'?t been|wasn'?t|was not) (run|done|checked) (here|for this (course|video))\b/i, 'something the video did not do'],
  [/\bthis course (hasn'?t|has not|met|ran into)\b/i, 'production note'],
];

const LESSON_REFERENCES = /\b(this|that|next|last|previous|earlier|later|final) lessons?\b|\blessons? (one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|\d+)\b|\bthe lesson('s)? (page|checkpoint|exercise)\b/i;

const lower = s => String(s || '').trim().toLowerCase();
const excerpt = (s, n = 70) => (s.length > n ? `${s.slice(0, n)}…` : s);

// ---- what a scene puts on screen ---------------------------------------------------------------

// Split one typed line into commands, flags, and files. Deliberately simple: tapes are meant to
// hold plain commands (tape-check.js warns about anything fancier).
function parseTyped(text) {
  const items = [];
  for (const segment of String(text).split(/\|\||&&|[|;]/)) {
    const tokens = segment.trim().replace(/\\$/, '').split(/\s+/).filter(Boolean);
    while (tokens.length && /^[A-Za-z_][A-Za-z0-9_]*=/.test(tokens[0])) tokens.shift(); // VAR=value prefix
    if (!tokens.length) continue;
    const head = tokens[0].replace(/^["'`]|["'`]$/g, '');
    if (!head.startsWith('-') && /^[\w./~-]+$/.test(head)) {
      const base = path.basename(head);
      const sub = tokens[1] && /^[a-z][a-z0-9-]*$/.test(tokens[1]) ? tokens[1] : null;
      if (!EVERYDAY.has(base)) items.push({ kind: 'command', name: sub ? `${base} ${sub}` : base });
    }
    for (const raw of tokens.slice(1).concat(head.startsWith('-') ? [head] : [])) {
      const tok = raw.replace(/^["'`]|["'`,]$/g, '');
      if (/^--?[A-Za-z][\w-]*/.test(tok)) { items.push({ kind: 'flag', name: tok.split('=')[0] }); continue; }
      if (/^[a-z]+:\/\//i.test(tok) || /[*?$(){}]/.test(tok)) continue; // URLs, globs, substitutions
      if (/\.[A-Za-z][A-Za-z0-9]{0,5}$/.test(tok) || (tok.includes('/') && !tok.endsWith('/'))) {
        const file = path.basename(tok);
        if (file && file !== '.' && file !== '..') items.push({ kind: 'file', name: file });
      }
    }
  }
  return items;
}

// Files a scene's HTML shows: file panels (data-file) and code-file labels.
function filesInHtml(file) {
  const html = fs.readFileSync(file, 'utf8').replace(/<!--[\s\S]*?-->/g, '');
  const out = new Set();
  for (const m of html.matchAll(/data-file="([^"]+)"/g)) out.add(path.basename(m[1]));
  for (const m of html.matchAll(/class="[^"]*\bcode-file\b[^"]*"[^>]*>([^<]+)</g)) {
    const name = m[1].trim().split(/\s+/)[0];
    if (/\.[A-Za-z][A-Za-z0-9]{0,5}$/.test(name) || name.includes('/')) out.add(path.basename(name));
  }
  return [...out];
}

// Everything that appears in a scene: [{ kind, name, n? }] where n is the visible command number.
function shownIn(scene, dir, tapes) {
  const items = [];
  const tape = tapes && tapes[scene.id];
  if (tape) {
    if (visibleCommands && tape.text) {
      for (const c of visibleCommands(tape.text)) {
        for (const p of parseTyped(c.text.replace(/\\\n/g, ' ').replace(/\n/g, ' '))) items.push({ ...p, n: c.n });
      }
    } else {
      // Without the timing module: a line typed after a trailing backslash continues the command.
      let n = 0;
      let continued = false;
      for (const c of tape.commands.filter(c => !c.hidden)) {
        if (!continued) n += 1;
        continued = /\\\s*$/.test(c.text);
        for (const p of parseTyped(c.text)) items.push({ ...p, n });
      }
    }
  } else if (['html', 'slide'].includes(scene.renderer) && scene.visual) {
    const file = path.resolve(dir, scene.visual);
    if (fs.existsSync(file)) for (const f of filesInHtml(file)) items.push({ kind: 'file', name: f });
  }
  for (const s of scene.shows || []) {
    const name = String(s).trim();
    items.push({ kind: name.startsWith('-') ? 'flag' : /\.[A-Za-z][A-Za-z0-9]{0,5}$/.test(name) ? 'file' : 'command', name });
  }
  const seen = new Set();
  return items.filter(i => { const k = `${i.kind}|${lower(i.name)}`; if (seen.has(k)) return false; seen.add(k); return true; });
}

// ---- the checks ---------------------------------------------------------------------------------

function checkNarrative(sb, scenes, problem, warn) {
  const n = sb.narrative;
  if (!n || typeof n !== 'object') {
    problem('no "narrative" block: plan the question the video answers and the arc before writing scenes (NARRATIVE.md)');
    return [];
  }
  if (!n.question || !String(n.question).trim()) problem('narrative.question is empty: state the one question this video answers');
  else if (!String(n.question).trim().endsWith('?')) warn('narrative.question should be a question the viewer would ask, ending in "?"');
  if (!n.viewer_starts) warn('narrative.viewer_starts is empty: say what the viewer already knows and can do when the video begins');
  const arc = Array.isArray(n.arc) ? n.arc : [];
  if (arc.length < 2) problem('narrative.arc needs at least two stages, each with what the viewer can do after it');
  if (arc.length > 6) warn(`narrative.arc has ${arc.length} stages; more than about six is hard to feel as progress. Merge stages or split the video`);
  const names = [];
  arc.forEach((a, i) => {
    if (!a || !a.stage) { problem(`narrative.arc[${i}] has no "stage" name`); return; }
    if (names.includes(a.stage)) problem(`narrative.arc stage "${a.stage}" is listed twice`);
    names.push(a.stage);
    if (!a.viewer_can || !String(a.viewer_can).trim()) problem(`narrative.arc stage "${a.stage}" has no "viewer_can": say what the viewer can do once this stage ends`);
  });
  // Every stage is used, scenes name real stages, and the video never goes back to an earlier one.
  let furthest = -1;
  const used = new Set();
  for (const s of scenes) {
    if (!s.stage) {
      if (TEACHING_ROLES.includes(s.role || 'body') && names.length) problem(`${s.id}: no "stage"; say which stage of the arc this scene belongs to (${names.join(', ')})`);
      continue;
    }
    const at = names.indexOf(s.stage);
    if (at < 0) { problem(`${s.id}: stage "${s.stage}" is not in narrative.arc (${names.join(', ')})`); continue; }
    used.add(s.stage);
    if (at < furthest) warn(`${s.id}: goes back to stage "${s.stage}" after "${names[furthest]}"; the viewer should feel progress, so move the scene or bridge the return in its first sentence`);
    furthest = Math.max(furthest, at);
  }
  for (const name of names) if (!used.has(name)) problem(`narrative.arc stage "${name}" has no scenes`);
  return arc;
}

function checkRolesAndModes(scenes, problem, warn, errors) {
  const teaching = [];
  scenes.forEach((s, i) => {
    if (s.role === undefined) problem(`${s.id}: no "role" (${ROLES.join(' | ')})`);
    else if (!ROLES.includes(s.role)) errors.push(`${s.id}: role "${s.role}" must be one of ${ROLES.join(', ')}`);
    const role = s.role || 'body';
    if (s.mode !== undefined && !MODES.includes(s.mode)) errors.push(`${s.id}: mode "${s.mode}" must be one of ${MODES.join(', ')}`);
    if (TEACHING_ROLES.includes(role)) {
      if (!s.mode) problem(`${s.id}: no "mode". Say what this scene is doing for the viewer: works (how the thing works), think (how to think about it), or use (how they would use it)`);
      else if (MODES.includes(s.mode)) teaching.push(s);
    }
    if (i === 0 && s.role && s.role !== 'hook' && s.role !== 'bridge') warn(`${s.id}: the first scene should be the hook (role "hook")`);
  });

  // The sequence, compressed: think → works ×3 → use ×2
  const runs = [];
  for (const s of teaching) {
    const last = runs[runs.length - 1];
    if (last && last.mode === s.mode) last.scenes.push(s.id); else runs.push({ mode: s.mode, scenes: [s.id] });
  }
  const strip = runs.map(r => (r.scenes.length > 1 ? `${r.mode} ×${r.scenes.length}` : r.mode)).join(' → ');

  const body = teaching.filter(s => (s.role || 'body') === 'body');
  if (body.length && body[0].mode === 'use') warn(`${body[0].id}: the first body scene is "use". Establish what the thing is and how to think about it before the viewer is shown using it`);
  // Five or more scenes in a row that each switch mode read as disjoint.
  let streak = 1;
  for (let i = 1; i <= teaching.length; i++) {
    if (i < teaching.length && teaching[i].mode !== teaching[i - 1].mode) { streak++; continue; }
    if (streak >= 5) warn(`modes change on every scene from ${teaching[i - streak].id} to ${teaching[i - 1].id} (${teaching.slice(i - streak, i).map(s => s.mode).join(' → ')}); group scenes so the viewer stays in one mode for a stretch`);
    streak = 1;
  }
  const changes = [];
  for (let i = 1; i < teaching.length; i++) {
    if (teaching[i].mode !== teaching[i - 1].mode) {
      changes.push({ scene: teaching[i].id, from: teaching[i - 1].mode, to: teaching[i].mode, opens_with: (teaching[i].narration || [])[0] || '' });
    }
  }
  return { strip, changes };
}

function checkIntroductions(scenes, dir, tapes, problem, warn) {
  const introduced = new Map(); // lowercased name -> index of the scene that introduces it
  const reported = new Set();
  const rows = [];
  scenes.forEach((s, idx) => {
    if (s.introduces !== undefined && !Array.isArray(s.introduces)) { problem(`${s.id}: "introduces" must be a list`); return; }
    const own = new Set((s.introduces || []).map(lower));
    const anchoredBefore = new Set((s.narration_items || []).map(i => /^typed:(\d+)/.exec(i.before || '')).filter(Boolean).map(m => Number(m[1])));
    for (const item of shownIn(s, dir, tapes)) {
      const key = lower(item.name);
      const earlier = introduced.has(key) ? scenes[introduced.get(key)].id : null;
      const row = { item: item.name, kind: item.kind, shown_in: s.id, introduced_in: earlier || (own.has(key) ? s.id : null) };
      if (!rows.some(r => r.kind === row.kind && lower(r.item) === key)) rows.push(row);
      if (earlier) continue;
      if (!own.has(key)) {
        if (reported.has(`${item.kind}|${key}`)) continue; // say it once, at its first appearance
        reported.add(`${item.kind}|${key}`);
        const msg = `${s.id}: ${item.kind} \`${item.name}\` appears before the viewer has been told what it is and why it matters. Explain it first, and list it in "introduces" on the scene that explains it`;
        if (item.kind === 'flag') warn(msg); else problem(msg);
      } else if (item.kind === 'command' && item.n && !anchoredBefore.has(item.n)) {
        problem(`${s.id}: \`${item.name}\` is introduced in the same scene that runs it, so nothing guarantees the explanation comes first. Put "before": "typed:${item.n}" on the sentence that explains it, or introduce it in an earlier scene`);
      }
    }
    for (const key of own) if (!introduced.has(key)) introduced.set(key, idx);
  });
  return rows;
}

function checkTone(sb, scenes, dir, warn) {
  const notes = [];
  const lessonRefs = [];
  const kind = sb.kind || 'lesson';
  const isLesson = kind === 'lesson' || kind === 'bridges'; // a bridge must not announce lessons either
  for (const s of scenes) {
    (s.narration || []).forEach((text, i) => {
      for (const [re, why] of PRODUCTION_NOTES) {
        if (re.test(text)) { notes.push({ scene: s.id, sentence: i, why, text }); break; }
      }
      // The hook's promise ("In this lesson, you'll …") is the one lesson reference a kept scene may make.
      const promise = s.role === 'hook' && /\bin this lesson,? (you(?:'ll| will)|we(?:'ll| will))\b/i.test(text) && !LESSON_REFERENCES.test(text.replace(/\bin this lesson\b/i, ''));
      if (isLesson && !promise && !DROPPABLE_ROLES.includes(s.role || 'body') && LESSON_REFERENCES.test(text)) lessonRefs.push({ scene: s.id, sentence: i, text });
    });
    // The same on screen: a "Lesson 3" label in a hook or body scene survives a compilation too.
    if (isLesson && !DROPPABLE_ROLES.includes(s.role || 'body') && ['html', 'slide'].includes(s.renderer) && s.visual) {
      const file = path.resolve(dir, s.visual);
      if (fs.existsSync(file)) {
        const visible = fs.readFileSync(file, 'utf8').replace(/<!--[\s\S]*?-->/g, ' ').replace(/<(script|style|head)[\s\S]*?<\/\1>/gi, ' ').replace(/<[^>]+>/g, ' ');
        const m = visible.match(/\bLesson\s+(\d+|one|two|three|four|five|six|seven|eight|nine|ten)\b/i);
        if (m) lessonRefs.push({ scene: s.id, sentence: null, text: `on screen: "${m[0]}"` });
      }
    }
  }
  for (const n of notes) warn(`${n.scene} sentence ${n.sentence}: ${n.why} ("${excerpt(n.text)}"). Do it the right way the first time and say why; how the video was made belongs in the script.md notes block (NARRATIVE.md → Do it right the first time)`);
  if (lessonRefs.length) {
    warn(`${lessonRefs.length} reference(s) to lessons in scenes a compilation keeps (e.g. ${lessonRefs.slice(0, 3).map(r => `${r.scene}: "${excerpt(r.text, 50)}"`).join('; ')}). Keep "this lesson", "next lesson", "the lesson page" to title, recap, and next scenes, or name the idea instead of the lesson`);
  }
  return { production_notes: notes, lesson_references: lessonRefs };
}

function checkHeadlines(scenes, dir, warn) {
  let total = 0;
  const italic = [];
  const bullets = [];
  const labels = [];
  const eyebrows = new Map(); // eyebrow text -> scene ids
  for (const s of scenes) {
    if (!['html', 'slide'].includes(s.renderer) || !s.visual) continue;
    const file = path.resolve(dir, s.visual);
    if (!fs.existsSync(file)) continue;
    const html = fs.readFileSync(file, 'utf8').replace(/<!--[\s\S]*?-->/g, '');
    // Deck habits (SLIDES.md → Evidence, not bullets).
    if (/<(ul|ol|li)\b/i.test(html)) bullets.push(s.id);
    for (const t of html.matchAll(/<table[\s\S]*?<\/table>/gi)) {
      const rowCount = (t[0].match(/<tr\b/gi) || []).length;
      if (rowCount > 9) warn(`${s.id}: a table of ${rowCount} rows is too much to read in a scene. Show the rows the point needs (keep the comparison row), or show the real file in a file panel`);
    }
    const eb = html.match(/class="[^"]*\beyebrow\b[^"]*"[^>]*>([^<]+)</);
    if (eb) eyebrows.set(eb[1].trim().toLowerCase(), (eyebrows.get(eb[1].trim().toLowerCase()) || []).concat(s.id));
    const m = html.match(/<(h[1-3])[^>]*class="[^"]*\bscene-title\b[^"]*"[^>]*>([\s\S]*?)<\/\1>/);
    if (!m) continue;
    total++;
    if (/<(em|i)\b/.test(m[2])) italic.push(s.id);
    const words = m[2].replace(/<[^>]+>/g, ' ').split(/\s+/).filter(w => /[A-Za-z0-9]/.test(w));
    if (!['title', 'recap', 'next'].includes(s.role) && words.length <= 2) labels.push(`${s.id} "${words.join(' ')}"`);
  }
  if (total >= 3 && italic.length > Math.ceil(total / 3)) {
    warn(`${italic.length} of ${total} headlines have an italic phrase. Italic is for the one word that carries a scene's point (a term being defined, a contrast); when most headlines have it, it reads as a tic. Make most of them plain (SLIDES.md → Headlines)`);
  }
  if (bullets.length) {
    warn(`bullet list on screen in ${bullets.join(', ')}. Bullets cut reasoning into fragments and drop the words that connect them. Let the voice carry the reasoning and put the evidence on screen: the real file or output, a table of the real numbers, or a diagram of the relationship`);
  }
  if (labels.length && labels.length > Math.ceil(total / 4)) {
    warn(`${labels.length} of ${total} headlines are one or two words (${labels.slice(0, 4).join(', ')}), which usually names a topic ("Results") instead of making a point. A headline states the scene's point in three to six words ("A skill is advice."): someone reading only the headlines should follow the argument`);
  }
  const sceneCount = scenes.filter(s => ['html', 'slide'].includes(s.renderer)).length;
  for (const [text, ids] of eyebrows) {
    if (ids.length >= 4 && ids.length > sceneCount / 2) {
      warn(`the eyebrow "${text}" repeats on ${ids.length} scenes. A label on every scene is furniture: it adds no information and, if it names the lesson or course, it survives into a compilation. Use an eyebrow only where it orients the viewer`);
    }
  }
  return { headlines: total, italic, bullet_scenes: bullets, label_headlines: labels };
}

function checkNarrationItems(scenes, errors, warn) {
  const outcome = [];
  for (const s of scenes) {
    (s.narration_items || []).forEach((item, i) => {
      if (item.pause !== undefined && !(Number(item.pause) >= 0 && Number(item.pause) <= 60)) errors.push(`${s.id} sentence ${i}: "pause" must be seconds between 0 and 60`);
      if (item.read !== undefined && !(Number(item.read) >= 0 && Number(item.read) <= 60)) errors.push(`${s.id} sentence ${i}: "read" must be seconds between 0 and 60`);
      for (const k of ['wait_for', 'before']) {
        if (item[k] === undefined) continue;
        if (s.renderer !== 'terminal') errors.push(`${s.id} sentence ${i}: "${k}" ties a sentence to a terminal recording; this scene's renderer is "${s.renderer}" (use "pause", or a cue for on-screen motion)`);
        else if (!/^(typed|enter|output|done):\d+(\+\d+(\.\d+)?)?$/.test(String(item[k]))) errors.push(`${s.id} sentence ${i}: "${k}": "${item[k]}" is not an event. Use typed:N, enter:N, output:N, or done:N (N = the Nth visible command), optionally +seconds`);
      }
      if (item.outcome) outcome.push({ scene: s.id, sentence: i, text: item.text });
      const known = ['text', 'pause', 'read', 'wait_for', 'before', 'outcome'];
      for (const k of Object.keys(item)) if (!known.includes(k)) warn(`${s.id} sentence ${i}: unknown narration field "${k}" (known: ${known.join(', ')})`);
    });
  }
  return outcome;
}

function checkStory(sb, dir, opts = {}) {
  const errors = [];
  const warnings = [];
  const scenes = sb.scenes || [];
  const strict = Boolean(opts.strictSchema);
  // On a current storyboard these are errors; on an older one they are reported as warnings.
  const problem = m => (strict ? errors : warnings).push(m);
  const warn = m => warnings.push(m);

  const arc = checkNarrative(sb, scenes, problem, warn);
  const { strip, changes } = checkRolesAndModes(scenes, problem, warn, errors);
  const introductions = checkIntroductions(scenes, dir, opts.tapes || {}, problem, warn);
  const tone = checkTone(sb, scenes, dir, warn);
  if ((sb.kind || 'lesson') === 'bridges') {
    for (const s of scenes) {
      if (!s.after) errors.push(`${s.id}: a bridges video needs "after": "<lesson slug>" on every scene, naming the lesson the bridge follows (COMPILATION.md)`);
      if (s.role && s.role !== 'bridge') warnings.push(`${s.id}: scenes in a bridges video have role "bridge"`);
    }
  }
  const headlines = checkHeadlines(scenes, dir, warn);
  const outcome = checkNarrationItems(scenes, errors, warn);

  return {
    errors, warnings,
    report: { arc, mode_sequence: strip, mode_changes: changes, introductions, outcome_sentences: outcome, ...tone, ...headlines },
  };
}

module.exports = { checkStory, parseTyped, shownIn, ROLES, MODES, TEACHING_ROLES, DROPPABLE_ROLES };
