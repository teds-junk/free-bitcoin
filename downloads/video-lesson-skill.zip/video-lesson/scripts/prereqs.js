/**
 * Validate prerequisites for the video-lesson skill.
 *
 * Usage:
 *   node prereqs.js
 *
 * Exits 0 if all REQUIRED prerequisites are met, 1 if any are missing.
 * Optional tools (only needed for some scene types) are reported but never fail the check.
 * Output is JSON: { "ok": true/false, "venv": true/false, "stt": true/false, "results": [...] }
 * ("stt": the optional speech-to-text model for `tts.py --transcribe` is installed)
 */

'use strict';

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const { chromePath, MODELS_DIR, SCRIPTS_DIR } = require('./lib');

const CHROME = chromePath();
// The speech-to-text model behind `tts.py --transcribe` (optional; fetched by setup.js --stt).
const STT = JSON.parse(fs.readFileSync(path.join(SCRIPTS_DIR, 'stt-model.json'), 'utf8'));
const STT_DIR = path.join(MODELS_DIR, STT.dir);

const prereqs = [
  {
    // Narration runs on MLX (mlx-audio): macOS on Apple Silicon only. sysctl is Rosetta-safe.
    name: 'apple-silicon',
    command: process.platform === 'darwin' ? 'test "$(sysctl -n hw.optional.arm64 2>/dev/null)" = 1 && echo 1.0.0' : 'false',
    installUrl: 'narration requires a Mac with Apple Silicon (Kokoro runs through MLX); this machine cannot run the skill',
  },
  { name: 'node', command: 'node --version', minVersion: '18.0.0', installUrl: 'https://nodejs.org' },
  { name: 'npm', command: 'npm --version', installUrl: 'https://nodejs.org' },
  { name: 'ffmpeg', command: 'ffmpeg -version', minVersion: '6.0.0', installUrl: 'https://ffmpeg.org/download.html (brew install ffmpeg)' },
  { name: 'ffprobe', command: 'ffprobe -version', installUrl: 'https://ffmpeg.org/download.html (ships with ffmpeg)' },
  {
    name: 'chrome',
    command: CHROME ? `"${CHROME}" --version` : 'false',
    installUrl: 'https://www.google.com/chrome/ (or set CHROME_PATH)',
  },
  {
    // The venv must be built with 3.12: misaki 0.9.4 (Kokoro's G2P) requires < 3.13 on PyPI.
    name: 'python3.12',
    command: 'python3.12 --version',
    installUrl: 'brew install python@3.12',
  },
  { name: 'espeak-ng', command: 'espeak-ng --version', installUrl: 'brew install espeak-ng (without it Kokoro silently skips unknown words)' },
  // Optional: only terminal scenes need these.
  { name: 'vhs', command: 'vhs --version', optional: 'terminal scenes', installUrl: 'brew install vhs' },
  { name: 'ttyd', command: 'ttyd --version', optional: 'terminal scenes', installUrl: 'brew install ttyd' },
  {
    name: 'jetbrains-mono-font',
    command: 'ls ~/Library/Fonts/JetBrainsMono-Variable.ttf /Library/Fonts/JetBrainsMono-Variable.ttf 2>/dev/null | head -1 | grep -q . && echo 1.0.0',
    optional: 'terminal scenes (vhs uses installed fonts)',
    installUrl: 'ask the user, then: node scripts/setup.js --yes --install-fonts',
  },
  {
    name: 'speech-to-text-model',
    command: `test -f "${STT_DIR}/config.json" && ls "${STT_DIR}"/*.safetensors >/dev/null 2>&1 && echo 1.0.0`,
    optional: 'the transcript check (tts.py --transcribe)',
    installUrl: `ask the user (downloads about ${STT.size_mb} MB to ${STT_DIR}), then: node scripts/setup.js --yes --stt`,
  },
];

function parseVersion(output) {
  const match = output.trim().match(/v?(\d+\.\d+(?:\.\d+)?)/);
  if (!match) return null;
  const parts = match[1].split('.');
  while (parts.length < 3) parts.push('0');
  return parts.join('.');
}

function meetsMinVersion(actual, min) {
  if (!min || !actual) return true;
  const a = actual.split('.').map(Number);
  const m = min.split('.').map(Number);
  for (let i = 0; i < 3; i++) {
    if (a[i] > m[i]) return true;
    if (a[i] < m[i]) return false;
  }
  return true;
}

function check(prereq) {
  const base = { name: prereq.name, optional: prereq.optional || false };
  try {
    const output = execSync(prereq.command, { encoding: 'utf8', timeout: 10000, stdio: ['pipe', 'pipe', 'pipe'], shell: '/bin/sh' });
    const version = parseVersion(output);
    if (prereq.minVersion && !meetsMinVersion(version, prereq.minVersion)) {
      return { ...base, ok: false, version, error: `Requires >= ${prereq.minVersion}, found ${version}`, installUrl: prereq.installUrl };
    }
    return { ...base, ok: true, version };
  } catch {
    return { ...base, ok: false, error: 'Not found', installUrl: prereq.installUrl };
  }
}

function main() {
  const results = prereqs.map(check);
  const ok = results.every(r => r.ok || r.optional);
  const venv = fs.existsSync(path.join(require('./lib').VENV_DIR, 'setup-report.json'));

  const stt = results.some(r => r.name === 'speech-to-text-model' && r.ok);
  console.log(JSON.stringify({ ok, venv, stt, results }, null, 2));

  const missing = results.filter(r => !r.ok);
  if (missing.length) {
    console.error(ok ? '\nOptional tools missing:\n' : '\nPrerequisite check failed:\n');
    for (const r of missing) {
      const tag = r.optional ? ` (optional, needed for ${r.optional})` : '';
      console.error(`  ${r.name}${tag}: ${r.error}`);
      console.error(`    Install: ${r.installUrl}\n`);
    }
  }
  if (!venv) {
    console.error('Narration environment not set up yet. It downloads several GB (torch, spaCy, Kokoro weights).');
    console.error(`ASK THE USER before running: node ${path.join(__dirname, 'setup.js')} --yes   (setup.js does not prompt)`);
  }
  if (!ok) process.exit(1);
}

main();
