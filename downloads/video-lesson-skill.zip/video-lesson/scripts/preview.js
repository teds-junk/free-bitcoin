#!/usr/bin/env node
/**
 * Render representative stills of one scene so you can check layout and motion before a
 * full render (design system step 11). Also reports font, cue, and overflow problems.
 *
 * Usage:
 *   node preview.js <scene.html> [--at 0,1.2,4,end] [--video <video-dir> --scene s03] [--out DIR]
 *       [--sheet]
 *   node preview.js --all <video-dir>      # one still of every slide scene, on one contact sheet
 *
 * --all      the whole video at a glance, before anything renders: one still of each html/slide
 *            scene (late in the scene, when its highlights have fired) in build/preview/_all/, and
 *            sheet.png with all of them side by side. Look at the sheet for what one scene alone
 *            cannot show: a scene that does not look like the others, headlines of uneven length,
 *            a layout used for everything. Also lists each scene's problems.
 * --at       comma-separated times in seconds, or sentence refs like "s2" (start of sentence 2)
 *            and "s2+0.5"; "end" is the scene's last frame. Default: 0, each sentence start
 *            + 1 s, and end.
 * --video/--scene  use that scene's real narration timing (audio/timings.json) and pacing;
 *            otherwise sentences are faked ~3 s apart (12 s scene).
 * --sheet    also write a contact sheet (sheet.png) of all stills.
 * Prints JSON { stills: [...], problems: [...] }. Problems include cue and font errors, content
 * off the canvas, and text too pale to read (measured contrast).
 */
'use strict';

const fs = require('fs');
const path = require('path');
const L = require('./lib');
const B = require('./browser');

function fakeVl() {
  const sentences = [];
  for (let i = 0; i < 4; i++) sentences.push({ text: '', start: 0.6 + i * 3, end: 0.6 + i * 3 + 2.4 });
  return { scene: 'preview', duration: 13, fps: L.VIDEO.fps, sentences };
}

// The scene's sentence times: from the narration (audio/timings.json) when it exists, with the
// scene's "pause" and "read"; otherwise estimated from the words, so cues still land in order.
function realVl(videoDir, sceneId) {
  const { sb } = L.loadStoryboard(videoDir);
  const scene = (sb.scenes || []).find(x => x.id === sceneId) || { narration: [], narration_items: [] };
  const file = path.join(videoDir, 'audio', 'timings.json');
  const timed = fs.existsSync(file) ? (L.readJSON(file).scenes || {})[sceneId] : null;
  const speed = (sb.voice && sb.voice.speed) || 1.2;
  const clips = timed && timed.length === scene.narration.length ? timed
    : scene.narration.map(text => ({ text, duration: Math.max(1, text.split(/\s+/).length / 150 * 60 / speed) }));
  const p = sb.pacing;
  let t = p.lead_in;
  const sentences = clips.map((c, i) => {
    const item = (scene.narration_items || [])[i] || {};
    t += Number(item.pause) || 0;
    const s = { text: c.text, start: t, end: t + c.duration };
    t += c.duration + (Number(item.read) || 0) + (i < clips.length - 1 ? p.gap : 0);
    return s;
  });
  return { scene: sceneId, duration: L.frameAlign(Math.max(t + p.tail + Number(scene.hold_after || 0), Number(scene.min_duration || 0), 1)), fps: L.VIDEO.fps, sentences };
}

function contactSheet(stills, sheet, cols, w, h) {
  const inputs = stills.flatMap(s => ['-i', s]);
  const layout = stills.map((_, i) => `${(i % cols) * w}_${Math.floor(i / cols) * h}`).join('|');
  const scaled = stills.map((_, i) => `[${i}]scale=${w}:${h}[s${i}]`).join(';');
  if (stills.length === 1) { L.ffmpeg(['-i', stills[0], '-vf', `scale=${w}:${h}`, sheet]); return; }
  L.ffmpeg([...inputs, '-filter_complex', `${scaled};${stills.map((_, i) => `[s${i}]`).join('')}xstack=inputs=${stills.length}:layout=${layout}:fill=#93a1a1`, sheet]);
}

// One still of every html/slide scene, and a contact sheet of them all.
async function previewAll(videoDir) {
  const { sb } = L.loadStoryboard(videoDir);
  const out = L.mkdirp(path.join(videoDir, 'build', 'preview', '_all'));
  const stills = [];
  const problems = {};
  for (const s of sb.scenes || []) {
    if (!['html', 'slide'].includes(s.renderer) || !s.visual) continue;
    const file = path.resolve(videoDir, s.visual);
    if (!fs.existsSync(file)) { problems[s.id] = [`${s.visual} does not exist yet`]; continue; }
    const vl = realVl(videoDir, s.id);
    const page = await B.openPage(file, vl);
    // Late in the scene, but before a closing "clear the highlight" cue.
    const last = vl.sentences[vl.sentences.length - 1];
    const t = s.renderer === 'slide' || !last ? vl.duration : Math.max(0, last.start - 0.2);
    await B.seek(page, t);
    const png = path.join(out, `${s.id}.png`);
    await page.screenshot({ path: png, type: 'png' });
    stills.push(png);
    const found = [...page.problems, ...(await B.pageProblems(page))];
    if (found.length) problems[s.id] = found;
    await page.close();
  }
  await B.close();
  const sheets = [];
  for (let i = 0; i < stills.length; i += 12) {
    const sheet = path.join(out, stills.length > 12 ? `sheet-${i / 12 + 1}.png` : 'sheet.png');
    contactSheet(stills.slice(i, i + 12), sheet, 3, 960, 540);
    sheets.push(sheet);
  }
  console.log(JSON.stringify({ sheets, stills, problems }, null, 2));
}

async function main() {
  const args = L.parseArgs(process.argv.slice(2), ['sheet']);
  if (args.all) return previewAll(path.resolve(args.all));
  const file = path.resolve(args._[0] || L.die('pass a scene HTML file, or --all <video-dir>'));
  const vl = args.video && args.scene ? realVl(path.resolve(args.video), args.scene) : fakeVl();
  const resolve = spec => {
    if (spec === 'end') return vl.duration - 1 / vl.fps;
    const m = /^s(\d+)(?:\+([\d.]+))?$/.exec(spec);
    if (m) return (vl.sentences[+m[1]] ? vl.sentences[+m[1]].start : 0) + (m[2] ? +m[2] : 0);
    return Number(spec);
  };
  const times = args.at
    ? args.at.split(',').map(s => resolve(s.trim()))
    : [0, ...vl.sentences.map(s => s.start + 1), vl.duration - 1 / vl.fps];
  const out = L.mkdirp(path.resolve(args.out || path.join(path.dirname(file), '..', 'build', 'preview', path.basename(file, '.html'))));

  const page = await B.openPage(file, vl);
  const stills = [];
  for (const t of times) {
    await B.seek(page, t);
    const png = path.join(out, `t${t.toFixed(2).padStart(6, '0')}.png`);
    await page.screenshot({ path: png, type: 'png' });
    stills.push(png);
  }
  const problems = [...page.problems, ...(await B.pageProblems(page))];
  await page.close();
  await B.close();

  if (args.sheet && stills.length) {
    const sheet = path.join(out, 'sheet.png');
    contactSheet(stills, sheet, Math.min(3, stills.length), 960, 540);
    stills.push(sheet);
  }
  console.log(JSON.stringify({ stills, problems }, null, 2));
}

main().catch(e => { console.error(e.stack || e.message); process.exit(1); });
