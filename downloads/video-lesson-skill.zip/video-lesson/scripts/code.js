#!/usr/bin/env node
/**
 * Syntax-highlight a code snippet (Shiki, Solarized) into the HTML fragment a scene uses,
 * wrapping marked expressions as concepts the runtime can focus and morph.
 *
 * Usage:
 *   node code.js --lang ts --in snippet.ts [--dark] [--line-numbers] [--id main] [--small]
 *   echo 'const x = ⟦input-users:users⟧' | node code.js --lang ts
 *
 * Mark a concept in the source with ⟦concept-id:expression⟧ (U+27E6 / U+27E7). Markers may
 * span tokens and lines and may nest. The output keeps the code exactly as written, minus
 * the markers, and prints:
 *   <pre class="code" data-lang="ts"><code>… <span data-concept="input-users" data-rep="code">…</span> …</code></pre>
 * Paste it into the scene HTML. Default is "code as typography" on the paper (solarized-light);
 * --dark gives the dark panel (solarized-dark) for terminals, diffs, long files, debugging.
 */
'use strict';

const fs = require('fs');
const L = require('./lib');

const OPEN = '⟦';
const CLOSE = '⟧';
// Shiki's Solarized themes are tuned for an editor at arm's length. A video is watched small and
// compressed, so every colour is moved to a variant that keeps its hue and reads clearly:
// on the paper, plain text and comments go to the theme's ink colours; on the dark panel, plain
// text, comments and the accents all get lighter (each is 4.2:1 or better against base02).
const LIGHT_REMAP = { '#657B83': '#2F4A53', '#586E75': '#2F4A53', '#93A1A1': '#4A6068', '#839496': '#4A6068' };
const DARK_REMAP = {
  '#839496': '#B3C0BF', '#93A1A1': '#B3C0BF', '#586E75': '#8296A0', '#657B83': '#8296A0',
  '#268BD2': '#4EA5E6', '#2AA198': '#3CC0B3', '#B58900': '#D3A41C', '#859900': '#A4BA1E',
  '#CB4B16': '#F0733F', '#DC322F': '#F26D68', '#6C71C4': '#959AE6', '#D33682': '#EA6AA6',
};
const darkColor = c => (c ? DARK_REMAP[String(c).toUpperCase()] || c : c);

function esc(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// Strip ⟦id:…⟧ markers; return plain code and concept ranges [start, end) in plain offsets.
function parseMarkers(src) {
  let out = '';
  const stack = [];
  const ranges = [];
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (ch === OPEN) {
      const colon = src.indexOf(':', i);
      if (colon < 0) L.die(`marker at ${i} has no ":" (use ⟦concept-id:expression⟧)`);
      const id = src.slice(i + 1, colon);
      if (!/^[a-z0-9][a-z0-9_-]*$/.test(id)) L.die(`concept id "${id}" must be kebab-case`);
      stack.push({ id, start: out.length });
      i = colon;
    } else if (ch === CLOSE) {
      const open = stack.pop();
      if (!open) L.die(`unmatched ${CLOSE} at ${i}`);
      ranges.push({ id: open.id, start: open.start, end: out.length });
    } else {
      out += ch;
    }
  }
  if (stack.length) L.die(`unclosed marker for "${stack[stack.length - 1].id}"`);
  return { code: out, ranges };
}

// Tokenize code with Shiki's Solarized theme: an array of lines, each an array of
// { content, color, fontStyle }. Shared with file-panel.js.
async function tokenize(code, lang, dark) {
  let shiki;
  try { shiki = await import('shiki'); } catch { L.die('shiki missing: run node scripts/setup.js --yes (after asking the user)'); }
  const theme = dark ? 'solarized-dark' : 'solarized-light';
  const { tokens } = await shiki.codeToTokens(code, { lang, theme });
  // Prose is plain. The Solarized themes colour a whole Markdown list item yellow, so a file of
  // bullets comes out as a block of yellow that fights the highlight backing behind it. In
  // Markdown only headings, code and links keep a colour.
  if (/^(markdown|md|mdx)$/.test(lang)) {
    for (const row of tokens) for (const tok of row) if (/^#b58900$/i.test(tok.color || '')) tok.color = undefined;
  }
  return tokens;
}

// The style attribute (with its leading space) for one token, or '' when it has no color.
// `dark` is true for a dark panel; 'panel' means the caller has already mapped the colours.
function tokenStyle(tok, dark) {
  const color = (dark === 'panel' ? tok.color : dark ? darkColor(tok.color) : (LIGHT_REMAP[(tok.color || '').toUpperCase()] || tok.color)) || '';
  return color ? ` style="color:${color}${tok.fontStyle & 1 ? ';font-style:italic' : ''}"` : '';
}

async function main() {
  const args = L.parseArgs(process.argv.slice(2), ['dark', 'line-numbers', 'small']);
  if (!args.lang) L.die('pass --lang (e.g. ts, js, py, go, rust, bash, yaml, json)');
  const src = args.in ? fs.readFileSync(args.in, 'utf8') : fs.readFileSync(0, 'utf8');
  const { code, ranges } = parseMarkers(src.replace(/\s+$/, ''));
  const tokens = await tokenize(code, args.lang, args.dark);

  // Boundary events at plain-text offsets.
  const opens = new Map(); const closes = new Map();
  for (const r of ranges) {
    (opens.get(r.start) || opens.set(r.start, []).get(r.start)).push(r);
    (closes.get(r.end) || closes.set(r.end, []).get(r.end)).push(r);
  }
  for (const list of opens.values()) list.sort((a, b) => b.end - a.end); // outer first
  const active = [];
  let pending = []; // concepts continuing onto a new line: reopened at its first non-space character
  let html = '';
  let offset = 0;

  const openTag = r => `<span data-concept="${r.id}" data-rep="code">`;
  function emitBoundary(pos) {
    const ending = closes.get(pos) || [];
    if (ending.length) {
      // Close down to the deepest ending range, then reopen the survivors.
      let deepest = Math.min(...ending.map(r => active.indexOf(r)).filter(i => i >= 0));
      if (Number.isFinite(deepest)) {
        const reopen = active.slice(deepest).filter(r => !ending.includes(r));
        html += '</span>'.repeat(active.length - deepest);
        active.length = deepest;
        for (const r of reopen) { html += openTag(r); active.push(r); }
      }
    }
    for (const r of opens.get(pos) || []) { html += openTag(r); active.push(r); }
  }

  tokens.forEach((line, li) => {
    if (args['line-numbers']) html += `<span class="ln">${li + 1}</span>`;
    for (const tok of line) {
      let text = tok.content;
      let start = offset;
      // Split the token at any concept boundary inside it.
      const cuts = [...new Set([...opens.keys(), ...closes.keys()])].filter(p => p > start && p < start + text.length).sort((a, b) => a - b);
      let pieces = [];
      let prev = start;
      for (const c of cuts) { pieces.push([prev, c]); prev = c; }
      pieces.push([prev, start + text.length]);
      for (const [a, b] of pieces) {
        emitBoundary(a);
        const style = tokenStyle(tok, args.dark);
        let piece = text.slice(a - start, b - start);
        if (pending.length) {
          // Leave indentation outside the concept so multi-line highlights align with the text.
          const ws = piece.match(/^\s*/)[0];
          if (ws) html += `<span${style}>${esc(ws)}</span>`;
          piece = piece.slice(ws.length);
          if (piece) {
            for (const r of pending) if (r.end > a + ws.length) { html += openTag(r); active.push(r); }
            pending = [];
          }
        }
        if (piece) html += `<span${style}>${esc(piece)}</span>`;
      }
      offset = start + text.length;
    }
    emitBoundary(offset);
    if (li < tokens.length - 1) {
      // Concepts don't straddle the newline: close, newline, reopen.
      const open = active.slice();
      html += '</span>'.repeat(open.length) + '\n';
      active.length = 0;
      offset += 1; // the newline
      pending = open.filter(r => r.end > offset);
    }
  });
  emitBoundary(offset);
  html += '</span>'.repeat(active.length);

  const cls = ['code', args.dark && 'dark', args.small && 'small'].filter(Boolean).join(' ');
  const id = args.id ? ` id="${args.id}"` : '';
  console.log(`<pre class="${cls}"${id} data-lang="${args.lang}"><code>${html}</code></pre>`);
}

module.exports = { esc, tokenize, tokenStyle, darkColor };

if (require.main === module) main().catch(e => { console.error(e.message); process.exit(1); });
