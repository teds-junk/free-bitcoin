'use strict';
// Recording a terminal demo with vhs, and the rules around it. render-scenes.js calls
// recordTerminal() for a scene whose recording is missing or out of date.
//
//   --no-record     never start vhs; say which scene needs recording and why
//   spend guard     a tape that declares `# Spend: 2 agent runs` records only with --allow-spend,
//                   is logged in <video-dir>/../spend-log.json, and stops at the budget in preferences.json
//   one at a time   a machine-wide lock (<STATE_DIR>/recording.lock): two recordings at once fight
//                   over the CPU and drop frames, and paid runs should not overlap by accident
//   screen text     vhs also saves the screen as text (build/raw/<id>.txt) for secret-scan.js
//
// Exports: recordTerminal, tapeSpend, declaredSpend, readSpendLog, spendTotal, acquireLock, releaseLock, LOCK_FILE

const fs = require('fs');
const path = require('path');
const L = require('./lib');
const { checkTape } = require('./tape-check');

const LOCK_FILE = path.join(L.STATE_DIR, 'recording.lock');
const LOCK_TIMEOUT_S = Number(process.env.VIDEO_LESSON_LOCK_TIMEOUT || 3600); // wait up to an hour for our turn
const LOCK_MAX_AGE_S = Number(process.env.VIDEO_LESSON_LOCK_MAX_AGE || 6 * 3600); // older than this: its pid was reused

// ---- spend -----------------------------------------------------------------

const unitKey = u => String(u || '').trim().toLowerCase().replace(/s$/, '');
const fmt = (n, unit) => `${Number(n.toFixed(2))} ${unit}`;

// `# Spend: 2 agent runs` in a tape: what one recording of it costs. null when it costs nothing.
function tapeSpend(text, defaultUnit = L.PREFERENCES.spend.unit) {
  const m = String(text).match(/^[ \t]*#[ \t]*Spend:[ \t]*([0-9]+(?:\.[0-9]+)?)[ \t]*(.*?)[ \t]*$/im);
  if (!m || Number(m[1]) <= 0) return null;
  return { amount: Number(m[1]), unit: m[2] || defaultUnit };
}

// What recording a scene costs: the tape's `# Spend:` line, else "spend" on the storyboard scene
// (a number, "2 agent runs", or { amount, unit }). The scene form exists for tapes that are already
// recorded: adding a comment to such a tape changes its hash and would force a paid re-recording.
function sceneSpend(scene, tapeText, defaultUnit = L.PREFERENCES.spend.unit) {
  const fromTape = tapeSpend(tapeText, defaultUnit);
  if (fromTape) return fromTape;
  const s = scene && scene.spend;
  if (typeof s === 'number') return s > 0 ? { amount: s, unit: defaultUnit } : null;
  if (typeof s === 'string') return tapeSpend(`# Spend: ${s}`, defaultUnit);
  if (s && Number(s.amount) > 0) return { amount: Number(s.amount), unit: s.unit || defaultUnit };
  return null;
}

const spendLogPath = dir => path.join(dir, '..', 'spend-log.json');

function readSpendLog(dir) {
  const file = spendLogPath(dir);
  if (!fs.existsSync(file)) return [];
  let data;
  try { data = L.readJSON(file); } catch (e) { return L.die(`${file} is not valid JSON: ${e.message}`); }
  return Array.isArray(data) ? data : [];
}

const spendTotal = (entries, unit) => entries.filter(e => unitKey(e.unit) === unitKey(unit)).reduce((n, e) => n + Number(e.amount || 0), 0);

// For the lint: what recording every tape of this video once would cost, and where the budget stands.
// `scenes` defaults to the storyboard's terminal scenes.
function declaredSpend(dir, scenes) {
  const prefs = L.loadPreferences(dir).spend;
  const list = scenes || (L.readJSON(path.join(dir, 'storyboard.json')).scenes || []).filter(s => s.renderer === 'terminal');
  const tapes = [];
  for (const s of list) {
    const file = path.resolve(dir, s.visual || '');
    if (!s.visual || !fs.existsSync(file) || !fs.statSync(file).isFile()) continue;
    const sp = sceneSpend(s, fs.readFileSync(file, 'utf8'), prefs.unit);
    if (sp) tapes.push({ scene: s.id, tape: s.visual, ...sp });
  }
  const totals = {};
  for (const t of tapes) totals[t.unit] = (totals[t.unit] || 0) + t.amount;
  const log = readSpendLog(dir);
  return {
    tapes,
    totals, // { "agent runs": 6 }
    total: spendTotal(tapes, prefs.unit), // in the budget's unit
    unit: prefs.unit,
    budget: prefs.budget,
    spent: spendTotal(log, prefs.unit), // already logged for this workspace
  };
}

// ---- the recording lock ------------------------------------------------------

let held = null;

const sleepMs = ms => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
function pidAlive(pid) {
  try { process.kill(pid, 0); return true; } catch (e) { return e.code === 'EPERM'; }
}
function readLock() {
  try { return JSON.parse(fs.readFileSync(LOCK_FILE, 'utf8')); } catch { return null; }
}
function removeLock(token) {
  const cur = readLock();
  if (cur && cur.token !== token) return;
  try { fs.unlinkSync(LOCK_FILE); } catch { /* already gone */ }
}

function releaseLock() {
  if (!held) return;
  removeLock(held.token);
  process.removeListener('exit', releaseLock);
  process.removeListener('SIGINT', onSignal);
  process.removeListener('SIGTERM', onSignal);
  held = null;
}
function onSignal() { releaseLock(); process.exit(130); }

// Take the machine-wide recording lock, waiting for whoever holds it. Dies after the timeout.
function acquireLock(what, opts = {}) {
  const timeoutMs = (opts.timeout !== undefined ? opts.timeout : LOCK_TIMEOUT_S) * 1000;
  const say = opts.log || (m => console.error(m));
  fs.mkdirSync(L.STATE_DIR, { recursive: true });
  const me = { pid: process.pid, what, started: new Date().toISOString(), token: `${process.pid}-${Date.now()}-${Math.random().toString(36).slice(2)}` };
  const deadline = Date.now() + timeoutMs;
  let announced = false;
  for (;;) {
    try {
      fs.writeFileSync(LOCK_FILE, JSON.stringify(me) + '\n', { flag: 'wx' });
      // Two waiters can both clear the same stale lock; let that settle, then check the lock is still ours.
      sleepMs(150);
      const now = readLock();
      if (now && now.token === me.token) {
        held = me;
        process.on('exit', releaseLock);
        process.on('SIGINT', onSignal);
        process.on('SIGTERM', onSignal);
        return me;
      }
      continue;
    } catch (e) {
      if (e.code !== 'EEXIST') throw e;
    }
    const cur = readLock();
    let age = 0;
    try { age = Date.now() - fs.statSync(LOCK_FILE).mtimeMs; } catch { continue; } // released just now
    if (!cur) {
      // Being written right now, or garbage. Give a writer a moment before calling it garbage.
      if (age > 5000) { say(`  recording lock ${LOCK_FILE} was unreadable; taking it over`); try { fs.unlinkSync(LOCK_FILE); } catch { /* gone */ } } else sleepMs(200);
      continue;
    }
    if (!pidAlive(cur.pid) || age > LOCK_MAX_AGE_S * 1000) {
      say(`  recording lock was left behind by a process that is gone (pid ${cur.pid}, ${cur.what}); taking it over`);
      removeLock(cur.token);
      continue;
    }
    if (Date.now() >= deadline) {
      L.die(`waited ${Math.round(timeoutMs / 60000)} min for another recording to finish: ${cur.what} (pid ${cur.pid}, started ${cur.started}).\n` +
        `  Only one terminal demo records at a time on this machine. Run again when it is done; if that process is stuck, stop it (the lock is ${LOCK_FILE}).`);
    }
    if (!announced) {
      say(`  waiting for another recording to finish: ${cur.what} (pid ${cur.pid}); up to ${Math.round(timeoutMs / 60000)} min`);
      announced = true;
    }
    sleepMs(opts.poll || 1000);
  }
}

// ---- recording ---------------------------------------------------------------

function videoSlug(dir) {
  try { return L.readJSON(path.join(dir, 'storyboard.json')).slug || path.basename(dir); } catch { return path.basename(dir); }
}

// Why render-scenes.js wants this scene recorded, in words.
function staleReason(dir, raw, body) {
  if (!fs.existsSync(raw)) return 'it has never been recorded';
  const kept = path.join(path.dirname(raw), `${path.basename(raw, '.mp4')}.tape`);
  if (fs.existsSync(kept)) {
    const old = fs.readFileSync(kept, 'utf8').split('\n').filter(l => !/^\s*Output\s/.test(l)).join('\n').trim();
    if (old !== body.trim()) return 'its tape changed after the last recording';
  }
  if (!fs.existsSync(`${raw}.key`)) return 'its recording has no cache key next to it (it was not made by render-scenes.js, or the key was deleted)';
  return 'a fresh recording was asked for (--force), or the recording is older than this version of the renderer';
}

function recordTerminal(scene, dir, raw, args) {
  const flags = args || {};
  const tape = path.resolve(dir, scene.visual);
  const rel = path.relative(dir, tape);
  const text = fs.readFileSync(tape, 'utf8');
  const body = text.split('\n').filter(l => !/^\s*Output\s/.test(l)).join('\n');
  const prefs = L.loadPreferences(dir).spend;
  const spend = sceneSpend(scene, text, prefs.unit);
  const costs = spend ? ` Recording it spends ${fmt(spend.amount, spend.unit)}.` : '';

  if (flags['no-record']) {
    L.die(`${scene.id}: ${rel} needs recording because ${staleReason(dir, raw, body)}, and --no-record was passed, so nothing was recorded.${costs}\n` +
      '  Run again without --no-record when it is fine for this demo to run for real.');
  }

  const check = checkTape(text);
  if (check.errors.length) L.die(`${scene.id}: unsafe or broken tape ${scene.visual}:\n  ${check.errors.join('\n  ')}`);
  const S = require('./secret-scan');
  S.tapeGate(scene, dir, raw);

  if (spend) {
    const log = readSpendLog(dir);
    const counts = unitKey(spend.unit) === unitKey(prefs.unit);
    const spent = spendTotal(log, spend.unit);
    const budget = counts && prefs.budget !== null && prefs.budget !== undefined ? Number(prefs.budget) : null;
    const standing = budget !== null ? `${fmt(spent, spend.unit)} of the ${fmt(budget, prefs.unit)} budget are spent` : `${fmt(spent, spend.unit)} spent so far, no budget set`;
    if (!flags['allow-spend']) {
      L.die(`${scene.id}: recording ${rel} spends ${fmt(spend.amount, spend.unit)} (its declared spend), and --allow-spend was not passed, so nothing was recorded.\n` +
        `  ${standing} (${path.relative(dir, spendLogPath(dir))}). Get the user's go-ahead for this spend, then run again with --allow-spend.`);
    }
    if (budget !== null && spent + spend.amount > budget) {
      L.die(`${scene.id}: recording ${rel} spends ${fmt(spend.amount, spend.unit)}, which would bring the total to ${fmt(spent + spend.amount, spend.unit)}; ` +
        `the budget is ${fmt(budget, prefs.unit)} and ${fmt(spent, spend.unit)} are already spent. Nothing was recorded.\n` +
        `  Ask the user before raising spend.budget in ${path.join('..', 'preferences.json')}; the log is ${path.relative(dir, spendLogPath(dir))}.`);
    }
    if (!counts && prefs.budget !== null) console.error(`  ${scene.id}: spend is in "${spend.unit}" but the budget is in "${prefs.unit}"; logged, not counted against the budget`);
  }

  // Record into temporary names so a failed run leaves the previous recording and its screen text alone.
  const base = raw.replace(/\.mp4$/, '');
  const tmpVideo = `${base}.recording.mp4`;
  const tmpText = `${base}.recording.txt`;
  const tmpTape = path.join(path.dirname(raw), `${scene.id}.tape`);
  fs.mkdirSync(path.dirname(raw), { recursive: true });
  fs.writeFileSync(tmpTape, `Output "${tmpVideo}"\nOutput "${tmpText}"\n${body}\n`);

  const slug = videoSlug(dir);
  acquireLock(`${slug}/${scene.id} (${rel})`);
  let ok = false;
  try {
    console.error(`  vhs ${rel}`);
    L.run('vhs', [tmpTape], { cwd: dir });
    if (!fs.existsSync(tmpVideo)) throw new Error(`${scene.id}: vhs finished but wrote no recording at ${tmpVideo}`);
    ok = true;
  } finally {
    releaseLock();
    if (spend) {
      const log = readSpendLog(dir);
      log.push({ date: new Date().toISOString(), video: slug, scene: scene.id, tape: rel, amount: spend.amount, unit: spend.unit, result: ok ? 'recorded' : 'failed' });
      L.writeJSON(spendLogPath(dir), log);
      console.error(`  spend: ${fmt(spend.amount, spend.unit)} for ${slug}/${scene.id}${ok ? '' : ' (the recording failed; the demo may still have run)'}; ` +
        `${fmt(spendTotal(log, spend.unit), spend.unit)} logged${prefs.budget !== null && unitKey(spend.unit) === unitKey(prefs.unit) ? ` of ${fmt(Number(prefs.budget), prefs.unit)}` : ''}`);
    }
    if (!ok) for (const f of [tmpVideo, tmpText]) fs.rmSync(f, { force: true });
  }

  fs.renameSync(tmpVideo, raw);
  const txt = S.snapshotPath(raw);
  if (fs.existsSync(tmpText)) fs.renameSync(tmpText, txt); else fs.rmSync(txt, { force: true });
  // Decisions about the old picture (redactions, reviews), stills of it, and any kept unredacted copy no longer apply.
  S.resetAfterRecording(scene, dir, raw);
  const R = require('./redact');
  R.dropOriginal(dir, scene.id);
  fs.rmSync(R.reviewDir(raw), { recursive: true, force: true });
  fs.rmSync(`${base}.redacted.png`, { force: true });
}

module.exports = { recordTerminal, tapeSpend, sceneSpend, declaredSpend, readSpendLog, spendTotal, spendLogPath, acquireLock, releaseLock, LOCK_FILE };
