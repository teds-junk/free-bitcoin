# Scenes and Visual Style

Every scene is an HTML page in the **Solarized Technical Essay** style: warm paper, short editorial serif headlines, code in dark boxes, quiet semantic color. The full design system is `references/SOLARIZED-TECHNICAL-ESSAY.md`; this file is the working summary and wins where the two differ. Motion is covered in `MOTION-GRAPHICS.md`.

The look is already built. Your job is to pick a layout, put the content in the theme's classes, and look at the result. You do not design: no stylesheet of your own, no fonts, no colors. A video that looks wrong almost always has too many words in a headline, or content that ignores the layouts.

## Contents

- [The frame](#the-frame)
- [The three faces](#the-three-faces)
- [One visual language](#one-visual-language)
- [Nonnegotiable rules](#nonnegotiable-rules)
- [Evidence, not bullets](#evidence-not-bullets)
- [Files](#files)
- [Layouts](#layouts-vary-them-across-a-video)
- [Writing a scene](#writing-a-scene) (headlines, code, blocks, color, dark scenes)
- [Type scale](#type-scale-already-in-themecss)
- [Check before rendering](#check-before-rendering)
- [Anti-patterns](#anti-patterns)

## The frame

Every scene but a title card has the same three parts, in this order:

```html
<main class="scene">
  <div class="eyebrow">A skill is advice</div>           <!-- optional: the chapter this scene is in -->
  <h2 class="scene-title">The first draft leaves gaps.</h2>  <!-- six words or fewer -->
  <div class="stage">
    …the scene's content…
  </div>
</main>
```

`.stage` takes everything under the headline and centers its content there, so nothing floats in a corner and nothing reaches the caption band. Content fills the width: use `<div class="cols">` for equal columns across it. Do not position anything by hand with `position`, `margin-top`, or pixel offsets.

## The three faces

| Face | Is for | Never for |
|---|---|---|
| **Display serif** (Instrument Serif) | The headline, and nothing else | A full sentence, a paragraph, a label, a list |
| **Sans** (Inter) | Everything a viewer reads as prose: leads, definitions, notes, tables, quotes | Code, commands, file names |
| **Mono** (JetBrains Mono) | Code, commands, file and model names, a term that is typed | Prose |

- **A headline is six words or fewer, on one line.** The serif is a condensed display face: it is elegant at five words and unreadable at twelve. Keep the claim and cut the words: "A skill is advice.", "One run, four steps.", "The first draft leaves gaps." If the point needs a sentence, the sentence goes in a `.lead` under the headline or in the narration. The lint warns over six words.
- **If a headline looks wrong, shorten it. Do not change its font.** Replacing the serif with the sans across a video throws away the look to fix a wording problem.
- **Text on the paper is `--ink`, `--ink-soft`, or `--ink-muted`. Nothing lighter.** The pale Solarized grays (`base0`, `base1`, `base00`) are 2.5:1 to 4.1:1 against the paper and vanish on a phone or a compressed stream; they are for rules and marks. The theme's classes already use the right colors, and `preview.js` measures contrast and reports anything under 4:1. Never write a color into a scene.

## One visual language

A viewer learns how to read your scenes in the first minute. Every scene after that uses the same grammar, or it reads as a different video.

| To show | Use | Layout |
|---|---|---|
| Code, a command, a path, output | A **dark code box on the left, a note on the right** level with each line that needs one (`.annotated` + `.callout`) | `code.html` |
| A real file | A file panel; notes beside it are callouts too | `file.html` |
| Two or three terms and what they mean | Soft blocks in a row (`.cols` of `.semantic-block`), each filled as it is named | `system.html` |
| Steps in order | The same blocks, numbered (`<div class="step">1</div>`) | `steps.html` |
| Something somebody said or typed to the agent | A `.quote` with a `.who` label | `code.html`, `before-after.html` |
| Two results to compare | Two `.card`s side by side, each a label over a dark box | `before-after.html` |
| Numbers, or facts with a name each | A `.data-table` | `table.html` |

- **A path with its parts explained is code with notes**: the path in a dark box, one part per line, a callout per line. It is not a table. The same goes for a command and its flags.
- **Callouts are positioned by the runtime.** `<p class="callout" data-anchor="concept-id">` sits level with the element that has that concept id, follows it when a file panel scrolls, and lights up while that element is highlighted. Do not place notes by hand; they drift out of line with what they explain.
- If a scene needs something the table does not list, build it from these parts. Do not invent a new visual style for one scene.

## Nonnegotiable Rules
1. **All readable text is visible from the first frame.** No typewriter effects, no word-by-word, line-by-line, or bullet-by-bullet reveals. The lint rejects the old reveal attributes.
2. Attention moves with **highlight backings** behind text that is already visible, never by changing the text.
3. **One thing is highlighted at a time.** When the voice moves on, the highlight moves with it. A highlight left on the last thing while the next is lit splits the viewer's eye.
4. Context stays: highlighting one expression never hides or dims the rest of the code to unreadability.
5. Related representations **morph** into each other; they don't pop in as unrelated objects.
6. Calm motion with a purpose, then a readable hold. No bounce, particles, ambient motion, camera moves, flashy transitions, glows, gradients, heavy outlines, shadows, decorative grids, or gratuitous icons.
7. Same meaning, same color, in every scene (see *Color semantics*).

## Evidence, not bullets

A scene is not a slide from a deck. Edward Tufte's critique of slideware (*The Cognitive Style of PowerPoint*) is that the format itself damages an explanation: it chops reasoning into fragments, hides what matters in a hierarchy, shows very little evidence per screen, and stacks things in time that need to be compared side by side. A narrated video has one advantage a deck lacks, a voice that speaks in full sentences, so divide the work accordingly: **the voice carries the reasoning; the screen carries the evidence the reasoning is about.**

1. **The headline states the point, briefly.** "A skill is advice.", not a topic label ("Skills", "The config file") and not the whole argument in one sentence. Someone who reads only the headlines, in order, should be able to follow the video. Title cards are the one exception.
2. **No bullet outlines.** Bullets drop the words that connect ideas (because, so, unless, compared with), which is where the reasoning lives. Decide what the list really is and show that instead: parallel items with attributes become a table; steps become numbered blocks; a relationship becomes a diagram; a claim becomes the headline; and reasoning goes to the voice. This holds for recaps too: one question and the picture the video already explained, not three bullets.
3. **Show the evidence itself, not a stand-in for it.** The real file, the real command output, the real numbers. If the point is that two models wrote different things, show the two things they wrote; a box with a question mark on it shows nothing. The limit of about 40 words on screen applies to prose you wrote; do not thin real evidence to meet it. A viewer cannot scan at their own pace as they can a page, so hold evidence long enough to read and move the eye across it with highlights.
4. **Give numbers with their units and something to compare them with.** "3 of 10 trials lost at five workers, 0 of 10 at two" tells the viewer something; "significantly more reliable" does not. More than two numbers go in a table (`<table class="data-table">`, with `class="num"` on numeric cells and the unit in the column header; wrap a number in `<span data-concept="…" data-rep="cell">` and a `focus` cue highlights it as the voice reaches it), not in a sentence and not in a chart. A chart earns its place only when there are enough numbers that the shape matters; then label the marks directly, with no legend, gridlines, or third dimension.
5. **Compare in space, not in time.** When the viewer needs to compare two things, both are on screen at once: two cards, two file panels, a row of small versions of the same picture. Do not ask them to hold the previous scene in memory. Across consecutive scenes, keep what has not changed in the same place.
6. **Nothing is ranked by indentation or type size unless it is ranked in fact.** The most important thing on the scene is the largest. A qualification that changes what the claim means sits beside the claim at the same size, never as a small note under an optimistic headline.
7. **Every mark means one thing.**
   - **An arrow means "flows into" or "becomes".** Use one only when something really passes from the first thing to the second. Three terms being defined are not a flow: put them in a row and highlight each as it is named. Steps that happen in order are numbered, not joined by arrows. The lint lists every arrow for you to justify.
   - **One object carries one mark.** A tick and a question mark on the same box contradict each other. Decide what the box says.
   - No logos, borders, icons, or labels repeated on every scene. An eyebrow names the chapter; a course or lesson name on every scene is furniture.
8. **Say where an outside fact comes from**, on screen, in a `.note`: who and when.

`lint-storyboard.js` warns about bullet lists, headlines over six words or of only one or two, a label repeated across most scenes, tables too long to read, arrows, a second stylesheet, pale text colors, and long paths. It cannot judge whether a headline makes a point; step through the headlines yourself (*Check before rendering*).

## Files
- Start each scene from a layout in `assets/layouts/` and copy it to `<video-dir>/scenes/<id>.html`. The `../_theme/` paths are already correct.
- `_theme/theme.css` holds the tokens, type, frame, and components. **Never edit it per video, never link a second stylesheet beside it, and never restyle its classes in a scene.** A scene's own `<style>` is for sizes and spacing that one scene needs (a `min-height`, a column width), nothing else. The lint warns about a second stylesheet, a `font-family`, and a pale text color.
- `_theme/fonts/` holds the bundled OFL fonts. Nothing loads from the network.
- `_theme/vl-runtime.js` is the motion runtime. Keep its `<script … defer>` tag in every scene.

## Layouts (vary them across a video)
| Layout | File | Use for |
|---|---|---|
| A. Concept introduction | `intro.html` | Chapter opener: big headline, one sentence, one simple relationship |
| B. Code + diagram | `code-diagram.html` | Code on the paper with its concept beside it; expressions morph into blocks |
| C. Code with notes | `code.html` | **The standard way to explain code, a command, a path, or output**: a dark box on the left, a callout on the right for each line that needs one |
| D. Side by side | `before-after.html` | Two results, two versions, or a request and what came of it, in cards |
| E. Terms | `system.html` | Two to four things and what they are, in blocks across the width, each filled as it is named |
| F. Concept expansion | `expand.html` | An abstraction opens to show its parts; good for a recap that asks before it answers |
| G. Summary | `summary.html` | One short statement plus a picture already explained; usually a static `slide` |
| H. File | `file.html`, `file-notes.html` | A real file the viewer reads: a scrolling panel with real line numbers, hidden-row markers, a minimap (a partial view always says it is partial: the minimap, or with no room for one the "lines hidden" rows when all are in view, else a scrollbar), and optional callouts (`FILES-ON-SCREEN.md`) |
| I. Steps | `steps.html` | Things that happen in order: numbered blocks, no arrows |
| J. Table | `table.html` | Numbers, or a short list of named facts |

Don't use the same layout for every scene. Consistency comes from the frame, the type, the colors, and the one visual language above.

## Writing a Scene
- Root: `<main class="scene">` (add the layout's class when it has one, e.g. `layout-file`). The canvas is 1920×1080 with a 120 px safe margin and a 160 px caption band at the bottom, both already in `.scene` padding.
- **Eyebrow** (optional): `<div class="eyebrow">`, the chapter's name in sentence case. It orients the viewer inside the video.
- **Headline:** `<h2 class="scene-title">A skill is advice.</h2>`, six words or fewer, sentence case. Chapter openers and title cards use `<h1 class="scene-title chapter">`.
- **Headlines are plain by default.** An italic phrase (`<em>`, shown in blue) is for the one word that carries the scene’s point: a term being defined (`An eval is a <em>question</em>.`) or a contrast (`It works for <em>me</em>.`). Italicising the last words of a headline for rhythm is decoration; when most headlines have it, it reads as a tic. Aim for no more than about one headline in four, and the lint warns above one in three.
- **Supporting sentence** (optional): `<p class="lead">`, one sentence, in the stage or under the headline.
- **At most about 40 words of prose on screen.** Code, file panels, terminal output, tables, and quoted requests are evidence and do not count against you. The narration carries the reasoning.

### Code, commands, and output
Generate code with the script; never hand-color it:
```bash
node <SKILL_DIR>/scripts/code.js --lang bash --dark --in snippet.sh    # the dark box: commands, output, paths, diffs
node <SKILL_DIR>/scripts/code.js --lang ts --in snippet.ts             # code as typography on the paper (layout B)
```
In the snippet, mark each expression you will talk about as a concept: `⟦model:--model claude-haiku-4.5⟧`. The output wraps it in `<span data-concept="model" data-rep="code">`, ready for a focus cue and for a callout to anchor to. Paste the `<pre class="code dark">` fragment into the scene:

```html
<div class="annotated">
  <pre class="code dark">…</pre>
  <aside class="callouts">
    <p class="callout" data-anchor="e">which eval file to run</p>
    <p class="callout" data-anchor="model">which models to run it on</p>
  </aside>
</div>
```

- A callout is a few words, in the sans. It is quiet until its anchor is highlighted, then lit; when the highlight moves on, it goes quiet again. You write no cue for it.
- 36 px in a dark box, ≤12 lines, ≤64 characters per line (42 px, ≤9 lines, ≤56 characters on the paper). If it doesn't fit, **split the scene; never shrink the code**.
- **A snippet is for code you wrote for the video; a real file gets a file panel.** If the lines come from a file the viewer will meet (a config, a spec, an output file), generate a panel with `file-panel.js` (`FILES-ON-SCREEN.md`) so the line numbers are real and skipped lines are marked.
- Colors come from the script: it moves Solarized's editor colors to variants that read on video, and leaves prose in a Markdown file plain so a highlight behind it is visible.
- No fake editor chrome: no window buttons, no tabs.
- Ligatures are off, so code shows exactly the characters typed.

### Blocks, quotes, and cards
- **A term and its meaning:** `<div class="semantic-block" data-concept="agent" data-rep="block" data-role="transform"><div class="title">agent</div><div class="label">A program that uses a model and tools to do a task.</div></div>`. `data-role` sets a faint tint at rest: structure (blue), transform (cyan), attention (yellow), success (green), change (orange), failure (red). A `focus` cue on the block fills it with the full color; that is how the viewer knows which one the voice is on.
- **A numbered step:** the same block with `<div class="step">2</div>` first.
- **A quote:** `<div class="quote"><span class="who">The request</span><p>“I fixed the typo in the help text. Put that in the changelog.”</p></div>`.
- **A labelled result:** `<div class="card"><div class="who">Your run, on <span class="mono">claude-haiku-4.5</span></div><pre class="code dark">…</pre></div>`.
- **Typographic diagrams** (`.diagram` of `.node`s, with `connect` cues) are for a real flow. One primary relationship per scene, flowing left to right; keep labels next to what they label; no legends.
- **Same concept, same id** everywhere it appears: code, diagram node, and block share `data-concept` and differ by `data-rep`.

### Color semantics
| Meaning | Accent | Focus backing |
|---|---|---|
| Structure, types, interfaces | blue | `blue` |
| Transformation, processing, current focus | cyan | `cyan` (default) |
| Attention, distinction, caution | yellow | `yellow` |
| Success, validation | green | `green` |
| Change, exceptional operation | orange | `orange` |
| Error, failure, destructive | red | `red` |
Use blue, cyan, and yellow most. Never rely on color alone; pair it with a label or position. Colored text under 36 px uses the darker ink variants, which the `.label.c-*` classes already apply; definitions inside a tinted block stay in the ink colors.

### Dark scenes
`<main class="scene dark">` (base03) is for a deliberate change of emphasis only, such as a debugging moment. Dark code boxes are for commands, output, diffs, files, and comparisons.

## Type Scale (already in theme.css)
| Element | Size | Class |
|---|---|---|
| Chapter or title headline | 136 px | `.scene-title.chapter` |
| Scene headline | 96 px | `.scene-title` |
| Supporting sentence | 38 px | `.lead` |
| Quote | 38 px | `.quote` |
| Code on the paper | 42 px | `.code` (38 px `.small`) |
| Code in a dark box, file panel | 36 px | `.code.dark` (32 px inside a `.card`) |
| Block title, block text | 44 px, 32 px | `.semantic-block .title`, `.label` |
| Callout, note | 32 px, 30 px | `.callout`, `.note` |
| Eyebrow | 24 px | `.eyebrow` |

Nothing a viewer must read is under 28 px.

## Check Before Rendering
Preview stills of one scene at the moments that matter:
```bash
node <SKILL_DIR>/scripts/preview.js <video-dir>/scenes/s03.html --at 0,s1+0.5,s2+1,end --sheet [--video <video-dir> --scene s03]
```
Look at the sheet: is everything readable at t=0, does nothing clip or crowd, does each highlight sit on the right expression, is each callout level with its line? `problems` in the output lists font and cue errors, content off the canvas, and text too pale to read.

Then look at the whole video at once:
```bash
node <SKILL_DIR>/scripts/preview.js --all <video-dir>      # build/preview/_all/sheet.png
```
Open the sheet and ask what one scene alone cannot tell you (`REVIEW.md` → *Look pass*): does any scene look like it came from a different video? Is every headline short? Is code always in a dark box with its notes on the right? Then read the headlines in order, with nothing else: they should state the video's argument, one point per scene. `lint-storyboard.js --strict` checks the rest.

## Anti-Patterns
- **A sentence in the headline:** "vally eval takes an eval file, models, and a results folder." in the display serif. Six words or fewer; the rest goes to the voice.
- **Fixing the font instead of the words:** switching every headline to the sans because long ones looked bad.
- **Your own stylesheet:** a `course.css` that restyles the theme. The look is not yours to change per video.
- **Pale gray text:** model names, labels, or notes in `base1` on the paper.
- **A new visual style for one scene:** a table for a path when every other scene puts code in a dark box with notes.
- **Arrows between things that do not flow:** skill → agent → model.
- **Two marks on one box:** a tick and a question mark.
- **A placeholder where the evidence should be:** "?" cards instead of the two results.
- **Notes floating beside code:** hand-placed, out of line with what they explain. Use callouts.
- **Part of a file with no sign that it is part:** a scrolling panel with neither minimap nor scrollbar, or lines left out with no "lines hidden" row. `file-panel.js` draws what is needed; do not remove it.
- **Two highlights at once:** the last note still lit while the next line is highlighted.
- **Slide-deck habits:** bullet lists (revealed one by one or all at once), a title plus bullets, uppercase labels, a course label on every scene.
- **Topic-label headlines:** "Results", "The trigger file". State what the scene shows about them.
- **A sentence about numbers instead of the numbers:** "most trials passed". Show the table.
- **Remember-the-last-scene comparisons:** before on one scene, after on the next. Put them side by side.
- **Italic on every headline:** the accent stops meaning anything. Most headlines are plain.
- **Shrinking code to fit:** split the scene instead.
- **Decoration:** icons, cards around everything, borders, shadows, background patterns, emoji.
- **Fake chrome:** editor windows, traffic lights, tabs, browser frames.
- **Color drift:** cyan meaning "transform" in one scene and "error" in another.
- **Remote assets or system fonts:** everything comes from `_theme/`.

## Decision Guide
1. Is it a real file? → Layout H, a file panel.
2. Code, a command, a path, or output to explain? → Layout C: dark box, callouts.
3. A few terms to define? → Layout E. Steps in order? → Layout I.
4. Two things to compare? → Layout D.
5. Numbers or named facts? → Layout J.
6. Does an abstraction hide steps, or is this the recap? → Layout F.
7. Too much for one scene? → Split it; each scene teaches one point.
