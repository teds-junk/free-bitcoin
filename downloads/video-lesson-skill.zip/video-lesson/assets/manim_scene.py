"""manim scene template (renderer "manim"). Copy to <video-dir>/manim/scenes.py.

Storyboard visual: "manim/scenes.py#SceneClassName". Rendered at 1920x1080, 30 fps.
Use Text/MarkupText only (no Tex/MathTex: LaTeX is not installed). Follow the design system:
paper background, ink text, semantic accents, Instrument Serif headlines, JetBrains Mono for code.
No bounce, no particles, no camera moves; motion explains a relationship, then holds.

render-scenes.js passes the narration timing in environment variables so the
animation can match the voice:
  VL_SENTENCES          JSON list of {"text", "start", "end"} in seconds
  VL_NARRATION_SECONDS  total narration length for this scene
Use play_at() to start animation i when sentence i starts and finish() at the end; both
read manim's own clock (self.time), so extra self.play()/self.wait() calls stay in sync. If it runs longer, the narration is padded
with silence; if shorter, the last frame is held.
"""
import json
import os
import sys

from pathlib import Path

import manimpango
from manim import (DOWN, LEFT, RIGHT, UP, Arrow, Create, FadeIn, RoundedRectangle, Scene,
                   Text, VGroup, config)

# Solarized Technical Essay (references/SOLARIZED-TECHNICAL-ESSAY.md): paper, ink, semantic accents.
# INK_MUTED is the theme's --ink-muted (6:1 on the paper), not Solarized base00: pale grey vanishes on video.
PAPER, PAPER_MUTED, INK, INK_MUTED = "#FDF6E3", "#F1EAD4", "#073642", "#4A6068"
BLUE, CYAN, YELLOW, GREEN, ORANGE, RED = "#268BD2", "#2AA198", "#B58900", "#859900", "#CB4B16", "#DC322F"
FOCUS_CYAN, FOCUS_BLUE = "#D7EBE3", "#DCEBF3"
DISPLAY, BODY, CODE = "Instrument Serif", "Inter", "JetBrains Mono"

# Bundled OFL fonts, registered for this process only (no system install needed).
# Call manimpango directly: manim's register_font() context manager unregisters on exit.
FONT_DIR = Path(os.environ.get("VL_FONT_DIR", Path(__file__).resolve().parents[1] / "_theme" / "fonts" / "ttf"))
for _f in sorted(FONT_DIR.glob("*.ttf")):
    if not manimpango.register_font(str(_f)):
        print(f"warning: could not register font {_f}", file=sys.stderr)

SENTENCES = json.loads(os.environ.get("VL_SENTENCES", "[]"))
TOTAL = float(os.environ.get("VL_NARRATION_SECONDS", "8"))


def at(i, default):
    """Start time (s) of sentence i, or a default when previewing without narration."""
    return SENTENCES[i]["start"] if i < len(SENTENCES) else default


class Timed(Scene):
    """Scene base class: land animations on sentence starts using manim's own clock (self.time),
    so plain self.play()/self.wait() calls in construct() can't throw the timing off."""

    def setup(self):
        config.background_color = PAPER
        self.camera.background_color = PAPER

    def play_at(self, start, *anims, run_time=0.8):
        gap = start - self.time
        if gap > 1 / config.frame_rate:
            self.wait(gap)
        elif gap < -0.1:
            print(f"warning: animation for t={start:.2f}s starts late at {self.time:.2f}s", file=sys.stderr)
        self.play(*anims, run_time=run_time)

    def finish(self):
        rest = TOTAL - self.time
        if rest > 1 / config.frame_rate:
            self.wait(rest)


class {{SCENE_CLASS}}(Timed):
    def construct(self):
        title = Text("{{HEADING}}", font=DISPLAY, font_size=60, color=INK).to_edge(UP, buff=0.9).to_edge(LEFT, buff=1.0)
        stages = VGroup(*[
            VGroup(RoundedRectangle(corner_radius=0.08, width=3.2, height=1.2, fill_color=FOCUS_CYAN,
                                    fill_opacity=1, stroke_width=0),
                   Text(label, font=CODE, font_size=34, color=INK))
            for label in ("{{STEP_1}}", "{{STEP_2}}", "{{STEP_3}}")
        ]).arrange(RIGHT, buff=1.4)
        arrows = VGroup(*[Arrow(stages[i].get_right(), stages[i + 1].get_left(), buff=0.2, color=INK_MUTED,
                                stroke_width=4, max_tip_length_to_length_ratio=0.12) for i in range(2)])

        self.add(title)  # text is visible from the first frame; motion explains relationships
        self.play_at(at(0, 0.8), FadeIn(stages[0], shift=UP * 0.2), run_time=0.7)
        self.play_at(at(1, 3.0), Create(arrows[0]), FadeIn(stages[1], shift=UP * 0.2), run_time=0.7)
        self.play_at(at(2, 5.0), Create(arrows[1]), FadeIn(stages[2], shift=UP * 0.2), run_time=0.7)
        self.play_at(at(3, 7.0), stages[2][0].animate.set_fill(GREEN, opacity=0.25), run_time=0.5)
        self.finish()
