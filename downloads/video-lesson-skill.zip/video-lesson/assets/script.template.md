# {{TITLE}} — narration script

<!-- Generated from storyboard.json by lint-storyboard.js. Edit storyboard.json, not this file.
     Free-form notes (sources, open questions) go between the notes markers and are kept. -->

Source: {{SOURCE}}  
Voice: {{VOICE}}

<!-- notes -->
<!-- /notes -->
