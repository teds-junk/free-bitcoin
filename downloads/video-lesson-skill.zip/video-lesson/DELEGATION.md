# Delegation

Who does which part of producing a video once the storyboard is approved, when your agent can launch subagents and run commands in the background. The split moves the mechanical production loop to a cheaper model and keeps every judgement about the look and the wording with you. If your agent can do neither, do every step yourself in the order of `SKILL.md`; nothing here changes what gets checked.

## The split

| Step | Who | Why |
|---|---|---|
| Story, storyboard, cold read, script pass, the approval checkpoint (steps 4–6) | You | The user approves your wording |
| Author the scenes and tapes; the look pass on `preview.js --all`; `lint --strict`; the command review (step 7) | You | Judgement about the look. The user notices when it slips |
| Narration (`tts.py`, step 8) | A background command, no agent | It needs only the approved script and the resolved pronunciations, so it runs while you author |
| Record, render, fit timing, assemble, verify, transcribe (steps 9–10) | One production subagent per video | Mechanical and documented. Its retries and script output stay out of your context |
| The look pass on **every** still of the finished video; every `outcome` sentence against its recording; `publish.md`; the report (steps 10–11) | You | See *The full review is yours* |

For a course batch, queue one background narration and one production subagent per video behind your authoring. Recordings still run one at a time (the renderer's lock), so launch the production subagents in lesson order and let them wait their turn.

## Narration in the background

Start it as soon as the script is approved and every word on the review list is resolved (the review-page results imported):

```bash
PY <SKILL_DIR>/scripts/tts.py <dir>
```

Run it as a background command and carry on authoring. Adding an anchor or a `read` later does not change the audio. Changing a sentence does: run it again, and only the changed sentences re-synthesize.

## The production subagent

Launch it when all of these hold: every scene and tape exists, you have done the look pass on the preview sheet, `lint-storyboard.js <dir> --strict` exits 0, the user has approved the commands, and narration has finished.

**Model.** One tier below your own is enough (for example Opus when you run on a higher tier). The work is running scripts, reading their findings, and adding anchors.

**The brief.** It starts with none of your context, so give it:
- The video folder, the skill folder, and the files to read first: `ASSEMBLY.md` and `TERMINAL-DEMOS.md` → *Timing to narration* and *Time to read*.
- The commands, in order: `render-scenes.js <dir>`, `sync-report.js <dir>`, `assemble.js <dir>`, `verify.js <dir> --frames`, `tts.py --transcribe <dir>`.
- Whether any recording may spend, and exactly which scenes. If none, say so.
- The limits and the report format below, word for word.

**Limits.**
- It may edit `storyboard.json` only to add or move `before`, `wait_for`, `read`, and `pause`. It never changes a sentence, a scene, a tape, a scene's HTML, a lexicon, or the preferences.
- It never passes `--allow-spend` except for the scenes you named, and never re-records to get a different outcome.
- It never runs a git command that writes, and never deletes anything outside the video's `build/` folder.
- A credential hit, a partly scanned recording, a render error it cannot fix with an anchor, or anything that needs a wording or visual change stops it. It reports and waits; it does not work around it.

**The report.** Facts, not a verdict:
- Each command it ran, its exit status, and every warning or finding, quoted.
- Each change it made to `storyboard.json`: scene, sentence, field, old and new value.
- The final `sync-report.js` findings that remain, and the `verify.js` result.
- The transcript's `by_word` list and the sentences that differ.
- The credential scan result for each recording.
- The MP4 path and length, and the folder of review stills.
- Anything it saw in a still that looked wrong, with the still's path. Tell it this list is a pointer for you and not a sign-off.

## The full review is yours

A subagent reports a miss in the same confident voice as a pass, and you cannot tell which from its summary. So its report tells you where to look first; it never replaces looking.

- Open **every** still in `build/review/` yourself and do the look pass (`REVIEW.md`) across the whole set. Do not sample, and do not look only at what was flagged.
- Check each `outcome` sentence against its recording (`build/raw/<id>.txt` and the stills) yourself.
- Read the anchor changes it made as a diff of `storyboard.json`, and confirm no sentence changed.
- Re-run `verify.js <dir>` yourself before you report: it is cheap, and it is the definition of done.
- What needs fixing goes back through *Recipe: change an existing video*. A fix that is only anchors and re-rendering can go back to the same subagent; a fix to wording or visuals is yours.

## Gotchas

- **Sampling the stills to save effort.** The user would rather spend the agent's effort than watch a video and send it back. Review the full set.
- **Handing over the look.** A subagent that authors or "tidies" scenes produces the scene that looks like it came from a different video. Scenes are yours.
- **A brief that says "make the video".** Without the limits it rewrites sentences to fix timing. Give it the limits verbatim.
- **Two production subagents recording at once.** The lock makes the second wait; do not work around it.
- **Handing over a tape you already paid for without saying so.** When you recorded a paid tape yourself (`TERMINAL-DEMOS.md` → *Non-deterministic demos*, step 6), the brief must say that it is recorded, that it must not be recorded again, and that its tape must not be edited, not even a comment.
- **Trusting a terminal scene's one review still.** `verify.js --frames` takes one frame per scene, and for a terminal scene it often lands mid-typing or just after a hidden clear. Pull frames at each output with `verify.js --at`, using the times `sync-report.js` prints.
- **Delegating before narration finished.** The render then fails on missing clips and the subagent starts narrating on its own. Wait for the background job.
