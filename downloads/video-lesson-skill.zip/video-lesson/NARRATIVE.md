# Narrative

A video can be correct scene by scene and still lose the viewer: they cannot tell whether they are being told how a thing works, how to think about it, or how they would use it, and commands start running before the ideas are in place. Plan the story before any scene exists, so the viewer feels progress from the first minute to the last.

## Contents

- [1. Plan the story](#1-plan-the-story)
- [2. Give every scene a job](#2-give-every-scene-a-job)
- [3. Explain before doing](#3-explain-before-doing)
- [4. Do it right the first time](#4-do-it-right-the-first-time)
- [5. Learning design](#5-learning-design)
- [6. Cold read](#6-cold-read)
- [Anti-patterns](#anti-patterns)

## 1. Plan the story

Fill in `narrative` in `storyboard.json` before writing a single scene.

For a lesson from a teach-me course, the plan has been made and agreed already: `COURSE-PLAN.md` gives the lesson's Question, its sections with their modes, and its Win. Copy them into `narrative` (`STORYBOARD.md` → *Reading the source*) and spend this step checking that the arc holds as a video, not inventing a new one.

```json
"narrative": {
  "question": "What does a passing eval actually prove?",
  "viewer_starts": "Has run one eval and seen it pass; has never opened a spec file",
  "arc": [
    { "stage": "see-the-parts", "viewer_can": "name the three things a spec decides" },
    { "stage": "read-a-spec",   "viewer_can": "predict what a spec will check before running it" },
    { "stage": "read-a-result", "viewer_can": "say why a run passed or failed from its record" }
  ]
}
```

- **`question`**: the one question the video answers, in words the viewer could have used before watching. "What does a passing eval actually prove?" works. "Anatomy of an eval" is a title, not a question.
- **`viewer_starts`**: what the viewer knows and can do at second zero. For a lesson in a course, that is what the earlier lessons established. Anything not listed here must be taught before it is used.
- **`arc`**: two to five stages, in order. Each has a short name and `viewer_can`: something the viewer can do or decide after that stage that they could not before. Use a verb you could watch someone do (name, predict, read, run, choose, fix), not "understands". Each stage's ability should be needed by the next one, and the last stage's ability answers the question.

Done when: you can say the arc in one breath as "first you'll be able to …, which lets you …, so that finally you can …". If two stages could swap places without loss, it is a list, not a progression: reorder or merge.

## 2. Give every scene a job

Each scene carries three tags.

**`stage`**: which arc stage it belongs to. Scenes never go back to an earlier stage.

**`role`**: what the scene is for in the video. A compilation uses this to choose scenes.

| Role | Purpose |
|---|---|
| `hook` | The opening: the payoff or the problem, and the promise |
| `title` | A title card |
| `body` | Teaching |
| `practice` | The exercise or checkpoint, posed and then performed on screen. This is teaching content and a compilation keeps it |
| `recap` | What the viewer can now do |
| `next` | What comes after this video: the next lesson, and any pointer to exercises on the lesson page. A compilation drops it |
| `bridge` | Connective scene between lessons in a compilation |

**`mode`**: what the scene is doing for the viewer. Required on hook, body, and practice scenes.

| Mode | The viewer leaves able to | Sounds like | Usual visual |
|---|---|---|---|
| `think` | See the thing the right way: why it matters, a mental model, a distinction, when to choose it | "A verdict is not a reason." | Concept intro, diagram, comparison |
| `works` | Predict what it will do: what it is made of, what happens inside | "This block decides which files the agent can see." | File panel, code walk, system diagram |
| `use` | Do it themselves: the command to run, where to look, what to do with the result | "We run lint first, because it's free." | Terminal demo |

- **One mode per scene.** A scene that explains a field and then runs a command is two scenes.
- **Stay in a mode for a stretch.** Within a stage the natural order is think, then works, then use: why care, what it is, do it. Modes that flip on every scene read as disjoint.
- **Signpost every change of mode** in the first sentence of the new scene, so the viewer knows what kind of thing comes next: "That's the idea. Here is the file that expresses it." "Now run it." "So what should you make of that number?"

The lint prints the mode sequence and lists each change of mode with the sentence that opens it. Read that list as a viewer: if an opening sentence does not announce the change, rewrite it.

## 3. Explain before doing

No command or file appears on screen until the viewer has been told what it is and why it matters. This is the rule the viewer feels most when it is broken: a command runs, output scrolls, and they do not know what they are looking at.

- **Say both halves**: what it is, and why it matters to the question. One or two sentences, in an earlier `think` or `works` scene, or in the same scene before the command is typed.
- **Keep the books in `introduces`.** On the scene that explains a command or file, list it: `"introduces": ["vally lint", "eval.yaml"]`. The lint reads what each tape types and what each file panel shows, and reports an error for anything that appears before a scene introduced it. Tapes and panels are written after the storyboard is approved, so until they exist, list what each scene will show in `"shows": ["vally lint", "eval.yaml"]`; the check then works at the approval checkpoint, where reordering is still cheap. Commands are matched with their subcommand (`vally lint` and `vally eval` are introduced separately).
- **Same-scene introductions need an anchor.** When a terminal scene both explains and runs a command, put `"before": "typed:N"` on the explaining sentence. The recording then holds until the sentence has finished (see `TERMINAL-DEMOS.md`), so the explanation cannot arrive late.
- **Flags count.** Every flag in a visible command gets a clause. If a flag is not worth a clause, take it out of the visible command by setting it up out of sight (a config file, the hidden setup).
- **Say what to look for before the output appears**, as a fact and not an order: "The last line is the pass rate; that's the one we're after."
- **Explain what is new to this viewer, and only that.** `viewer_starts` says what they already know. Do not explain a shell basic to a programmer or a concept from an earlier lesson at length; one reminding clause is the most a known thing gets.
- **Define each term at first use**, in the course's wording, and do not use it before then. That includes the hook: its promise may only use ideas the viewer already has. In a teach-me course the plan's concept order table says where each term, tool, and file is introduced. Something introduced in an earlier lesson is known, but gets one reminding clause the first time this video uses it.

## 4. Do it right the first time

Never show a mistake and then explain it. The viewer copies what they see first, and a correction afterwards reads as the video losing its way.

- **Configure the demo correctly from the start, and give the reason in a clause**: "with two workers, because more can drop sessions on a laptop". Do not run it the wrong way first.
- **What happened while making the video stays out of the narration**: first attempts, something that did not work on this machine, steps that were not run, what was recorded when. Write those between `<!-- notes -->` and `<!-- /notes -->` in `script.md`, where the user can read them.
- **A failure that is the subject of the video is fine when it is the plan.** Announce it before it happens ("Here is what a failing grader looks like") and never present it as a discovery ("turns out…").
- **Do not show what will not be done.** A command that is "not run here" teaches nothing. Run it, or leave it to the lesson page.
- A jump cut over a slow command may be acknowledged in a clause ("about a minute later").

The lint warns on phrasing that usually marks a production note ("my first attempt", "I ran this before recording", "on this machine"). Treat each warning as a prompt to look, then rewrite or move the sentence to the notes.

## 5. Learning design

These are the principles the `teach-me` skill plans a course by. They are restated here so this file stands alone, and so a video made from another source follows them too.

- **One tangible win.** The video ends with the viewer able to do one thing they could not do before. That is the last stage of the arc. Cut what does not serve it.
- **Working memory is small.** When presenting something new, difficulty is the enemy. One new idea per scene, one running example for the whole video, and no more than three or four new terms in play at once.
- **Knowledge first, then the skill.** Teach only the knowledge the win needs, then show it used.
- **Ground it in why the viewer cares.** The hook connects to their goal (for a course, one sentence from `MISSION.md`), not to the tool.
- **Use the workspace's vocabulary exactly**, as its glossary defines it.
- **Start where the viewer is.** Be honest in `viewer_starts`. A video that assumes too much loses the viewer in the first minute; one that assumes too little bores them.
- **Practice early.** Do not hold the doing back until the explaining is finished. Each stage that can end in the viewer doing something should.
- **Recall beats review.** Feeling fluent while watching is not retention. In the `practice` scene, ask the question the demo will answer ("What would you expect each model to do?") and leave a beat of silence (`"read": 2`) before performing it, so the performance is feedback and not a spoiler. Do not tell the viewer to pause the video, type along, or do it themselves: they are watching, and the doing happens on the lesson page. Narrate the demo as what we are doing ("If you tried it yourself, here's what you'd see"). In the `recap`, ask before answering: a question, a `pause` of about two seconds, then the answer, in the form the question asked for (verbs for "what does it do?"). A teach-me plan lists each lesson's Recalls; they make good recap and bridge questions.

## 6. Cold read

Run this after the lint passes and before showing the user the checkpoint. It catches what the lint cannot.

Give `script.md`, and nothing else, to a fresh reader: a subagent if your agent can launch one. If it cannot, read the script yourself from top to bottom as a viewer who knows only `viewer_starts`, and tell the user the read was not independent. Do not tell the reader what you expect to find. Ask:

1. For each scene: is this telling you how something works, how to think about it, or how you would use it?
2. Where did you first meet a command, file, flag, or term you had not been told about?
3. Where did the video do something and only then explain it, or show a mistake and then correct it?
4. After each stage: what can you now do?
5. Where were you lost, and where did nothing new happen?
6. Does the opening promise use any word or idea that is only explained later?
7. Where were you told something that someone described in "The viewer starts" already knows?
8. Which sentences did you have to read twice to understand?
9. Where were you told to do something (pause, type, try), or told how long the video is?

Compare the answers with the `mode` and `viewer_can` you wrote. Each mismatch is a scene to rewrite, reorder, or cut. Fix them, re-run the lint, and report at the checkpoint what the cold read found and what you changed.

## Anti-patterns

- **A list of topics as an arc.** Stages that name subjects ("the config file", "the CLI") instead of abilities.
- **Tour of the file.** Walking every field of a file in order. Show the fields the question needs.
- **Run first, explain after.** A terminal scene as the first scene of a stage.
- **The confession.** "One honest detail: my first attempt…". See section 4.
- **Mode soup.** A fact about how it works, then a command, then advice, in one scene.
- **Reference dump before the close.** Tables of everything a tool can do, placed where the viewer expects the payoff.
- **The manual.** A demo narrated as instructions ("Run it. Now list the folder. Pause here and compare."). The viewer is watching someone do it; say what we are doing and what it shows.
- **A promise in words not yet taught.** A hook that names the files, flags, or terms the video has not introduced.
