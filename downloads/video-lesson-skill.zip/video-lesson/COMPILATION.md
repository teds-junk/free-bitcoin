# Compilation

Weave finished lesson videos into one course video. A viewer watching straight through should not hear a title, a recap, and a "next lesson" every eight minutes: the compilation keeps each lesson's teaching scenes, drops the scenes that only make sense for a lesson watched alone, and joins the lessons with short narrated bridges. Lessons are never re-rendered.

## Inputs

Parts are **video folders, not MP4 files**: `compile.js` builds from each folder's per-scene clips and narration track. Find the folders under `<workspace>/videos/`; do not ask the user for MP4 paths. Every part must be a finished video made by this skill (`build/clips/`, `build/narration.wav`, `build/timeline.json`, `<slug>.srt`). `compile.js` stops and names a part that is missing them or whose clips, timeline, and narration disagree; finish or re-assemble that video first.

What gets kept depends on each scene's `role` in its `storyboard.json` (`NARRATIVE.md` → *Give every scene a job*). A scene with no role counts as `body`, so a lesson made before roles existed is kept whole until its scenes are tagged. Adding `role` to a finished storyboard changes nothing about its render; no re-narration or re-render is needed.

## Steps

1. **List the parts in order.** For a teach-me course, take the order and the course title from `<workspace>/COURSE-PLAN.md` (or `assets/course.js` in a course without a plan). Confirm the list and the title with the user.
2. **Check the roles.** Every lesson should have its title, recap, and next scenes tagged. For older lessons, add the tags now. A "your turn" scene that only points at the lesson page is `next`; a scene that performs the exercise is `practice` and stays in.
3. **Write the bridges.** One short video (`kind: "bridges"`, made with `new-video.js --kind bridges` and the normal workflow, approval checkpoint included) in `<workspace>/videos/bridges/`. Each scene carries `"role": "bridge"` and `"after": "<lesson slug>"`, and plays after that lesson's last kept scene. A bridge is 10–25 s and does two things: names what the viewer can now do (the lesson's last arc stage) and why the next thing follows from it. It does not say "lesson", "next lesson", or a lesson number. In a teach-me course the plan has written it: each lesson's Hand-off states what the viewer now has and the question that leads on ("Both models got a green tick, yet they did different things. So what did the tick check?"), and its Recalls make a good question to ask before moving on. Add a bridge after the last lesson too, or an outro, so the video does not end on a body scene.
4. **Intro and outro** (optional; ask the user). Each is a normal short video (`kind: "intro"` / `"outro"`) in `<workspace>/videos/00-intro/` and `99-outro/`:
   - Intro (30–60 s): the course's promise (the plan's Story: the starting problem and the destination), who it is for, and the journey in one line per stage.
   - Outro (30–60 s): what the viewer can now do and where to go next.
5. **Show the plan and get approval.**
   ```bash
   node <SKILL_DIR>/scripts/compile.js --parts <dir>,<dir>,... --bridges <ws>/videos/bridges --plan
   ```
   It renders nothing. It prints what is kept and dropped per lesson with durations, which bridge covers each boundary, any boundary with neither a bridge nor a title card, the chapters, the references to lessons that survive in kept scenes, and the resulting length. Show this to the user. A boundary marked `UNMARKED hard cut` needs a bridge.
6. **Compile:**
   ```bash
   node <SKILL_DIR>/scripts/compile.js --out <workspace>/videos/course --title "<Course title>" \
     --parts <dir>,<dir>,... --bridges <ws>/videos/bridges
   ```
   Ask the user before using an output folder other than `<workspace>/videos/course/`.
7. **Verify.** `compile.js` runs `verify.js` itself and prints one JSON result with `ok`, `warnings`, and `checks`. Then run `node <SKILL_DIR>/scripts/verify.js --file <out>/<slug>.mp4 --timeline <out>/build/timeline.json --srt <out>/<slug>.srt --chapters <out>/chapters.txt --frames` and look at the stills in `build/review/`, especially on both sides of every lesson boundary.
8. **Report** as for a single video: the path and length, the `.srt` to upload in YouTube Studio, the warnings, and a `publish.md` for the course. A teach-me course home shows the combined video when `video` in `<workspace>/assets/course.js` names it (for example `'videos/course/<slug>.mp4'`); offer to set that line, and set it only if the user agrees, since the file belongs to the course.

## Options

| Flag | Effect |
|---|---|
| (default) | Drop `title`, `recap`, and `next` scenes from lessons; one chapter per lesson, named by the lesson's title. `practice` scenes are kept: they perform the checkpoint, which is teaching content |
| `--keep <roles>` | Keep some of those after all. `--keep all` drops nothing |
| `--drop <roles>` | Drop more roles, for example `--drop practice` for a shorter cut without the exercises |
| `--bridges <dir>` | The bridges video. With bridges, title cards are off |
| `--cards` / `--no-cards` | A title card before each lesson (on by default only when there are no bridges) |
| `--numbered` | "Lesson N: title" chapters and cards |
| `--scene-chapters` | Keep each lesson's own chapters instead of one per lesson |
| `--staple` | The old join: every lesson's whole video behind a numbered title card |

Intro, outro, and bridge scenes always play; roles are dropped from lessons only.

## What the compiler does

- Concatenates the kept scenes' clips by stream copy (one encoding, no quality loss).
- Copies each kept scene's stretch of its lesson's narration track to the scene's new position. Scenes begin and end on whole frames, so the audio cannot drift from the picture.
- Keeps the captions of kept scenes, shifted and renumbered.
- A bridge opens the next lesson's chapter. Chapters shorter than 10 s are merged with a neighbour and reported.
- Lists **lesson references that survive**: "this lesson", "lesson three", "the lesson page" spoken or shown in kept scenes. They cannot be cut out; fixing one means rewording that sentence (or editing that scene) in the lesson and re-rendering that scene. Show the list to the user and ask which matter.

## Gotchas

- **References to lessons in hooks and body scenes survive the weave.** In new lessons, keep lesson talk, and an on-screen "Lesson N" label, to the title, recap, and next scenes (`STORYBOARD.md`). The lint on each lesson warns about spoken ones.
- **A recap scene that also says "next, lesson four…" cannot be kept on its own.** Make `recap` and `next` separate scenes.
- **Stale lessons.** After editing a lesson, re-run `render-scenes.js` and `assemble.js` for it before compiling.
- **Re-rendering lessons for the compilation** is unnecessary; it reuses their clips.
- **No ending.** With the closing scenes dropped and no outro or closing bridge, the video stops on the last lesson's last body scene. The plan warns.
