# Course plan: Querying CSV exports with SQLite

Status: agreed
<!-- draft → agreed → authored → built → verified -->

## Story
Starting problem: the learner answers the same monthly questions about an orders export by filtering and summing in a spreadsheet, slowly and with mistakes.
Destination: they answer each question with a saved query they can rerun on next month's file.
Running example: a small orders export, `orders.csv`, that the course creates in `./practice/`, with about twenty rows and the columns `order_id`, `customer`, `amount` and `status`.

## Lessons

### 1. Load a CSV and ask it a question
File: 0001-load-a-csv.html
Question: can I ask my orders export a question without opening a spreadsheet?
Win: load a CSV into a database and answer a "which rows" question with one query.
Hand-off: you can pick out rows. The monthly questions are totals per customer, so the next question is how to add up by group.
Sections:
1. A query is a question you can rerun | think | a query names the columns you want, the table, and the condition rows must meet
2. What import does to your file | works | the header row becomes column names and each line after it becomes a row
3. Load the export and ask | use | create the practice file, import it, check what arrived, run one query
Recalls: none
Primary source: Command Line Shell For SQLite

### 2. Total by group
File: 0002-total-by-group.html
Question: how do I get a total per customer, largest first?
Win: produce a per-customer total, largest first, saved as a file you can rerun.
Hand-off: none. This is the last lesson; the workflow guide is the page to come back to.
Sections:
1. Decide the group before the sum | think | a total needs a group: one output row per distinct value of a column
2. What grouping and sorting do to the rows | works | rows that share a value collapse into one output row with its sum, and ORDER BY then sorts those output rows
3. Total, sort, save and rerun | use | group and sum, sort largest first, put the query in a file, run the file
Recalls: what import does with the header row; what the WHERE condition does to rows
Primary source: SELECT, SQLite SQL language documentation

## Concept order
| Term, tool or file | Origin | Introduced | First used |
|---|---|---|---|
| table | SQLite documentation | L1 §1 | L1 §2 |
| SELECT | SQLite documentation | L1 §1 | L1 §3 |
| WHERE | SQLite documentation | L1 §1 | L1 §3 |
| sqlite3 | SQLite documentation | L1 §2 | L1 §3 |
| .import | SQLite documentation | L1 §2 | L1 §3 |
| .schema | SQLite documentation | L1 §2 | L1 §3 |
| GROUP BY | SQLite documentation | L2 §1 | L2 §3 |
| SUM | SQLite documentation | L2 §1 | L2 §3 |
| ORDER BY | SQLite documentation | L2 §2 | L2 §3 |
| .read | SQLite documentation | L2 §3 | L2 §3 |

## Reference sheets
- workflow-guide.html: answering a question about a new CSV export, from the file to a saved query
