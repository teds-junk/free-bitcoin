# Querying CSV exports with SQLite: Resources

## Knowledge

- [Reference: Command Line Shell For SQLite](https://sqlite.org/cli.html)
  The official guide to the `sqlite3` shell, including importing CSV files and the dot-commands. Use for: any claim about `.import`, `.mode`, `.headers`, `.schema` or `.read`.
- [Reference: SELECT, SQLite SQL language documentation](https://sqlite.org/lang_select.html)
  The authoritative description of `SELECT`, `WHERE`, `GROUP BY` and `ORDER BY`. Use for: what each clause does and the order they run in.
- [Reference: Datatypes In SQLite](https://sqlite.org/datatype3.html)
  Explains storage classes and how text and numbers compare and sort. Use for: how text and numbers compare and sort.

## Wisdom (Communities)

- The learner has opted out of joining a community for this course. Do not propose one.
