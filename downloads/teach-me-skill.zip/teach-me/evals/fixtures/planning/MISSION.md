# Mission: Querying CSV exports with SQLite

## Why
Every month I get a CSV export of orders, a few thousand rows, and I answer the same questions about it by filtering and summing in a spreadsheet. It takes an hour and I make mistakes. I want to answer each question with a query I can save and run again on next month's file.

## Success looks like
- Load a CSV file into a database from the command line and confirm the rows arrived.
- Answer a "which rows" question with one query.
- Produce a total per customer, largest first.
- Save a query in a file and rerun it on a new export.

## Subject map
- **Facts**: the `sqlite3` shell and its dot-commands `.import`, `.mode`, `.headers`, `.schema`, `.read`; the SQL keywords `SELECT`, `FROM`, `WHERE`, `ORDER BY`, `GROUP BY`, and the functions `COUNT` and `SUM`.
- **Concepts**: a table has rows and named columns; a query is a question that can be rerun; grouping collapses the rows that share a value into one output row.
- **Procedures**: import a CSV; inspect what arrived; filter rows; total by group; sort the totals; save and rerun a query.

## Audience
- **Shareable**: the course should work for anyone given the course folder. It creates its own examples and names nothing private.

## Constraints
- Two lessons, about 15 minutes each.
- I am comfortable in a terminal. I have never written SQL.

## Out of scope
- Joins across several tables.
- Other databases, and database design.
