# Hands-On Practice

How to write the parts of a lesson where the learner runs or does something, and how to prove they work. Read this in step 5 for any lesson with a checkpoint, and again for the first check in step 7.

## Contents

- [Where practice happens](#where-practice-happens)
- [Write plain commands](#write-plain-commands)
- [Show the file before you query it](#show-the-file-before-you-query-it)
- [Show what the reader should see](#show-what-the-reader-should-see)
- [Verify by running](#verify-by-running)
- [Subjects with nothing to run](#subjects-with-nothing-to-run)

## Where practice happens

Read the Audience section of `./MISSION.md` first.

**Shareable (the default).** The course must work for anyone who has the course folder and the stated prerequisites.

- Practice happens in `./practice/`, inside the workspace. The course does not ship that folder: the first checkpoint has the reader create it, so a fresh copy of the course starts clean. The lessons put everything in it: a step has the reader make the file or project, or copy it from a `./practice-starter/` folder the course ships.
- The checkpoint's first step tells the reader to open a terminal in `./practice/`. Every later path is relative to it. Do not write home-directory paths (`~/src/…`, `/Users/name/…`): the reader's files are somewhere else.
- Do not rely on the user's own repositories, projects, locally defined tools, accounts or pinned versions. If the topic needs something to operate on, the course builds a small one.
- State prerequisites on the course home: what to install, the version the course was verified with, how to check it, and anything that needs an account or costs money.
- Where a value differs for each reader (an account's available models, a device name, an API region), do not print yours as if it were universal. Show the command that lists the reader's own values, then say "pick one; this course used `<the one you ran>`".

**Just me.** The course may use the user's real project, paths and accounts, since that is what they asked for. Record the locations it depends on in `./NOTES.md`, and still follow every other rule in this file.

A small example the course creates is not a toy if it shows the real behaviour. Tie it to the mission through the kind of problem it poses, not through the user's private files.

## Write plain commands

The reader is learning the topic, not the shell. Every command in a checkpoint or a workflow guide is one a careful published guide would print:

- **One idea per command.** One command per code block, or a few closely related commands each on its own line. Do not join commands with `&&` or `;`.
- **Literal paths and values.** No shell variables (`RUN=…`, `$RUN`), no command substitution (`$(…)` or backticks). If a path is only known at run time, such as a timestamped results folder, have the reader list the folder, then give the next command with a clearly marked stand-in and say what to replace it with.
- **No pipelines**, unless the pipe is the thing being taught. If one pipe really is the simplest honest way, say what each side does. Never chain three or more.
- **Short paths.** Change into the practice folder once at the start, so later commands do not carry long paths that wrap or scroll.
- **Short lines.** A code block holds 62 characters at full width and 52 inside a checkpoint step, which is indented. Break a long command with a trailing backslash at a natural point, one option per line.
- **A goal before every command**: one line saying what the step finds out or does, in the `.goal` line of the template. Say so plainly when a step installs something, writes outside `./practice/`, or costs money.
- **Say where each command is typed.** When the lesson uses a program with its own prompt (a database shell, a language's interactive prompt, a debugger), the reader has two places to type and will mix them up. Mark every command block in that lesson with `data-where`: `<pre data-where="terminal">` or `<pre data-where="sqlite3">`, using the program's name. The page shows it as a label on the block. Say in a step when the reader enters the program and when they leave it.

Instead of this:

```
RUN=$(ls -d results/lesson-2/*/ | tail -n 1)
jq 'select(.type == "trial-result") | .trajectory.metrics' "$RUN/results.jsonl"
```

write this, as two steps with a goal each:

```
ls results/lesson-2
```

"You should see one folder named with the time of your run, such as `2026-11-09T14-02-11`. Use your folder's name in place of that one below."

```
less results/lesson-2/2026-11-09T14-02-11/results.jsonl
```

`scripts/check-lessons.js` fails a checkpoint command that uses a variable, a substitution, chaining or a long pipeline. For the rare lesson where shell syntax itself is the subject, mark the block `<pre data-shell="taught">`.

## Show the file before you query it

When a lesson needs a fact that lives in a file (a config, a log, a results file), the reader has to know what the file looks like before a filter over it means anything.

1. **Show the file.** Print an excerpt of the real file, from your own run, in a `.file-excerpt` block with its path. Mark every place you left lines out with a gap marker that says how many, so the reader never mistakes an excerpt for the whole file. **Never hide a single line.** A gap marker takes a line itself, so it saves nothing, and an excerpt broken up by "1 line hidden" markers is harder to read than the file. Hide a run of three or more lines, or a line that is too wide for the page or names something private, and say in the marker what was left out. Show one or two skipped lines as they are.
2. **Annotate it.** Number the lines that matter and explain each in the notes under the code: what the line is and why it matters here.
3. **Have the reader look.** The checkpoint step opens or prints the file and tells the reader which line to find.
4. **Only then, optionally, offer a query**, after the reader has found the fact by eye, labelled as a scripting shortcut: "Once you know the shape, this one line prints the same field." Explain each part of it. A lesson never depends on the reader understanding the query.

## Show what the reader should see

After each command, say what a successful run prints, in an `.expect` line or an output block (`<pre class="output">`), copied from your real run and trimmed to the lines that matter. Where output varies between runs or machines (times, identifiers, counts), say which parts will differ. Call your own run "our run" and its output "ours" ("Those above are ours; yours will differ"), never "the author's run". If a step can fail in a way you met while running it, say what that looks like and what to do.

## Verify by running

Nothing in a hands-on step is written from memory. Commands, flags, file contents, code and expected output all come from running them. What you remember of a tool is often a version behind, and a lesson that fails at step 2 loses the reader's trust in everything after it.

**While writing (step 5):** run each step as you write it and paste the real output into the lesson.

**Before the course is shown (step 7):** run the whole course again from a clean start, because steps that worked one at a time can fail in sequence.

1. Make a scratch copy of the course's starting state: an empty practice folder, or a copy of `./practice-starter/`, outside the workspace. For a "just me" course that uses the user's project, work on a copy or a separate branch, never on their working files.
2. Go through every lesson's checkpoint in order, typing exactly what the page says, in the place the page says. Then go through the workflow guide once from start to finish, putting real values where it has stand-ins.
3. Compare what happens with what the lesson says will happen. Fix the lesson when they differ. Do not adjust your run to make it pass.
4. Check every code sample and config file that is shown but not run in a checkpoint: run it, parse it, or lint it with the tool it is for.
5. Settle every "check this yourself" note. If one run would answer it, run it and state the answer. Keep such a note only where the answer truly depends on the reader's own setup, and then say what it depends on.
6. Record in `./NOTES.md` under `## Verification`: the date, the tool versions, which lessons were run end to end, and what was not run and why.

**What you may not be able to run**, and what to do:

| Situation | Do this |
|---|---|
| The step costs money, uses paid API calls, or consumes a quota | Tell the user what it would spend and ask before running |
| The step needs the user's credentials or account | Ask the user to run it and paste the output, or to authorise you to |
| The step changes something outside the workspace (a global install, a system setting) | Ask first. Prefer a local or isolated install for your own run |
| The tool is not installed and cannot be | Say so. Mark the step in the lesson as one we could not run, and list it for the user |
| The step needs hardware, another person, or the physical world | See the next section |

Anything left unverified is stated in two places: in the lesson at that step, and in your message to the user when the course is ready. Do not present an unrun step as verified.

## Subjects with nothing to run

For a subject practised away from the computer (a language, an instrument, a sport, a craft), there is no command to run, and the same standard applies in another form:

- Every instruction comes from a cited source in `RESOURCES.md`, not from memory.
- Every checkpoint says what the learner should observe that tells them they did it right, and what the common mistake looks like.
- Where safety is involved, state the source's safety guidance with the step.
- In `./NOTES.md` under `## Verification`, record that the steps were checked against their sources rather than run.
