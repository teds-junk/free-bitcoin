# Step 6: Reference Sheets, the Workflow Guide and the Course Home

Lessons are worked through once. Reference sheets are what the learner comes back to. This file covers the three kinds of durable page a course produces.

## Contents

- [Reference sheets](#reference-sheets)
- [The workflow guide](#the-workflow-guide)
- [The course home](#the-course-home)

## Reference sheets

A reference sheet is the compressed form of what several lessons taught, laid out for looking things up: syntax and snippets, a catalogue of options, a decision table, a set of poses or drills, a checklist. Write them into `./reference/` as HTML, using the same stylesheet and page chrome as the lessons, and make them print cleanly.

- Plan them in `COURSE-PLAN.md` under "Reference sheets", and write them once the lessons exist, so they compress what was actually taught.
- A sheet holds facts and procedures, not explanation. Each entry links to the lesson section that explains it, by the section's `id`.
- Use the plan's vocabulary. Every command and snippet on a sheet meets the rules in `HANDS-ON-PRACTICE.md` and has been run.
- Detail that was cut from a lesson because the lesson did not need it belongs here.
- List every sheet in `./assets/course.js` so it appears in each page's course map, and link to it from the lessons that feed it.

## The workflow guide

Write `./reference/workflow-guide.html` whenever the course teaches a procedure the learner will repeat: writing an eval, shipping a release, setting up a practice session, diagnosing a fault. It is the page that lets them come back two months later, having forgotten most of the lessons, and do the task again correctly. Skip it only when the course is purely conceptual, and say so in the plan.

Start from `./assets/workflow-guide-template.html`.

**What it contains**

- **A router at the top**, "Where are you?", because a returning reader is rarely at the beginning. Each situation links to the step to start from.
- **Stages**, lettered A, B, C, each a phase of the task.
- **Steps** inside each stage, labelled A1, A2, with sub-steps A2a where needed. Each step is one action, written as an instruction, with:
  - the exact command or the thing to produce, where there is one;
  - **Done when**: what the reader can observe that tells them the step worked;
  - **GOTOs** for the conditions that change the path: "If the check fails, GOTO B2." "If you already have one, GOTO A4.";
  - a link to the lesson that taught it, for when the step alone is not enough.

**Rules**

- **It applies everything the course taught.** Go through the plan's lessons one by one: each lesson's win must appear as at least one step. A win that appears nowhere means the guide skips something the course thought mattered.
- **It stands alone.** Write each step for someone who has forgotten the lessons: the action and the check are on the page, and the lesson link is the back-up, not the instruction.
- **Decisions are explicit.** Wherever the right action depends on the situation, write the condition and where each answer leads. Judgement the lessons taught ("prefer the cheapest check that cannot be fooled") appears as a decision step with its options, not as a reminder to use judgement.
- **Labels are identifiers.** They are written by hand, and each step's `id` equals its label, because GOTOs link to them. Every GOTO is a link to a label that exists; `scripts/check-lessons.js` fails a GOTO that points nowhere.
- **Loops are fine.** A real workflow revisits earlier steps. Say when to stop: "If it still fails after two attempts, GOTO D1."
- **Commands are verified and plain**, as in `HANDS-ON-PRACTICE.md`. Where a value differs each time (this month's file name), use a clearly marked stand-in and say what replaces it. Verify the guide by running it once from start to finish with real values in place of the stand-ins. Put the date and tool versions it was verified with in the header.
- **Keep it to what fits in the hand.** Two or three printed pages. Detail belongs on the other reference sheets, linked from the step that needs it.

A short example of the form, for a course on answering questions about a CSV export with a database:

```
A  Load the file
   A1  Is this export's database already there from last time?
       If yes, GOTO A3. If no, continue to A2.
   A2  Import the CSV into a new database.
       Done when: the row count matches the file's line count, less
       the header.
   A3  Look at the column names before writing any query.
       Done when: you can name the column your question is about.
B  Ask the question
   B1  Is the question "which rows" or "how much per group"?
       If "which rows", continue to B2. If "per group", GOTO B3.
   B2  Write a query with a condition. Then GOTO C1.
   B3  Write a query that groups and totals.
       Done when: there is one output row per group.
       If the order looks wrong (9 after 10), GOTO B4.
   B4  Sort by the value as a number, not as text. Then GOTO C1.
C  Keep it
   C1  Save the query in a file and run it from the file.
       Done when: running the file prints the same answer.
```

Link the workflow guide from the course home and from the last lesson's footer.

## The course home

Write `./index.html` from `./assets/course-home-template.html`. It is the page a learner opens first, and the page someone the course is shared with sees without any other context.

- **The story**: the plan's starting problem and destination, in two or three sentences.
- **Before you start**: what to install, with the versions the course was verified against and how to check them; where practice happens; anything that needs an account or costs money. For a shareable course this must be enough for a stranger to begin.
- **How to use this course**: keep the template's list, adjusted to the course.
- **The course map**: rendered from `./assets/course.js`, showing each lesson and what it lets the learner do.
- **The video slot**: copy it unchanged. It appears when `COURSE.video` in `course.js` names a file that exists.

Do not put anything on the course home that is true only of the user's machine, unless the mission says the course is just for them.
