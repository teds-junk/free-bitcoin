# Step 5: Write the Lessons

How to write a lesson from its entry in `COURSE-PLAN.md`. The plan decides what each lesson and section is for. This file is about making the page deliver it, so that a reader always knows what they are being told and why.

## Contents

- [The shape of a lesson](#the-shape-of-a-lesson)
- [Write each section in its mode](#write-each-section-in-its-mode)
- [Every statement earns its place](#every-statement-earns-its-place)
- [Explain enough](#explain-enough)
- [Terms](#terms)
- [Voice](#voice)
- [Titles and headings](#titles-and-headings)
- [Figures and images](#figures-and-images)
- [Recall and quizzes](#recall-and-quizzes)
- [Sources](#sources)
- [The footer](#the-footer)
- [The cold read](#the-cold-read)

## The shape of a lesson

Start every lesson from `./assets/lesson-template.html` and keep its parts in this order. Each part has a job in the journey:

| Part | Job | Comes from |
|---|---|---|
| Header | Says where the reader is ("Lesson 3 of 8") and what they will be able to do | The plan's title and Win |
| Video slot | Shows the lesson's video once one exists. Copy it unchanged | The template |
| Warm-up | Two questions answered from memory, so earlier material is retrieved before it is built on. Lessons 2 onward | The plan's Recalls |
| Lesson question | "So far" (what the reader can already do) and "This lesson answers" (the one question) | The previous Win, and the plan's Question |
| Opening paragraph | The problem that makes the question worth answering, tied to the mission | The Story and the mission |
| Sections | Each answers one part of the question, in one mode | The plan's Sections |
| Checkpoint | The reader does the thing, inside a "use" section | The plan, and `HANDS-ON-PRACTICE.md` |
| Primary source | The one thing to read or watch for this lesson | `RESOURCES.md` |
| Exercises | Recall and application, with answers to check against | The Win |
| Course map | Where this lesson sits, and what each lesson lets you do | `assets/course.js` |
| Footer | What the reader can do now, and why the next lesson follows | The plan's Win and Hand-off |

Keep the lesson inside the time the plan gives it. Estimate it as the words of prose outside code blocks, exercises and the footer, at about 130 words a minute, plus about one minute per checkpoint step. If a lesson runs over, do not cut explanation the checkpoint depends on: the plan gave the lesson too much. Split it in the plan, and tell the user.

Write lessons in order. Later lessons rely on the vocabulary, the running example and the files that earlier ones leave behind.

## Write each section in its mode

Each `<h2>` in the body carries the mode the plan gave it: `data-mode="think"`, `"works"` or `"use"`. The stylesheet shows it as a label above the heading. Then keep the section inside its mode:

- In a **think** section, write about purpose, choice and judgement. If you find yourself listing fields or flags, that belongs in a "works" section or on a reference sheet.
- In a **works** section, describe the mechanism: what the parts are, what goes in, what comes out, what the file looks like. If you find yourself writing "you should" or giving steps, that belongs in "think" or "use".
- In a **use** section, give the reader things to do and what they should see. If you find yourself introducing a concept or explaining an internal, it should have come earlier: move it up, into a section of the right mode, and update the plan.

A sentence of connection is fine ("You saw why this matters; here is what the file contains"). A paragraph in another mode is a sign the section should be split.

## Every statement earns its place

For each paragraph, be able to say what it does for the lesson's question, in one of these ways:

- It tells the reader something they need for a later section or the checkpoint.
- It answers a question the previous paragraph raised.
- It corrects a mistake the reader would otherwise make.

If you cannot say which, cut it. If it is true and useful but not needed here, move it to a reference sheet or a "Go deeper" aside at the end of the section. Interesting detail that serves no later step is what makes a lesson feel disjoint: the reader keeps it in mind waiting for it to matter, and it never does.

Put each explanation where it is needed. Explain a thing just before the reader uses it, not three sections earlier, and do not explain it twice.

## Explain enough

The test for every checkpoint: **before running each command, could the reader say what it does and why they are running it?** If not, the lesson has hand-waved something.

Before a checkpoint, the lesson has explained, for every tool, command, flag, file and concept the checkpoint uses:

- What it is, in words the reader already has.
- What problem it solves here.
- For a command: what goes in, what comes out, and what it changes.
- For a file: what it contains, shown as an excerpt (see `HANDS-ON-PRACTICE.md`).

Then check the explanations themselves. An explanation that relies on another unexplained term has explained nothing. "The golden patch is the reference solution as a patch" fails for a reader who has never made a patch. Either explain the inner term first, or say it plainly: "a file that records the exact changes a correct answer would make".

Do not skip an explanation because the thing is obvious to you, or because the documentation covers it. The reader is here because it is not obvious to them. If explaining it properly would take the lesson past its length, the lesson is doing too much: take the tool out of this lesson's checkpoint, or give it its own lesson in the plan.

## Terms

Use the words in the plan's concept order table, and no synonyms. A reader who meets "test case", "stimulus" and "prompt" in three paragraphs assumes three different things.

- **First use**: define the term where the plan says it is introduced, in a definition box or a plain sentence, before relying on it.
- **Terms from a source**: use the source's word, and cite the source.
- **Coined terms**: use only those the plan marks `coined (agreed)`. At first use, say so in the sentence: "This course calls this the two-way check. That is our name for it, not a standard term, so searching for it will find nothing."
- **A new name mid-lesson**: stop and ask the user, as `COURSE-PLANNING.md` describes. Until they answer, write the plain description.

## Voice

Write the way a person teaching would write: "we" for the course and whoever made it, "you" for the reader.

- The course's own runs and results are **ours**: "In our run, one model passed and one did not." "Yours will differ from ours." "Show our tally." "From our run on 2026-11-10."
- Never write "the author", "the author's run" or "the writer". Nobody talks like that, and it puts a stranger between the reader and the page.
- Use "we" for what the course did or found ("When we first wrote this pattern, it was wrong"), not for what the reader is about to do. Instructions address the reader: "Run the command", "You should see".

## Titles and headings

- Write titles and headings in plain text. Do not italicise or otherwise emphasise a word in a heading as decoration. When every heading has an emphasised word, the emphasis carries no meaning.
- Use `<em>` in a heading only when that word is being defined or is being contrasted with another word in the same heading. This will be rare.
- A lesson title says what the lesson is about in the reader's words. A section heading says what the section tells them.
- Give each section heading a short `id`, so reference sheets and the workflow guide can link straight to it.
- Never write section, figure, definition, example or exercise numbers by hand. The stylesheet adds them.

## Figures and images

Include a figure wherever it shows something prose cannot: a process with steps, a hierarchy, a before and after, a spatial relationship. Most lessons are better with at least one. Do not add a figure that only decorates.

- **Generated** (preferred when the idea can be drawn): inline SVG or a Mermaid diagram. Draw SVG with `currentColor` or the CSS tokens, never a hard-coded colour, so it survives both themes.
- **From the web** (photos, complex illustrations): download the file to `./assets/images/` with a descriptive name (`tcp-handshake-diagram.png`) and reference it by relative path. Do not link to the remote URL: the lesson must work offline and must not break when the URL changes.
- Every figure is a `<figure>` with a `<figcaption>` saying what it shows and why it matters. Every `<img>` has alt text.

## Recall and quizzes

After presenting something, have the reader retrieve it: a quiz, a prediction, a sorter, or an explain-from-memory exercise. Retrieval is what makes it stick, and it applies to facts and concepts as much as to skills.

- Give every exercise an answer the reader can check, in a collapsed "Show answer".
- In a multiple-choice quiz, make every option the same length in words, and close in characters, with the same formatting. A longer or more qualified option gives the answer away.
- Ask about what the lesson taught, in a form that needs understanding rather than recognition of a phrase.
- Feedback is immediate and says why, not only whether. A quiz locks after one click, so the feedback for a wrong answer explains which answer is right and why. Do not write it as a hint to try again.

## Sources

- Build the content from `RESOURCES.md`. Cite the source for any claim a reader might doubt, with a link, using the source citation block.
- Recommend one primary source per lesson: the best thing to read or watch for that lesson, and which part of it.
- When sources disagree, or evidence is thin or recent, say so in the lesson.

## The footer

Every lesson ends with the What's Next footer from the template:

1. **What you can do now**: the plan's Win, in one sentence.
2. **Up next**: a link to the next lesson's file and the plan's Hand-off, so the reader sees why it follows. On the last lesson, say the course is complete and link the workflow guide or the course home.
3. **How to continue**: the line the user gives their agent, `/teach-me Continue my lessons on {topic}`. On the last lesson it is `/teach-me Review my lessons on {topic}`.
4. A reminder that they can ask the agent about anything in the lesson, or ask for a review session.

Keep the tone plain and encouraging, matching the rest of the lesson.

## The cold read

Part of step 7. You wrote the lessons knowing the whole course, so you cannot see what a newcomer cannot follow. A reader with no context can.

If you can start a separate agent with a fresh context, give it only the lesson files, in order, and this task. If you cannot, do the task yourself in a separate pass, reading each lesson from the top and using nothing you know from outside the page; tell the user this is the weaker check.

> You are a learner taking this course, starting with no knowledge of the topic beyond: {the starting point from MISSION.md}. Read the lessons in order. For each lesson, report:
>
> (For item 3: "how to think about it" means what a thing is for and when to reach for it. "How it works" means what it is and what happens inside, including what a command or a piece of syntax does. "How to use it" means steps for you to carry out.)
>
> 1. For each command in the hands-on checkpoint: what it does, why you are running it, and where you type it, using only what the lessons so far have told you. List every command where you cannot say.
> 2. Every term, tool, file, flag or abbreviation that was used before it was explained, or never explained.
> 3. For each section: is it telling you how to think about something, how it works, or how to use it? List any section that mixes these, and any place you could not tell.
> 4. Any paragraph where you could not say why it was there.
> 5. In one sentence, what you can do after this lesson that you could not do before.
>
> Do not fill gaps from your own knowledge. If the lesson did not say it, report it as missing.

Then act on the report:

- Items 1 and 2: add the missing explanation before the first use, in a section of the right mode, and correct the plan's concept order table.
- Item 3: split or rewrite the section so it has one mode.
- Item 4: cut the paragraph, or connect it to the question.
- Item 5: compare with the plan's Win. If they differ, the lesson is not delivering its win: fix the lesson, not the plan.

Run the cold read again, with a fresh reader, on any lesson whose explanations you rewrote. Small wording fixes do not need another read.
