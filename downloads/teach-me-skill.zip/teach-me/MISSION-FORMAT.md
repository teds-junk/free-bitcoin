# MISSION.md Format

`MISSION.md` lives at the workspace root. It captures the _reason_ the user is learning this topic. Every teaching decision — what to teach next, which resources to surface, which exercises to design — should trace back to this document.

## Template

```md
# Mission: {Topic}

## Why
{1-3 sentences. The concrete real-world goal the user is chasing. What changes in their life or work when they have this skill? Avoid abstract framings like "to understand X" — push for the underlying outcome.}

## Success looks like
- {A specific, observable thing the user will be able to do}
- {Another specific thing}
- {…}

## Subject map
{A decomposition of the topic into its key components — facts to memorize, concepts to understand, and procedures to practice. Research how experts and successful learners typically acquire this skill. This map gives the agent a backbone for sequencing lessons and reveals gaps in coverage. Draft early, revise as understanding deepens.}

- **Facts**: {key terms, definitions, reference data}
- **Concepts**: {principles, mental models, relationships}
- **Procedures**: {skills, techniques, workflows to practice}

## Audience
{Keep exactly one of these two lines and delete the other:}
- **Shareable**: the course should work for anyone given the course folder. It creates its own examples and names nothing private.
- **Just me**: the course may use my own projects, files, paths and accounts: {which ones}.

## Constraints
- {Time, budget, prior commitments, learning preferences, anything that bounds the approach}

## Out of scope
- {Adjacent topics the user explicitly does not want to chase right now — protects the zone of proximal development}
```

## Rules

- **One mission per workspace.** If the user wants to learn two unrelated things, that is two workspaces.
- **Concrete over abstract.** "Run a half marathon by October" beats "get fitter." "Ship a Rust CLI to my team" beats "learn Rust."
- **Push back on vagueness.** If the user cannot articulate why, interview them before writing anything. A bad mission is worse than no mission.
- **Revise when reality shifts.** Missions change. When the user's goal moves, update this file — don't leave a stale mission steering future sessions.
- **Ask who the course is for.** Put the question plainly while setting the mission: "Is this course just for you, or should it work for someone you share it with?" A course built on the user's private repositories, local paths or account-specific names cannot be shared afterwards without rewriting its exercises. If the user does not answer, write **Shareable**: it is the choice that can be relaxed later. When the user asks for practice on their own real project, that is **Just me**; say that this makes the course specific to their machine, and record which projects it uses.
- **The mission is personal either way.** A shareable course is still aimed at this user's goal. What changes is where the exercises run, not why the course exists.
- **Keep it short.** If `MISSION.md` runs past a screen, it has stopped being a compass and started being a plan.