# Lesson Style Guide

The visual identity for every page a course produces: lessons, reference sheets, the workflow guide and the course home. The aesthetic is a **math-notebook textbook**: a white sheet on graph paper, deep navy ink, one royal-blue accent, serif prose, uppercase letterspaced labels, numbered sections and figures, and dark navy code blocks. Academic, precise and quietly playful.

The stylesheet, page script and page templates are files in `./assets/`, copied from this skill in step 4. Use them as they are. Do not retype the stylesheet, restyle a page inline, or build a page without a template.

## Contents

- [The files](#the-files)
- [Colour and the two themes](#colour-and-the-two-themes)
- [Typography](#typography)
- [Numbering](#numbering)
- [Components](#components)
- [Fitting the page](#fitting-the-page)
- [The video slot](#the-video-slot)
- [Adding a component](#adding-a-component)
- [Print](#print)

## The files

| File in `./assets/` | Use |
|---|---|
| `styles.css` | Every page links it: `../assets/styles.css` from lessons and reference sheets, `assets/styles.css` from the course home |
| `lesson.js` | Every page loads it at the end of `<body>`, after `course.js`. Theme toggle, quizzes, sorters, course map, video slot, syntax highlighting |
| `course.js` | The list of lessons and reference sheets. Filled in from the plan |
| `lesson-template.html` | The starting point for each lesson. Keep its parts and their order |
| `course-home-template.html` | The starting point for `index.html` |
| `workflow-guide-template.html` | The starting point for the workflow guide, and the page chrome for other reference sheets |

Replace every `{{PLACEHOLDER}}` in a template. Delete blocks a page does not need. A finished page contains no `{{`.

## Colour and the two themes

Every colour is a CSS token defined in `styles.css`, with a light and a dark value. A dark mode toggle is fixed in the upper-left corner of every page; the choice is stored under `teach-me-theme` and applies to the whole course.

| Token | Role |
|---|---|
| `--ground` | The page and the sheet |
| `--grid`, `--grid-strong` | Graph-paper lines; borders and stronger rules |
| `--ink`, `--ink-soft` | Body text and headings; captions and secondary text |
| `--accent` | Links, labels, numbering, rules |
| `--accent-solid` | A filled accent surface that keeps white text legible in both themes |
| `--paper-edge` | Fills for boxes, figures and table stripes |
| `--code-bg`, `--code-ink`, `--code-hint` | Code blocks, dark in both themes |
| `--code-kw`, `--code-str`, `--code-num`, `--code-key`, `--code-fn`, `--code-var`, `--code-add`, `--code-del` | Syntax colours on the dark code card |
| `--green`, `--red` and their `-bg` and `-ink` forms | Quiz feedback only |

Rules:

- **Never hard-code a colour in page content**, including inline SVG. A diagram drawn with a fixed dark stroke disappears in dark mode. Draw with `currentColor`, `var(--accent)` or `var(--ink-soft)`.
- **Surfaces that hold light text stay dark in both themes.** Fill them with `--code-bg` or `--accent-solid`, never with `--ink` or `--accent`, which lighten in dark mode.
- For Mermaid diagrams, keep the template's theme selection (`neutral` in light, `dark` in dark).

## Typography

- **Prose and headings**: Spectral, a serif, with Georgia as the offline fallback. Headings are light (300 to 500) and upright. Hierarchy comes from size, not weight or slant.
- **Labels** (the lesson eyebrow, section numbers and modes, box labels, figure labels): Space Grotesk, small, uppercase, widely letterspaced. This label voice is the signature of the look.
- **Code**: JetBrains Mono.
- **Emphasis**: `<em>` is italic in the accent colour inside a heading, and plain italic in prose. Because headings are upright, emphasis in a heading is visible, so use it only where it means something: a word being defined, or contrasted with another. Do not emphasise a word in a title as decoration.

## Numbering

The stylesheet numbers things with CSS counters. Never write these numbers in the content, or they appear twice:

- **Sections**: each top-level `<h2>` gets `01`, `02`, … With `data-mode`, the label reads `01 · HOW IT WORKS` on its own line above the heading.
- **Figures**: each `<figcaption>` is prefixed `FIG. N`.
- **Definitions and examples**: `.callout.definition` and `.callout.example` are labelled `DEFINITION N` and `EXAMPLE N` before the `.callout-title`.
- **Exercises**: items in `.exercises` are labelled `EX. N`.
- **Sidenotes** and **checkpoint steps** number themselves.

Workflow guide labels (A, A1, A2a) are the exception: they are identifiers that GOTOs point at, so they are written by hand.

## Components

Each component's markup is shown in `lesson-template.html` or in a comment above its rules in `styles.css`.

| Component | Class | Use it for |
|---|---|---|
| Chapter opening | `.lesson-header`, `.lesson-number`, `.lesson-meta` | Eyebrow, title, time and win |
| Lesson question | `.lesson-question` | "So far" and "This lesson answers" |
| Section mode | `h2[data-mode]` | `think`, `works` or `use`, from the plan |
| Drop cap | `p.drop-cap` | The opening paragraph only |
| Warm-up | `.warmup` | Two recall questions from earlier lessons |
| Answer reveal | `details.answer` | Any answer the reader should attempt first |
| Definition, example, key idea | `.callout.definition`, `.callout.example`, `.callout`, `.callout.tip`, `.callout.warning` | Boxed apparatus |
| Predict first | `.predict` | A prediction before the reader sees the result |
| Checkpoint | `section.checkpoint`, `ol.steps`, `.goal`, `.expect` | Hands-on steps, each with a goal and what to expect |
| File excerpt | `.file-excerpt`, `.file-name`, `pre .gap` | A real file, with omitted lines marked |
| Annotated code | `.annotated`, `pre .mark`, `ol.notes` | Code with numbered notes |
| Output | `pre.output` | What a command printed |
| Where to type | `pre[data-where]` | Labels a command block with where it is typed, in lessons that use a program with its own prompt |
| Code highlights | `pre .hl`, `pre .bad`, `pre .cm` | A line to notice, a wrong line, a comment |
| Code language | `code.language-yaml`, `-bash`, `-json`, `-javascript`, `-diff` | Syntax colour on a block the reader types or a file's contents. `lesson.js` loads highlight.js from cdnjs and keeps the spans above. Leave `pre.output`, file trees and prose unclassed. Offline, the code shows plain |
| Quiz | `.quiz` | Multiple choice with immediate feedback. One click locks it, so the wrong-answer feedback explains the right answer |
| Sorter | `.sorter`, `.sort-item` | Classifying items into categories |
| Figure | `figure`, `figcaption` | Images, SVG and Mermaid diagrams |
| Sidenote | `.sidenote-ref`, `.sidenote` | An aside that would interrupt the main thread. Leave the `.sidenote-ref` span empty: the mark and the note number themselves |
| Primary source | `.primary-source` | The one source to read for the lesson |
| Citation | `.source-citation` | The source for a claim |
| Exercises | `section.exercises` | End-of-lesson recall and application |
| Video slot | `.lesson-video` | The lesson or course video |
| Course map | `nav.course-map` | Rendered from `course.js` |
| Footer | `footer.next-steps`, `.continue-prompt` | What's Next |
| Workflow guide | `ol.workflow`, `.wf-label`, `.wf-done`, `.wf-goto`, `.wf-src` | The nested, labelled procedure |
| Reference density | `.ref-grid`, `.ref-card`, `.table-wrap` | Compact reference sheets, wide tables |

## Fitting the page

The sheet is 760 pixels wide, with about 596 pixels of text. Content wider than that scrolls sideways inside its box, and a reader who has to scroll code sideways while reading notes about it loses both.

- **Code lines are at most 62 characters, and 52 inside a checkpoint or workflow step.** That is what a code block holds at full width and when indented inside a step. Break long commands with a trailing backslash; shorten paths by working from the practice folder; wrap long YAML and JSON strings where the format allows. If a block of output is too wide for a step, show it at full width just before or after the checkpoint.
- **Annotated code is stacked.** `.annotated` puts the code at full width and its numbered notes directly after it. This is the default because code beside notes leaves each about 30 characters.
- **Side by side only when it fits.** Add `class="annotated side"` only when every code line is 28 characters or fewer. If in doubt, stack.
- **Long files are split.** For more than about 25 lines, show consecutive excerpts, each followed by its own notes, so an explanation is never a screen away from its line.
- **A gap marker hides three lines or more.** `<span class="gap">` takes a line of its own, so hiding one line saves no space and several one-line gaps make an excerpt harder to read than the file. Show one or two skipped lines as they are. The exception is a line too wide for the page or one that names something private: hide it, and say in the marker what it was.
- **Wide tables** go inside `<div class="table-wrap">`. Prefer fewer columns: move detail into the text or a second table.
- **Figures** scale to the sheet. Give SVG a `viewBox` and no fixed pixel width. Text inside a diagram must render at 9 pixels or more at phone width: a diagram drawn 600 units wide is shown at about half size on a phone, so its text needs a font size of 18 or more. Prefer fewer, larger elements.

**The layout check.** In step 7, run `node <skill-dir>/scripts/check-layout.js . --screenshots <a scratch directory>`, where `<skill-dir>` is the directory containing SKILL.md. It opens every page at desktop and phone width and reports:

- `page`: the whole page scrolls sideways.
- `scroll`: a code block, figure or diagram scrolls sideways at desktop width.
- `sticks`: something reaches past the right edge of the sheet.
- `small`: text inside an SVG figure renders smaller than 9 pixels.

Fix each finding and run it again until it exits 0. Then look at the screenshots, in light and dark: a page can fit and still read badly. Check that annotated notes sit next to their code, that no diagram has vanished in dark mode, and that nothing looks cramped. If the script reports that no browser is installed, do the manual check it prints.

## The video slot

`lesson-template.html` and `course-home-template.html` each contain a `.lesson-video` block marked `hidden`. Copy it unchanged into every page. `lesson.js` looks for the file and shows the slot, with the video's length, only when it loads:

- A lesson page looks for `./videos/<lesson-file-stem>/<lesson-file-stem>.mp4`, with `poster.png` beside it if present.
- The course home uses the `video` path in `./assets/course.js`.
- `data-src` on the slot overrides either.

So adding a video is a matter of putting the file in place. No page is edited, and a page without a video shows nothing.

## Adding a component

When a lesson needs something the stylesheet lacks and a second lesson could reuse it (a simulator, a calculator, a new kind of drill), write it as its own file in `./assets/` and link it from the pages that use it. Use the tokens, follow the label voice, and check it in both themes. Do not paste the same block of script or style into several lessons.

## Print

Pages print as ink on white whatever theme is active: the grid, sheet chrome, toggle, course map and video are dropped, code prints light, link URLs are shown, and figures, boxes and workflow steps avoid page breaks. Reference sheets and the workflow guide are meant to be printed, so check them in print preview when they are dense.
