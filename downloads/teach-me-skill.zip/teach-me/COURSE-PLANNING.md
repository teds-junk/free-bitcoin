# Step 3: Plan the Course

How to turn a mission and a set of sources into `COURSE-PLAN.md`: the document every lesson is written from. A course feels like a journey when the plan is one, and feels disjoint when lessons are written from a list of titles. Plan first, in this order.

## Contents

- [What the plan must settle](#what-the-plan-must-settle)
- [1. The story](#1-the-story)
- [2. The lessons: question, win, hand-off](#2-the-lessons-question-win-hand-off)
- [3. The sections: one mode each](#3-the-sections-one-mode-each)
- [4. Concept order](#4-concept-order)
- [5. Vocabulary and coined terms](#5-vocabulary-and-coined-terms)
- [6. Recall, spacing and practice across the sequence](#6-recall-spacing-and-practice-across-the-sequence)
- [7. Check the plan](#7-check-the-plan)
- [8. Agree it with the user](#8-agree-it-with-the-user)
- [COURSE-PLAN.md template](#course-planmd-template)
- [Keeping the plan true](#keeping-the-plan-true)

## What the plan must settle

Before any lesson is written, the plan answers:

- Where does the learner start, and where do they end up?
- What one question does each lesson answer, and why is that the next question?
- In each section, is the reader being told how to think about something, how it works, or how to use it?
- Where is each term, tool and file first explained, and is that before its first use?
- Which names are the field's and which are yours?

## 1. The story

Write two sentences from the mission:

- **Starting problem**: what the learner cannot do today, in their terms. Not "does not know X" but "has to do Y by hand" or "cannot tell whether Z is safe".
- **Destination**: what they can do at the end. Take it from "Success looks like" in `MISSION.md`.

Then choose the **running example**: one concrete thing the course builds up or returns to, so each lesson adds to something the reader already knows instead of starting from a new toy. Read the Audience section of `MISSION.md` before choosing:

- **Shareable** (the default): the course supplies the example itself. Either a lesson step has the learner create it, or the course ships it in `./practice-starter/` and a lesson step copies it into `./practice/`. All hands-on work happens in `./practice/`, which the first checkpoint creates, and every path in a lesson is relative to it. Any reader can follow it on their own machine.
- **Just me**: the example may be the user's own project, files or accounts.

## 2. The lessons: question, win, hand-off

List the lessons the destination requires. For each one write three lines:

- **Question**: the one question this lesson answers, as the learner would ask it. One question means one lesson; "and" in a question is two lessons.
- **Win**: what the learner can do afterwards that they could not do before. A win is something done or made, not something understood: "run an eval and say why it failed", not "understand eval results".
- **Hand-off**: why this win makes the next lesson's question the natural one. "You can now find the commit by answering by hand. Answering forty times is tedious, so: can a script answer for you?"

Rules:

- Lesson 1's question comes from the starting problem. The last lesson's win is the destination.
- Each lesson's question must be one the previous hand-off raised. If a lesson's question comes from nowhere, the sequence has a gap: reorder, or add the missing step.
- Each lesson is completable in one short sitting. Working memory is small; a lesson that needs two wins is two lessons.
- Put a real hands-on win in lesson 1 or 2. Do not spend the opening lessons on background.
- Give each lesson a time budget, taken from the mission's constraints, and note it in the plan. Estimate a lesson as its reading time plus about one minute per checkpoint step.
- **When the mission's lesson count or time cannot hold its wins, do not overfill the lessons.** A constraint such as "two lessons of 15 minutes" and four things to be able to do may not fit together. Keep each lesson to one question and one win, and put the choice to the user at plan review: more lessons of the same length, or fewer wins. Say which you recommend.
- Tell the user how many lessons the plan comes to before you show it, so a long course is not a surprise.

## 3. The sections: one mode each

Outline each lesson as three to five sections. Give every section exactly one **mode** and one new idea:

| Mode | The reader is asking | The section contains | It does not contain |
|---|---|---|---|
| **How to think about it** (`think`) | "What is this for, and when would I reach for it?" | The problem it solves, a mental model, how to choose, what good looks like | Internals, step-by-step commands |
| **How it works** (`works`) | "What actually happens when I use it?" | The mechanism: parts, inputs and outputs, what a file contains, what a command does inside | Advice on when to use it, steps for the reader to carry out |
| **How to use it** (`use`) | "What do I do?" | The steps the reader takes, the checkpoint, what they should see | New concepts, new mechanism |

Rules:

- **One mode per section.** When a section wants two, split it. A reader who cannot tell which question is being answered cannot tell what to do with the answer.
- **Order by need.** The usual order is think, then works, then use: why it matters, what it is, then do it. Change the order when the lesson's question calls for it, but do not return to an earlier mode once you have left it, unless the lesson has two rounds.
- **"How it works" has to earn its place.** Include only as much mechanism as the reader needs in order to use the thing or to judge its output. The rest goes on a reference sheet.
- **A "use" section introduces nothing.** Everything its checkpoint relies on was explained in an earlier section or lesson. This is the rule the concept order table checks.
- **One new idea per section.** Two ideas in one section compete for the same small working memory.

The mode is shown to the reader as a label above the section heading, so the plan's choice is visible on the page.

## 4. Concept order

List every term, tool, command, flag, file and file format a lesson relies on. For each, record where it is **introduced** (explained well enough that the reader could explain it back) and where it is **first used** (relied on in a checkpoint, an exercise or a later explanation).

The rule: **introduced comes before first used**, in reading order. Naming a thing is not introducing it. A term is introduced when the lesson has said what it is, what it is for, and, for a tool or command, what goes in and what comes out.

Watch for explanations that lean on other unexplained things. "A golden patch is the reference solution as a patch" introduces nothing to a reader who does not know what a patch is: either the table has a row for "patch" that comes first, or the explanation uses plain words instead.

## 5. Vocabulary and coined terms

Every term in the concept order table has an **origin**:

- **A source**: the documentation, book or expert the term comes from, named so the user could look it up.
- **Course**: a file or name the course makes up for its running example, such as `orders.csv`. These are not vocabulary and need no sign-off. List them only when a later lesson relies on them.
- **Coined**: you named a concept, because the sources have no name for the idea or use several.

A coined term is a name for an idea. File names, sample data and the names of made-up customers are not coined terms.

Rules for coined terms:

- Prefer a plain description to a new name. "The table that lists where each term is introduced" needs no name until it is used often.
- When a name is worth having, list it in the plan as `coined (proposed)`, with the plain description beside it.
- At plan review, tell the user which terms are your coinage and ask them to accept, rename or drop each one. Change the row to `coined (agreed)` only then.
- In lessons, the first use of an agreed coinage says it is this course's name for the idea, not a standard term.
- If a new name occurs to you while writing a lesson, stop and ask before using it. If the user is not there to ask, use the plain description.
- Never present a coined term as established vocabulary. The learner will search for it, or use it with colleagues, and find nothing.

This table is the course's working vocabulary: lessons use these words and no synonyms. `GLOSSARY.md` is different. It records the terms the user has shown they understand, and grows as they learn.

## 6. Recall, spacing and practice across the sequence

Retention is a property of the sequence, not of one lesson. In the plan:

- **Recalls**: for each lesson after the first, name two earlier concepts its warm-up asks the reader to retrieve from memory. Choose ones the lesson is about to build on, and ones not recalled for a few lessons.
- **Interleaving**: where a later checkpoint can reuse an earlier skill in a new setting, plan it. Mixed practice is harder in the moment and sticks better.
- **Real practice**: mark the lessons whose checkpoint has the learner do the real thing rather than answer questions about it. The first should come early.
- **Community**: where a lesson reaches a question of judgement, note the community from `RESOURCES.md` the footer should point to.

## 7. Check the plan

Do each check and fix what it finds before showing the plan.

1. **Read only the Question, Win and Hand-off lines, top to bottom.** They should read as one story with no jump. If you have to explain a jump, the plan has a gap.
2. **For every "use" section**, list what its checkpoint needs the reader to know. Each item must be in the concept order table with an Introduced cell that comes earlier.
3. **For every row of the concept order table**, Introduced is at or before First used.
4. **For every section**, say in one sentence why the course needs it to answer the lesson's question. If you cannot, cut it or move it to a reference sheet.
5. **For every lesson**, the win is something the reader does, and it is one thing.
6. **For every term**, the origin is a named source, `course` or `coined`.
7. **For every lesson**, the estimate fits its time budget. If it does not, split the lesson; do not trim explanation the checkpoint depends on.

## 8. Agree it with the user

Show the user, in the conversation:

- The story, in two sentences.
- The numbered lessons, each with its question and win.
- Any coined terms, each with its plain description, asking them to accept, rename or drop it.
- The running example and where practice happens.
- Anything you could not source, from `## Gaps` in `RESOURCES.md`.

Ask them to cut, add or reorder. Apply their changes, re-run the checks in section 7, set `Status: agreed`, and stop until they confirm.

## COURSE-PLAN.md template

````md
# Course plan: {Topic}

Status: draft
<!-- draft → agreed → authored → built → verified -->

## Story
Starting problem: {what the learner cannot do today}
Destination: {what they can do at the end}
Running example: {the one thing the course builds or returns to, and where it lives}

## Lessons

### 1. {Title, plain words, no emphasis}
File: 0001-{dash-case-name}.html
Question: {the one question this lesson answers}
Win: {what the learner can do afterwards}
Hand-off: {why that win raises the next lesson's question}
Time: {minutes, from the mission's constraints}
Sections:
1. {Heading} | think | {the one new idea}
2. {Heading} | works | {the one new idea}
3. {Heading} | use   | {the checkpoint: what the learner does}
Recalls: {none in lesson 1; afterwards, two earlier concepts}
Primary source: {the one source to read for this lesson}

### 2. {Title}
…

## Concept order
| Term, tool or file | Origin | Introduced | First used |
|---|---|---|---|
| {term} | {source name} | L1 §2 | L1 §3 |
| {file the course creates} | course | L1 §3 | L2 §3 |
| {term} | coined (proposed): {plain description} | L2 §1 | L2 §3 |

## Reference sheets
- {file name}: {what it compresses, and from which lessons}
- workflow-guide.html: {the task it walks through}, or "none: the course teaches no repeatable procedure"
````

Write the Introduced and First used cells as `L{lesson} §{section}`. `scripts/check-lessons.js` reads this table and fails when a term appears in a lesson earlier than the one that introduces it. Write each term exactly as it appears on the page. A term in capitals, such as `SUM`, is matched in capitals only, so the ordinary word "sum" in an earlier lesson does not count; other terms are matched whatever their case.

## Keeping the plan true

The plan is a plan, not a contract. When writing a lesson shows that a section needs a different mode, an extra concept, or a different order, change `COURSE-PLAN.md` first and then write the lesson from it. When a learning record shows the user is ahead, behind or missing a prerequisite, change the plan for the lessons still ahead, and tell the user what changed and why. A plan that no longer matches the lessons cannot be checked against them.
