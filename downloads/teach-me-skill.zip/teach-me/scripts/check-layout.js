#!/usr/bin/env node
/* Layout check for a teach-me workspace: opens every page in a headless
   Chrome-family browser at a desktop and a phone width and reports anything
   that scrolls sideways or sticks out of the page.

   No npm dependencies. Needs Node.js 22 or newer and an installed Chrome,
   Chromium, Edge or Brave.

   Usage:   node check-layout.js <workspace | file.html …> [--screenshots <dir>]
                                 [--widths 1280,390] [--browser <path>] [--json]
   Example: node check-layout.js ~/learn/git-bisect --screenshots /tmp/shots

   Exit 0: every page fits.  1: something overflows.  2: bad usage.
   Exit 3: no browser found. Follow the manual check it prints instead. */

'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const { pathToFileURL } = require('url');

const HELP = `Usage: node check-layout.js <workspace | file.html …> [options]

Opens each page headless at each width and reports:
  page      the whole page is wider than the window
  scroll    a code block, table, figure or diagram scrolls sideways
            (at phone width, code blocks and .table-wrap may scroll inside their box)
  sticks    an element reaches past the right edge of the sheet
  small     text inside an SVG figure renders smaller than 9px

Options:
  --screenshots <dir>  also save a full-page PNG of each page at each width,
                       in light and dark, to look at
  --widths <list>      window widths in pixels (default 1280,390)
  --browser <path>     browser binary (default: CHROME_PATH, then common installs)
  --json               print findings as JSON

Example: node check-layout.js ~/learn/git-bisect --screenshots /tmp/shots`;

const MANUAL = `Manual layout check (no browser was found to run it automatically):
  1. Open each lesson, reference sheet and index.html in a browser.
  2. At full width, then with the window narrowed to about phone width:
     - no code block, table or figure shows a horizontal scrollbar
     - nothing reaches past the right edge of the white sheet
     - annotated code shows its notes below the code, readable without scrolling
  3. Switch to dark mode with the toggle and look once more.
To run this check automatically, install Chrome or Chromium, or pass --browser <path>.`;

// ── Arguments ────────────────────────────────────────────────

const argv = process.argv.slice(2);
if (argv.includes('--help') || argv.includes('-h')) { console.log(HELP); process.exit(0); }
const opts = { widths: [1280, 390], screenshots: null, browser: process.env.CHROME_PATH || null, json: false };
const inputs = [];
for (let i = 0; i < argv.length; i++) {
  const a = argv[i];
  if (a === '--json') opts.json = true;
  else if (a === '--screenshots') opts.screenshots = argv[++i];
  else if (a === '--browser') opts.browser = argv[++i];
  else if (a === '--widths') opts.widths = String(argv[++i]).split(',').map((w) => parseInt(w, 10));
  else if (a.startsWith('--')) { console.error(`Unknown option ${a}\n\n${HELP}`); process.exit(2); }
  else inputs.push(a);
}
if (inputs.length === 0 || opts.widths.some((w) => !Number.isFinite(w) || w < 200)) {
  console.error(HELP);
  process.exit(2);
}

function expand(p) { return path.resolve(p.replace(/^~(?=\/|$)/, os.homedir())); }

const pages = [];
for (const input of inputs.map(expand)) {
  if (!fs.existsSync(input)) { console.error(`Not found: ${input}`); process.exit(2); }
  if (fs.statSync(input).isDirectory()) {
    for (const dir of ['', 'lessons', 'reference']) {
      const full = path.join(input, dir);
      if (!fs.existsSync(full)) continue;
      for (const name of fs.readdirSync(full).sort()) {
        if (dir === '' ? name === 'index.html' : name.endsWith('.html')) pages.push(path.join(full, name));
      }
    }
  } else pages.push(input);
}
if (pages.length === 0) { console.error('No HTML pages found to check.'); process.exit(2); }

// ── Find a browser ───────────────────────────────────────────

function findBrowser() {
  if (opts.browser) return fs.existsSync(expand(opts.browser)) ? expand(opts.browser) : null;
  const home = os.homedir();
  const candidates = [
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    '/Applications/Chromium.app/Contents/MacOS/Chromium',
    '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
    '/Applications/Brave Browser.app/Contents/MacOS/Brave Browser',
    '/usr/bin/google-chrome', '/usr/bin/google-chrome-stable', '/usr/bin/chromium',
    '/usr/bin/chromium-browser', '/usr/bin/microsoft-edge', '/snap/bin/chromium',
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  ];
  // Browsers downloaded by Playwright, if any
  for (const cache of [path.join(home, 'Library/Caches/ms-playwright'), path.join(home, '.cache/ms-playwright')]) {
    if (!fs.existsSync(cache)) continue;
    for (const dir of fs.readdirSync(cache).filter((d) => /^chromium-\d+$/.test(d)).sort().reverse()) {
      for (const sub of ['chrome-mac/Chromium.app/Contents/MacOS/Chromium',
        'chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing',
        'chrome-mac-x64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing',
        'chrome-linux/chrome', 'chrome-linux64/chrome']) {
        candidates.push(path.join(cache, dir, sub));
      }
    }
  }
  return candidates.find((c) => fs.existsSync(c)) || null;
}

// ── The check that runs inside each page ─────────────────────

const PROBE = `(() => {
  const findings = [];
  const winW = window.innerWidth;
  const docW = document.documentElement.scrollWidth;
  if (docW > winW + 1) findings.push({ kind: 'page', detail: 'The page is ' + docW + 'px wide in a ' + winW + 'px window, so the whole page scrolls sideways.' });
  const describe = (el) => {
    const cls = el.getAttribute('class');
    const text = (el.textContent || '').trim().replace(/\\s+/g, ' ').slice(0, 50);
    return '<' + el.tagName.toLowerCase() + (cls ? ' class="' + cls + '"' : '') + '>' + (text ? ' "' + text + '…"' : '');
  };
  const sheet = document.body.getBoundingClientRect();
  const seen = new Set();
  for (const el of document.querySelectorAll('pre, table, figure, svg, img, video, .mermaid, .annotated, .table-wrap, .checkpoint, .callout, .quiz')) {
    if (el.closest('[hidden]') || el.closest('details:not([open])')) continue;
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) continue;
    const over = el.scrollWidth - el.clientWidth;
    // On a phone-width window, code and wide tables scroll inside their own
    // box by design. What must not happen there is the page itself scrolling.
    const scrollsByDesign = winW < 600 && (el.tagName === 'PRE' || el.classList.contains('table-wrap'));
    if (over > 1 && el.tagName !== 'TABLE' && el.tagName !== 'svg' && !scrollsByDesign) {
      findings.push({ kind: 'scroll', detail: describe(el) + ' scrolls sideways: its content is ' + over + 'px wider than the box.' });
      seen.add(el);
    }
    if (rect.right > sheet.right + 1 && !seen.has(el) && ![...seen].some((s) => s.contains(el))) {
      findings.push({ kind: 'sticks', detail: describe(el) + ' reaches ' + Math.round(rect.right - sheet.right) + 'px past the right edge of the sheet.' });
    }
  }
  // Text inside a diagram must stay readable when the diagram is scaled down
  for (const svg of document.querySelectorAll('figure svg')) {
    if (svg.closest('[hidden]')) continue;
    const box = svg.viewBox && svg.viewBox.baseVal;
    const rect = svg.getBoundingClientRect();
    if (!box || !box.width || !rect.width) continue;
    const scale = rect.width / box.width;
    let smallest = Infinity;
    for (const text of svg.querySelectorAll('text')) {
      const size = parseFloat(getComputedStyle(text).fontSize) * scale;
      if (size > 0) smallest = Math.min(smallest, size);
    }
    if (smallest < 9) findings.push({ kind: 'small', detail: 'Text in a figure renders at ' + smallest.toFixed(1) + 'px, too small to read (minimum 9px). Use larger text or fewer, bigger elements: ' + describe(svg) });
  }
  // How many monospace characters fit on one line of a full-width code block
  let columns = null;
  for (const code of document.querySelectorAll('pre code')) {
    const pre = code.closest('pre');
    if (pre.closest('[hidden]') || pre.clientWidth === 0) continue;
    const style = getComputedStyle(pre);
    const probe = document.createElement('span');
    probe.textContent = '0'.repeat(100);
    probe.style.cssText = 'visibility:hidden;position:absolute;white-space:pre';
    code.appendChild(probe);
    const charW = probe.getBoundingClientRect().width / 100;
    probe.remove();
    const room = pre.clientWidth - parseFloat(style.paddingLeft) - parseFloat(style.paddingRight);
    if (charW > 0 && room > 0) columns = Math.max(columns || 0, Math.floor(room / charW));
  }
  return JSON.stringify({ findings, columns });
})()`;

// ── Minimal DevTools protocol client ─────────────────────────

function connect(wsUrl) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    let nextId = 1;
    const pending = new Map();
    const waiters = [];
    ws.onopen = () => resolve({
      send(method, params = {}) {
        const id = nextId++;
        ws.send(JSON.stringify({ id, method, params }));
        return new Promise((res, rej) => pending.set(id, { res, rej }));
      },
      waitFor(method, timeoutMs) {
        return new Promise((res) => {
          const timer = setTimeout(() => res(null), timeoutMs);
          waiters.push({ method, res: (v) => { clearTimeout(timer); res(v); } });
        });
      },
      close() { ws.close(); },
    });
    ws.onerror = () => reject(new Error('Could not connect to the browser.'));
    ws.onmessage = (event) => {
      const msg = JSON.parse(event.data);
      if (msg.id && pending.has(msg.id)) {
        const { res, rej } = pending.get(msg.id);
        pending.delete(msg.id);
        if (msg.error) rej(new Error(msg.error.message)); else res(msg.result);
      } else if (msg.method) {
        for (let i = waiters.length - 1; i >= 0; i--) {
          if (waiters[i].method === msg.method) waiters.splice(i, 1)[0].res(msg.params);
        }
      }
    };
  });
}

function launch(browserPath, profileDir) {
  return new Promise((resolve, reject) => {
    const child = spawn(browserPath, [
      '--headless=new', '--remote-debugging-port=0', `--user-data-dir=${profileDir}`,
      '--no-first-run', '--no-default-browser-check', '--disable-gpu', '--hide-scrollbars',
      '--allow-file-access-from-files', 'about:blank',
    ], { stdio: ['ignore', 'ignore', 'pipe'] });
    let buffer = '';
    const timer = setTimeout(() => { child.kill(); reject(new Error('The browser did not start within 20 seconds.')); }, 20000);
    child.stderr.on('data', (chunk) => {
      buffer += chunk;
      const match = buffer.match(/DevTools listening on (ws:\/\/[^\s]+)/);
      if (match) { clearTimeout(timer); resolve({ child, port: new URL(match[1]).port }); }
    });
    child.on('error', (err) => { clearTimeout(timer); reject(err); });
    child.on('exit', () => { clearTimeout(timer); reject(new Error('The browser exited before it was ready.')); });
  });
}

// ── Main ─────────────────────────────────────────────────────

(async () => {
  if (typeof WebSocket !== 'function' || typeof fetch !== 'function') {
    console.error(`This check needs Node.js 22 or newer (found ${process.version}).\n\n${MANUAL}`);
    process.exitCode = 3;
    return;
  }
  const browserPath = findBrowser();
  if (!browserPath) {
    console.error(opts.browser ? `Browser not found at ${opts.browser}.\n` : 'No Chrome, Chromium, Edge or Brave found.\n');
    console.error(MANUAL);
    process.exitCode = 3;
    return;
  }

  const profileDir = fs.mkdtempSync(path.join(os.tmpdir(), 'teach-me-layout-'));
  let browser;
  const results = [];
  let columnsByWidth = {};
  try {
    browser = await launch(browserPath, profileDir);
    const created = await (await fetch(`http://127.0.0.1:${browser.port}/json/new?about:blank`, { method: 'PUT' })).json();
    const page = await connect(created.webSocketDebuggerUrl);
    await page.send('Page.enable');
    if (opts.screenshots) fs.mkdirSync(expand(opts.screenshots), { recursive: true });

    for (const file of pages) {
      for (const width of opts.widths) {
        await page.send('Emulation.setDeviceMetricsOverride', { width, height: 900, deviceScaleFactor: 1, mobile: width < 600 });
        await page.send('Emulation.setEmulatedMedia', { features: [{ name: 'prefers-color-scheme', value: 'light' }] });
        const loaded = page.waitFor('Page.loadEventFired', 15000);
        await page.send('Page.navigate', { url: pathToFileURL(file).href });
        await loaded;
        // Let webfonts and diagrams settle, but never wait long for them
        await page.send('Runtime.evaluate', {
          expression: 'Promise.race([document.fonts.ready, new Promise(r => setTimeout(r, 3000))]).then(() => new Promise(r => setTimeout(r, 300)))',
          awaitPromise: true,
        });
        const evaluated = await page.send('Runtime.evaluate', { expression: PROBE, returnByValue: true });
        const { findings, columns } = JSON.parse(evaluated.result.value);
        if (columns) columnsByWidth[width] = Math.max(columnsByWidth[width] || 0, columns);
        for (const finding of findings) results.push({ file, width, ...finding });

        if (opts.screenshots) {
          for (const theme of ['light', 'dark']) {
            await page.send('Emulation.setEmulatedMedia', { features: [{ name: 'prefers-color-scheme', value: theme }] });
            await page.send('Runtime.evaluate', { expression: 'new Promise(r => setTimeout(r, 150))', awaitPromise: true });
            const shot = await page.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: true });
            const name = `${path.basename(file, '.html')}-${width}-${theme}.png`;
            fs.writeFileSync(path.join(expand(opts.screenshots), name), Buffer.from(shot.data, 'base64'));
          }
        }
      }
    }
    page.close();
  } catch (error) {
    console.error(`Layout check could not run: ${error.message}\n\n${MANUAL}`);
    process.exitCode = 3;
    return;
  } finally {
    if (browser) browser.child.kill();
    try { fs.rmSync(profileDir, { recursive: true, force: true }); } catch (e) { /* the browser may still hold it */ }
  }

  const base = inputs.length === 1 && fs.statSync(expand(inputs[0])).isDirectory() ? expand(inputs[0]) : process.cwd();
  if (opts.json) {
    console.log(JSON.stringify({ pages: pages.length, widths: opts.widths, columns: columnsByWidth, findings: results }, null, 2));
  } else {
    console.log(`Checked ${pages.length} pages at ${opts.widths.join('px and ')}px`);
    for (const [width, columns] of Object.entries(columnsByWidth)) {
      console.log(`  At ${width}px a full-width code block fits ${columns} characters per line.`);
    }
    console.log('');
    const PER_FILE = 8;
    const byFile = {};
    for (const r of results) (byFile[r.file] = byFile[r.file] || []).push(r);
    for (const [file, list] of Object.entries(byFile)) {
      console.log(`  ${path.relative(base, file)}`);
      for (const r of list.slice(0, PER_FILE)) console.log(`    FAIL  ${String(r.width).padStart(4)}px  ${r.kind.padEnd(6)}  ${r.detail}`);
      if (list.length > PER_FILE) console.log(`    … and ${list.length - PER_FILE} more (use --json for all)`);
    }
    if (results.length === 0) console.log('  Every page fits at every width.');
    else console.log(`\n${results.length} layout problem(s). Shorten or break the long lines, stack annotated code, or wrap a wide table in <div class="table-wrap">, then run this again.`);
    if (opts.screenshots) console.log(`\nScreenshots saved to ${expand(opts.screenshots)}. Look at them: a page can fit and still read badly.`);
  }
  process.exitCode = results.length ? 1 : 0;
})();
