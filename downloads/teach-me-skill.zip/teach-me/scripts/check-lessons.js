#!/usr/bin/env node
/* Static checks on a teach-me workspace. No dependencies, no browser.

   Usage:   node check-lessons.js <workspace> [--external] [--json] [--max-line <n>]
   Example: node check-lessons.js ~/learn/git-bisect

   Exit 0 when nothing FAILs, 1 when something does, 2 on bad usage.
   WARN lines are things to look at and either fix or accept on purpose. */

'use strict';

const fs = require('fs');
const path = require('path');

const HELP = `Usage: node check-lessons.js <workspace> [--external] [--json] [--max-line <n>]

Checks every page in <workspace>/lessons, <workspace>/reference and
<workspace>/index.html for rules a program can decide:

  links          every local href, src and poster points at a file that exists,
                 and every #anchor exists in the page it points at.
                 --external also fetches each web link and warns on failures
  placeholders   no {{…}} left from a template
  mode           every lesson section heading declares data-mode (think|works|use)
  concept-order  no term from COURSE-PLAN.md's "Concept order" table appears in a
                 lesson earlier than the lesson that introduces it
  command        commands in checkpoints and workflow guides are plain: no shell
                 variables, command substitution, chaining, or pipelines.
                 Blocks typed elsewhere (<pre data-where="sqlite3">) are skipped
  line-length    code lines fit the sheet without scrolling (default 62 characters,
                 10 fewer inside a checkpoint or workflow step)
  gap            no gap marker in an excerpt hides a single line
  voice          pages say "we" and "our run", not "the author"
  heading-em     emphasis in headings is the exception, not a habit
  private-path   a shareable course names no home-directory paths
  structure      lessons have the video slot, lesson question, course map and footer
  course-data    assets/course.js and the lesson files agree
  unverified     "check this yourself" notes are listed for review
  colour         no hard-coded colours in inline styles or SVG

Example: node check-lessons.js ~/learn/git-bisect`;

const args = process.argv.slice(2);
if (args.includes('--help') || args.includes('-h')) { console.log(HELP); process.exit(0); }
const asJson = args.includes('--json');
const checkExternalLinks = args.includes('--external');
let maxLine = 62;
const maxIdx = args.indexOf('--max-line');
if (maxIdx !== -1) maxLine = parseInt(args[maxIdx + 1], 10);
const positional = args.filter((a, i) => !a.startsWith('--') && args[i - 1] !== '--max-line');
if (positional.length !== 1 || !Number.isFinite(maxLine)) {
  console.error(HELP);
  process.exit(2);
}
const workspace = path.resolve(positional[0].replace(/^~(?=\/|$)/, process.env.HOME || '~'));
if (!fs.existsSync(workspace) || !fs.statSync(workspace).isDirectory()) {
  console.error(`Not a directory: ${workspace}\nPass the course workspace: the folder that holds MISSION.md and lessons/.`);
  process.exit(2);
}

const findings = [];
function report(level, rule, file, line, message) {
  findings.push({ level, rule, file: path.relative(workspace, file), line, message });
}

function listHtml(dir) {
  const full = path.join(workspace, dir);
  if (!fs.existsSync(full)) return [];
  return fs.readdirSync(full).filter((f) => f.endsWith('.html')).sort().map((f) => path.join(full, f));
}
const lessonFiles = listHtml('lessons');
const referenceFiles = listHtml('reference');
const homeFile = path.join(workspace, 'index.html');
const pages = [...lessonFiles, ...referenceFiles, ...(fs.existsSync(homeFile) ? [homeFile] : [])];

if (lessonFiles.length === 0) {
  console.error(`No lessons found in ${path.join(workspace, 'lessons')}. Nothing to check.`);
  process.exit(2);
}

// ── Helpers ──────────────────────────────────────────────────

const VOID = new Set(['meta', 'link', 'br', 'img', 'hr', 'input', 'source', 'track', 'wbr', 'col', 'area', 'base', 'embed', 'param']);

function unescapeHtml(text) {
  return text
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'").replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&');
}
function stripTags(html) { return unescapeHtml(html.replace(/<[^>]*>/g, '')); }
function lineOf(source, index) { return source.slice(0, index).split('\n').length; }

/* Walk the tags in order, keeping a stack of open elements, and collect every
   <pre> and <h1>/<h2> with the classes of the elements around it. */
function scan(source) {
  // Blank out comments and the bodies of scripts and styles, keeping line
  // numbers and the opening tags (a <script src> is a link worth checking).
  const blanked = source
    .replace(/<!--[\s\S]*?-->/g, (m) => m.replace(/[^\n]/g, ' '))
    .replace(/(<(script|style)\b[^>]*>)([\s\S]*?)(<\/\2>)/gi,
      (m, open, tag, body, close) => open + body.replace(/[^\n]/g, ' ') + close);
  const tagRe = /<(\/?)([a-zA-Z][a-zA-Z0-9]*)\b([^>]*)>/g;
  const stack = [];
  const pres = [];
  const headings = [];
  let match;
  while ((match = tagRe.exec(blanked))) {
    const closing = match[1] === '/';
    const tag = match[2].toLowerCase();
    const attrs = match[3];
    if (VOID.has(tag) || /\/\s*$/.test(attrs)) continue;
    if (!closing) {
      const cls = (attrs.match(/\bclass\s*=\s*"([^"]*)"/) || [, ''])[1];
      const entry = { tag, cls, attrs, start: match.index, contentStart: tagRe.lastIndex };
      entry.context = stack.map((s) => `${s.tag}.${s.cls}`).join(' ');
      stack.push(entry);
    } else {
      let i = stack.length - 1;
      while (i >= 0 && stack[i].tag !== tag) i--;
      if (i < 0) continue;
      const entry = stack[i];
      stack.length = i;
      const inner = blanked.slice(entry.contentStart, match.index);
      if (tag === 'pre') pres.push({ ...entry, inner });
      if (tag === 'h1' || tag === 'h2') headings.push({ ...entry, inner });
    }
  }
  return { blanked, pres, headings };
}

function stripQuoted(line) {
  return line.replace(/'[^']*'/g, "''").replace(/"[^"]*"/g, '""');
}

// ── Workspace-level facts ────────────────────────────────────

const missionPath = path.join(workspace, 'MISSION.md');
let audience = 'shareable';
if (fs.existsSync(missionPath)) {
  const mission = fs.readFileSync(missionPath, 'utf8');
  const section = mission.split(/^##\s+Audience\s*$/im)[1];
  // "Just me" counts only when the section does not also say "Shareable", so a
  // mission that kept both template lines is treated as shareable, the safe side.
  const body = section ? section.split(/^##\s/m)[0] : '';
  if (/\bjust me\b/i.test(body) && !/\bshareable\b/i.test(body)) audience = 'private';
}

// Concept order table from the plan: | term | origin | introduced | first used |
const planPath = path.join(workspace, 'COURSE-PLAN.md');
const concepts = [];
if (fs.existsSync(planPath)) {
  const plan = fs.readFileSync(planPath, 'utf8');
  const section = (plan.split(/^##\s+Concept order\s*$/im)[1] || '').split(/^##\s/m)[0];
  for (const row of section.split('\n')) {
    const cells = row.split('|').map((c) => c.trim());
    if (cells.length < 5 || /^-+$/.test(cells[1].replace(/[:\s]/g, '')) || /^term/i.test(cells[1])) continue;
    const term = cells[1].replace(/[`*_]/g, '').trim();
    const introduced = (cells[3].match(/L(?:esson\s*)?(\d+)/i) || [])[1];
    if (term && introduced) concepts.push({ term, lesson: parseInt(introduced, 10) });
  }
  if (concepts.length === 0) {
    report('WARN', 'concept-order', planPath, 1,
      'No rows read from the "Concept order" table, so concept order was not checked. Each row needs a term and an "Introduced" cell such as "L2 §1".');
  }
} else {
  report('WARN', 'concept-order', planPath, 1, 'COURSE-PLAN.md not found, so concept order was not checked.');
}

// Link checking: ids per page (cached), and external URLs collected for --external
const idCache = new Map();
function idsOf(file) {
  if (!idCache.has(file)) {
    const text = fs.readFileSync(file, 'utf8').replace(/<!--[\s\S]*?-->/g, '');
    idCache.set(file, new Set([...text.matchAll(/\b(?:id|name)\s*=\s*"([^"]+)"/g)].map((x) => x[1])));
  }
  return idCache.get(file);
}
const externalLinks = new Map();

function lessonNumber(file) {
  const m = path.basename(file).match(/^(\d+)/);
  return m ? parseInt(m[1], 10) : NaN;
}

// ── Per-page checks ──────────────────────────────────────────

const headingStats = { total: 0, withEm: 0 };
const lessonTexts = [];

for (const file of pages) {
  const source = fs.readFileSync(file, 'utf8');
  const isLesson = lessonFiles.includes(file);
  const { blanked, pres, headings } = scan(source);

  // placeholders
  // Template placeholders start with a capital letter or an ellipsis. Real
  // content such as ${{ github.token }} or {{ name }} is left alone.
  const placeholder = /(?<!\$)\{\{[A-Z…][^}]*\}\}/g;
  let m;
  let shown = 0;
  while ((m = placeholder.exec(blanked)) && shown < 5) {
    report('FAIL', 'placeholders', file, lineOf(source, m.index), `Template placeholder left in the page: ${m[0].slice(0, 60)}`);
    shown++;
  }

  // headings: emphasis and section mode
  const exemptFrom = Math.min(
    ...['<section class="exercises"', '<footer class="next-steps"']
      .map((marker) => blanked.indexOf(marker)).filter((i) => i >= 0), Infinity);
  for (const h of headings) {
    headingStats.total++;
    if (/<em\b/i.test(h.inner)) {
      headingStats.withEm++;
      report('WARN', 'heading-em', file, lineOf(source, h.start),
        `Emphasis in a heading ("${stripTags(h.inner).trim().slice(0, 50)}"). Keep it only if that word is being defined or contrasted.`);
    }
    if (isLesson && h.tag === 'h2' && h.start < exemptFrom && !/(^|\s)(section|footer|div|details)\./.test(h.context.replace(/^html\.\S* body\.\S*\s?/, ''))) {
      const mode = (h.attrs.match(/data-mode\s*=\s*"([^"]*)"/) || [])[1];
      if (!['think', 'works', 'use'].includes(mode)) {
        report('FAIL', 'mode', file, lineOf(source, h.start),
          `Section "${stripTags(h.inner).trim().slice(0, 50)}" has no mode. Add data-mode="think", "works" or "use" to the h2, as the plan lists it.`);
      }
    }
  }

  // code blocks: gap markers, line length everywhere, plain commands in checkpoints and workflows
  for (const pre of pres) {
    // A gap marker takes a line of its own, so one that hides a single line saves nothing.
    const gapRe = /<span class="gap">([\s\S]*?)<\/span>/g;
    let gap;
    while ((gap = gapRe.exec(pre.inner))) {
      const label = stripTags(gap[1]).trim();
      if (/^(1|one)\s+\w+\s+hidden\b/i.test(label)) {
        report('WARN', 'gap', file, lineOf(source, pre.start),
          `Gap marker "${label.slice(0, 40)}" hides a single line, which takes the same space as the line. Show the line, unless it is too wide for the page or names something private.`);
      }
    }

    const text = stripTags(pre.inner.replace(/<span class="(mark|gap)">[\s\S]*?<\/span>/g, ''));
    const lines = text.split('\n');
    const longest = lines.reduce((a, b) => (b.length > a.length ? b : a), '');
    const inPractice = /\.checkpoint\b|ol\.workflow\b|ol\.steps\b/.test(pre.context);
    // A block inside a checkpoint or workflow step is indented, so it holds less.
    const limit = inPractice ? maxLine - 10 : maxLine;
    if (longest.length > limit) {
      report('WARN', 'line-length', file, lineOf(source, pre.start),
        `Code line of ${longest.length} characters (limit ${limit}${inPractice ? ' inside a step' : ''}) will scroll sideways: "${longest.trim().slice(0, 40)}…". Break the line or shorten the path.`);
    }

    const isFileOrOutput = /\.file-excerpt\b/.test(pre.context) || /\boutput\b/.test(pre.cls);
    const shellTaught = /data-shell\s*=\s*"taught"/.test(pre.attrs);
    // data-where names where a block is typed. Anything other than the terminal
    // (a database prompt, a REPL) is not shell, so the shell rules do not apply.
    const where = (pre.attrs.match(/data-where\s*=\s*"([^"]*)"/) || [])[1];
    const notShell = where && !/^(terminal|shell|command line)$/i.test(where.trim());
    if (!inPractice || isFileOrOutput || shellTaught || notShell) continue;

    const problems = new Set();
    for (const raw of lines) {
      const line = raw.trim();
      if (!line || line.startsWith('#')) continue;
      const bare = stripQuoted(line);
      if (/\$\(|`/.test(line)) problems.add('command substitution ($(…) or backticks)');
      if (/^[A-Za-z_][A-Za-z0-9_]*=/.test(line) || /\$\{?[A-Za-z_]/.test(bare)) problems.add('a shell variable');
      if (/&&|\|\||;\s*\S/.test(bare)) problems.add('several commands chained on one line');
      const pipes = (bare.replace(/\|\|/g, '').match(/\|/g) || []).length;
      if (pipes > 1) problems.add('a pipeline of three or more commands');
      else if (pipes === 1) {
        report('WARN', 'command', file, lineOf(source, pre.start),
          `A pipe in "${line.slice(0, 50)}". Keep it only if the pipe is what this step teaches, and say what each side does.`);
      }
    }
    for (const problem of problems) {
      report('FAIL', 'command', file, lineOf(source, pre.start),
        `Command uses ${problem}. Write plain commands with literal paths, one idea per command. (A file's contents belong in a .file-excerpt; printed output in <pre class="output">; mark a block data-shell="taught" only when shell syntax itself is the lesson.)`);
    }
  }

  // private paths
  if (audience === 'shareable') {
    const privatePath = /(\/Users\/[A-Za-z0-9._-]+|\/home\/[A-Za-z0-9._-]+|[A-Z]:\\Users\\[A-Za-z0-9._-]+)/g;
    const seen = new Set();
    while ((m = privatePath.exec(blanked))) {
      if (seen.has(m[1])) continue;
      seen.add(m[1]);
      report('FAIL', 'private-path', file, lineOf(source, m.index),
        `Home-directory path "${m[1]}" in a shareable course. Use a path inside the practice folder the course creates.`);
    }
    // ~/src/my-repo is one person's layout. ~/.config/tool is the same for everyone.
    const homeRelative = /~\/(?!\.)[A-Za-z0-9._-]+(?:\/[A-Za-z0-9._-]+)*/g;
    while ((m = homeRelative.exec(blanked))) {
      if (seen.has(m[0])) continue;
      seen.add(m[0]);
      report('FAIL', 'private-path', file, lineOf(source, m.index),
        `Home-relative path "${m[0]}" in a shareable course: readers keep their files elsewhere. Use a path relative to the practice folder the course creates.`);
    }
  }

  // links: every local target exists, and every #anchor exists in its page
  const linkRe = /\b(href|src|poster)\s*=\s*"([^"]*)"/g;
  while ((m = linkRe.exec(blanked))) {
    const value = unescapeHtml(m[2]).trim();
    const line = lineOf(source, m.index);
    if (value.startsWith('{{')) continue; // already reported as a placeholder
    if (value === '') {
      report('FAIL', 'links', file, line, `Empty ${m[1]} attribute.`);
      continue;
    }
    if (/^(https?:)?\/\//i.test(value)) {
      const url = value.startsWith('//') ? 'https:' + value : value;
      if (!externalLinks.has(url)) externalLinks.set(url, { file, line });
      continue;
    }
    if (/^[a-z][a-z0-9+.-]*:/i.test(value)) continue; // mailto:, data:, and so on
    const [beforeHash, fragment] = value.split('#');
    const pathPart = beforeHash.split('?')[0];
    let target = file;
    if (pathPart) {
      let decoded = pathPart;
      try { decoded = decodeURIComponent(pathPart); } catch (e) { /* keep the raw path */ }
      target = path.resolve(path.dirname(file), decoded);
      if (!fs.existsSync(target)) {
        report('FAIL', 'links', file, line,
          `Broken link: ${m[1]}="${value}" points at ${path.relative(workspace, target)}, which does not exist.`);
        continue;
      }
      if (fs.statSync(target).isDirectory()) {
        report('FAIL', 'links', file, line, `Link ${m[1]}="${value}" points at a folder. Link the file inside it.`);
        continue;
      }
    }
    if (fragment && /\.html?$/i.test(target)) {
      if (!idsOf(target).has(fragment)) {
        report('FAIL', 'links', file, line,
          `Broken anchor: ${m[1]}="${value}". No element with id="${fragment}" in ${path.relative(workspace, target)}.`);
      }
    }
  }

  // unverified notes
  const unverified = /(check this (for )?yourself|verify this yourself|not (yet )?verified|unverified|untested)/gi;
  while ((m = unverified.exec(blanked))) {
    report('WARN', 'unverified', file, lineOf(source, m.index),
      `"${m[0]}": if one run would settle this, run it and state the result instead.`);
  }

  // voice: the course speaks as "we", never as "the author"
  const thirdPerson = /\bthe (author|writer)('s|’s)?\b/gi;
  let voiceShown = 0;
  while ((m = thirdPerson.exec(blanked)) && voiceShown < 3) {
    report('WARN', 'voice', file, lineOf(source, m.index),
      `"${m[0]}": write as "we". Say "in our run" and "ours", not "the author's run".`);
    voiceShown++;
  }

  // hard-coded colours
  const colour =/(style\s*=\s*"[^"]*#[0-9a-fA-F]{3,8}\b|\b(fill|stroke)\s*=\s*"#[0-9a-fA-F]{3,8}")/g;
  if ((m = colour.exec(blanked))) {
    report('WARN', 'colour', file, lineOf(source, m.index),
      'Hard-coded colour. Use currentColor or a CSS token such as var(--accent), or it breaks in one of the two themes.');
  }

  // structure
  if (isLesson) {
    const required = [
      ['class="lesson-video"', 'FAIL', 'the video slot (copy it from assets/lesson-template.html, unchanged)'],
      ['class="lesson-question"', 'FAIL', 'the lesson question block ("So far" and "This lesson answers")'],
      ['class="next-steps"', 'FAIL', 'the What\'s Next footer'],
      ['class="course-map"', 'WARN', 'the course map nav'],
      ['class="primary-source"', 'WARN', 'a primary source'],
    ];
    for (const [needle, level, what] of required) {
      if (!blanked.includes(needle)) report(level, 'structure', file, 1, `Missing ${what}.`);
    }
    if (!/class="(quiz|sorter|exercises|checkpoint)\b/.test(blanked)) {
      report('WARN', 'structure', file, 1, 'No quiz, sorter, exercise or checkpoint: the lesson has no retrieval or practice.');
    }
    const footerAt = blanked.indexOf('<footer class="next-steps"');
    const body = footerAt >= 0 ? blanked.slice(0, footerAt) : blanked;
    lessonTexts.push({ file, n: lessonNumber(file), text: stripTags(body) });
  }
}

// heading emphasis as a habit
if (headingStats.total >= 4 && headingStats.withEm / headingStats.total > 0.25) {
  report('FAIL', 'heading-em', workspace, 1,
    `${headingStats.withEm} of ${headingStats.total} headings carry emphasis. That is a habit, not meaning: remove it from every heading where the word is not being defined or contrasted.`);
}

// concept order across lessons
for (const { term, lesson } of concepts) {
  // A term written in capitals (SUM, GROUP BY) is matched in capitals only, so
  // the ordinary words "sum" and "real" do not count as early uses of it.
  const exactCase = /[A-Z]/.test(term) && term === term.toUpperCase();
  const escaped = term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`(^|[^A-Za-z0-9])${escaped}([^A-Za-z0-9]|$)`, exactCase ? '' : 'i');
  const early = lessonTexts.filter((l) => l.n < lesson && pattern.test(l.text)).sort((a, b) => a.n - b.n)[0];
  if (early) {
    report('FAIL', 'concept-order', early.file, 1,
      `"${term}" appears in lesson ${early.n}, but the plan introduces it in lesson ${lesson}. Introduce it where it is first used, or remove the early use, and update the plan's table.`);
  }
}

// course.js agrees with the lesson files
const courseJs = path.join(workspace, 'assets', 'course.js');
if (fs.existsSync(courseJs)) {
  const text = fs.readFileSync(courseJs, 'utf8');
  if (/\{\{[A-Z…]/.test(text)) report('FAIL', 'placeholders', courseJs, 1, 'assets/course.js still has template placeholders.');
  const listed = [...text.matchAll(/file:\s*['"]([^'"]+\.html)['"]/g)].map((x) => x[1]);
  for (const file of lessonFiles) {
    if (!listed.includes(path.basename(file))) {
      report('FAIL', 'course-data', courseJs, 1, `Lesson ${path.basename(file)} is not listed in assets/course.js, so it is missing from every course map.`);
    }
  }
  for (const name of listed) {
    if (!fs.existsSync(path.join(workspace, 'lessons', name)) && !fs.existsSync(path.join(workspace, 'reference', name))) {
      report('FAIL', 'course-data', courseJs, 1, `assets/course.js lists ${name}, which does not exist in lessons/ or reference/.`);
    }
  }
} else {
  report('WARN', 'course-data', courseJs, 1, 'assets/course.js not found, so pages have no course map.');
}

// ── External links (only with --external) ────────────────────

/* A web request can fail for reasons that have nothing to do with the link
   (no network, a site that refuses scripts), so these are WARN, never FAIL. */
async function checkExternal() {
  if (typeof fetch !== 'function') {
    report('WARN', 'links', workspace, 1, 'This Node.js has no fetch, so external links were not checked. Use Node.js 22 or newer.');
    return;
  }
  const queue = [...externalLinks.entries()].filter(([url]) => !/fonts\.(googleapis|gstatic)\.com/.test(url));
  async function one([url, where]) {
    const attempt = async (method) => {
      const response = await fetch(url, {
        method, redirect: 'follow', signal: AbortSignal.timeout(15000),
        headers: { 'User-Agent': 'link-check' },
      });
      return response.status;
    };
    try {
      let status = await attempt('HEAD');
      if (status >= 400) status = await attempt('GET');
      if (status >= 400) report('WARN', 'links', where.file, where.line, `External link answered ${status}: ${url}`);
    } catch (error) {
      report('WARN', 'links', where.file, where.line, `External link could not be reached (${error.name}): ${url}`);
    }
  }
  const workers = Array.from({ length: 6 }, async () => {
    while (queue.length) await one(queue.shift());
  });
  await Promise.all(workers);
}

// ── Output ───────────────────────────────────────────────────

(async () => {
  if (checkExternalLinks) await checkExternal();

  const fails = findings.filter((f) => f.level === 'FAIL');
  const warns = findings.filter((f) => f.level === 'WARN');

  if (asJson) {
    console.log(JSON.stringify({ workspace, pages: pages.length, audience, fails: fails.length, warns: warns.length, findings }, null, 2));
  } else {
    const external = checkExternalLinks ? `${externalLinks.size} external links fetched` : `${externalLinks.size} external links not fetched (add --external)`;
    console.log(`Checked ${pages.length} pages in ${workspace}`);
    console.log(`Audience: ${audience} · ${concepts.length} terms in the concept order table · ${external}\n`);
    const PER_RULE = 12;
    const byRule = {};
    for (const f of findings) (byRule[f.rule] = byRule[f.rule] || []).push(f);
    for (const [rule, list] of Object.entries(byRule)) {
      for (const f of list.slice(0, PER_RULE)) {
        console.log(`  ${f.level}  ${rule.padEnd(13)} ${f.file || '.'}:${f.line}\n        ${f.message}`);
      }
      if (list.length > PER_RULE) console.log(`        … and ${list.length - PER_RULE} more ${rule} findings (use --json for all)`);
    }
    console.log(`\n${fails.length} failed, ${warns.length} warning(s)`);
    if (fails.length) console.log('Fix every FAIL and run this again. Read each WARN and fix it or accept it on purpose.');
  }
  // Set the exit code instead of exiting, so piped output is never cut short.
  process.exitCode = fails.length ? 1 : 0;
})();
