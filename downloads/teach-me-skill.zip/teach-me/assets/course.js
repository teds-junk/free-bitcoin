/* The one place lesson titles, files and wins are listed. lesson.js renders
   it into every page's course map, so a title is typed once.

   Fill this in from COURSE-PLAN.md, one entry per lesson, in teaching order.
   - win:   what the learner can do after the lesson, as the plan states it.
   - part:  optional label. Consecutive lessons with the same label are grouped.
   - video: path to a whole-course video, relative to the workspace root, for
            example 'videos/course/my-course.mp4'. Leave empty when there is none. */
window.COURSE = {
  title: '{{COURSE_TITLE}}',
  video: '',
  lessons: [
    { n: 1, file: '0001-{{LESSON_SLUG}}.html', title: '{{LESSON_TITLE}}', win: '{{LESSON_WIN}}', part: '' }
  ],
  // Leave this empty until the reference sheets exist (step 6), then add one
  // entry per sheet: { file: 'workflow-guide.html', title: 'Workflow guide' }
  references: []
};
