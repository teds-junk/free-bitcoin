---
name: teach-me
description: >-
  Runs a multi-session course on a topic the user wants to learn. Builds and
  maintains a course workspace (mission, resources, a course plan, HTML
  lessons, reference sheets, a workflow guide, a glossary and learning
  records), verifies every hands-on step by running it, then teaches one
  lesson per session and adapts what is ahead. Use when the user starts it by
  name to begin, continue or revise a course: each run reads the workspace and
  resumes at the first unfinished step. Not for one-off
  explanations or quick questions (answer directly), book summaries (use
  `bookworm`), or lesson videos (use `video-lesson`).
compatibility: >-
  The check scripts need Node.js 22 or newer. The layout check also needs an
  installed Chrome, Chromium, Edge or Brave, and prints a manual checklist
  when there is none.
disable-model-invocation: true
argument-hint: "What would you like to learn about?"
---

# Teach Me

This skill is a program the user starts by name, not advice to draw on. It turns "I want to learn X" into a course the user can finish: a sequence of short lessons that reads as one journey, where every lesson ends in something the learner can now do, every command has been run, and the reference sheets are worth returning to months later. Its state lives in the current directory, the **course workspace**, so any run can pick up where the last one stopped.

Paths in this skill are relative to the directory that contains this SKILL.md, written `<skill-dir>` in commands. Paths starting with `./` are in the course workspace.

## Start every run here

1. Read `./MISSION.md`, `./COURSE-PLAN.md`, `./NOTES.md` and the file names in `./lessons/` and `./learning-records/`, whichever exist.
2. If the user asked for something specific in this run (a review session, a change to one lesson, the workflow guide, a new topic), do that, using the workflow step it belongs to.
3. Otherwise find the first row below that matches. Before resuming there, check that the "Done when" of each earlier step still holds, and resume at the first one that does not: a file existing is not the same as its step being finished.

| The workspace has | Resume at |
|---|---|
| No `MISSION.md`, or one with unfilled sections | Step 1 |
| A mission, but no `RESOURCES.md` | Step 2 |
| No `COURSE-PLAN.md`, or its `Status:` is `draft` | Step 3 |
| Plan `Status: agreed`, but no `./assets/styles.css` | Step 4 |
| Fewer lesson files than the plan lists | Step 5 |
| Every lesson written, plan `Status: authored` | Step 6 |
| Plan `Status: built` | Step 7 |
| Plan `Status: verified` | Step 8 |
| Lessons but no `COURSE-PLAN.md` (a course from before the plan existed) | Ask the user: keep teaching it as it is (step 8), or bring it up to this format first (step 3, planning from the existing lessons) |

The `Status:` line in `COURSE-PLAN.md` is how the program remembers where it is. Update it at the end of each step, as the steps say.

## Workflow

Steps 1 and 3 end by waiting for the user. Do not write lessons before the plan is agreed: a lesson cut from a list costs nothing, and a lesson cut after it is written wastes the user's time and yours.

1. **Establish the mission.** Ask why the user wants to learn this and what they want to be able to do, pushing for concrete outcomes. Ask who the course is for: just them, or something they could share. Write `./MISSION.md` using [MISSION-FORMAT.md](MISSION-FORMAT.md), including a subject map of facts, concepts and procedures.
   Done when: the user has confirmed the mission, and `MISSION.md` has no unfilled section and states the audience.

2. **Find resources.** Search for high-trust sources (primary documentation, recognised experts, books, communities) and write `./RESOURCES.md` using [RESOURCES-FORMAT.md](RESOURCES-FORMAT.md). Lessons are built from these sources, not from what you remember: your memory of a topic is often out of date or subtly wrong, and the learner cannot tell.
   Done when: every item in the mission's subject map has at least one source, or is listed under `## Gaps`.

3. **Plan the course.** Read [COURSE-PLANNING.md](COURSE-PLANNING.md) and write `./COURSE-PLAN.md` with `Status: draft`: the course story, each lesson's question, win and hand-off, each section's mode, the concept order table, and every term the course will use with its origin. Show the user the plan and ask them to cut, add or reorder lessons and to accept or rename any term you coined. If the course has hands-on work, also read "Where practice happens" in [HANDS-ON-PRACTICE.md](HANDS-ON-PRACTICE.md) before choosing the running example, because it decides where the example lives.
   Done when: the user has agreed the sequence and the coined terms, and the plan says `Status: agreed`.

4. **Set up the workspace.** If `./assets/styles.css` does not exist, copy every file from `<skill-dir>/assets/` into `./assets/` (`cp -R <skill-dir>/assets/. ./assets/`) and create `./assets/images/`. Fill in the lessons in `./assets/course.js` from the plan; its reference list stays empty until step 6. Do not create `./practice/`: the first checkpoint has the learner create it. In a workspace that already has assets, leave them alone and add only files that are missing.
   Done when: `./assets/course.js` lists every lesson in the plan and contains no `{{`.

5. **Author every lesson.** Read [LESSON-WRITING.md](LESSON-WRITING.md), [HANDS-ON-PRACTICE.md](HANDS-ON-PRACTICE.md) and [LESSON-STYLE.md](LESSON-STYLE.md). Write each lesson from `./assets/lesson-template.html` into `./lessons/`, in order, following the plan section by section. Run each hands-on step as you write it, so that the commands and output on the page come from a real run. If writing shows the plan is wrong, change the plan first, then the lesson.
   Done when: every lesson in the plan exists as a file, and the plan says `Status: authored`.

6. **Build the reference sheets and the course home.** Read [REFERENCE-DOCS.md](REFERENCE-DOCS.md). Write the reference sheets into `./reference/`, the workflow guide if the course teaches a repeatable procedure, and `./index.html` from `./assets/course-home-template.html`. List each reference sheet in `./assets/course.js`.
   Done when: `./index.html` exists, every sheet is listed in `course.js`, and the plan says `Status: built`.

7. **Verify the whole course.** Do all four, in this order. After a fix that changes a page, run checks 3 and 4 again every time, since they are quick. Run check 1 again for a lesson whose commands or output changed, and check 2 again for a lesson whose explanations you rewrote.
   1. Run every hands-on step from a clean start, as "Verify by running" in [HANDS-ON-PRACTICE.md](HANDS-ON-PRACTICE.md) describes.
   2. Do the cold read described in [LESSON-WRITING.md](LESSON-WRITING.md) and fix what it finds.
   3. Validate all links and the other rules a program can check: `node <skill-dir>/scripts/check-lessons.js .` Fix every `FAIL` and run it again until there are none. Read each `WARN` and fix it or accept it on purpose.
   4. Check the layout: `node <skill-dir>/scripts/check-layout.js . --screenshots <a scratch directory>` Fix what it reports, then look at the screenshots yourself.
   If `node` is not installed, tell the user, then do checks 3 and 4 by hand: open every page, follow every link on it, and go through the rules listed under Gotchas.
   Done when: `check-lessons.js` and `check-layout.js` both exit 0, `./NOTES.md` records what was run and anything that could not be, and the plan says `Status: verified`. Then tell the user the course is ready, how many lessons it has, and what you could not verify. Open `./index.html` for them if you can.

8. **Teach the next lesson.** One lesson per session. First read `./learning-records/` to check the lesson still fits what the user can do, and look for concepts shown several sessions ago and not exercised since. Open the lesson for the user, let them work through it, answer questions, and weave in recall prompts for anything due for review. When they do the checkpoint, look at what happened and give feedback.
   Done when: the user has done the lesson's checkpoint or exercises, or has said they are stopping.

9. **Write learning records.** When the user has shown they understand something, disclosed prior knowledge, or corrected a misconception, record it in `./learning-records/` using [LEARNING-RECORD-FORMAT.md](LEARNING-RECORD-FORMAT.md). Add terms they can now use correctly to `./GLOSSARY.md` using [GLOSSARY-FORMAT.md](GLOSSARY-FORMAT.md).
   Done when: each thing demonstrated this session has a record, or you have decided it does not qualify.

10. **Revise what is ahead.** When a learning record shows the plan is wrong (too fast, too slow, a missing prerequisite, a shifted mission), update `./COURSE-PLAN.md`, rewrite the affected upcoming lessons, and repeat step 7 for the pages you changed. Tell the user what changed and why. Lessons already taught stay as they were taught: they are the record of what the user did.
    Done when: the plan and the upcoming lessons agree. Continue from step 8 next session.

Stop and ask the user when: the mission is unclear after two rounds of questions; a hands-on step costs money, needs their credentials, or changes something outside the workspace; a source, or what you observe when you run something, contradicts another source or the mission and the choice changes what a lesson teaches; the mission's lesson count or time cannot hold what it asks for; or you want to introduce a name the plan does not list.

If the user has said to carry on without them, or cannot be reached, do not decide silently. Take the choice that is easiest to undo: teach what you verified by running it, leave `MISSION.md` as it is, and use a plain description instead of a coined name. Record each open decision in `./NOTES.md` under `## Decisions waiting for the user`, and list them in your message when you finish.

## Teaching principles

These shape the plan and every session. [COURSE-PLANNING.md](COURSE-PLANNING.md) turns them into planning rules.

- **Knowledge, skills, wisdom.** Knowledge comes from high-trust sources. Skills come from practice with feedback. Wisdom comes from using the skill among other practitioners, so find the user a community and point them to it when a question needs judgement you cannot supply. If they do not want one, respect that and record it in `RESOURCES.md`.
- **Working memory is small.** A lesson is short, teaches one tightly scoped thing, and ends in one tangible win. When presenting something new, make it as easy to take in as you can.
- **Storage strength, not fluency.** Feeling fluent in the moment is not retention. Build retention with effortful recall after each presentation, spacing (earlier material returns in later lessons), and interleaving (mixing related topics in practice). Difficulty belongs in retrieval, not in the explanation.
- **Zone of proximal development.** Each lesson should stretch the user just past what they can already do. Judge that from the learning records, and from concepts they got right but found effortful: drilling the weakest link often helps more than new material.
- **Practice early.** Do not hold real practice back until the theory is finished. Knowledge learned out of context rarely transfers.
- **Tight feedback loops.** Every exercise gives feedback at once, automatically where possible.

## The course workspace

| Path | What it is |
|---|---|
| `MISSION.md` | Why the user is learning this, what success looks like, who the course is for. Grounds every decision |
| `RESOURCES.md` | The trusted sources lessons are built from, and the communities |
| `COURSE-PLAN.md` | The story, the lessons, the concept order and the vocabulary. The program's state |
| `lessons/0001-<dash-case-name>.html` | One self-contained lesson per file, numbered in teaching order |
| `reference/*.html` | Reference sheets and the workflow guide: the compressed, durable part of the course |
| `index.html` | The course home |
| `assets/` | Shared stylesheet, script, `course.js`, page templates, `images/`, and any component a second lesson could reuse |
| `practice/` | Where the learner does hands-on work, when the course has any |
| `GLOSSARY.md` | Terms the user has shown they understand |
| `learning-records/0001-<dash-case-name>.md` | What the user has learned, disclosed or corrected |
| `NOTES.md` | The user's preferences, the verification log, and your working notes |

## Gotchas

Each of these happened in a real course.

- **Lessons that do not add up to a journey.** Lessons were written from a list of titles, and the reader could not tell whether a passage was explaining how something works, how to think about it, or how to use it. Write the plan first, give every section one mode, and write from the plan.
- **A concept used before it was explained.** A lesson's checkpoint leaned on a tool and a term ("golden patch") that the lesson had only named, and the learner stopped there. Keep the plan's concept order table true, and before each checkpoint make sure the reader could say what every command does and why.
- **Commands that had never been run.** A course shipped with model names that did not exist on the learner's account, a filter that printed nothing, and "check this yourself" notes that one run would have settled. Run every command and show its real output.
- **A course tied to one person's machine.** Examples that lean on the user's private repositories, local paths or pinned versions cannot be shared. Unless the mission says the course is only for them, have the course create its own examples.
- **A coined term presented as standard vocabulary.** If you named it, say so, and get the user's agreement before it appears in a lesson or the glossary.
- **Clever shell.** Shell variables, command substitution and long pipelines make the reader decode the shell instead of learning the topic. Use plain commands with literal paths, one idea per command.
- **Querying a file the reader has never seen.** Extracting facts with a filter assumes the reader knows the file's shape. Show an annotated excerpt first.
- **"The author" on every page.** Lessons said "in the author's run" and "the author's tally" dozens of times. People write "in our run" and "ours". Write as "we", and address the reader as "you".
- **Gap markers that hide one line.** An excerpt of a results record had six "1 field hidden" markers. Each took the same line it saved, and together they were more distracting than the fields. Hide runs of three or more lines; show one or two as they are.
- **Emphasis on every title.** A word italicised in every heading means nothing. Headings are plain.
- **Code that scrolls sideways.** Side-by-side code and notes did not fit the page. Stack the notes under the code, keep code lines to 62 characters (52 inside a checkpoint step), and run the layout check.
- **Not knowing where to type.** When a lesson uses a program with its own prompt, readers type its commands into the shell and the reverse. Label every command block with where it is typed.
- **Broken local links.** Lessons link to each other, to reference sheets and to images, and renames break them silently. `check-lessons.js` validates every link; run it after any change to a page.
- **Numbers written by hand.** The stylesheet numbers sections, figures, definitions, examples and exercises. Writing "Figure 1" in the content doubles them.
- **Hotlinked images.** Images from the web are downloaded to `./assets/images/` and referenced by relative path, so the course works offline and does not rot.

## Files

| File | Read when |
|---|---|
| [MISSION-FORMAT.md](MISSION-FORMAT.md) | Step 1, or when the mission changes |
| [RESOURCES-FORMAT.md](RESOURCES-FORMAT.md) | Step 2 |
| [COURSE-PLANNING.md](COURSE-PLANNING.md) | Step 3, and step 10 when the plan changes |
| [LESSON-WRITING.md](LESSON-WRITING.md) | Step 5, and the cold read in step 7 |
| [HANDS-ON-PRACTICE.md](HANDS-ON-PRACTICE.md) | Step 5 if any lesson has the learner run or do something, and step 7 |
| [LESSON-STYLE.md](LESSON-STYLE.md) | Step 5, before writing the first page, and when fixing a layout finding |
| [REFERENCE-DOCS.md](REFERENCE-DOCS.md) | Step 6 |
| [LEARNING-RECORD-FORMAT.md](LEARNING-RECORD-FORMAT.md) | Step 9 |
| [GLOSSARY-FORMAT.md](GLOSSARY-FORMAT.md) | Step 3 for coined terms, and step 9 |

| Script | What it does |
|---|---|
| `scripts/check-lessons.js` | Run it. Validates every local link and anchor, and checks section modes, concept order, plain commands, code line length, heading emphasis, private paths, leftover placeholders and page structure. `--external` also fetches web links |
| `scripts/check-layout.js` | Run it. Opens each page in a headless browser at desktop and phone width and reports anything that scrolls sideways. Prints a manual checklist when no browser is installed |

| Asset | What it is |
|---|---|
| `assets/styles.css`, `assets/lesson.js` | The shared stylesheet and page script. Copy them; do not retype or restyle them |
| `assets/course.js` | The lesson list every course map is rendered from |
| `assets/lesson-template.html` | Start every lesson from this |
| `assets/course-home-template.html` | Start `index.html` from this |
| `assets/workflow-guide-template.html` | Start the workflow guide from this |

## Out of scope

- A one-off "explain X" or "what is Y": answer directly, with no workspace.
- Summarising a book: use the skill named `bookworm` if it is installed.
- Making a video of a lesson: use the skill named `video-lesson` if it is installed. Lesson pages already have a slot that shows the video once it exists at `./videos/<lesson-file-stem>/<lesson-file-stem>.mp4`.
